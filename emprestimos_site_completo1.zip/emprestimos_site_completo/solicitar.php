<?php
session_start();
require_once 'config/conexao.php';

$mensagem = "";

// Verifica se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cpf = trim($_POST['cpf']);
    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    $telefone = trim($_POST['telefone']);
    $valor = floatval($_POST['valor']);
    $parcelas = intval($_POST['parcelas']);

    if (!empty($cpf) && !empty($nome) && !empty($email) && !empty($telefone) && $valor > 0 && $parcelas > 0) {
        try {
            $stmt = $conn->prepare("INSERT INTO solicitacoes (cpf, nome, email, telefone, valor, parcelas, status) VALUES (?, ?, ?, ?, ?, ?, 'Pendente')");
            $stmt->execute([$cpf, $nome, $email, $telefone, $valor, $parcelas]);

            $mensagem = "Solicitação enviada com sucesso! Entraremos em contato.";
        } catch (PDOException $e) {
            $mensagem = "Erro ao enviar solicitação: " . $e->getMessage();
        }
    } else {
        $mensagem = "Por favor, preencha todos os campos corretamente.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Solicitar Empréstimo</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header>
        <h1>Solicitar Empréstimo</h1>
        <nav>
            <ul>
                <li><a href="index.php">Início</a></li>
                <li><a href="simulador.php">Simulador</a></li>
                <li><a href="depoimentos.php">Depoimentos</a></li>
                <li><a href="contato.php">Contato</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section id="solicitacao">
            <h2>Preencha seus dados para solicitar o empréstimo</h2>

            <?php if ($mensagem): ?>
                <p class="mensagem"><?= htmlspecialchars($mensagem) ?></p>
            <?php endif; ?>

            <form action="solicitar.php" method="POST">
                <label for="cpf">CPF:</label>
                <input type="text" name="cpf" id="cpf" required>

                <label for="nome">Nome Completo:</label>
                <input type="text" name="nome" id="nome" required>

                <label for="email">E-mail:</label>
                <input type="email" name="email" id="email" required>

                <label for="telefone">Telefone:</label>
                <input type="tel" name="telefone" id="telefone" required>

                <label for="valor">Valor desejado:</label>
                <input type="number" name="valor" id="valor" required>

                <label for="parcelas">Número de parcelas:</label>
                <select name="parcelas" id="parcelas">
                    <option value="12">12x</option>
                    <option value="24">24x</option>
                    <option value="36">36x</option>
                </select>

                <button type="submit">Enviar Solicitação</button>
            </form>
        </section>
    </main>

    <footer>
        <p>&copy; 2025 Empréstimos Consignados</p>
    </footer>
</body>
</html>