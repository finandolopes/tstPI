<?php
// Configuração inicial e conexão com o banco de dados
require_once 'config/conexao.php';

// Definir taxa de juros fixa (ou você pode calcular dinamicamente dependendo de fatores)
$taxa_juros = 0.02;  // Exemplo: 2% ao mês

// Função para calcular o valor da parcela
function calcularParcela($valor, $parcelas, $taxa_juros) {
    // Fórmula para calcular a parcela (Sistema de Amortização Francês)
    $juros_mes = $taxa_juros / 100;
    $parcela = $valor * ($juros_mes * pow(1 + $juros_mes, $parcelas)) / (pow(1 + $juros_mes, $parcelas) - 1);
    return round($parcela, 2);
}

// Verifica se o formulário foi submetido
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $valor_emprestimo = $_POST['valor'];
    $numero_parcelas = $_POST['parcelas'];

    // Calcular a parcela
    $valor_parcela = calcularParcela($valor_emprestimo, $numero_parcelas, $taxa_juros);

    // Calcular o valor total do empréstimo
    $valor_total = $valor_parcelas * $numero_parcelas;
}

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Simulador de Empréstimo Consignado</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/responsivo.css">
</head>
<body>
    <header>
        <div class="logo">
            <h1>Empréstimo Consignado</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Início</a></li>
                <li><a href="#simulador">Simulador</a></li>
                <li><a href="#depoimentos">Depoimentos</a></li>
                <li><a href="#faq">FAQ</a></li>
                <li><a href="#contato">Contato</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section id="simulador">
            <h2>Simule seu Empréstimo</h2>
            <form action="simulador.php" method="POST">
                <div class="form-group">
                    <label for="valor">Valor do Empréstimo</label>
                    <input type="number" id="valor" name="valor" placeholder="R$" required>
                </div>
                <div class="form-group">
                    <label for="parcelas">Número de Parcelas</label>
                    <input type="number" id="parcelas" name="parcelas" placeholder="Ex: 12" required>
                </div>
                <button type="submit">Simular</button>
            </form>

            <?php if ($_SERVER['REQUEST_METHOD'] === 'POST'): ?>
                <div class="resultado">
                    <h3>Resultado da Simulação:</h3>
                    <p><strong>Valor Total do Empréstimo:</strong> R$ <?= number_format($valor_total, 2, ',', '.') ?></p>
                    <p><strong>Valor da Parcela:</strong> R$ <?= number_format($valor_parcela, 2, ',', '.') ?></p>
                    <p><strong>Total de Juros:</strong> R$ <?= number_format($valor_total - $valor_emprestimo, 2, ',', '.') ?></p>
                </div>
            <?php endif; ?>
        </section>
    </main>

    <footer>
        <p>&copy; 2025 Empréstimo Consignado | Todos os direitos reservados.</p>
    </footer>

    <script src="assets/js/main.js"></script>
</body>
</html>