<?php
session_start();

// Função para gerar o CAPTCHA
function gerarCaptcha() {
    $caracteres = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    $captcha = '';
    for ($i = 0; $i < 6; $i++) {
        $captcha .= $caracteres[rand(0, strlen($caracteres) - 1)];
    }
    $_SESSION['captcha'] = $captcha;  // Armazena o CAPTCHA na sessão
    return $captcha;
}

$captcha = gerarCaptcha();  // Gera o CAPTCHA

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    if ($_POST['captcha'] === $_SESSION['captcha']) {
        // Verifica as credenciais do usuário
        $email = $_POST['email'];
        $senha = $_POST['senha'];
        
        // (Lógica de autenticação existente...)
    } else {
        echo "Captcha inválido.";
    }
}
?>

<form method="POST">
    <label for="email">E-mail:</label>
    <input type="email" name="email" required>
    
    <label for="senha">Senha:</label>
    <input type="password" name="senha" required>
    
    <label for="captcha">Digite o código de verificação:</label>
    <input type="text" name="captcha" required>
    
    <img src="gerar_captcha.php" alt="Captcha" />
    
    <button type="submit">Entrar</button>
</form>