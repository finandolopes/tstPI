<?php
require_once '../config/conexao.php';
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Aprovar Depoimento
if (isset($_GET['aprovar'])) {
    $id = $_GET['aprovar'];
    $conn->query("UPDATE depoimentos SET aprovado = 1 WHERE id = $id");
    header("Location: depoimentos.php");
}

// Rejeitar Depoimento
if (isset($_GET['rejeitar'])) {
    $id = $_GET['rejeitar'];
    $conn->query("DELETE FROM depoimentos WHERE id = $id");
    header("Location: depoimentos.php");
}

$depoimentos = $conn->query("SELECT * FROM depoimentos WHERE aprovado = 0 ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<main>
    <h2>Moderação de Depoimentos</h2>
    
    <table>
        <thead>
            <tr>
                <th>Nome</th>
                <th>Depoimento</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($depoimentos as $dep): ?>
                <tr>
                    <td><?php echo $dep['nome']; ?></td>
                    <td><?php echo $dep['mensagem']; ?></td>
                    <td>
                        <a href="depoimentos.php?aprovar=<?= $dep['id'] ?>">✅ Aprovar</a> | 
                        <a href="depoimentos.php?rejeitar=<?= $dep['id'] ?>">❌ Rejeitar</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</main>