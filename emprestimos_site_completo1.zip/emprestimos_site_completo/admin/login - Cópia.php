<?php
session_start();
include '../config/conexao.php';

// Verifica se o usuário já está logado
if (isset($_SESSION['usuario'])) {
    header("Location: index.php");
    exit;
}

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $usuario = $_POST['usuario'];
    $senha = $_POST['senha'];
    
    // Verifica as credenciais do usuário
    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE usuario = :usuario");
    $stmt->bindParam(':usuario', $usuario);
    $stmt->execute();
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($usuario && password_verify($senha, $usuario['senha'])) {
        // Cria a sessão com as informações do usuário
        $_SESSION['usuario'] = $usuario['usuario'];
        $_SESSION['role'] = $usuario['role']; // Salva o papel (admin, moderador, etc)
        
        header("Location: index.php");
        exit;
    } else {
        $erro = "Usuário ou senha inválidos!";
    }
}
?>

<!-- Formulário de login -->
<form method="POST">
    <label for="usuario">Usuário:</label>
    <input type="text" name="usuario" id="usuario" required>
    
    <label for="senha">Senha:</label>
    <input type="password" name="senha" id="senha" required>
    
    <button type="submit">Login</button>
</form>