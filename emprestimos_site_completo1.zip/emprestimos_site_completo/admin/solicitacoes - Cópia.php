<?php
require_once '../config/conexao.php';
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$solicitacoes = $conn->query("SELECT * FROM emprestimos ORDER BY criado_em DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Solicitações de Empréstimo</h2>
<table>
    <tr><th>Cliente</th><th>Valor</th><th>Parcelas</th><th>Status</th><th>Ações</th></tr>
    <?php foreach ($solicitacoes as $solicitacao): ?>
        <tr>
            <td><?php echo $solicitacao['usuario_id']; ?></td>
            <td><?php echo $solicitacao['valor']; ?></td>
            <td><?php echo $solicitacao['parcelas']; ?></td>
            <td><?php echo $solicitacao['status']; ?></td>
            <td>
                <a href="aprovar_emprestimo.php?id=<?php echo $solicitacao['id']; ?>">Aprovar</a>
                <a href="recusar_emprestimo.php?id=<?php echo $solicitacao['id']; ?>">Recusar</a>
            </td>
        </tr>
    <?php endforeach; ?>
</table>