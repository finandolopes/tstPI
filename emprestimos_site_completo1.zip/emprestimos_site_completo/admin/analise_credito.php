<?php
require_once '../config/conexao.php';

// Verifica se o usuário tem permissão de administrador
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Buscar requisições de análise de crédito
$query_analise = "SELECT * FROM analises_credito ORDER BY data_solicitacao DESC";
$analises = $conn->query($query_analise)->fetchAll(PDO::FETCH_ASSOC);

// Aprovar análise de crédito
if (isset($_GET['aprovar'])) {
    $id = $_GET['aprovar'];
    $update_query = "UPDATE analises_credito SET status = 'Aprovado' WHERE id = :id";
    $stmt = $conn->prepare($update_query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    header('Location: analise_credito.php');
}

// Rejeitar análise de crédito
if (isset($_GET['rejeitar'])) {
    $id = $_GET['rejeitar'];
    $update_query = "UPDATE analises_credito SET status = 'Rejeitado' WHERE id = :id";
    $stmt = $conn->prepare($update_query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    header('Location: analise_credito.php');
}

// Excluir análise de crédito
if (isset($_GET['excluir'])) {
    $id = $_GET['excluir'];
    $delete_query = "DELETE FROM analises_credito WHERE id = :id";
    $stmt = $conn->prepare($delete_query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    header('Location: analise_credito.php');
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Análise de Crédito</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header>
        <div class="logo">
            <h1>Painel Administrativo</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Dashboard</a></li>
                <li><a href="depoimentos.php">Depoimentos</a></li>
                <li><a href="contato.php">Mensagens</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="analise_credito.php">Análise de Crédito</a></li>
                <li><a href="usuarios.php">Usuários</a></li>
                <li><a href="relatorios.php">Relatórios</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Requisições de Análise de Crédito</h2>
        <table>
            <thead>
                <tr>
                    <th>Nome do Solicitante</th>
                    <th>Valor Solicitado</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($analises as $analise): ?>
                    <tr>
                        <td><?= htmlspecialchars($analise['nome']) ?></td>
                        <td>R$ <?= number_format($analise['valor_solicitado'], 2, ',', '.') ?></td>
                        <td><?= htmlspecialchars($analise['status']) ?></td>
                        <td>
                            <?php if ($analise['status'] == 'Pendente'): ?>
                                <a href="?aprovar=<?= $analise['id'] ?>">Aprovar</a> | 
                                <a href="?rejeitar=<?= $analise['id'] ?>">Rejeitar</a>
                            <?php endif; ?>
                            <a href="?excluir=<?= $analise['id'] ?>">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </main>
</body>
</html>