<?php
require_once '../config/conexao.php';
session_start();

if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$logs = $conn->query("SELECT * FROM logs ORDER BY data DESC")->fetchAll(PDO::FETCH_ASSOC);

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<main>
    <h2>Logs de Auditoria</h2>
    <table>
        <thead>
            <tr>
                <th>Usuário</th>
                <th>Ação</th>
                <th>Data</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($logs as $log): ?>
                <tr>
                    <td><?php echo $log['usuario']; ?></td>
                    <td><?php echo $log['acao']; ?></td>
                    <td><?php echo $log['data']; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</main>