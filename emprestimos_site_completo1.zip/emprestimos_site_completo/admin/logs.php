<?php
require_once '../config/conexao.php';
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$logs = $conn->query("SELECT * FROM logs ORDER BY data DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Logs do Sistema</h2>
<table>
    <tr><th>Usuário</th><th>Ação</th><th>Data</th></tr>
    <?php foreach ($logs as $log): ?>
        <tr>
            <td><?php echo $log['usuario']; ?></td>
            <td><?php echo $log['acao']; ?></td>
            <td><?php echo $log['data']; ?></td>
        </tr>
    <?php endforeach; ?>
</table>