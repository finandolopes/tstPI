<?php
require_once '../config/conexao.php';
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

if (isset($_POST['agendar'])) {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $data = $_POST['data_retorno'];

    $stmt = $conn->prepare("INSERT INTO agendamentos (nome, email, data_retorno) VALUES (?, ?, ?)");
    $stmt->execute([$nome, $email, $data]);

    header('Location: agendamentos.php');
}

$agendamentos = $conn->query("SELECT * FROM agendamentos ORDER BY data_retorno ASC")->fetchAll(PDO::FETCH_ASSOC);
include 'includes/header.php';
include 'includes/sidebar.php';
?>

<main>
    <h2>Agendamentos de Retorno</h2>
    <form method="POST">
        <label>Nome:</label>
        <input type="text" name="nome" required>
        <label>Email:</label>
        <input type="email" name="email" required>
        <label>Data de Retorno:</label>
        <input type="date" name="data_retorno" required>
        <button type="submit" name="agendar">Agendar</button>
    </form>

    <h3>Agendamentos Pendentes</h3>
    <table>
        <thead>
            <tr>
                <th>Nome</th>
                <th>Email</th>
                <th>Data de Retorno</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($agendamentos as $agendamento): ?>
                <tr>
                    <td><?= htmlspecialchars($agendamento['nome']) ?></td>
                    <td><?= htmlspecialchars($agendamento['email']) ?></td>
                    <td><?= date('d/m/Y', strtotime($agendamento['data_retorno'])) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</main>