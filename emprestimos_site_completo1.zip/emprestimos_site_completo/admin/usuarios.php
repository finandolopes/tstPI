<?php
require_once '../config/conexao.php';

// Verifica se o usuário tem permissão de administrador
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Buscar todos os usuários cadastrados
$query_usuarios = "SELECT * FROM usuarios";
$usuarios = $conn->query($query_usuarios)->fetchAll(PDO::FETCH_ASSOC);

// Adicionar novo usuário
if (isset($_POST['add_usuario'])) {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
    $role = $_POST['role'];

    $insert_query = "INSERT INTO usuarios (nome, email, senha, role) VALUES (:nome, :email, :senha, :role)";
    $stmt = $conn->prepare($insert_query);
    $stmt->bindParam(':nome', $nome);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':senha', $senha);
    $stmt->bindParam(':role', $role);
    $stmt->execute();

    header('Location: usuarios.php');
}

// Excluir usuário
if (isset($_GET['excluir'])) {
    $id = $_GET['excluir'];
    $delete_query = "DELETE FROM usuarios WHERE id = :id";
    $stmt = $conn->prepare($delete_query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    header('Location: usuarios.php');
}

// Editar usuário
if (isset($_GET['editar'])) {
    $id = $_GET['editar'];
    $user_query = "SELECT * FROM usuarios WHERE id = :id";
    $stmt = $conn->prepare($user_query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $user = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Usuários</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header>
        <div class="logo">
            <h1>Painel Administrativo</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Dashboard</a></li>
                <li><a href="depoimentos.php">Depoimentos</a></li>
                <li><a href="contato.php">Mensagens</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="analise_credito.php">Análise de Crédito</a></li>
                <li><a href="usuarios.php">Usuários</a></li>
                <li><a href="relatorios.php">Relatórios</a></li>
                <li><a href="configuracoes.php">Configurações</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Gestão de Usuários</h2>
        
        <!-- Formulário de Adição de Novo Usuário -->
        <section class="form-add-user">
            <h3>Adicionar Novo Usuário</h3>
            <form method="POST" action="usuarios.php">
                <label for="nome">Nome:</label>
                <input type="text" id="nome" name="nome" required>
                <label for="email">E-mail:</label>
                <input type="email" id="email" name="email" required>
                <label for="senha">Senha:</label>
                <input type="password" id="senha" name="senha" required>
                <label for="role">Permissão:</label>
                <select name="role" id="role" required>
                    <option value="admin">Administrador</option>
                    <option value="user">Usuário</option>
                </select>
                <button type="submit" name="add_usuario">Adicionar Usuário</button>
            </form>
        </section>

        <!-- Listagem de Usuários -->
        <section class="user-list">
            <h3>Usuários Cadastrados</h3>
            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Email</th>
                        <th>Permissão</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($usuarios as $usuario): ?>
                        <tr>
                            <td><?php echo $usuario['id']; ?></td>
                            <td><?php echo $usuario['nome']; ?></td>
                            <td><?php echo $usuario['email']; ?></td>
                            <td><?php echo $usuario['role']; ?></td>
                            <td>
                                <a href="usuarios.php?editar=<?php echo $usuario['id']; ?>">Editar</a> | 
                                <a href="usuarios.php?excluir=<?php echo $usuario['id']; ?>">Excluir</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    </main>
</body>
</html>