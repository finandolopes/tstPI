<?php
// Arquivo para verificação da autenticação de 2 fatores
session_start();

// Supondo que o código seja enviado para o email do usuário, vamos pedir para ele digitar o código
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Verifique o código enviado pelo usuário
    $codigo_digitado = $_POST['codigo'];
    $codigo_gerado = $_SESSION['codigo_2fa']; // Código gerado anteriormente

    if ($codigo_digitado == $codigo_gerado) {
        // Código correto, pode liberar o acesso
        header("Location: dashboard.php");
        exit;
    } else {
        echo "Código inválido!";
    }
}

// Gerar um código aleatório e enviá-lo para o email do usuário
$_SESSION['codigo_2fa'] = rand(100000, 999999);
?>

<form method="POST">
    <label for="codigo">Digite o código enviado para seu e-mail:</label>
    <input type="text" name="codigo" required>
    <button type="submit">Verificar</button>
</form>