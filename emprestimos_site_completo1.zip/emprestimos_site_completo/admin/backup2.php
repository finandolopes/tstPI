<?php
require_once '../config/conexao.php';
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Função para fazer backup do banco de dados
function fazerBackup() {
    $nome_arquivo = 'backup_' . date('Y-m-d_H-i-s') . '.sql';
    $comando = "mysqldump -u {db_user} -p{db_pass} {db_name} > /path_to_backups/$nome_arquivo";
    exec($comando);
    return $nome_arquivo;
}

// Se o botão for pressionado, realiza o backup
if (isset($_POST['backup'])) {
    $backup = fazerBackup();
    echo "Backup realizado com sucesso! Arquivo: $backup";
}
?>

<h2>Backup de Banco de Dados</h2>

<form method="POST">
    <button type="submit" name="backup">Fazer Backup</button>
</form>