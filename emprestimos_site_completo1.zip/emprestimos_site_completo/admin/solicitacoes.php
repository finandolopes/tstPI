<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

require_once '../config/conexao.php';

// Verifica se há algum filtro de busca
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';

// Consulta de solicitações com filtros
$query = "SELECT * FROM solicitacoes WHERE nome LIKE ? AND (status LIKE ?)";
$stmt = $conn->prepare($query);
$stmt->execute(['%' . $search . '%', '%' . $status_filter . '%']);
$solicitacoes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Atualizar status de solicitação
if (isset($_POST['update_status'])) {
    $id = $_POST['id'];
    $status = $_POST['status'];
    $stmt = $conn->prepare("UPDATE solicitacoes SET status = ? WHERE id = ?");
    $stmt->execute([$status, $id]);

    header("Location: solicitacoes.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Solicitações</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <header>
        <h1>Gestão de Solicitações</h1>
        <nav>
            <ul>
                <li><a href="index.php">Início</a></li>
                <li><a href="solicitacoes.php">Solicitações</a></li>
                <li><a href="depoimentos.php">Depoimentos</a></li>
                <li><a href="mensagens.php">Mensagens</a></li>
                <li><a href="banners.php">Banners</a></li>
                <li><a href="logout.php">Sair</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section>
            <h2>Filtrar Solicitações</h2>
            <form action="solicitacoes.php" method="GET">
                <input type="text" name="search" placeholder="Pesquisar por nome..." value="<?= htmlspecialchars($search) ?>">
                <select name="status">
                    <option value="">Todos os Status</option>
                    <option value="Pendente" <?= $status_filter == 'Pendente' ? 'selected' : '' ?>>Pendente</option>
                    <option value="Aprovado" <?= $status_filter == 'Aprovado' ? 'selected' : '' ?>>Aprovado</option>
                    <option value="Rejeitado" <?= $status_filter == 'Rejeitado' ? 'selected' : '' ?>>Rejeitado</option>
                </select>
                <button type="submit">Filtrar</button>
            </form>

            <h2>Solicitações de Empréstimo</h2>

            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Valor</th>
                        <th>Parcelas</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($solicitacoes as $solicitacao): ?>
                        <tr>
                            <td><?= $solicitacao['id'] ?></td>
                            <td><?= htmlspecialchars($solicitacao['nome']) ?></td>
                            <td><?= 'R$ ' . number_format($solicitacao['valor'], 2, ',', '.') ?></td>
                            <td><?= $solicitacao['parcelas'] ?> parcelas</td>
                            <td><?= $solicitacao['status'] ?></td>
                            <td>
                                <form action="solicitacoes.php" method="POST">
                                    <input type="hidden" name="id" value="<?= $solicitacao['id'] ?>">
                                    <select name="status">
                                        <option value="Pendente" <?= $solicitacao['status'] == 'Pendente' ? 'selected' : '' ?>>Pendente</option>
                                        <option value="Aprovado" <?= $solicitacao['status'] == 'Aprovado' ? 'selected' : '' ?>>Aprovado</option>
                                        <option value="Rejeitado" <?= $solicitacao['status'] == 'Rejeitado' ? 'selected' : '' ?>>Rejeitado</option>
                                    </select>
                                    <button type="submit" name="update_status">Atualizar Status</button>
                                </form>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    </main>
</body>
</html>