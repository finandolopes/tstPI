<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

require_once '../config/conexao.php';

// Consultar estatísticas
$query = "SELECT COUNT(*) AS total_acessos FROM acessos";
$total_acessos = $conn->query($query)->fetch(PDO::FETCH_ASSOC)['total_acessos'];

$query = "SELECT COUNT(*) AS total_clientes FROM clientes";
$total_clientes = $conn->query($query)->fetch(PDO::FETCH_ASSOC)['total_clientes'];

$query = "SELECT AVG(tempo_sessao) AS tempo_medio FROM acessos";
$tempo_medio = $conn->query($query)->fetch(PDO::FETCH_ASSOC)['tempo_medio'];

$query = "SELECT COUNT(*) AS total_requisicoes FROM requisicoes";
$total_requisicoes = $conn->query($query)->fetch(PDO::FETCH_ASSOC)['total_requisicoes'];
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estatísticas do Site</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
    <!-- Inclua bibliotecas de gráficos (ex: Chart.js) -->
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <header>
        <h1>Estatísticas do Site</h1>
        <nav>
            <ul>
                <li><a href="index.php">Início</a></li>
                <li><a href="solicitacoes.php">Solicitações</a></li>
                <li><a href="requisicoes.php">Requisições</a></li>
                <li><a href="depoimentos.php">Depoimentos</a></li>
                <li><a href="banners.php">Banners</a></li>
                <li><a href="logout.php">Sair</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section>
            <h2>Visão Geral</h2>
            <div class="estatisticas">
                <div class="stat-item">
                    <h3>Total de Acessos</h3>
                    <p><?= $total_acessos ?></p>
                </div>
                <div class="stat-item">
                    <h3>Total de Clientes</h3>
                    <p><?= $total_clientes ?></p>
                </div>
                <div class="stat-item">
                    <h3>Tempo Médio no Site</h3>
                    <p><?= round($tempo_medio, 2) ?> minutos</p>
                </div>
                <div class="stat-item">
                    <h3>Total de Requisições</h3>
                    <p><?= $total_requisicoes ?></p>
                </div>
            </div>

            <h2>Gráficos de Acesso</h2>
            <canvas id="acessosChart"></canvas>
            <script>
                var ctx = document.getElementById('acessosChart').getContext('2d');
                var acessosChart = new Chart(ctx, {
                    type: 'line',
                    data: {
                        labels: ['Jan', 'Fev', 'Mar', 'Abr', 'Mai', 'Jun'], // Adapte com seus dados reais
                        datasets: [{
                            label: 'Acessos por Mês',
                            data: [12, 19, 3, 5, 2, 3], // Adapte com seus dados reais
                            borderColor: 'rgba(75, 192, 192, 1)',
                            backgroundColor: 'rgba(75, 192, 192, 0.2)',
                            borderWidth: 1
                        }]
                    },
                    options: {
                        scales: {
                            y: {
                                beginAtZero: true
                            }
                        }
                    }
                });
            </script>
        </section>
    </main>
</body>
</html>