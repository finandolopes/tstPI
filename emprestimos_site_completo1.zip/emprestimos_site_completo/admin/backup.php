<?php
$host = 'localhost';
$dbname = 'emprestimos';
$username = 'root';
$password = '';

// Nome do arquivo de backup
$data = date('Y-m-d-H-i-s');
$backup_file = 'backups/backup_' . $data . '.sql';

// Comando para fazer o backup do banco de dados
$comando = "mysqldump -h $host -u $username -p$password $dbname > $backup_file";
system($comando);

// Registra o backup no banco de dados
require_once 'config/conexao.php';
$stmt = $conn->prepare("INSERT INTO backups (arquivo, data) VALUES (:arquivo, NOW())");
$stmt->bindParam(':arquivo', $backup_file);
$stmt->execute();

echo "Backup realizado com sucesso!";
?>