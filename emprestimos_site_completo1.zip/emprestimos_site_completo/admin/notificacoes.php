<?php
require_once '../config/conexao.php';
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

$notificacoes = $conn->query("SELECT * FROM notificacoes ORDER BY data DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Notificações</h2>
<ul>
    <?php foreach ($notificacoes as $notificacao): ?>
        <li>
            <strong><?php echo $notificacao['titulo']; ?></strong> - <?php echo $notificacao['mensagem']; ?>
            <br><small><?php echo $notificacao['data']; ?></small>
        </li>
    <?php endforeach; ?>
</ul>