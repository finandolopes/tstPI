<?php
require_once '../config/conexao.php';
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Contagem de registros
$total_usuarios = $conn->query("SELECT COUNT(*) FROM usuarios")->fetchColumn();
$total_credito = $conn->query("SELECT COUNT(*) FROM analise_credito")->fetchColumn();
$total_acessos = $conn->query("SELECT SUM(visualizacoes) FROM estatisticas")->fetchColumn();
$ultimas_mensagens = $conn->query("SELECT * FROM contato ORDER BY data DESC LIMIT 5")->fetchAll(PDO::FETCH_ASSOC);

// Dados para gráficos
$dados_emprestimos = $conn->query("SELECT COUNT(*) as total, MONTH(data) as mes FROM analise_credito GROUP BY mes")->fetchAll(PDO::FETCH_ASSOC);
$dados_usuarios = $conn->query("SELECT COUNT(*) as total, MONTH(data_criacao) as mes FROM usuarios GROUP BY mes")->fetchAll(PDO::FETCH_ASSOC);

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<main>
    <h2>Dashboard</h2>
    <div class="cards">
        <div class="card">👤 Clientes cadastrados: <strong><?php echo $total_usuarios; ?></strong></div>
        <div class="card">💰 Análises de crédito: <strong><?php echo $total_credito; ?></strong></div>
        <div class="card">📊 Total de acessos: <strong><?php echo $total_acessos; ?></strong></div>
    </div>

    <h3>📊 Gráfico de Empréstimos</h3>
    <canvas id="emprestimosChart"></canvas>

    <h3>📊 Gráfico de Usuários</h3>
    <canvas id="usuariosChart"></canvas>

    <h3>📩 Últimas Mensagens</h3>
    <table>
        <tr><th>Nome</th><th>Email</th><th>Mensagem</th></tr>
        <?php foreach ($ultimas_mensagens as $msg): ?>
        <tr><td><?php echo $msg['nome']; ?></td><td><?php echo $msg['email']; ?></td><td><?php echo $msg['mensagem']; ?></td></tr>
        <?php endforeach; ?>
    </table>
</main>

<?php include 'includes/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
<script>
    const emprestimosCtx = document.getElementById('emprestimosChart').getContext('2d');
    const usuariosCtx = document.getElementById('usuariosChart').getContext('2d');

    // Gráfico de Empréstimos
    const emprestimosChart = new Chart(emprestimosCtx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode(array_column($dados_emprestimos, 'mes')); ?>,
            datasets: [{
                label: 'Empréstimos por Mês',
                data: <?php echo json_encode(array_column($dados_emprestimos, 'total')); ?>,
                borderColor: 'rgba(75, 192, 192, 1)',
                fill: false
            }]
        }
    });

    // Gráfico de Usuários
    const usuariosChart = new Chart(usuariosCtx, {
        type: 'line',
        data: {
            labels: <?php echo json_encode(array_column($dados_usuarios, 'mes')); ?>,
            datasets: [{
                label: 'Usuários por Mês',
                data: <?php echo json_encode(array_column($dados_usuarios, 'total')); ?>,
                borderColor: 'rgba(153, 102, 255, 1)',
                fill: false
            }]
        }
    });
</script>
