<?php
// Conexão com o banco de dados
require_once '../config/conexao.php';

session_start();

// Verifica se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $captcha = $_POST['captcha'];

    // Validação do CAPTCHA
    if ($captcha !== $_SESSION['captcha']) {
        $erro = "Captcha incorreto!";
    } else {
        // Valida as credenciais do usuário
        $stmt = $conn->prepare("SELECT * FROM usuarios WHERE email = ?");
        $stmt->execute([$email]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($usuario && password_verify($senha, $usuario['senha'])) {
            $_SESSION['role'] = $usuario['role'];
            $_SESSION['user_id'] = $usuario['id'];
            header('Location: index.php');
        } else {
            $erro = "E-mail ou senha incorretos!";
        }
    }
}

// Gerar CAPTCHA
function gerarCaptcha() {
    $caracteres = 'ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789';
    $captcha = '';
    for ($i = 0; $i < 6; $i++) {
        $captcha .= $caracteres[rand(0, strlen($caracteres) - 1)];
    }
    $_SESSION['captcha'] = $captcha;
    return $captcha;
}

$captcha = gerarCaptcha();
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Painel Administrativo</title>
</head>
<body>

    <form action="login.php" method="POST">
        <input type="email" name="email" placeholder="E-mail" required>
        <input type="password" name="senha" placeholder="Senha" required>
        
        <label for="captcha">Captcha: <?php echo $captcha; ?></label>
        <input type="text" name="captcha" placeholder="Digite o CAPTCHA" required>

        <?php if (isset($erro)) { echo "<p style='color:red;'>$erro</p>"; } ?>

        <button type="submit">Entrar</button>
    </form>

</body>
</html>