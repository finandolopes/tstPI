<?php
require_once 'config/conexao.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $senha = password_hash($_POST['senha'], PASSWORD_BCRYPT);
    $token = $_GET['token'];
    
    // Verifica o token na tabela de recuperação
    $stmt = $conn->prepare("SELECT * FROM recuperacao_senha WHERE token = :token AND expiracao > NOW()");
    $stmt->bindParam(':token', $token);
    $stmt->execute();
    
    if ($stmt->rowCount() > 0) {
        $recuperacao = $stmt->fetch(PDO::FETCH_ASSOC);
        // Atualiza a senha do usuário
        $stmt = $conn->prepare("UPDATE usuarios SET senha = :senha WHERE id = :usuario_id");
        $stmt->bindParam(':senha', $senha);
        $stmt->bindParam(':usuario_id', $recuperacao['usuario_id']);
        $stmt->execute();
        
        // Apaga o token após a redefinição
        $stmt = $conn->prepare("DELETE FROM recuperacao_senha WHERE token = :token");
        $stmt->bindParam(':token', $token);
        $stmt->execute();
        
        echo "Senha alterada com sucesso.";
    } else {
        echo "Token inválido ou expirado.";
    }
}
?>

<form method="POST">
    <label for="senha">Nova Senha:</label>
    <input type="password" name="senha" id="senha" required>
    <button type="submit">Redefinir Senha</button>
</form>