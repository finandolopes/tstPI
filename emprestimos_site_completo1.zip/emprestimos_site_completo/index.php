<?php
// Conexão com banco de dados
require_once 'config/conexao.php';

// Buscar banners ativos
$query_banners = "SELECT * FROM banners WHERE status = 'Ativo'";
$banners = $conn->query($query_banners)->fetchAll(PDO::FETCH_ASSOC);

// Buscar depoimentos aprovados
$query_depoimentos = "SELECT * FROM depoimentos WHERE status = 'Aprovado'";
$depoimentos = $conn->query($query_depoimentos)->fetchAll(PDO::FETCH_ASSOC);

// Buscar últimas perguntas frequentes (FAQ)
$query_faq = "SELECT * FROM faq ORDER BY id DESC LIMIT 3";
$faqs = $conn->query($query_faq)->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Empréstimo Consignado</title>
    <link rel="stylesheet" href="assets/css/style.css">
    <link rel="stylesheet" href="assets/css/responsivo.css">
</head>
<body>
    <header>
        <div class="logo">
            <h1>Empréstimo Consignado</h1>
        </div>
        <nav>
            <ul>
                <li><a href="#sobre">Sobre</a></li>
                <li><a href="#simulador">Simulador</a></li>
                <li><a href="#depoimentos">Depoimentos</a></li>
                <li><a href="#faq">FAQ</a></li>
                <li><a href="#contato">Contato</a></li>
            </ul>
        </nav>
    </header>

    <!-- Banners e Slides -->
    <section id="banners">
        <div class="slider">
            <?php foreach ($banners as $banner): ?>
                <div class="slide">
                    <img src="uploads/banners/<?= $banner['imagem'] ?>" alt="<?= $banner['titulo'] ?>">
                    <div class="slide-caption">
                        <h2><?= $banner['titulo'] ?></h2>
                        <p><?= $banner['descricao'] ?></p>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Simulador de Empréstimos -->
    <section id="simulador">
        <h2>Simule seu Empréstimo</h2>
        <form action="simulador.php" method="POST">
            <label for="valor">Valor do Empréstimo:</label>
            <input type="number" name="valor" id="valor" required>
            
            <label for="parcelas">Número de Parcelas:</label>
            <input type="number" name="parcelas" id="parcelas" required>
            
            <button type="submit">Simular</button>
        </form>
    </section>

    <!-- Depoimentos -->
    <section id="depoimentos">
        <h2>O que nossos clientes dizem</h2>
        <div class="depoimentos-lista">
            <?php foreach ($depoimentos as $depoimento): ?>
                <div class="depoimento">
                    <p>"<?= $depoimento['depoimento'] ?>"</p>
                    <h3>- <?= $depoimento['nome_cliente'] ?></h3>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- FAQ -->
    <section id="faq">
        <h2>Perguntas Frequentes</h2>
        <div class="faq-lista">
            <?php foreach ($faqs as $faq): ?>
                <div class="faq">
                    <h3><?= $faq['pergunta'] ?></h3>
                    <p><?= $faq['resposta'] ?></p>
                </div>
            <?php endforeach; ?>
        </div>
    </section>

    <!-- Contato -->
    <section id="contato">
        <h2>Entre em contato conosco</h2>
        <form action="contato.php" method="POST">
            <label for="nome">Nome:</label>
            <input type="text" name="nome" id="nome" required>

            <label for="email">E-mail:</label>
            <input type="email" name="email" id="email" required>

            <label for="mensagem">Mensagem:</label>
            <textarea name="mensagem" id="mensagem" required></textarea>

            <button type="submit">Enviar</button>
        </form>
    </section>

    <footer>
        <p>&copy; 2025 Empréstimo Consignado | Todos os direitos reservados</p>
    </footer>

    <script src="assets/js/slider.js"></script>
</body>
</html>
