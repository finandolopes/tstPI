<?php
require_once 'config/conexao.php';

$valor = $_GET['valor'] ?? 1000;
$parcelas = $_GET['parcelas'] ?? 12;
$taxa = 0.02; // 2% ao mês

// Cálculo do valor da parcela usando a fórmula de juros compostos
$parcela = ($valor * pow(1 + $taxa, $parcelas) * $taxa) / (pow(1 + $taxa, $parcelas) - 1);
$total = $parcela * $parcelas;

include 'includes/header.php';
?>

<main>
    <h2>Resultado da Simulação</h2>
    <p>Valor solicitado: <strong>R$ <?php echo number_format($valor, 2, ',', '.'); ?></strong></p>
    <p>Parcelas: <strong><?php echo $parcelas; ?>x de R$ <?php echo number_format($parcela, 2, ',', '.'); ?></strong></p>
    <p>Total a pagar: <strong>R$ <?php echo number_format($total, 2, ',', '.'); ?></strong></p>

    <a href="index.php">Voltar</a>
</main>

<?php include 'includes/footer.php'; ?>