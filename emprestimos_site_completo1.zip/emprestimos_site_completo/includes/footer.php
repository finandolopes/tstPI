<footer>
    <p>&copy; <?php echo date('Y'); ?> Sua Empresa. Todos os direitos reservados.</p>
</footer>
</body>
</html>