<aside class="sidebar">
    <nav>
        <ul>
            <li><a href="index.php">Dashboard</a></li>
            <li><a href="slides.php">Slides</a></li>
            <li><a href="depoimentos.php">Depoimentos</a></li>
            <li><a href="contato.php">Contatos</a></li>
            <li><a href="analise_credito.php">Análises de Crédito</a></li>
            <li><a href="faq.php">FAQ</a></li>
            <li><a href="usuarios.php">Usuários</a></li>
            <li><a href="relatorios.php">Relatórios</a></li>
            <li><a href="configuracoes.php">Configurações</a></li>
            <li><a href="logout.php">Sair</a></li>
        </ul>
    </nav>
</aside>