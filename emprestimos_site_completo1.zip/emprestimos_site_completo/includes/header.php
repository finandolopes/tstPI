<?php
session_start();
if (!isset($_SESSION['usuario'])) {
    header("Location: ../login.php");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Administrativo</title>
    <link rel="stylesheet" href="../assets/css/style.css">
    <script src="https://kit.fontawesome.com/a076d05399.js" crossorigin="anonymous"></script>
</head>
<body>
    <header>
        <h1>Painel Administrativo</h1>
        <nav>
            <a href="index.php">Dashboard</a>
            <a href="slides.php">Slides</a>
            <a href="depoimentos.php">Depoimentos</a>
            <a href="analise_credito.php">Análises</a>
            <a href="usuarios.php">Usuários</a>
            <a href="configuracoes.php">Configurações</a>
            <a href="logout.php">Sair</a>
        </nav>
    </header>