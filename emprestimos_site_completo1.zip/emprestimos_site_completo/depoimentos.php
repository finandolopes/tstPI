<?php
session_start();
require_once 'config/conexao.php';

// Busca os depoimentos aprovados
$stmt = $conn->prepare("SELECT nome, mensagem, data FROM depoimentos WHERE status = 'Aprovado' ORDER BY data DESC");
$stmt->execute();
$depoimentos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Mensagem de feedback
$mensagem = "";

// Verifica se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome']);
    $mensagem_usuario = trim($_POST['mensagem']);

    if (!empty($nome) && !empty($mensagem_usuario)) {
        try {
            $stmt = $conn->prepare("INSERT INTO depoimentos (nome, mensagem, status, data) VALUES (?, ?, 'Pendente', NOW())");
            $stmt->execute([$nome, $mensagem_usuario]);

            $mensagem = "Depoimento enviado com sucesso! Aguarde aprovação.";
        } catch (PDOException $e) {
            $mensagem = "Erro ao enviar depoimento: " . $e->getMessage();
        }
    } else {
        $mensagem = "Por favor, preencha todos os campos.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Depoimentos</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header>
        <h1>Depoimentos</h1>
        <nav>
            <ul>
                <li><a href="index.php">Início</a></li>
                <li><a href="simulador.php">Simulador</a></li>
                <li><a href="depoimentos.php">Depoimentos</a></li>
                <li><a href="contato.php">Contato</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section id="depoimentos">
            <h2>O que nossos clientes dizem</h2>
            
            <?php foreach ($depoimentos as $depoimento): ?>
                <div class="depoimento">
                    <p><strong><?= htmlspecialchars($depoimento['nome']) ?>:</strong></p>
                    <p>"<?= htmlspecialchars($depoimento['mensagem']) ?>"</p>
                    <small>Data: <?= date('d/m/Y', strtotime($depoimento['data'])) ?></small>
                </div>
            <?php endforeach; ?>
        </section>

        <section id="novo-depoimento">
            <h2>Deixe seu depoimento</h2>
            <?php if ($mensagem): ?>
                <p class="mensagem"><?= htmlspecialchars($mensagem) ?></p>
            <?php endif; ?>

            <form action="depoimentos.php" method="POST">
                <label for="nome">Seu Nome:</label>
                <input type="text" name="nome" id="nome" required>

                <label for="mensagem">Seu Depoimento:</label>
                <textarea name="mensagem" id="mensagem" required></textarea>

                <button type="submit">Enviar</button>
            </form>
        </section>
    </main>

    <footer>
        <p>&copy; 2025 Empréstimos Consignados</p>
    </footer>
</body>
</html>