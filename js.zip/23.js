(function () {
    // CSS em JavaScript
    const styles = `
    body.high-contrast {
        background-color: #000;
        color: #fff;
    }
    
    body.negative-contrast {
        background-color: #fff;
        color: #000;
    }
    
    body.grayscale {
        filter: grayscale(100%);
    }
    
    body.dark-mode {
        background-color: #121212;
        color: #e0e0e0;
    }
    
    .accessibility-menu {
        position: fixed;
        top: 50%;
        right: 0;
        transform: translateY(-50%);
        z-index: 9999;
    }
    
    .accessibility-menu .button {
        margin-bottom: 10px;
        width: 40px;
        height: 40px;
        display: flex;
        justify-content: center;
        align-items: center;
        background-color: #007bff;
        color: #fff;
        border: none;
        border-radius: 50%;
        cursor: pointer;
    }
    
    .accessibility-options {
        display: none;
        width: 300px;
        padding: 20px;
        position: fixed;
        top: 50%;
        right: 50px;
        transform: translateY(-50%);
        z-index: 9999;
        background-color: #fff;
        border: 1px solid #ddd;
        box-shadow: 0 4px 8px rgba(0,0,0,0.1);
    }
    
    .accessibility-options.show {
        display: block;
    }
    `;

    // Adiciona CSS ao documento
    const styleSheet = document.createElement("style");
    styleSheet.type = "text/css";
    styleSheet.innerText = styles;
    document.head.appendChild(styleSheet);
    
    // Cria e insere o ícone e menu de acessibilidade no DOM
    const body = document.body;
    
    const accessibilityMenu = document.createElement('div');
    accessibilityMenu.classList.add('accessibility-menu');
    
    const button = document.createElement('button');
    button.classList.add('button');
    button.innerHTML = '<i class="fas fa-universal-access"></i>';
    button.onclick = () => toggleAccessibilityMenu();
    accessibilityMenu.appendChild(button);
    
    const menu = document.createElement('div');
    menu.id = 'accessibility-options';
    menu.classList.add('accessibility-options');
    menu.innerHTML = `
        <h2>Menu de Acessibilidade</h2>
        <button onclick="adjustFontSize('increase')" class="btn btn-info w-100 mb-2">Aumentar Fonte</button>
        <button onclick="adjustFontSize('decrease')" class="btn btn-info w-100 mb-2">Diminuir Fonte</button>
        <button onclick="toggleHighContrast()" class="btn btn-info w-100 mb-2">Alto Contraste</button>
        <button onclick="toggleNegativeContrast()" class="btn btn-info w-100 mb-2">Contraste Negativo</button>
        <button onclick="toggleGrayscale()" class="btn btn-info w-100 mb-2">Tons de Cinza</button>
        <button onclick="toggleDarkMode()" class="btn btn-info w-100 mb-2">Modo Escuro</button>
        <button onclick="resetSettings()" class="btn btn-warning w-100 mb-2">Reiniciar Padrões</button>
        <button onclick="showHelp()" class="btn btn-light w-100 mb-2">Ajuda</button>
    `;
    accessibilityMenu.appendChild(menu);
    
    body.appendChild(accessibilityMenu);
    
    // Funções de acessibilidade
    window.toggleAccessibilityMenu = function () {
        const menu = document.getElementById('accessibility-options');
        menu.classList.toggle('show');
    }
    
    window.adjustFontSize = function (action) {
        document.body.style.fontSize = action === 'increase' ? 'larger' : 'smaller';
    }
    
    window.toggleHighContrast = function () {
        document.body.classList.toggle('high-contrast');
    }
    
    window.toggleNegativeContrast = function () {
        document.body.classList.toggle('negative-contrast');
    }
    
    window.toggleGrayscale = function () {
        document.body.classList.toggle('grayscale');
    }
    
    window.toggleDarkMode = function () {
        document.body.classList.toggle('dark-mode');
    }
    
    window.resetSettings = function () {
        Swal.fire({
            title: 'Deseja reiniciar as configurações?',
            showCancelButton: true,
            confirmButtonText: 'Sim, reiniciar',
            cancelButtonText: 'Não'
        }).then((result) => {
            if (result.isConfirmed) {
                document.body.classList.remove('high-contrast', 'negative-contrast', 'grayscale', 'dark-mode');
                document.body.style.fontSize = '';
                Swal.fire('Configurações reiniciadas');
            }
        });
    }
    
    window.showHelp = function () {
        Swal.fire({
            title: 'Ajuda do Menu de Acessibilidade',
            html: `
                <p><b>Aumentar Fonte:</b> Aumenta o tamanho do texto.</p>
                <p><b>Diminuir Fonte:</b> Diminui o tamanho do texto.</p>
                <p><b>Alto Contraste:</b> Ativa modo de alto contraste.</p>
                <p><b>Contraste Negativo:</b> Ativa modo de contraste negativo.</p>
                <p><b>Tons de Cinza:</b> Ativa modo em tons de cinza.</p>
                <p><b>Modo Escuro:</b> Ativa modo escuro.</p>
                <p><b>Reiniciar Padrões:</b> Reinicia para as configurações padrão do site.</p>
            `
        });
    }
})();
