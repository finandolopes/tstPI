document.addEventListener('DOMContentLoaded', function () {
    const state = {
        fontSize: 100,
        letterSpacing: 0,
        lineSpacing: 0,
        isDarkModeActive: false,
        isHighContrastActive: false,
        isGrayScaleActive: false,
        isNegativeContrastActive: false,
        isReadingRulerActive: false,
        isReadingMaskActive: false,
        isMagnifying: false,
        textReaderSpeed: 'normal', // 'normal', 'fast', 'slow'
        saturationLevel: 1,
        epilepsyMode: false,
        tdaMode: false,
        dyslexiaMode: false,
        daltonismMode: 0, // 0: None, 1: Protanopia, 2: Deuteranopia, 3: Tritanopia
        isMotorSkillsModeActive: false,
        isTextReaderActive: false,
        backgroundColor: '#ffffff',
        fontColor: '#000000',
        fontFamily: 'Arial',
        systemDarkMode: window.matchMedia && window.matchMedia('(prefers-color-scheme: dark)').matches,
        customTheme: 'default' // nova funcionalidade para temas personalizados
    };

    // Detectar configurações do sistema
    function detectSystemPreferences() {
        if (state.systemDarkMode) toggleDarkMode(true);
    }

    // Carregar configurações salvas
    function loadSettings() {
        const savedState = JSON.parse(localStorage.getItem('accessibilityState'));
        if (savedState) Object.assign(state, savedState);
        applySettings();
    }

    function saveSettings() {
        localStorage.setItem('accessibilityState', JSON.stringify(state));
    }

    // Aplicar as configurações salvas
    function applySettings() {
        adjustFontSize(state.fontSize);
        adjustLetterSpacing(state.letterSpacing);
        adjustLineSpacing(state.lineSpacing);
        document.body.style.filter = `saturate(${state.saturationLevel})`;
        document.body.style.backgroundColor = state.backgroundColor;
        document.body.style.color = state.fontColor;
        document.body.style.fontFamily = state.fontFamily;
        if (state.isDarkModeActive) toggleDarkMode(true);
        if (state.isHighContrastActive) toggleHighContrast(true);
        if (state.isGrayScaleActive) toggleGrayScale(true);
        if (state.isNegativeContrastActive) toggleNegativeContrast(true);
        if (state.isReadingRulerActive) toggleReadingRuler(true);
        if (state.isReadingMaskActive) toggleReadingMask(true);
        if (state.isMotorSkillsModeActive) toggleMotorSkillsMode(true);
        if (state.isTextReaderActive) toggleTextReader(true);
        if (state.tdaMode) toggleTDAMode();
    }

    // Tema personalizado
    function applyCustomTheme(theme) {
        state.customTheme = theme;
        switch (theme) {
            case 'dark':
                document.body.style.backgroundColor = '#000';
                document.body.style.color = '#fff';
                break;
            case 'light':
                document.body.style.backgroundColor = '#fff';
                document.body.style.color = '#000';
                break;
            default:
                document.body.style.backgroundColor = '#f8f9fa';
                document.body.style.color = '#333';
        }
        saveSettings();
    }

    // Ajuste do layout do menu para suportar mais funcionalidades
    function createAccessibilityMenu() {
        const menu = document.createElement('div');
        menu.id = 'accessibilityMenu';
        menu.className = 'accessibility-menu hidden';
        menu.innerHTML = `
            <div class="container-fluid h-100">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h3 class="text-primary">Acessibilidade</h3>
                    <button class="btn btn-outline-secondary" onclick="showHelp()">
                        <i class="fas fa-question-circle"></i>
                    </button>
                </div>
                <div class="row">
                    <!-- Ajustes de Fonte -->
                    <div class="col-12 mb-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h5 class="card-title">Ajustes de Fonte</h5>
                                <div class="mb-3">
                                    <label class="form-label">Tamanho da Fonte</label>
                                    <input type="range" min="80" max="200" value="${state.fontSize}" id="fontSizeSlider" class="form-range" onchange="adjustFontSize(this.value)">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Espaçamento entre Caracteres</label>
                                    <input type="range" min="0" max="10" value="${state.letterSpacing}" id="letterSpacingSlider" class="form-range" onchange="adjustLetterSpacing(this.value)">
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Espaçamento entre Linhas</label>
                                    <input type="range" min="0" max="10" value="${state.lineSpacing}" id="lineSpacingSlider" class="form-range" onchange="adjustLineSpacing(this.value)">
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Modos Visuais -->
                    <div class="col-12 mb-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h5 class="card-title">Modos Visuais</h5>
                                <div class="d-flex justify-content-around">
                                    <button class="btn btn-outline-secondary" onclick="toggleDarkMode()">Modo Escuro</button>
                                    <button class="btn btn-outline-secondary" onclick="toggleHighContrast()">Alto Contraste</button>
                                    <button class="btn btn-outline-secondary" onclick="toggleGrayScale()">Escala de Cinza</button>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Novas Funcionalidades -->
                    <div class="col-12 mb-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h5 class="card-title">Ferramentas de Leitura</h5>
                                <button class="btn btn-outline-primary w-100 mb-1" onclick="toggleTextReader()">Leitura de Texto</button>
                                <button class="btn btn-outline-info w-100 mb-1" onclick="toggleReadingRuler()">Régua de Leitura</button>
                                <button class="btn btn-outline-warning w-100 mb-1" onclick="toggleMagnifier()">Lupa</button>
                            </div>
                        </div>
                    </div>
                    <!-- Resetar Configurações -->
                    <div class="col-12">
                        <button class="btn btn-danger w-100 mt-3" onclick="resetSettings()">Resetar Configurações</button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(menu);
    }

    // Exibir ajuda
    window.showHelp = function() {
        Swal.fire({
            title: 'Ajuda de Acessibilidade',
            html: `
                <ul style="text-align: left;">
                    <li><strong>Modo Escuro:</strong> Alterna o modo escuro.</li>
                    <li><strong>Alto Contraste:</strong> Aumenta o contraste do site.</li>
                    <li><strong>Leitura de Texto:</strong> Lê o texto em voz alta.</li>
                </ul>
            `,
            icon: 'info',
            confirmButtonText: 'Ok'
        });
    };

    // Funções para alternar entre temas e aplicar configurações visuais
    window.toggleDarkMode = function() {
        state.isDarkModeActive = !state.isDarkModeActive;
        document.body.classList.toggle('dark-mode', state.isDarkModeActive);
        saveSettings();
    };

    window.toggleHighContrast = function() {
        state.isHighContrastActive = !state.isHighContrastActive;
        document.body.classList.toggle('high-contrast', state.isHighContrastActive);
        saveSettings();
    };

    window.toggleGrayScale = function() {
        state.isGrayScaleActive = !state.isGrayScaleActive;
        document.body.classList.toggle('grayscale', state.isGrayScaleActive);
        saveSettings();
    };

    // Criação do botão e menu de acessibilidade
    createAccessibilityButton();
    createAccessibilityMenu();
    loadSettings();
    detectSystemPreferences();
});
// Funções adicionais para ajustes de leitura, modos e ferramentas visuais

// Ajustar tamanho da fonte
window.adjustFontSize = function(value) {
    state.fontSize = value;
    document.body.style.fontSize = `${value}%`;
    saveSettings();
};

// Ajustar espaçamento entre letras
window.adjustLetterSpacing = function(value) {
    state.letterSpacing = value;
    document.body.style.letterSpacing = `${value}px`;
    saveSettings();
};

// Ajustar espaçamento entre linhas
window.adjustLineSpacing = function(value) {
    state.lineSpacing = value;
    document.body.style.lineHeight = `${1 + value / 10}`;
    saveSettings();
};

// Ativar/desativar o modo régua de leitura
window.toggleReadingRuler = function() {
    state.isReadingRulerActive = !state.isReadingRulerActive;
    if (state.isReadingRulerActive) {
        const ruler = document.createElement('div');
        ruler.id = 'readingRuler';
        ruler.style.position = 'fixed';
        ruler.style.width = '100%';
        ruler.style.height = '50px';
        ruler.style.backgroundColor = 'rgba(255, 255, 0, 0.6)';
        ruler.style.pointerEvents = 'none';
        ruler.style.zIndex = '1000';
        document.body.appendChild(ruler);

        document.addEventListener('mousemove', function(event) {
            ruler.style.top = `${event.clientY - 25}px`;
        });
    } else {
        const ruler = document.getElementById('readingRuler');
        if (ruler) ruler.remove();
    }
    saveSettings();
};

// Função para lupa
window.toggleMagnifier = function() {
    state.isMagnifying = !state.isMagnifying;
    if (state.isMagnifying) {
        document.body.style.cursor = 'zoom-in';
        document.addEventListener('mousedown', startMagnifying);
    } else {
        document.body.style.cursor = 'default';
        document.removeEventListener('mousedown', startMagnifying);
    }
};

function startMagnifying(event) {
    const zoomedElement = document.elementFromPoint(event.clientX, event.clientY);
    if (zoomedElement) {
        zoomedElement.style.transform = 'scale(1.5)';
        zoomedElement.style.transition = 'transform 0.2s ease';
    }
}

// Ativar/desativar leitura de texto
window.toggleTextReader = function() {
    state.isTextReaderActive = !state.isTextReaderActive;
    if (state.isTextReaderActive) {
        document.addEventListener('mouseup', handleTextSelection);
    } else {
        document.removeEventListener('mouseup', handleTextSelection);
        speechSynthesis.cancel();
    }
};

function handleTextSelection() {
    const selection = window.getSelection().toString();
    if (selection) {
        const utterance = new SpeechSynthesisUtterance(selection);
        utterance.rate = 1;
        speechSynthesis.speak(utterance);
    }
}

// Função para resetar configurações
window.resetSettings = function() {
    state.fontSize = 100;
    state.letterSpacing = 0;
    state.lineSpacing = 0;
    state.isDarkModeActive = false;
    state.isHighContrastActive = false;
    state.isGrayScaleActive = false;
    state.isNegativeContrastActive = false;
    state.isReadingRulerActive = false;
    state.isReadingMaskActive = false;
    state.isMagnifying = false;
    state.saturationLevel = 1;
    state.tdaMode = false;
    state.dyslexiaMode = false;
    state.epilepsyMode = false;
    state.isMotorSkillsModeActive = false;
    state.daltonismMode = 0;
    state.isTextReaderActive = false;

    document.body.style.fontSize = '100%';
    document.body.style.letterSpacing = '0px';
    document.body.style.lineHeight = 'normal';
    document.body.style.filter = 'none';
    document.body.classList.remove('dark-mode', 'high-contrast', 'grayscale', 'negative-contrast', 
                                     'tda-mode', 'dyslexia-mode', 'epilepsy-mode', 'motor-skills-mode');

    const ruler = document.getElementById('readingRuler');
    if (ruler) ruler.remove();

    document.body.style.cursor = 'default';

    saveSettings();
};

// Adicionar feedback visual quando uma configuração for ativada/desativada
function toggleButtonVisual(button, isActive) {
    if (isActive) {
        button.classList.add('btn-active');
    } else {
        button.classList.remove('btn-active');
    }
}

// Criação do botão de acessibilidade
function createAccessibilityButton() {
    const button = document.createElement('button');
    button.innerHTML = '<i class="fas fa-universal-access fa-3x"></i>';
    button.className = 'btn btn-primary accessibility-toggle';
    button.setAttribute('aria-label', 'Abrir Menu de Acessibilidade');
    document.body.appendChild(button);
    button.onclick = toggleMenu;
    button.style.position = 'fixed';
    button.style.top = '50%';
    button.style.right = '10px';
    button.style.transform = 'translateY(-50%)';
    button.style.zIndex = '10000';
    button.style.borderRadius = '50%';
    button.style.width = '60px';
    button.style.height = '60px';
    button.style.display = 'flex';
    button.style.justifyContent = 'center';
    button.style.alignItems = 'center';
}

// Alternar menu de acessibilidade
function toggleMenu() {
    const menu = document.getElementById('accessibilityMenu');
    menu.classList.toggle('hidden');
}

// Inicializar configurações e criar componentes
createAccessibilityButton();
createAccessibilityMenu();
loadSettings();
detectSystemPreferences();
// Ativar/Desativar Modo TDAH com Pomodoro
window.toggleTDAMode = function() {
    state.tdaMode = !state.tdaMode;
    document.body.classList.toggle('tda-mode', state.tdaMode);

    if (state.tdaMode) {
        // Ativar ciclo Pomodoro (25 min foco, 5 min pausa)
        let workTimer = setTimeout(() => {
            alert('Hora de fazer uma pausa!');
            setTimeout(() => alert('Hora de voltar ao trabalho!'), 5 * 60 * 1000); // Pausa de 5 minutos
        }, 25 * 60 * 1000); // 25 minutos de foco

        // Ativar ferramentas de leitura
        toggleTextReader(true);
        toggleReadingRuler(true);

        // Bloquear distrações visuais (remove animações e banners)
        blockDistractions();
    } else {
        clearTimeout(workTimer);
        toggleTextReader(false);
        toggleReadingRuler(false);
        unblockDistractions();
    }

    saveSettings();
};

// Função para bloquear animações e distrações visuais
function blockDistractions() {
    document.querySelectorAll('video, .banner, .popup').forEach(el => {
        el.style.display = 'none';
    });
}

// Função para desbloquear distrações quando o modo TDAH for desativado
function unblockDistractions() {
    document.querySelectorAll('video, .banner, .popup').forEach(el => {
        el.style.display = '';
    });
}

// Modo Dislexia
window.toggleDyslexiaMode = function() {
    state.dyslexiaMode = !state.dyslexiaMode;
    document.body.classList.toggle('dyslexia-mode', state.dyslexiaMode);

    if (state.dyslexiaMode) {
        document.body.style.fontFamily = "'OpenDyslexic', Arial, sans-serif";
        document.body.style.letterSpacing = '0.12em';
        document.body.style.lineHeight = '1.6';
    } else {
        document.body.style.fontFamily = '';
        document.body.style.letterSpacing = '';
        document.body.style.lineHeight = '';
    }

    saveSettings();
};

// Modo Epilepsia (remover animações e flashes)
window.toggleEpilepsyMode = function() {
    state.epilepsyMode = !state.epilepsyMode;
    document.body.classList.toggle('epilepsy-mode', state.epilepsyMode);

    if (state.epilepsyMode) {
        document.querySelectorAll('*').forEach(el => {
            el.style.animation = 'none';
            el.style.transition = 'none';
        });
    } else {
        document.querySelectorAll('*').forEach(el => {
            el.style.animation = '';
            el.style.transition = '';
        });
    }

    saveSettings();
};

// Alternar modos de daltonismo
window.toggleDaltonismMode = function() {
    state.daltonismMode = (state.daltonismMode + 1) % 4;
    document.body.classList.remove('protanopia', 'deuteranopia', 'tritanopia');

    if (state.daltonismMode === 1) {
        document.body.classList.add('protanopia');
    } else if (state.daltonismMode === 2) {
        document.body.classList.add('deuteranopia');
    } else if (state.daltonismMode === 3) {
        document.body.classList.add('tritanopia');
    }

    saveSettings();
};

// Função para alternar entre temas personalizados
window.changeTheme = function(theme) {
    applyCustomTheme(theme);
};

// Aplicação de temas personalizados
function applyCustomTheme(theme) {
    state.customTheme = theme;
    switch (theme) {
        case 'dark':
            document.body.style.backgroundColor = '#000';
            document.body.style.color = '#fff';
            break;
        case 'light':
            document.body.style.backgroundColor = '#fff';
            document.body.style.color = '#000';
            break;
        case 'blue':
            document.body.style.backgroundColor = '#001f3f';
            document.body.style.color = '#ffffff';
            break;
        default:
            document.body.style.backgroundColor = '#f8f9fa';
            document.body.style.color = '#333';
    }
    saveSettings();
}
// Ajuste do layout do menu para incluir todas as novas funcionalidades
function createAccessibilityMenu() {
    const menu = document.createElement('div');
    menu.id = 'accessibilityMenu';
    menu.className = 'accessibility-menu hidden';
    menu.innerHTML = `
        <div class="container-fluid h-100">
            <div class="d-flex justify-content-between align-items-center mb-4">
                <h3 class="text-primary">Acessibilidade</h3>
                <button class="btn btn-outline-secondary" onclick="showHelp()">
                    <i class="fas fa-question-circle"></i>
                </button>
            </div>
            <div class="row">
                <!-- Ajustes de Fonte -->
                <div class="col-12 mb-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <h5 class="card-title">Ajustes de Fonte</h5>
                            <input type="range" min="80" max="200" value="${state.fontSize}" id="fontSizeSlider" class="form-range" onchange="adjustFontSize(this.value)">
                            <input type="range" min="0" max="10" value="${state.letterSpacing}" id="letterSpacingSlider" class="form-range" onchange="adjustLetterSpacing(this.value)">
                            <input type="range" min="0" max="10" value="${state.lineSpacing}" id="lineSpacingSlider" class="form-range" onchange="adjustLineSpacing(this.value)">
                        </div>
                    </div>
                </div>
                <!-- Modos Visuais -->
                <div class="col-12 mb-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <h5 class="card-title">Modos Visuais</h5>
                            <button class="btn btn-outline-secondary w-100 mb-1" onclick="toggleDarkMode()">Modo Escuro</button>
                            <button class="btn btn-outline-secondary w-100 mb-1" onclick="toggleHighContrast()">Alto Contraste</button>
                            <button class="btn btn-outline-secondary w-100 mb-1" onclick="toggleGrayScale()">Escala de Cinza</button>
                            <button class="btn btn-outline-secondary w-100 mb-1" onclick="toggleDaltonismMode()">Modo Daltonismo</button>
                        </div>
                    </div>
                </div>
                <!-- Ferramentas de Leitura -->
                <div class="col-12 mb-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <h5 class="card-title">Ferramentas de Leitura</h5>
                            <button class="btn btn-outline-primary w-100 mb-1" onclick="toggleTextReader()">Leitura de Texto</button>
                            <button class="btn btn-outline-info w-100 mb-1" onclick="toggleReadingRuler()">Régua de Leitura</button>
                            <button class="btn btn-outline-warning w-100 mb-1" onclick="toggleMagnifier()">Lupa</button>
                        </div>
                    </div>
                </div>
                <!-- Modos Especiais -->
                <div class="col-12 mb-3">
                    <button class="btn btn-outline-warning w-100 mb-1" onclick="toggleDyslexiaMode()">Modo Dislexia</button>
                    <button class="btn btn-outline-success w-100 mb-1" onclick="toggleTDAMode()">Modo TDAH</button>
                    <button class="btn btn-outline-danger w-100 mb-1" onclick="toggleEpilepsyMode()">Modo Epilepsia</button>
                </div>
                <!-- Temas Personalizados -->
                <div class="col-12 mb-3">
                    <h5 class="text-center">Temas</h5>
                    <button class="btn btn-outline-info w-100 mb-1" onclick="changeTheme('light')">Tema Claro</button>
                    <button class="btn btn-outline-dark w-100 mb-1" onclick="changeTheme('dark')">Tema Escuro</button>
                    <button class="btn btn-outline-primary w-100 mb-1" onclick="changeTheme('blue')">Tema Azul</button>
                </div>
                <!-- Resetar Configurações -->
                <div class="col-12">
                    <button class="btn btn-danger w-100 mt-3" onclick="resetSettings()">Resetar Configurações</button>
                </div>
            </div>
        </div>
    `;
    document.body.appendChild(menu);
}
// Ativar navegação via teclado com feedback visual
window.enableKeyboardNavigation = function() {
    document.addEventListener('keydown', keyboardNavigationHandler);
};

window.disableKeyboardNavigation = function() {
    document.removeEventListener('keydown', keyboardNavigationHandler);
};

// Função para navegação por teclado
function keyboardNavigationHandler(event) {
    if (event.altKey) {
        switch (event.key) {
            case '1':
                toggleHighContrast(); // Atalho para Alto Contraste
                break;
            case '2':
                toggleDarkMode(); // Atalho para Modo Escuro
                break;
            case '3':
                toggleTextReader(); // Atalho para Leitura de Texto
                break;
            case '4':
                toggleReadingRuler(); // Atalho para Régua de Leitura
                break;
            case '5':
                resetSettings(); // Atalho para Resetar Configurações
                break;
            default:
                break;
        }
    }
}

// Melhorar feedback visual dos botões
function toggleButtonVisual(button, isActive) {
    if (isActive) {
        button.classList.add('btn-active');
        button.style.backgroundColor = '#007bff'; // Cor azul quando ativo
        button.style.color = '#fff';
    } else {
        button.classList.remove('btn-active');
        button.style.backgroundColor = '';
        button.style.color = '';
    }
}

// Haptics (feedback tátil) para dispositivos móveis
function applyHaptics() {
    if (window.navigator.vibrate) {
        window.navigator.vibrate(100); // Vibra quando uma função é ativada/desativada
    }
}
// Detectar idioma do navegador e aplicar a tradução correspondente
function applyLanguageSettings() {
    const userLang = navigator.language || navigator.userLanguage;
    if (userLang.startsWith('pt')) {
        setLanguage('pt');
    } else if (userLang.startsWith('es')) {
        setLanguage('es');
    } else {
        setLanguage('en'); // Padrão para inglês
    }
}

// Função para aplicar o idioma selecionado
function setLanguage(lang) {
    const translations = {
        en: {
            fontSize: 'Font Size',
            letterSpacing: 'Letter Spacing',
            lineSpacing: 'Line Spacing',
            darkMode: 'Dark Mode',
            highContrast: 'High Contrast',
            grayScale: 'Gray Scale',
            dyslexiaMode: 'Dyslexia Mode',
            tdaMode: 'TDAH Mode',
            epilepsyMode: 'Epilepsy Mode',
            textReader: 'Text Reader',
            readingRuler: 'Reading Ruler',
            magnifier: 'Magnifier',
            resetSettings: 'Reset Settings',
            themes: 'Themes',
            help: 'Help'
        },
        pt: {
            fontSize: 'Tamanho da Fonte',
            letterSpacing: 'Espaçamento entre Letras',
            lineSpacing: 'Espaçamento entre Linhas',
            darkMode: 'Modo Escuro',
            highContrast: 'Alto Contraste',
            grayScale: 'Escala de Cinza',
            dyslexiaMode: 'Modo Dislexia',
            tdaMode: 'Modo TDAH',
            epilepsyMode: 'Modo Epilepsia',
            textReader: 'Leitura de Texto',
            readingRuler: 'Régua de Leitura',
            magnifier: 'Lupa',
            resetSettings: 'Resetar Configurações',
            themes: 'Temas',
            help: 'Ajuda'
        },
        es: {
            fontSize: 'Tamaño de Fuente',
            letterSpacing: 'Espaciado entre Letras',
            lineSpacing: 'Espaciado entre Líneas',
            darkMode: 'Modo Oscuro',
            highContrast: 'Alto Contraste',
            grayScale: 'Escala de Grises',
            dyslexiaMode: 'Modo Dislexia',
            tdaMode: 'Modo TDAH',
            epilepsyMode: 'Modo Epilepsia',
            textReader: 'Lector de Texto',
            readingRuler: 'Regla de Lectura',
            magnifier: 'Lupa',
            resetSettings: 'Restablecer Configuraciones',
            themes: 'Temas',
            help: 'Ayuda'
        }
    };

    document.getElementById('fontSizeLabel').textContent = translations[lang].fontSize;
    document.getElementById('letterSpacingLabel').textContent = translations[lang].letterSpacing;
    document.getElementById('lineSpacingLabel').textContent = translations[lang].lineSpacing;
    document.getElementById('darkModeButton').textContent = translations[lang].darkMode;
    document.getElementById('highContrastButton').textContent = translations[lang].highContrast;
    document.getElementById('grayScaleButton').textContent = translations[lang].grayScale;
    document.getElementById('dyslexiaModeButton').textContent = translations[lang].dyslexiaMode;
    document.getElementById('tdaModeButton').textContent = translations[lang].tdaMode;
    document.getElementById('epilepsyModeButton').textContent = translations[lang].epilepsyMode;
    document.getElementById('textReaderButton').textContent = translations[lang].textReader;
    document.getElementById('readingRulerButton').textContent = translations[lang].readingRuler;
    document.getElementById('magnifierButton').textContent = translations[lang].magnifier;
    document.getElementById('resetSettingsButton').textContent = translations[lang].resetSettings;
    document.getElementById('themesLabel').textContent = translations[lang].themes;
    document.getElementById('helpButton').textContent = translations[lang].help;
}

// Chamar a função de detecção de idioma ao carregar a página
applyLanguageSettings();
// Bloquear reprodução automática de vídeos e ativar legendas
window.blockAutoplay = function() {
    document.querySelectorAll('video').forEach(video => {
        video.autoplay = false;
        video.controls = true; // Mostrar controles do vídeo
        video.setAttribute('playsinline', 'playsinline');

        // Ativar legendas se disponíveis
        if (video.textTracks) {
            for (let i = 0; i < video.textTracks.length; i++) {
                video.textTracks[i].mode = 'showing'; // Ativa legendas
            }
        }
    });
};
// Função OCR para leitura de texto em PDFs e imagens
window.readTextFromImages = function(imageElement) {
    const canvas = document.createElement('canvas');
    const ctx = canvas.getContext('2d');
    canvas.width = imageElement.width;
    canvas.height = imageElement.height;
    ctx.drawImage(imageElement, 0, 0, canvas.width, canvas.height);

    // Usando Tesseract.js para OCR
    Tesseract.recognize(canvas.toDataURL(), 'eng').then(result => {
        const text = result.data.text;
        if (text) {
            const utterance = new SpeechSynthesisUtterance(text);
            speechSynthesis.speak(utterance); // Ler o texto reconhecido
        }
    });
};
// Modo Simplificado (Remove elementos visuais desnecessários)
window.toggleSimplifiedMode = function() {
    state.isSimplifiedModeActive = !state.isSimplifiedModeActive;
    if (state.isSimplifiedModeActive) {
        // Ocultar elementos que possam distrair
        document.querySelectorAll('header, footer, nav, aside, .sidebar, .ads, .popup').forEach(el => {
            el.style.display = 'none';
        });
        // Focar no conteúdo principal
        document.querySelector('main').style.margin = 'auto';
        document.querySelector('main').style.width = '100%';
        document.querySelector('main').style.maxWidth = '800px';
    } else {
        // Restaurar os elementos ocultos
        document.querySelectorAll('header, footer, nav, aside, .sidebar, .ads, .popup').forEach(el => {
            el.style.display = '';
        });
        document.querySelector('main').style.margin = '';
        document.querySelector('main').style.width = '';
        document.querySelector('main').style.maxWidth = '';
    }
    saveSettings();
};
// Simplificação de conteúdo com IA (usando OpenAI API)
async function simplifyContent() {
    const content = document.body.innerText; // Extrair texto do corpo do documento
    const simplifiedText = await fetch('https://api.openai.com/v1/engines/davinci-codex/completions', {
        method: 'POST',
        headers: {
            'Content-Type': 'application/json',
            'Authorization': `Bearer YOUR_API_KEY`
        },
        body: JSON.stringify({
            prompt: `Simplify the following content:\n\n${content}`,
            max_tokens: 500
        })
    }).then(response => response.json()).then(data => data.choices[0].text);

    // Substituir o conteúdo da página pelo texto simplificado
    document.body.innerHTML = `<div class="simplified-content">${simplifiedText}</div>`;
}
// Adicionar efeito visual ao clique do cursor
window.addCursorClickEffect = function() {
    document.addEventListener('click', function(e) {
        const ripple = document.createElement('span');
        ripple.className = 'ripple-effect';
        ripple.style.left = `${e.pageX - 10}px`;
        ripple.style.top = `${e.pageY - 10}px`;
        document.body.appendChild(ripple);

        setTimeout(() => {
            ripple.remove();
        }, 500); // Efeito desaparece após 0.5s
    });
};

// CSS para o efeito de clique do cursor
const rippleStyle = document.createElement('style');
rippleStyle.innerHTML = `
    .ripple-effect {
        position: absolute;
        width: 20px;
        height: 20px;
        border-radius: 50%;
        background: rgba(0, 150, 255, 0.5);
        pointer-events: none;
        animation: ripple-animation 0.5s ease-out;
    }

    @keyframes ripple-animation {
        from {
            transform: scale(1);
            opacity: 1;
        }
        to {
            transform: scale(2);
            opacity: 0;
        }
    }
`;
document.head.appendChild(rippleStyle);
// Bloquear rastreadores e scripts invasivos
window.enablePrivacyMode = function() {
    document.querySelectorAll('iframe, script[src*="tracker"], script[src*="analytics"]').forEach(el => {
        el.remove();
    });
};

// Ativar o modo de privacidade automaticamente ao carregar a página
window.onload = function() {
    enablePrivacyMode();
};
// Controle de saturação
window.toggleSaturation = function() {
    if (state.saturationLevel < 10) {
        state.saturationLevel += 1;
    } else {
        state.saturationLevel = 1;
    }
    document.body.style.filter = `saturate(${state.saturationLevel})`;
    saveSettings();
};
// Alternar entre modos de daltonismo
window.toggleDaltonismMode = function() {
    state.daltonismMode = (state.daltonismMode + 1) % 4; // Ciclamos entre 0, 1, 2 e 3
    document.body.classList.remove('protanopia', 'deuteranopia', 'tritanopia');

    if (state.daltonismMode === 1) {
        document.body.classList.add('protanopia'); // Vermelho-insensível
    } else if (state.daltonismMode === 2) {
        document.body.classList.add('deuteranopia'); // Verde-insensível
    } else if (state.daltonismMode === 3) {
        document.body.classList.add('tritanopia'); // Azul-insensível
    }

    saveSettings();
};

// CSS para os modos de daltonismo
const daltonismStyles = document.createElement('style');
daltonismStyles.innerHTML = `
    .protanopia {
        filter: url('#protanopia');
    }
    .deuteranopia {
        filter: url('#deuteranopia');
    }
    .tritanopia {
        filter: url('#tritanopia');
    }
`;
document.head.appendChild(daltonismStyles);

// Adicionar os filtros SVG para daltonismo
const svgFilters = `
    <svg xmlns="http://www.w3.org/2000/svg" version="1.1">
        <defs>
            <filter id="protanopia">
                <feColorMatrix type="matrix" values="0.567,0.433,0,0,0,0.558,0.442,0,0,0,0,0.242,0.758,0,0,0,0,0,1,0"/>
            </filter>
            <filter id="deuteranopia">
                <feColorMatrix type="matrix" values="0.625,0.375,0,0,0,0.7,0.3,0,0,0,0,0.3,0.7,0,0,0,0,0,1,0"/>
            </filter>
            <filter id="tritanopia">
                <feColorMatrix type="matrix" values="0.95,0.05,0,0,0,0,0.433,0.567,0,0,0,0.475,0.525,0,0,0,0,0,1,0"/>
            </filter>
        </defs>
    </svg>
`;
document.body.insertAdjacentHTML('beforeend', svgFilters);
.accessibility-menu {
    position: fixed;
    top: 10px;
    right: 10px;
    width: 350px;
    max-width: 100%;
    background-color: #fff;
    border-radius: 8px;
    box-shadow: 0px 0px 10px rgba(0, 0, 0, 0.1);
    padding: 15px;
    z-index: 10000;
    overflow-y: auto;
    max-height: 90vh;
}

.accessibility-menu h5 {
    font-size: 1.25rem;
    margin-bottom: 10px;
}

@media (max-width: 600px) {
    .accessibility-menu {
        width: 100%;
        left: 0;
        right: 0;
        top: 0;
        border-radius: 0;
        height: 100vh;
        max-height: 100vh;
    }
}
// Criação do botão de acessibilidade
function createAccessibilityButton() {
    const button = document.createElement('button');
    button.innerHTML = '<i class="fas fa-universal-access fa-2x"></i>';
    button.className = 'btn btn-primary accessibility-toggle';
    button.setAttribute('aria-label', 'Abrir Menu de Acessibilidade');
    document.body.appendChild(button);
    button.onclick = toggleMenu;
    button.style.position = 'fixed';
    button.style.top = '10px';
    button.style.right = '10px';
    button.style.zIndex = '10000';
    button.style.borderRadius = '50%';
    button.style.width = '50px';
    button.style.height = '50px';
    button.style.display = 'flex';
    button.style.justifyContent = 'center';
    button.style.alignItems = 'center';
}

// Alternar visibilidade do menu de acessibilidade
function toggleMenu() {
    const menu = document.getElementById('accessibilityMenu');
    menu.classList.toggle('hidden');
}
(function() {
    const state = {
        fontSize: 100,
        letterSpacing: 0,
        lineSpacing: 0,
        isDarkModeActive: false,
        isHighContrastActive: false,
        isGrayScaleActive: false,
        isNegativeContrastActive: false,
        isReadingRulerActive: false,
        isMagnifying: false,
        textReaderSpeed: 'normal',
        saturationLevel: 1,
        epilepsyMode: false,
        tdaMode: false,
        dyslexiaMode: false,
        daltonismMode: 0,
        isTextReaderActive: false,
        customTheme: 'default'
    };

    function init() {
        createAccessibilityButton();
        createAccessibilityMenu();
        applySettings();
    }

    function saveSettings() {
        localStorage.setItem('accessibilityState', JSON.stringify(state));
    }

    function loadSettings() {
        const savedState = localStorage.getItem('accessibilityState');
        if (savedState) {
            Object.assign(state, JSON.parse(savedState));
        }
        applySettings();
    }

    function applySettings() {
        adjustFontSize(state.fontSize);
        adjustLetterSpacing(state.letterSpacing);
        adjustLineSpacing(state.lineSpacing);
        if (state.isDarkModeActive) toggleDarkMode(true);
        if (state.isHighContrastActive) toggleHighContrast(true);
        if (state.isGrayScaleActive) toggleGrayScale(true);
        if (state.isReadingRulerActive) toggleReadingRuler(true);
        if (state.isMagnifying) toggleMagnifier(true);
        if (state.isTextReaderActive) toggleTextReader(true);
    }

    function createAccessibilityButton() {
        const button = document.createElement('button');
        button.innerHTML = '<i class="fas fa-universal-access fa-2x"></i>';
        button.className = 'btn btn-primary accessibility-toggle';
        button.setAttribute('aria-label', 'Abrir Menu de Acessibilidade');
        button.style.position = 'fixed';
        button.style.top = '10px';
        button.style.right = '10px';
        button.style.zIndex = '10000';
        button.style.borderRadius = '50%';
        button.style.width = '50px';
        button.style.height = '50px';
        button.style.display = 'flex';
        button.style.justifyContent = 'center';
        button.style.alignItems = 'center';
        document.body.appendChild(button);
        button.onclick = toggleMenu;
    }

    function createAccessibilityMenu() {
        const menu = document.createElement('div');
        menu.id = 'accessibilityMenu';
        menu.className = 'accessibility-menu hidden';
        menu.innerHTML = `
            <div class="container-fluid h-100">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h3 class="text-primary">Acessibilidade</h3>
                    <button class="btn btn-outline-secondary" onclick="showHelp()">
                        <i class="fas fa-question-circle"></i>
                    </button>
                </div>
                <div class="row">
                    <div class="col-12 mb-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h5 class="card-title">Ajustes de Fonte</h5>
                                <input type="range" min="80" max="200" value="${state.fontSize}" id="fontSizeSlider" class="form-range" onchange="adjustFontSize(this.value)">
                                <input type="range" min="0" max="10" value="${state.letterSpacing}" id="letterSpacingSlider" class="form-range" onchange="adjustLetterSpacing(this.value)">
                                <input type="range" min="0" max="10" value="${state.lineSpacing}" id="lineSpacingSlider" class="form-range" onchange="adjustLineSpacing(this.value)">
                            </div>
                        </div>
                    </div>
                    <div class="col-12 mb-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h5 class="card-title">Modos Visuais</h5>
                                <button class="btn btn-outline-secondary w-100 mb-1" onclick="toggleDarkMode()">Modo Escuro</button>
                                <button class="btn btn-outline-secondary w-100 mb-1" onclick="toggleHighContrast()">Alto Contraste</button>
                                <button class="btn btn-outline-secondary w-100 mb-1" onclick="toggleGrayScale()">Escala de Cinza</button>
                                <button class="btn btn-outline-secondary w-100 mb-1" onclick="toggleDaltonismMode()">Modo Daltonismo</button>
                            </div>
                        </div>
                    </div>
                    <div class="col-12 mb-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h5 class="card-title">Ferramentas de Leitura</h5>
                                <button class="btn btn-outline-primary w-100 mb-1" onclick="toggleTextReader()">Leitura de Texto</button>
                                <button class="btn btn-outline-info w-100 mb-1" onclick="toggleReadingRuler()">Régua de Leitura</button>
                                <button class="btn btn-outline-warning w-100 mb-1" onclick="toggleMagnifier()">Lupa</button>
                            </div>
                        </div>
                    </div>
                    
<div class="col-12 mb-3">
                        <button class="btn btn-outline-warning w-100 mb-1" onclick="toggleDyslexiaMode()">Modo Dislexia</button>
                        <button class="btn btn-outline-success w-100 mb-1" onclick="toggleTDAMode()">Modo TDAH</button>
                        <button class="btn btn-outline-danger w-100 mb-1" onclick="toggleEpilepsyMode()">Modo Epilepsia</button>
                    </div>
                    <div class="col-12 mb-3">
                        <h5 class="text-center">Temas</h5>
                        <button class="btn btn-outline-info w-100 mb-1" onclick="changeTheme('light')">Tema Claro</button>
                        <button class="btn btn-outline-dark w-100 mb-1" onclick="changeTheme('dark')">Tema Escuro</button>
                        <button class="btn btn-outline-primary w-100 mb-1" onclick="changeTheme('blue')">Tema Azul</button>
                    </div>
                    <div class="col-12">
                        <button class="btn btn-danger w-100 mt-3" onclick="resetSettings()">Resetar Configurações</button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(menu);
    }

    // Funções de configuração do menu
    function toggleMenu() {
        const menu = document.getElementById('accessibilityMenu');
        menu.classList.toggle('hidden');
    }

    function adjustFontSize(value) {
        state.fontSize = value;
        document.body.style.fontSize = `${value}%`;
        saveSettings();
    }

    function adjustLetterSpacing(value) {
        state.letterSpacing = value;
        document.body.style.letterSpacing = `${value}px`;
        saveSettings();
    }

    function adjustLineSpacing(value) {
        state.lineSpacing = value;
        document.body.style.lineHeight = `${1 + value / 10}`;
        saveSettings();
    }

    function toggleDarkMode() {
        state.isDarkModeActive = !state.isDarkModeActive;
        document.body.classList.toggle('dark-mode', state.isDarkModeActive);
        saveSettings();
    }

    function toggleHighContrast() {
        state.isHighContrastActive = !state.isHighContrastActive;
        document.body.classList.toggle('high-contrast', state.isHighContrastActive);
        saveSettings();
    }

    function toggleGrayScale() {
        state.isGrayScaleActive = !state.isGrayScaleActive;
        document.body.classList.toggle('grayscale', state.isGrayScaleActive);
        saveSettings();
    }

    function toggleDaltonismMode() {
        state.daltonismMode = (state.daltonismMode + 1) % 4; // Cicla entre os modos
        document.body.classList.remove('protanopia', 'deuteranopia', 'tritanopia');

        if (state.daltonismMode === 1) {
            document.body.classList.add('protanopia');
        } else if (state.daltonismMode === 2) {
            document.body.classList.add('deuteranopia');
        } else if (state.daltonismMode === 3) {
            document.body.classList.add('tritanopia');
        }

        saveSettings();
    }

    function toggleTextReader() {
        state.isTextReaderActive = !state.isTextReaderActive;
        if (state.isTextReaderActive) {
            document.addEventListener('mouseup', handleTextSelection);
        } else {
            document.removeEventListener('mouseup', handleTextSelection);
            speechSynthesis.cancel();
        }
        saveSettings();
    }

    function handleTextSelection() {
        const selection = window.getSelection().toString();
        if (selection) {
            const utterance = new SpeechSynthesisUtterance(selection);
            utterance.rate = state.textReaderSpeed === 'fast' ? 1.5 : state.textReaderSpeed === 'slow' ? 0.75 : 1;
            speechSynthesis.speak(utterance);
        }
    }

    function toggleReadingRuler() {
        state.isReadingRulerActive = !state.isReadingRulerActive;
        if (state.isReadingRulerActive) {
            const ruler = document.createElement('div');
            ruler.id = 'readingRuler';
            ruler.style.position = 'fixed';
            ruler.style.width = '100%';
            ruler.style.height = '50px';
            ruler.style.backgroundColor = 'rgba(255, 255, 0, 0.6)';
            ruler.style.pointerEvents = 'none';
            ruler.style.zIndex = '1000';
            document.body.appendChild(ruler);
            document.addEventListener('mousemove', function(event) {
                ruler.style.top = `${event.clientY - 25}px`;
            });
        } else {
            const ruler = document.getElementById('readingRuler');
            if (ruler) ruler.remove();
        }
        saveSettings();
    }

    function toggleMagnifier() {
        state.isMagnifying = !state.isMagnifying;
        if (state.isMagnifying) {
            document.body.style.cursor = 'zoom-in';
            document.addEventListener('mousedown', startMagnifying);
        } else {
            document.body.style.cursor = 'default';
            document.removeEventListener('mousedown', startMagnifying);
        }
        saveSettings();
    }

    function startMagnifying(event) {
        const zoomedElement = document.elementFromPoint(event.clientX, event.clientY);
        if (zoomedElement) {
            zoomedElement.style.transform = 'scale(1.5)';
            zoomedElement.style.transition = 'transform 0.2s ease';
        }
    }

    function toggleDyslexiaMode() {
        state.dyslexiaMode = !state.dyslexiaMode;
        if (state.dyslexiaMode) {
            document.body.style.fontFamily = "'OpenDyslexic', Arial, sans-serif";
            document.body.style.letterSpacing = '0.12em';
            document.body.style.lineHeight = '1.6';
        } else {
            document.body.style.fontFamily = '';
            document.body.style.letterSpacing = '';
            document.body.style.lineHeight = '';
        }
        saveSettings();
    }

    function toggleTDAMode() {
        state.tdaMode = !state.tdaMode;
        if (state.tdaMode) {
            // Implementação do modo TDAH
            alert('Modo TDAH ativado: Foco em 25 minutos seguido de 5 minutos de pausa.');
            // Aqui você pode adicionar um temporizador ou lógica de bloqueio de distrações.
        }
        saveSettings();
    }

    function toggleEpilepsyMode() {
        state.epilepsyMode = !state.epilepsyMode;
        if (state.epilepsyMode) {
            document.querySelectorAll('*').forEach(el => {
                el.style.animation = 'none';
                el.style.transition = 'none';
            });
        } else {
            document.querySelectorAll('*').forEach(el => {
                el.style.animation = '';
                el.style.transition = '';
            });
        }
        saveSettings();
    }

    function changeTheme(theme) {
        state.customTheme = theme;
        switch (theme) {
            case 'dark':
                document.body.style.backgroundColor = '#000';
                document.body.style.color = '#fff';
                break;
            case 'light':
                document.body.style.backgroundColor = '#fff';
                document.body.style.color = '#000';
                break;
            case 'blue':
                document.body.style.backgroundColor = '#001f3f';
                document.body.style.color = '#ffffff';
                break;
            default:
                document.body.style.backgroundColor = '#f8f9fa';
                document.body.style.color = '#333';
        }
        saveSettings();
    }

    function resetSettings() {
        state.fontSize = 100;
        state.letterSpacing = 0;
        state.lineSpacing = 0;
        state.isDarkModeActive = false;
        state.isHighContrastActive = false;
        state.isGrayScaleActive = false;
        state.isReadingRulerActive = false;
        state.isMagnifying = false;
        state.tdaMode = false;
        state.dyslexiaMode = false;
        state.epilepsyMode = false;
        state.daltonismMode = 0;
        state.isTextReaderActive = false;
        document.body.style.fontSize = '100%';
        document.body.style.letterSpacing = '0px';
        document.body.style.lineHeight = '';
        document.body.style.filter = 'none';
        saveSettings();
        applySettings();
    }

    init();
    loadSettings();
})();