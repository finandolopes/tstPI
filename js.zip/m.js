document.addEventListener('DOMContentLoaded', function () {
    const state = {
        fontSize: 100,
        letterSpacing: 0,
        lineSpacing: 0,
        isDarkModeActive: false,
        isHighContrastActive: false,
        isGrayScaleActive: false,
        isNegativeContrastActive: false,
        isReadingRulerActive: false,
        isReadingMaskActive: false,
        isMagnifying: false,
        textReaderSpeed: 'normal', // 'normal', 'fast', 'slow'
        saturationLevel: 1,
        epilepsyMode: false,
        tdaMode: false,
        dyslexiaMode: false,
        daltonismMode: 0, // 0: None, 1: Protanopia, 2: Deuteranopia, 3: Tritanopia
        isMotorSkillsModeActive: false,
        isTextReaderActive: false,
        simplifiedMode: false,
        backgroundColor: '#ffffff',
        fontColor: '#000000',
        fontFamily: 'Arial'
    };

    function loadSettings() {
        const savedState = JSON.parse(localStorage.getItem('accessibilityState'));
        if (savedState) Object.assign(state, savedState);
        applySettings();
    }

    function saveSettings() {
        localStorage.setItem('accessibilityState', JSON.stringify(state));
    }

    function applySettings() {
        adjustFontSize(state.fontSize);
        adjustLetterSpacing(state.letterSpacing);
        adjustLineSpacing(state.lineSpacing);
        document.body.style.filter = `saturate(${state.saturationLevel})`;
        document.body.style.backgroundColor = state.backgroundColor;
        document.body.style.color = state.fontColor;
        document.body.style.fontFamily = state.fontFamily;
        if (state.isDarkModeActive) toggleDarkMode(true);
        if (state.isHighContrastActive) toggleHighContrast(true);
        if (state.isGrayScaleActive) toggleGrayScale(true);
        if (state.isNegativeContrastActive) toggleNegativeContrast(true);
        if (state.isReadingRulerActive) toggleReadingRuler(true);
        if (state.isReadingMaskActive) toggleReadingMask(true);
        if (state.isMotorSkillsModeActive) toggleMotorSkillsMode(true);
        if (state.isTextReaderActive) toggleTextReader(true);
        if (state.tdaMode) toggleTDAMode(); // Ativa o modo TDAH se estiver no estado
    }

    function toggleMenu() {
        const menu = document.getElementById('accessibilityMenu');
        menu.classList.toggle('hidden');
    }

    function createAccessibilityButton() {
        const button = document.createElement('button');
        button.innerHTML = '<i class="fas fa-universal-access fa-3x"></i>';
        button.className = 'btn btn-primary accessibility-toggle';
        button.setAttribute('aria-label', 'Open Accessibility Menu');
        button.title = 'Open Accessibility Menu';
        document.body.appendChild(button);
        button.onclick = toggleMenu;
        button.style.position = 'fixed';
        button.style.top = '50%';
        button.style.right = '10px';
        button.style.transform = 'translateY(-50%)';
        button.style.zIndex = '10000';
        button.style.borderRadius = '50%';
        button.style.width = '60px';
        button.style.height = '60px';
        button.style.display = 'flex';
        button.style.justifyContent = 'center';
        button.style.alignItems = 'center';
    }

    function createAccessibilityMenu() {
        const menu = document.createElement('div');
        menu.id = 'accessibilityMenu';
        menu.className = 'accessibility-menu hidden';
        menu.innerHTML = `
            <div class="container-fluid h-100">
                <div class="d-flex justify-content-between align-items-center mb-4">
                    <h3 class="text-primary">Acessibilidade</h3>
                    <button class="btn btn-outline-secondary" onclick="showHelp()">
                        <i class="fas fa-question-circle"></i>
                    </button>
                </div>
                <div class="row">
                    <!-- Ajustes de Fonte -->
                    <div class="col-12 mb-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h5 class="card-title">Ajustes de Fonte</h5>
                                <div class="mb-3">
                                    <label class="form-label">Tamanho da Fonte</label>
                                    <div class="d-flex align-items-center justify-content-center">
                                        <button class="btn btn-outline-secondary" onclick="decreaseFont()">-</button>
                                        <input type="range" min="80" max="200" value="${state.fontSize}" id="fontSizeSlider" class="form-range mx-2" onchange="adjustFontSize(this.value)">
                                        <button class="btn btn-outline-secondary" onclick="increaseFont()">+</button>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Espaçamento entre Caracteres</label>
                                    <div class="d-flex align-items-center justify-content-center">
                                        <button class="btn btn-outline-secondary" onclick="decreaseLetterSpacing()">-</button>
                                        <input type="range" min="0" max="10" value="${state.letterSpacing}" id="letterSpacingSlider" class="form-range mx-2" onchange="adjustLetterSpacing(this.value)">
                                        <button class="btn btn-outline-secondary" onclick="increaseLetterSpacing()">+</button>
                                    </div>
                                </div>
                                <div class="mb-3">
                                    <label class="form-label">Espaçamento entre Linhas</label>
                                    <div class="d-flex align-items-center justify-content-center">
                                        <button class="btn btn-outline-secondary" onclick="decreaseLineSpacing()">-</button>
                                        <input type="range" min="0" max="10" value="${state.lineSpacing}" id="lineSpacingSlider" class="form-range mx-2" onchange="adjustLineSpacing(this.value)">
                                        <button class="btn btn-outline-secondary" onclick="increaseLineSpacing()">+</button>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Modos Visuais -->
                    <div class="col-12 mb-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h5 class="card-title">Contrastes e Modos</h5>
                                <div class="d-flex justify-content-around mb-3">
                                    <div class="text-center icon-button" onclick="toggleDarkMode()">
                                        <i id="darkModeIcon" class="fas fa-moon fa-2x text-primary"></i>
                                        <p class="icon-label">Modo Escuro</p>
                                    </div>
                                    <div class="text-center" onclick="toggleHighContrast()">
                                        <i id="highContrastIcon" class="fas fa-adjust fa-2x text-warning"></i>
                                        <p>Alto Contraste</p>
                                    </div> 
                                    <div class="text-center icon-button" onclick="toggleNegativeContrast()">
                                        <i id="negativeContrastIcon" class="fas fa-exclamation-triangle fa-2x text-danger"></i>
                                        <p class="icon-label">Contraste Negativo</p>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Ferramentas de Leitura -->
                    <div class="col-12 mb-3">
                        <div class="card">
                            <div class="card-body text-center">
                                <h5 class="card-title">Ferramentas de Leitura</h5>
                                <div class="d-flex justify-content-between">
                                    <div class="text-center icon-button" onclick="toggleReadingRulerMode()">
                                        <i id="readingRulerIcon" class="fas fa-grip-lines fa-lg text-info"></i>
                                        <p class="icon-label">Régua</p>
                                    </div>
                                    <div class="text-center icon-button" onclick="toggleReadingMask()">
                                        <i id="readingMaskIcon" class="fas fa-mask fa-lg text-info"></i>
                                        <p class="icon-label">Máscara</p>
                                    </div>
                                    <div class="text-center" onclick="toggleMagnifier()">
                                        <i id="Magnifier" class="fas fa-search-plus fa-lg text-info"></i>
                                        <p>Lupa</p>
                                    </div>
                                </div>
                                <div class="text-center mt-2 icon-button">
                                    <i id="textReaderIcon" class="fas fa-volume-up fa-lg" onclick="toggleTextReader()"></i>
                                    <p class="icon-label">Leitura de Texto <span id="textReaderSpeedLabel">(Normal)</span></p>
                                </div>
                            </div>
                        </div>
                    </div>
                    <!-- Saturação -->
                    <div class="col-12 mb-3">
                        <div class="card">
                            <div class="card-body text-center">
                                
<h5 class="card-title">Saturação</h5>
                                <button class="btn btn-outline-info w-100" onclick="toggleSaturation()">Ajustar Saturação</button>
                            </div>
                        </div>
                    </div>
                    <!-- Modos Especiais -->
                    <div class="col-12">
                        <button class="btn btn-outline-warning w-100 mb-1 btn-sm" onclick="toggleDyslexiaMode()">
                            <i class="fas fa-book-reader"></i> Dislexia
                        </button>
                        <button class="btn btn-outline-success w-100 mb-1 btn-sm" onclick="toggleTDAMode()">
                            <i class="fas fa-brain"></i> TDAH
                        </button>
                        <button class="btn btn-outline-danger w-100 mb-1 btn-sm" onclick="toggleEpilepsyMode()">
                            <i class="fas fa-exclamation-triangle"></i> Modo Anti-Epilepsia
                        </button>
                    </div>
                    <!-- Habilidades Motoras -->
                    <div class="col-12"> 
                        <button class="btn btn-outline-primary w-100 mb-1 btn-sm" onclick="toggleMotorSkillsMode()">
                            <i class="fas fa-wheelchair"></i> Habilidades Motoras
                        </button>
                        <button class="btn btn-outline-secondary w-100 mb-1 btn-sm" onclick="toggleDaltonismMode()">
                            <i class="fas fa-eye"></i> Daltonismo <span id="daltonismModeLabel">(Nenhum)</span>
                        </button>
                    </div>
                    <!-- Resetar Configurações -->
                    <div class="col-12">
                        <button class="btn btn-danger w-100 mt-3" onclick="resetSettings()">
                            <i class="fas fa-undo"></i> Resetar
                        </button>
                    </div>
                </div>
            </div>
        `;
        document.body.appendChild(menu);
    }

    // Estilos CSS para o menu de acessibilidade
    const style = document.createElement('style');
    style.innerHTML = `
        .accessibility-menu {
            background-color: #f8f9fa;
            border: 1px solid #dee2e6;
            border-radius: 8px;
            padding: 20px;
            max-width: 600px;
            margin: auto;
            position: fixed;
            top: 10%;
            right: 10px;
            z-index: 10000;
            overflow-y: auto;
            height: 80%;
        }
        .accessibility-menu.hidden {
            display: none;
        }
        .accessibility-menu h3 {
            font-size: 1.5rem;
            color: #007bff;
        }
        .accessibility-menu .btn {
            border-radius: 10px;
            margin-top: 5px;
        }
        .accessibility-menu .icon-button {
            cursor: pointer;
            transition: transform 0.3s, color 0.3s;
        }
        .accessibility-menu .icon-button:hover {
            transform: scale(1.1);
        }
        .accessibility-menu .icon-label {
            font-size: 0.85rem;
        }
        .accessibility-menu .icon-button.selected i {
            color: #007bff;
        }
    `;
    document.head.appendChild(style);

    // Inicialização do plugin de acessibilidade
    createAccessibilityButton();
    createAccessibilityMenu();
    loadSettings();
});