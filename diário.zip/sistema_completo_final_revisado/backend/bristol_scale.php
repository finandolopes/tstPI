<?php
require 'config.php';
header("Content-Type: application/json");

$user_id = 1; // Substituir pelo usuário logado

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $data = json_decode(file_get_contents("php://input"), true);
    $type = $data["type"];
    $query = "INSERT INTO bristol_scale (user_id, type, date) VALUES (?, ?, NOW())";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $user_id, $type);
    $stmt->execute();
    echo json_encode(["success" => true]);
    exit;
}

$query = "SELECT type, date FROM bristol_scale WHERE user_id = ? ORDER BY date DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result();
$history = $result->fetch_all(MYSQLI_ASSOC);

echo json_encode(["history" => $history]);
?>