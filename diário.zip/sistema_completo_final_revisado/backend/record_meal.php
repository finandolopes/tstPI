<?php
require 'config.php';
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);
$user_id = 1; // Substituir pelo usuário logado

foreach ($data["meals"] as $meal) {
    $query = "INSERT INTO meals (user_id, name, quantity, category) VALUES (?, ?, ?, ?)";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("isis", $user_id, $meal["name"], $meal["quantity"], $meal["category"]);
    $stmt->execute();
}

echo json_encode(["success" => true]);
?>