<?php
require 'config.php';
header("Content-Type: application/json");

$start_date = isset($_GET["start_date"]) ? $_GET["start_date"] : null;
$end_date = isset($_GET["end_date"]) ? $_GET["end_date"] : null;
$user_id = 1; // Substituir pelo usuário logado

// Relatório de Nutrientes Consumidos
$query_nutrition = "SELECT category, SUM(quantity) AS total FROM meals WHERE user_id = ? AND (date BETWEEN ? AND ?) GROUP BY category";
$stmt = $conn->prepare($query_nutrition);
$stmt->bind_param("iss", $user_id, $start_date, $end_date);
$stmt->execute();
$result_nutrition = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Relatório de Sintomas Relacionados
$query_symptoms = "SELECT symptom, COUNT(*) AS occurrences FROM symptoms WHERE user_id = ? AND (date BETWEEN ? AND ?) GROUP BY symptom";
$stmt = $conn->prepare($query_symptoms);
$stmt->bind_param("iss", $user_id, $start_date, $end_date);
$stmt->execute();
$result_symptoms = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Organizar os dados para os gráficos
$nutrition = [];
foreach ($result_nutrition as $row) {
    $nutrition[$row["category"]] = $row["total"];
}

$symptoms = [];
foreach ($result_symptoms as $row) {
    $symptoms[$row["symptom"]] = $row["occurrences"];
}

echo json_encode(["nutrition" => $nutrition, "symptoms" => $symptoms]);
?>