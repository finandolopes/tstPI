<?php
require 'config.php';
header("Content-Type: application/json");

$date = isset($_GET["date"]) ? $_GET["date"] : null;
$user_id = 1; // Substituir pelo usuário logado

if ($date) {
    $query = "SELECT date, name, quantity FROM meals WHERE user_id = ? AND date = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("is", $user_id, $date);
} else {
    $query = "SELECT date, name, quantity FROM meals WHERE user_id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("i", $user_id);
}

$stmt->execute();
$result = $stmt->get_result();
$meals = $result->fetch_all(MYSQLI_ASSOC);

echo json_encode(["meals" => $meals]);
?>