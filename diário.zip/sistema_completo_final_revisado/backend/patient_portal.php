<?php
require 'config.php';
header("Content-Type: application/json");

$user_id = 1; // Substituir pelo usuário logado

// Dados do Paciente
$query = "SELECT name, age, condition, nutrition_plan, medical_advice FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

// Últimos Registros
$query_entries = "SELECT date, description FROM records WHERE user_id = ? ORDER BY date DESC LIMIT 5";
$stmt = $conn->prepare($query_entries);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$entries = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

echo json_encode([
    "name" => $result["name"],
    "age" => $result["age"],
    "condition" => $result["condition"],
    "nutrition_plan" => $result["nutrition_plan"],
    "medical_advice" => $result["medical_advice"],
    "entries" => $entries
]);
?>