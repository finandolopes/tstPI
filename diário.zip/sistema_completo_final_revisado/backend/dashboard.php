<?php
require 'config.php';
header("Content-Type: application/json");

$user_id = $_GET['user_id'];

$query = "SELECT 
            (SELECT COUNT(*) FROM meals WHERE user_id = ?) AS meals,
            (SELECT SUM(amount) FROM water_intake WHERE user_id = ?) AS water,
            (SELECT COUNT(*) FROM symptoms WHERE user_id = ?) AS symptoms";

$stmt = $conn->prepare($query);
$stmt->bind_param("iii", $user_id, $user_id, $user_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

$progress_query = "SELECT date, score FROM progress WHERE user_id = ?";
$stmt = $conn->prepare($progress_query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$progress_result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$dates = array_column($progress_result, "date");
$values = array_column($progress_result, "score");

echo json_encode([
    "meals" => $result["meals"] ?? 0,
    "water" => $result["water"] ?? 0,
    "symptoms" => $result["symptoms"] ?? 0,
    "progress" => ["dates" => $dates, "values" => $values]
]);
?>