<?php
header('Content-Type: application/json');
require '../config/config.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $action = $_POST['action'] ?? '';

    switch ($action) {
        case 'schedule_appointment':
            $doctor_id = $_POST['doctor_id'] ?? '';
            $patient_id = $_POST['patient_id'] ?? '';
            $date = $_POST['date'] ?? '';
            $time = $_POST['time'] ?? '';
            
            $stmt = $conn->prepare("INSERT INTO appointments (doctor_id, patient_id, date, time) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("iiss", $doctor_id, $patient_id, $date, $time);
            if ($stmt->execute()) {
                echo json_encode(["status" => "success", "message" => "Consulta agendada com sucesso"]);
            } else {
                echo json_encode(["status" => "error", "message" => "Erro ao agendar consulta"]);
            }
            break;

        case 'get_appointments':
            $doctor_id = $_POST['doctor_id'] ?? '';
            
            $stmt = $conn->prepare("SELECT * FROM appointments WHERE doctor_id = ? ORDER BY date ASC");
            $stmt->bind_param("i", $doctor_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $appointments = [];
            while ($row = $result->fetch_assoc()) {
                $appointments[] = $row;
            }
            echo json_encode(["status" => "success", "data" => $appointments]);
            break;

        case 'cancel_appointment':
            $appointment_id = $_POST['appointment_id'] ?? '';
            
            $stmt = $conn->prepare("DELETE FROM appointments WHERE id = ?");
            $stmt->bind_param("i", $appointment_id);
            if ($stmt->execute()) {
                echo json_encode(["status" => "success", "message" => "Consulta cancelada com sucesso"]);
            } else {
                echo json_encode(["status" => "error", "message" => "Erro ao cancelar consulta"]);
            }
            break;

        default:
            echo json_encode(["status" => "error", "message" => "Ação inválida"]);
            break;
    }
} else {
    echo json_encode(["status" => "error", "message" => "Método não permitido"]);
}
?>
