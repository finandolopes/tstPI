<?php
require 'config.php';
header("Content-Type: application/json");

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $data = json_decode(file_get_contents("php://input"), true);
    
    if (isset($data['email']) && isset($data['password'])) {
        $email = $data['email'];
        $password = md5($data['password']); // Hash seguro de senha
        
        $query = "SELECT id, name FROM users WHERE email = ? AND password = ?";
        $stmt = $conn->prepare($query);
        $stmt->bind_param("ss", $email, $password);
        $stmt->execute();
        $result = $stmt->get_result();

        if ($result->num_rows > 0) {
            $user = $result->fetch_assoc();
            echo json_encode(["success" => true, "user" => $user]);
        } else {
            echo json_encode(["success" => false, "message" => "Usuário ou senha inválidos"]);
        }
    } else {
        echo json_encode(["success" => false, "message" => "Parâmetros inválidos"]);
    }
}
?>