<?php
header('Content-Type: application/json');
require '../config/config.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $action = $_POST['action'] ?? '';

    switch ($action) {
        case 'generate_report':
            $patient_id = $_POST['patient_id'] ?? '';
            
            $stmt = $conn->prepare("SELECT date, meal, symptoms FROM records WHERE patient_id = ? ORDER BY date ASC");
            $stmt->bind_param("i", $patient_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $report = [];
            while ($row = $result->fetch_assoc()) {
                $report[] = $row;
            }
            
            echo json_encode(["status" => "success", "data" => $report]);
            break;
        
        case 'generate_summary':
            $patient_id = $_POST['patient_id'] ?? '';
            
            $stmt = $conn->prepare("SELECT COUNT(*) as total_meals, COUNT(DISTINCT symptoms) as unique_symptoms FROM records WHERE patient_id = ?");
            $stmt->bind_param("i", $patient_id);
            $stmt->execute();
            $summary = $stmt->get_result()->fetch_assoc();
            
            echo json_encode(["status" => "success", "summary" => $summary]);
            break;

        default:
            echo json_encode(["status" => "error", "message" => "Ação inválida"]);
            break;
    }
} else {
    echo json_encode(["status" => "error", "message" => "Método não permitido"]);
}
?>

