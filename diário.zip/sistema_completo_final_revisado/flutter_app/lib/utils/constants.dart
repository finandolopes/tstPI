class Constants {
  static const String apiUrl = "https://seuservidor.com/api";
  static const String appName = "Diário Alimentar";
}