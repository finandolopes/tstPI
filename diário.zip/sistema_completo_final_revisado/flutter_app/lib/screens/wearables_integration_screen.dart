import 'package:flutter/material.dart';
import 'package:flutter_app/services/api_service.dart';

class WearablesIntegrationScreen extends StatefulWidget {
  @override
  _WearablesIntegrationScreenState createState() => _WearablesIntegrationScreenState();
}

class _WearablesIntegrationScreenState extends State<WearablesIntegrationScreen> {
  bool isConnected = false;
  bool isLoading = false;

  void _connectWearable() async {
    setState(() {
      isLoading = true;
    });

    bool success = await ApiService.connectWearableDevice();

    setState(() {
      isConnected = success;
      isLoading = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(success ? "Dispositivo conectado com sucesso!" : "Falha ao conectar dispositivo."),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Integração com Wearables")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(
              isConnected ? Icons.watch : Icons.watch_later_outlined,
              size: 100,
              color: isConnected ? Colors.green : Colors.grey,
            ),
            SizedBox(height: 20),
            Text(
              isConnected ? "Dispositivo conectado!" : "Nenhum dispositivo conectado.",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            isLoading
                ? CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: _connectWearable,
                    child: Text(isConnected ? "Desconectar Dispositivo" : "Conectar Dispositivo"),
                  ),
          ],
        ),
      ),
    );
  }
}