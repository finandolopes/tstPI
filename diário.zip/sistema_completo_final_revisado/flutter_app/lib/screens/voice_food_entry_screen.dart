import 'package:flutter/material.dart';
import 'package:flutter_speech/flutter_speech.dart';
import 'package:flutter_app/services/food_service.dart';

class VoiceFoodEntryScreen extends StatefulWidget {
  @override
  _VoiceFoodEntryScreenState createState() => _VoiceFoodEntryScreenState();
}

class _VoiceFoodEntryScreenState extends State<VoiceFoodEntryScreen> {
  final SpeechRecognition _speech = SpeechRecognition();
  bool _isListening = false;
  String _recognizedText = "";

  @override
  void initState() {
    super.initState();
    _speech.setAvailabilityHandler((bool result) => setState(() {}));
    _speech.setRecognitionStartedHandler(() => setState(() => _isListening = true));
    _speech.setRecognitionResultHandler((String text) => setState(() => _recognizedText = text));
    _speech.setRecognitionCompleteHandler(() => setState(() => _isListening = false));
    _speech.activate();
  }

  void _startListening() {
    _speech.listen(locale: "pt_BR");
  }

  void _stopListening() {
    _speech.stop();
  }

  void _saveFoodEntry() async {
    if (_recognizedText.isNotEmpty) {
      bool success = await FoodService.addFoodEntry(_recognizedText);
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text(success ? "Alimento registrado com sucesso!" : "Erro ao registrar alimento.")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Registro de Alimentos por Voz")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text("Diga o nome do alimento que deseja registrar:"),
            SizedBox(height: 20),
            Text(
              _recognizedText,
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Row(
              mainAxisAlignment: MainAxisAlignment.center,
              children: [
                FloatingActionButton(
                  onPressed: _isListening ? _stopListening : _startListening,
                  child: Icon(_isListening ? Icons.mic_off : Icons.mic),
                  backgroundColor: _isListening ? Colors.red : Colors.blue,
                ),
                SizedBox(width: 20),
                ElevatedButton(
                  onPressed: _saveFoodEntry,
                  child: Text("Salvar Alimento"),
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}