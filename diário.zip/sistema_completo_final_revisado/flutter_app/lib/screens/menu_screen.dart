import 'package:flutter/material.dart';
import 'package:flutter_app/screens/dashboard_screen.dart';
import 'package:flutter_app/screens/record_meal_screen.dart';
import 'package:flutter_app/screens/sii_checklist_screen.dart';
import 'package:flutter_app/screens/bristol_scale_screen.dart';
import 'package:flutter_app/screens/custom_reports_screen.dart';
import 'package:flutter_app/screens/gamification_screen.dart';
import 'package:flutter_app/screens/premium_subscription_screen.dart';
import 'package:flutter_app/screens/integration_screen.dart';

class MenuScreen extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: ListView(
        padding: EdgeInsets.zero,
        children: [
          DrawerHeader(
            decoration: BoxDecoration(color: Colors.blue),
            child: Text(
              "Menu Principal",
              style: TextStyle(color: Colors.white, fontSize: 24),
            ),
          ),
          _buildMenuItem(context, Icons.dashboard, "Dashboard", DashboardScreen()),
          _buildMenuItem(context, Icons.fastfood, "Registro de Refeições", RecordMealScreen()),
          _buildMenuItem(context, Icons.checklist, "Checklist SII", SIIChecklistScreen()),
          _buildMenuItem(context, Icons.format_shapes, "Escala de Bristol", BristolScaleScreen()),
          _buildMenuItem(context, Icons.analytics, "Relatórios", CustomReportsScreen()),
          _buildMenuItem(context, Icons.emoji_events, "Gamificação", GamificationScreen()),
          _buildMenuItem(context, Icons.stars, "Assinatura Premium", PremiumSubscriptionScreen()),
          _buildMenuItem(context, Icons.sync, "Integrações", IntegrationScreen()),
        ],
      ),
    );
  }

  Widget _buildMenuItem(BuildContext context, IconData icon, String title, Widget screen) {
    return ListTile(
      leading: Icon(icon, color: Colors.blue),
      title: Text(title),
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => screen));
      },
    );
  }
}