import 'package:flutter/material.dart';
import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_app/services/auth_service.dart';

class LoginScreen extends StatefulWidget {
  @override
  _LoginScreenState createState() => _LoginScreenState();
}

class _LoginScreenState extends State<LoginScreen> {
  final TextEditingController _emailController = TextEditingController();
  final TextEditingController _passwordController = TextEditingController();
  bool isLoading = false;

  void _loginWithEmail() async {
    setState(() => isLoading = true);
    bool success = await AuthService.loginWithEmail(
      _emailController.text,
      _passwordController.text,
    );
    setState(() => isLoading = false);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(success ? "Login realizado!" : "Erro ao realizar login.")),
    );
  }

  void _loginWithGoogle() async {
    setState(() => isLoading = true);
    bool success = await AuthService.loginWithGoogle();
    setState(() => isLoading = false);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(success ? "Login com Google realizado!" : "Erro no login.")),
    );
  }

  void _loginWithFacebook() async {
    setState(() => isLoading = true);
    bool success = await AuthService.loginWithFacebook();
    setState(() => isLoading = false);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(success ? "Login com Facebook realizado!" : "Erro no login.")),
    );
  }

  void _loginWithApple() async {
    setState(() => isLoading = true);
    bool success = await AuthService.loginWithApple();
    setState(() => isLoading = false);

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(success ? "Login com Apple realizado!" : "Erro no login.")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Login")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _emailController,
              decoration: InputDecoration(labelText: "E-mail"),
            ),
            TextField(
              controller: _passwordController,
              obscureText: true,
              decoration: InputDecoration(labelText: "Senha"),
            ),
            SizedBox(height: 20),
            isLoading
                ? CircularProgressIndicator()
                : Column(
                    children: [
                      ElevatedButton(
                        onPressed: _loginWithEmail,
                        child: Text("Login com E-mail"),
                      ),
                      SizedBox(height: 10),
                      ElevatedButton.icon(
                        onPressed: _loginWithGoogle,
                        icon: Icon(Icons.login, color: Colors.white),
                        label: Text("Login com Google"),
                        style: ElevatedButton.styleFrom(primary: Colors.red),
                      ),
                      SizedBox(height: 10),
                      ElevatedButton.icon(
                        onPressed: _loginWithFacebook,
                        icon: Icon(Icons.facebook, color: Colors.white),
                        label: Text("Login com Facebook"),
                        style: ElevatedButton.styleFrom(primary: Colors.blue),
                      ),
                      SizedBox(height: 10),
                      ElevatedButton.icon(
                        onPressed: _loginWithApple,
                        icon: Icon(Icons.apple, color: Colors.white),
                        label: Text("Login com Apple"),
                        style: ElevatedButton.styleFrom(primary: Colors.black),
                      ),
                    ],
                  ),
          ],
        ),
      ),
    );
  }
}
