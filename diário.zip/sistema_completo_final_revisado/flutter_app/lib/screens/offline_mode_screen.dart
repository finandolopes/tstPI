import 'package:flutter/material.dart';
import 'package:flutter_app/utils/offline_storage.dart';

class OfflineModeScreen extends StatefulWidget {
  @override
  _OfflineModeScreenState createState() => _OfflineModeScreenState();
}

class _OfflineModeScreenState extends State<OfflineModeScreen> {
  List<Map<String, dynamic>> offlineData = [];

  @override
  void initState() {
    super.initState();
    _loadOfflineData();
  }

  Future<void> _loadOfflineData() async {
    final data = await OfflineStorage.getOfflineData();
    setState(() {
      offlineData = data;
    });
  }

  Future<void> _syncData() async {
    final success = await OfflineStorage.syncOfflineData();
    if (success) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Dados sincronizados com sucesso!")),
      );
      _loadOfflineData(); 
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Falha ao sincronizar. Tente novamente.")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Modo Offline")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: offlineData.isEmpty
                  ? Center(child: Text("Nenhum dado armazenado offline."))
                  : ListView.builder(
                      itemCount: offlineData.length,
                      itemBuilder: (context, index) {
                        final item = offlineData[index];
                        return Card(
                          child: ListTile(
                            title: Text("${item['type']} - ${item['date']}"),
                            subtitle: Text(item['details']),
                          ),
                        );
                      },
                    ),
            ),
            ElevatedButton(
              onPressed: _syncData,
              child: Text("Sincronizar Dados"),
            ),
          ],
        ),
      ),
    );
  }
}