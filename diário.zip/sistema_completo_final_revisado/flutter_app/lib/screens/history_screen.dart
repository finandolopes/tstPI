import 'package:flutter/material.dart';
import 'package:flutter_app/services/api_service.dart';

class HistoryScreen extends StatefulWidget {
  @override
  _HistoryScreenState createState() => _HistoryScreenState();
}

class _HistoryScreenState extends State<HistoryScreen> {
  List<Map<String, dynamic>> meals = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchMealHistory();
  }

  Future<void> _fetchMealHistory() async {
    final response = await ApiService.getMealHistory();
    setState(() {
      meals = response;
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Histórico Alimentar")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: isLoading
            ? Center(child: CircularProgressIndicator())
            : meals.isEmpty
                ? Center(child: Text("Nenhum registro encontrado."))
                : ListView.builder(
                    itemCount: meals.length,
                    itemBuilder: (context, index) {
                      final meal = meals[index];
                      return Card(
                        elevation: 4,
                        margin: EdgeInsets.symmetric(vertical: 8),
                        child: ListTile(
                          title: Text("${meal['meal']} - ${meal['date']}"),
                          subtitle: Column(
                            crossAxisAlignment: CrossAxisAlignment.start,
                            children: [
                              Text("Alimentos: ${meal['food']}"),
                              Text("Sintomas: ${meal['symptoms'] ?? 'Nenhum'}"),
                            ],
                          ),
                          trailing: Icon(Icons.fastfood, color: Colors.blue),
                        ),
                      );
                    },
                  ),
      ),
    );
  }
}