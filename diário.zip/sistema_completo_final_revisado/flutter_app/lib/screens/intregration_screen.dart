import 'package:flutter/material.dart';
import 'package:flutter_app/services/integration_service.dart';

class IntegrationScreen extends StatefulWidget {
  @override
  _IntegrationScreenState createState() => _IntegrationScreenState();
}

class _IntegrationScreenState extends State<IntegrationScreen> {
  bool isGoogleFitConnected = false;
  bool isAppleHealthConnected = false;
  bool isLoading = false;

  Future<void> _connectGoogleFit() async {
    setState(() {
      isLoading = true;
    });

    bool success = await IntegrationService.connectGoogleFit();

    setState(() {
      isGoogleFitConnected = success;
      isLoading = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(success ? "Google Fit conectado!" : "Erro ao conectar Google Fit.")),
    );
  }

  Future<void> _connectAppleHealth() async {
    setState(() {
      isLoading = true;
    });

    bool success = await IntegrationService.connectAppleHealth();

    setState(() {
      isAppleHealthConnected = success;
      isLoading = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(success ? "Apple Health conectado!" : "Erro ao conectar Apple Health.")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Integração com Aplicativos de Saúde")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text("Conecte-se com plataformas de monitoramento de saúde."),
            SizedBox(height: 20),
            isLoading
                ? CircularProgressIndicator()
                : Column(
                    children: [
                      ElevatedButton(
                        onPressed: _connectGoogleFit,
                        child: Text(
                          isGoogleFitConnected ? "Google Fit Conectado" : "Conectar ao Google Fit",
                        ),
                      ),
                      SizedBox(height: 10),
                      ElevatedButton(
                        onPressed: _connectAppleHealth,
                        child: Text(
                          isAppleHealthConnected ? "Apple Health Conectado" : "Conectar ao Apple Health",
                        ),
                      ),
                    ],
                  ),
          ],
        ),
      ),
    );
  }
}