import 'package:flutter/material.dart';

class RecordMealScreen extends StatefulWidget {
  @override
  _RecordMealScreenState createState() => _RecordMealScreenState();
}

class _RecordMealScreenState extends State<RecordMealScreen> {
  final TextEditingController _foodController = TextEditingController();
  final TextEditingController _symptomsController = TextEditingController();
  String _selectedMeal = "Café da manhã";

  void _saveMeal() {
    // Aqui você pode enviar os dados para a API
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Refeição registrada com sucesso!")),
    );
    _foodController.clear();
    _symptomsController.clear();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Registrar Refeição")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            DropdownButtonFormField(
              value: _selectedMeal,
              items: ["Café da manhã", "Almoço", "Jantar", "Lanche"]
                  .map((meal) => DropdownMenuItem(
                        value: meal,
                        child: Text(meal),
                      ))
                  .toList(),
              onChanged: (value) => setState(() => _selectedMeal = value!),
              decoration: InputDecoration(labelText: "Tipo de Refeição"),
            ),
            SizedBox(height: 10),
            TextField(
              controller: _foodController,
              decoration: InputDecoration(labelText: "Alimentos Consumidos"),
            ),
            SizedBox(height: 10),
            TextField(
              controller: _symptomsController,
              decoration: InputDecoration(labelText: "Sintomas (opcional)"),
            ),
            SizedBox(height: 20),
            ElevatedButton(
              onPressed: _saveMeal,
              child: Text("Salvar Refeição"),
            ),
          ],
        ),
      ),
    );
  }
}