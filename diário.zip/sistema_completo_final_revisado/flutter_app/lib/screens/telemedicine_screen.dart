import 'package:flutter/material.dart';
import 'package:flutter_webrtc/flutter_webrtc.dart';
import 'package:flutter_app/services/api_service.dart';

class TelemedicineScreen extends StatefulWidget {
  @override
  _TelemedicineScreenState createState() => _TelemedicineScreenState();
}

class _TelemedicineScreenState extends State<TelemedicineScreen> {
  final _localRenderer = RTCVideoRenderer();
  final _remoteRenderer = RTCVideoRenderer();
  bool isCallActive = false;
  bool isMicOn = true;
  bool isCamOn = true;

  @override
  void initState() {
    super.initState();
    _initializeRenderers();
  }

  Future<void> _initializeRenderers() async {
    await _localRenderer.initialize();
    await _remoteRenderer.initialize();
  }

  Future<void> _startCall() async {
    setState(() {
      isCallActive = true;
    });

    // Simulação de chamada iniciada (Substituir com WebRTC real)
    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text("Iniciando chamada de vídeo..."),
    ));

    // Conectar-se à API para obter dados de chamada (em um caso real)
    await ApiService.startTelemedicineCall();
  }

  Future<void> _endCall() async {
    setState(() {
      isCallActive = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(SnackBar(
      content: Text("Chamada finalizada"),
    ));
  }

  void _toggleMic() {
    setState(() {
      isMicOn = !isMicOn;
    });
  }

  void _toggleCamera() {
    setState(() {
      isCamOn = !isCamOn;
    });
  }

  @override
  void dispose() {
    _localRenderer.dispose();
    _remoteRenderer.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Telemedicina")),
      body: Column(
        children: [
          Expanded(
            child: Stack(
              children: [
                if (isCallActive)
                  Container(
                    color: Colors.black,
                    child: RTCVideoView(_remoteRenderer, mirror: true),
                  )
                else
                  Center(
                    child: Text("Nenhuma chamada ativa", style: TextStyle(fontSize: 18)),
                  ),
                Positioned(
                  bottom: 20,
                  right: 20,
                  child: isCallActive
                      ? Container(
                          width: 100,
                          height: 150,
                          decoration: BoxDecoration(
                            border: Border.all(color: Colors.white),
                          ),
                          child: RTCVideoView(_localRenderer, mirror: true),
                        )
                      : SizedBox(),
                ),
              ],
            ),
          ),
          Padding(
            padding: EdgeInsets.all(10),
            child: Row(
              mainAxisAlignment: MainAxisAlignment.spaceEvenly,
              children: [
                FloatingActionButton(
                  onPressed: _toggleMic,
                  child: Icon(isMicOn ? Icons.mic : Icons.mic_off),
                  backgroundColor: isMicOn ? Colors.green : Colors.red,
                ),
                FloatingActionButton(
                  onPressed: isCallActive ? _endCall : _startCall,
                  child: Icon(isCallActive ? Icons.call_end : Icons.video_call),
                  backgroundColor: isCallActive ? Colors.red : Colors.green,
                ),
                FloatingActionButton(
                  onPressed: _toggleCamera,
                  child: Icon(isCamOn ? Icons.videocam : Icons.videocam_off),
                  backgroundColor: isCamOn ? Colors.blue : Colors.grey,
                ),
              ],
            ),
          ),
        ],
      ),
    );
  }
}