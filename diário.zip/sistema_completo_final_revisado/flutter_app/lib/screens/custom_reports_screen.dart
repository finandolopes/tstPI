import 'package:flutter/material.dart';
import 'package:flutter_app/services/report_service.dart';
import 'package:flutter_file_saver/flutter_file_saver.dart';

class CustomReportsScreen extends StatefulWidget {
  @override
  _CustomReportsScreenState createState() => _CustomReportsScreenState();
}

class _CustomReportsScreenState extends State<CustomReportsScreen> {
  bool isLoading = false;

  Future<void> _exportReport(String format) async {
    setState(() {
      isLoading = true;
    });

    final reportData = await ReportService.generateReport(format);

    setState(() {
      isLoading = false;
    });

    if (reportData != null) {
      await FlutterFileSaver().writeFileAsBytes(
        fileName: "relatorio.$format",
        bytes: reportData,
        ext: format,
      );
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Relatório exportado com sucesso!")),
      );
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Erro ao gerar relatório.")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Relatórios Personalizados")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              "Escolha o formato para exportação do relatório:",
              style: TextStyle(fontSize: 18),
            ),
            SizedBox(height: 20),
            isLoading
                ? CircularProgressIndicator()
                : Column(
                    children: [
                      ElevatedButton(
                        onPressed: () => _exportReport("pdf"),
                        child: Text("Exportar como PDF"),
                      ),
                      SizedBox(height: 10),
                      ElevatedButton(
                        onPressed: () => _exportReport("xlsx"),
                        child: Text("Exportar como Excel"),
                      ),
                    ],
                  ),
          ],
        ),
      ),
    );
  }
}