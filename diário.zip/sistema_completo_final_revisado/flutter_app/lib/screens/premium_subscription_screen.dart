import 'package:flutter/material.dart';
import 'package:flutter_app/services/payment_service.dart';

class PremiumSubscriptionScreen extends StatefulWidget {
  @override
  _PremiumSubscriptionScreenState createState() => _PremiumSubscriptionScreenState();
}

class _PremiumSubscriptionScreenState extends State<PremiumSubscriptionScreen> {
  bool isLoading = false;

  void _subscribe() async {
    setState(() {
      isLoading = true;
    });

    bool success = await PaymentService.subscribeToPremium();

    setState(() {
      isLoading = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(success ? "Assinatura Premium ativada!" : "Erro ao processar pagamento.")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Assinatura Premium")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.center,
          children: [
            Text(
              "Desbloqueie recursos exclusivos!",
              style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Text("✅ Acesso ao Assistente Virtual IA"),
            Text("✅ Relatórios Avançados e Análises de Intolerâncias"),
            Text("✅ Plano Alimentar Personalizado por Nutricionistas"),
            Text("✅ Monitoramento de Saúde com Dispositivos Wearables"),
            SizedBox(height: 30),
            isLoading
                ? CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: _subscribe,
                    child: Text("Assinar Premium - R\$ 29,90/mês"),
                  ),
          ],
        ),
      ),
    );
  }
}