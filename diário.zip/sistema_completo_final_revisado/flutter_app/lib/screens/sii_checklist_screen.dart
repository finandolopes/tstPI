import 'package:flutter/material.dart';
import 'package:flutter_app/services/sii_service.dart';

class SIIChecklistScreen extends StatefulWidget {
  @override
  _SIIChecklistScreenState createState() => _SIIChecklistScreenState();
}

class _SIIChecklistScreenState extends State<SIIChecklistScreen> {
  Map<String, bool> symptoms = {
    "Dor abdominal": false,
    "Distensão abdominal": false,
    "Inchaço": false,
    "Esforço defecatório": false,
    "Urgência defecatória": false,
    "Evacuação incompleta": false,
    "Muco nas fezes": false,
  };

  int bowelMovements = 0;
  String stoolForm = "E"; // E = Endurecidas, D = Diarreicas, M = Mistas
  bool isLoading = false;

  void _saveChecklist() async {
    setState(() {
      isLoading = true;
    });

    bool success = await SIIService.saveSIIChecklist(
      symptoms,
      bowelMovements,
      stoolForm,
    );

    setState(() {
      isLoading = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(success ? "Checklist salvo com sucesso!" : "Erro ao salvar checklist.")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Checklist - Síndrome do Intestino Irritável")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text("Sintomas", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            ...symptoms.keys.map((String key) {
              return CheckboxListTile(
                title: Text(key),
                value: symptoms[key],
                onChanged: (bool? value) {
                  setState(() {
                    symptoms[key] = value!;
                  });
                },
              );
            }).toList(),
            SizedBox(height: 20),
            Text("Número de evacuações por dia:", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            TextField(
              keyboardType: TextInputType.number,
              onChanged: (value) => bowelMovements = int.tryParse(value) ?? 0,
              decoration: InputDecoration(labelText: "Exemplo: 3"),
            ),
            SizedBox(height: 20),
            Text("Forma das fezes:", style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
            DropdownButton<String>(
              value: stoolForm,
              items: [
                DropdownMenuItem(value: "E", child: Text("Endurecidas")),
                DropdownMenuItem(value: "D", child: Text("Diarreicas")),
                DropdownMenuItem(value: "M", child: Text("Mistas")),
              ],
              onChanged: (String? value) {
                setState(() {
                  stoolForm = value!;
                });
              },
            ),
            SizedBox(height: 20),
            isLoading
                ? Center(child: CircularProgressIndicator())
                : ElevatedButton(
                    onPressed: _saveChecklist,
                    child: Text("Salvar Checklist"),
                  ),
          ],
        ),
      ),
    );
  }
}