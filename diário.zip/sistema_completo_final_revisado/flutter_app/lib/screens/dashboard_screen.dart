import 'package:flutter/material.dart';
import 'package:fl_chart/fl_chart.dart';
import 'package:flutter_app/screens/record_meal_screen.dart';
import 'package:flutter_app/screens/sii_checklist_screen.dart';
import 'package:flutter_app/screens/bristol_scale_screen.dart';
import 'package:flutter_app/screens/custom_reports_screen.dart';
import 'package:flutter_app/screens/gamification_screen.dart';
import 'package:flutter_app/services/dashboard_service.dart';

class DashboardScreen extends StatefulWidget {
  @override
  _DashboardScreenState createState() => _DashboardScreenState();
}

class _DashboardScreenState extends State<DashboardScreen> {
  Map<String, dynamic> dashboardData = {};
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchDashboardData();
  }

  Future<void> _fetchDashboardData() async {
    final data = await DashboardService.getDashboardData();
    setState(() {
      dashboardData = data;
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Dashboard")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: isLoading
            ? Center(child: CircularProgressIndicator())
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  _buildSectionTitle("Resumo Diário"),
                  _buildSummaryCard(
                    "Refeições Registradas",
                    dashboardData["meals"] ?? 0,
                    Icons.fastfood,
                  ),
                  _buildSummaryCard(
                    "Consumo de Água",
                    "${dashboardData["water"] ?? 0} mL",
                    Icons.local_drink,
                  ),
                  _buildSummaryCard(
                    "Check-ins de Sintomas",
                    dashboardData["symptoms"] ?? 0,
                    Icons.checklist,
                  ),
                  _buildSectionTitle("Gráficos de Evolução"),
                  Expanded(child: _buildProgressGraph()),
                  _buildSectionTitle("Acesso Rápido"),
                  _buildQuickAccessGrid(),
                ],
              ),
      ),
    );
  }

  Widget _buildSectionTitle(String title) {
    return Padding(
      padding: EdgeInsets.only(top: 16.0, bottom: 8.0),
      child: Text(title, style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
    );
  }

  Widget _buildSummaryCard(String title, dynamic value, IconData icon) {
    return Card(
      elevation: 3,
      child: ListTile(
        leading: Icon(icon, color: Colors.blue, size: 40),
        title: Text(title),
        subtitle: Text(value.toString(), style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
      ),
    );
  }

  Widget _buildProgressGraph() {
    return LineChart(
      LineChartData(
        gridData: FlGridData(show: false),
        titlesData: FlTitlesData(show: false),
        borderData: FlBorderData(show: false),
        lineBarsData: [
          LineChartBarData(
            spots: dashboardData["progress"] ?? [],
            isCurved: true,
            colors: [Colors.blue],
            barWidth: 3,
            isStrokeCapRound: true,
          ),
        ],
      ),
    );
  }

  Widget _buildQuickAccessGrid() {
    return GridView.count(
      shrinkWrap: true,
      crossAxisCount: 2,
      crossAxisSpacing: 10,
      mainAxisSpacing: 10,
      children: [
        _buildDashboardItem(context, Icons.fastfood, "Registro de Refeições", RecordMealScreen()),
        _buildDashboardItem(context, Icons.checklist, "Checklist SII", SIIChecklistScreen()),
        _buildDashboardItem(context, Icons.format_shapes, "Escala de Bristol", BristolScaleScreen()),
        _buildDashboardItem(context, Icons.analytics, "Relatórios", CustomReportsScreen()),
        _buildDashboardItem(context, Icons.emoji_events, "Gamificação", GamificationScreen()),
      ],
    );
  }

  Widget _buildDashboardItem(BuildContext context, IconData icon, String title, Widget screen) {
    return GestureDetector(
      onTap: () {
        Navigator.push(context, MaterialPageRoute(builder: (context) => screen));
      },
      child: Card(
        elevation: 4,
        shape: RoundedRectangleBorder(borderRadius: BorderRadius.circular(10)),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.center,
          children: [
            Icon(icon, size: 40, color: Colors.blue),
            SizedBox(height: 10),
            Text(title, textAlign: TextAlign.center, style: TextStyle(fontSize: 16, fontWeight: FontWeight.bold)),
          ],
        ),
      ),
    );
  }
}
