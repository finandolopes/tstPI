import 'package:flutter/material.dart';
import 'package:flutter_app/services/diet_service.dart';

class DietPersonalizationScreen extends StatefulWidget {
  @override
  _DietPersonalizationScreenState createState() => _DietPersonalizationScreenState();
}

class _DietPersonalizationScreenState extends State<DietPersonalizationScreen> {
  final TextEditingController _calorieGoalController = TextEditingController();
  final TextEditingController _proteinGoalController = TextEditingController();
  final TextEditingController _carbsGoalController = TextEditingController();
  final TextEditingController _fatGoalController = TextEditingController();
  bool isLoading = false;

  void _saveDietPreferences() async {
    setState(() {
      isLoading = true;
    });

    bool success = await DietService.saveDietPreferences({
      "calories": int.tryParse(_calorieGoalController.text) ?? 0,
      "protein": int.tryParse(_proteinGoalController.text) ?? 0,
      "carbs": int.tryParse(_carbsGoalController.text) ?? 0,
      "fat": int.tryParse(_fatGoalController.text) ?? 0,
    });

    setState(() {
      isLoading = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(success ? "Metas nutricionais salvas!" : "Erro ao salvar metas.")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Personalização de Dieta")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _calorieGoalController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: "Meta de Calorias (kcal)"),
            ),
            TextField(
              controller: _proteinGoalController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: "Proteínas (g)"),
            ),
            TextField(
              controller: _carbsGoalController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: "Carboidratos (g)"),
            ),
            TextField(
              controller: _fatGoalController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(labelText: "Gorduras (g)"),
            ),
            SizedBox(height: 20),
            isLoading
                ? CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: _saveDietPreferences,
                    child: Text("Salvar Metas"),
                  ),
          ],
        ),
      ),
    );
  }
}