import 'package:flutter/material.dart';
import 'package:flutter_app/services/api_service.dart';
import 'package:fl_chart/fl_chart.dart';

class WaterIntakeScreen extends StatefulWidget {
  @override
  _WaterIntakeScreenState createState() => _WaterIntakeScreenState();
}

class _WaterIntakeScreenState extends State<WaterIntakeScreen> {
  final TextEditingController _waterController = TextEditingController();
  List<FlSpot> waterData = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchWaterHistory();
  }

  Future<void> _fetchWaterHistory() async {
    final response = await ApiService.getWaterIntake();
    setState(() {
      waterData = response;
      isLoading = false;
    });
  }

  void _saveWaterIntake() async {
    final int amount = int.tryParse(_waterController.text) ?? 0;
    if (amount > 0) {
      await ApiService.addWaterIntake(amount);
      _fetchWaterHistory();
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Registro de água salvo!")),
      );
      _waterController.clear();
    } else {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Por favor, insira um valor válido.")),
      );
    }
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Consumo de Água")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            TextField(
              controller: _waterController,
              keyboardType: TextInputType.number,
              decoration: InputDecoration(
                labelText: "Quantidade (ml)",
                border: OutlineInputBorder(),
              ),
            ),
            SizedBox(height: 10),
            ElevatedButton(
              onPressed: _saveWaterIntake,
              child: Text("Registrar Consumo"),
            ),
            SizedBox(height: 20),
            isLoading
                ? Center(child: CircularProgressIndicator())
                : Expanded(
                    child: LineChart(
                      LineChartData(
                        gridData: FlGridData(show: false),
                        titlesData: FlTitlesData(show: false),
                        borderData: FlBorderData(show: false),
                        lineBarsData: [
                          LineChartBarData(
                            spots: waterData,
                            isCurved: true,
                            colors: [Colors.blue],
                            barWidth: 3,
                            isStrokeCapRound: true,
                          ),
                        ],
                      ),
                    ),
                  ),
          ],
        ),
      ),
    );
  }
}