import 'package:flutter/material.dart';
import 'package:flutter_app/services/bristol_service.dart';

class BristolScaleScreen extends StatefulWidget {
  @override
  _BristolScaleScreenState createState() => _BristolScaleScreenState();
}

class _BristolScaleScreenState extends State<BristolScaleScreen> {
  int selectedType = 0;
  bool isLoading = false;

  void _saveBristolEntry() async {
    if (selectedType == 0) {
      ScaffoldMessenger.of(context).showSnackBar(
        SnackBar(content: Text("Por favor, selecione um tipo de fezes.")),
      );
      return;
    }

    setState(() {
      isLoading = true;
    });

    bool success = await BristolService.saveBristolEntry(selectedType);

    setState(() {
      isLoading = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(success ? "Registro salvo com sucesso!" : "Erro ao registrar.")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Escala de Bristol")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            Text(
              "Selecione o formato das fezes:",
              style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold),
            ),
            SizedBox(height: 20),
            Expanded(
              child: GridView.builder(
                gridDelegate: SliverGridDelegateWithFixedCrossAxisCount(
                  crossAxisCount: 2,
                  crossAxisSpacing: 10,
                  mainAxisSpacing: 10,
                ),
                itemCount: 7,
                itemBuilder: (context, index) {
                  return GestureDetector(
                    onTap: () => setState(() => selectedType = index + 1),
                    child: Container(
                      decoration: BoxDecoration(
                        border: Border.all(
                          color: selectedType == index + 1 ? Colors.blue : Colors.grey,
                          width: selectedType == index + 1 ? 3 : 1,
                        ),
                        borderRadius: BorderRadius.circular(10),
                      ),
                      child: Column(
                        mainAxisAlignment: MainAxisAlignment.center,
                        children: [
                          Image.asset("assets/bristol/${index + 1}.png", height: 80),
                          SizedBox(height: 10),
                          Text("Tipo ${index + 1}"),
                        ],
                      ),
                    ),
                  );
                },
              ),
            ),
            isLoading
                ? CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: _saveBristolEntry,
                    child: Text("Salvar Registro"),
                  ),
          ],
        ),
      ),
    );
  }
}