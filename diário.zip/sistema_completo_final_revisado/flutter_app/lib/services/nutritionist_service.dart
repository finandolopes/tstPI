import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_app/utils/constants.dart';

class NutritionistService {
  static Future<List<Map<String, dynamic>>> getPatients() async {
    final response = await http.get(Uri.parse('${Constants.apiUrl}/nutritionist/patients'));

    if (response.statusCode == 200) {
      return List<Map<String, dynamic>>.from(jsonDecode(response.body));
    } else {
      return [];
    }
  }

  static Future<bool> assignDietPlan(int patientId) async {
    final response = await http.post(
      Uri.parse('${Constants.apiUrl}/nutritionist/assign_plan'),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"patient_id": patientId}),
    );

    return response.statusCode == 200;
  }
}