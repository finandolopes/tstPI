import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_app/utils/constants.dart';

class GamificationService {
  static Future<Map<String, dynamic>> getUserAchievements() async {
    final response = await http.get(Uri.parse('${Constants.apiUrl}/gamification'));

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      return {};
    }
  }
}