import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_app/utils/constants.dart';

class BristolService {
  static Future<bool> saveBristolEntry(int type) async {
    final response = await http.post(
      Uri.parse('${Constants.apiUrl}/bristol_entry'),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"user_id": 123, "type": type}),
    );

    return response.statusCode == 200;
  }
}