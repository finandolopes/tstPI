import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_app/utils/constants.dart';

class DashboardService {
  static Future<Map<String, dynamic>> getDashboardData() async {
    final response = await http.get(Uri.parse('${Constants.apiUrl}/dashboard_data'));

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      return {
        "meals": 0,
        "water": 0,
        "symptoms": 0,
        "progress": [],
      };
    }
  }
}