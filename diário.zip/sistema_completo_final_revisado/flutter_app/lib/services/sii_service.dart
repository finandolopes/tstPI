import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_app/utils/constants.dart';

class SIIService {
  static Future<bool> saveSIIChecklist(
    Map<String, bool> symptoms,
    int bowelMovements,
    String stoolForm,
  ) async {
    final response = await http.post(
      Uri.parse('${Constants.apiUrl}/sii_checklist'),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({
        "user_id": 123, // Substituir pelo ID real do usuário logado
        "symptoms": symptoms,
        "bowel_movements": bowelMovements,
        "stool_form": stoolForm,
      }),
    );

    return response.statusCode == 200;
  }
}