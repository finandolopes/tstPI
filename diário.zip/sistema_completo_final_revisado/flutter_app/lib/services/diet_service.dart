import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_app/utils/constants.dart';

class DietService {
  static Future<bool> saveDietPreferences(Map<String, dynamic> preferences) async {
    final response = await http.post(
      Uri.parse('${Constants.apiUrl}/diet_preferences'),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode(preferences),
    );

    return response.statusCode == 200;
  }
}