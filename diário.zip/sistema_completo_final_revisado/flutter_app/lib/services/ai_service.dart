import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_app/utils/constants.dart';

class AiService {
  static Future<String> askAiAssistant(String question) async {
    final response = await http.post(
      Uri.parse('${Constants.apiUrl}/ai_assistant'),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"question": question}),
    );

    if (response.statusCode == 200) {
      return jsonDecode(response.body)["response"];
    } else {
      return "Erro ao obter resposta da IA.";
    }
  }
}