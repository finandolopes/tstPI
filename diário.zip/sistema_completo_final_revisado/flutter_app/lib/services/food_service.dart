import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_app/utils/constants.dart';

class FoodService {
  static Future<bool> addFoodEntry(String foodName) async {
    final response = await http.post(
      Uri.parse('${Constants.apiUrl}/add_food_entry'),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"food": foodName}),
    );

    return response.statusCode == 200;
  }
}