import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_app/utils/constants.dart';

class ReportService {
  static Future<List<int>?> generateReport(String format) async {
    final response = await http.get(
      Uri.parse('${Constants.apiUrl}/generate_report?format=$format'),
    );

    if (response.statusCode == 200) {
      return response.bodyBytes;
    } else {
      return null;
    }
  }
}