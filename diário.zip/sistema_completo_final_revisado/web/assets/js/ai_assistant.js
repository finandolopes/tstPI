document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("user-input").addEventListener("keypress", function (event) {
        if (event.key === "Enter") {
            sendQuestion();
        }
    });
});

function sendQuestion() {
    const userInput = document.getElementById("user-input").value;
    if (!userInput.trim()) return;

    const chatBox = document.getElementById("chat-messages");
    chatBox.innerHTML += `<div class='text-end text-primary'><strong>Você:</strong> ${userInput}</div>`;

    fetch("/backend/ai_assistant.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ question: userInput })
    })
    .then(response => response.json())
    .then(data => {
        chatBox.innerHTML += `<div class='text-start text-success'><strong>Assistente:</strong> ${data.response}</div>`;
        chatBox.scrollTop = chatBox.scrollHeight;
    });

    document.getElementById("user-input").value = "";
}