document.addEventListener("DOMContentLoaded", function () {
    loadBristolHistory();
});

let selectedType = null;

function selectBristolType(type) {
    selectedType = type;
    alert(`Tipo ${type} selecionado!`);
}

function saveBristol() {
    if (!selectedType) {
        alert("Por favor, selecione um tipo de fezes.");
        return;
    }

    fetch("/backend/bristol_scale.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ type: selectedType })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("Registro salvo com sucesso!");
            loadBristolHistory();
        } else {
            alert("Erro ao salvar.");
        }
    });
}

function loadBristolHistory() {
    fetch("/backend/bristol_scale.php")
        .then(response => response.json())
        .then(data => {
            const list = document.getElementById("bristol-history");
            list.innerHTML = "";
            data.history.forEach(item => {
                list.innerHTML += `<li>${item.date} - Tipo ${item.type}</li>`;
            });
        });
}