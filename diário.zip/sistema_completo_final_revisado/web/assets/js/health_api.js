document.addEventListener("DOMContentLoaded", function () {
    loadHealthData();
});

function syncHealthData(source, steps, heartRate, calories) {
    fetch("/backend/health_api.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ source, steps, heart_rate: heartRate, calories })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(`Dados do ${source} sincronizados com sucesso!`);
            loadHealthData();
        } else {
            alert("Erro ao sincronizar dados.");
        }
    });
}

function loadHealthData() {
    fetch("/backend/health_api.php")
        .then(response => response.json())
        .then(data => {
            const healthList = document.getElementById("health-data");
            healthList.innerHTML = "";
            data.health_data.forEach(entry => {
                healthList.innerHTML += `<li>${entry.date} - ${entry.source}: ${entry.steps} passos, ${entry.heart_rate} BPM, ${entry.calories} kcal</li>`;
            });
        });
}