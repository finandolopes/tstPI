document.addEventListener("DOMContentLoaded", function () {
    loadPatientData();
});

function loadPatientData() {
    fetch("/backend/patient_portal.php")
        .then(response => response.json())
        .then(data => {
            document.getElementById("patient-info").innerHTML = `
                <strong>Nome:</strong> ${data.name} <br>
                <strong>Idade:</strong> ${data.age} anos <br>
                <strong>Condição:</strong> ${data.condition}
            `;

            const entryList = document.getElementById("latest-entries");
            entryList.innerHTML = "";
            data.entries.forEach(entry => {
                entryList.innerHTML += `<li>${entry.date}: ${entry.description}</li>`;
            });

            document.getElementById("nutrition-plan").innerText = data.nutrition_plan;
            document.getElementById("medical-advice").innerText = data.medical_advice;
        });
}