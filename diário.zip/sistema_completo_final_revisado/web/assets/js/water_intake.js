document.addEventListener("DOMContentLoaded", function () {
    loadWaterHistory();
});

function addWater() {
    const amount = document.getElementById("water-amount").value;
    if (!amount) {
        alert("Por favor, insira a quantidade de água.");
        return;
    }

    fetch("/backend/water_intake.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ amount })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("Consumo registrado com sucesso!");
            loadWaterHistory();
        } else {
            alert("Erro ao registrar consumo.");
        }
    });
}

function setWaterGoal() {
    const goal = document.getElementById("water-goal").value;
    if (!goal) {
        alert("Defina uma meta válida.");
        return;
    }

    fetch("/backend/water_goal.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ goal })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("Meta de água definida!");
        } else {
            alert("Erro ao salvar meta.");
        }
    });
}

function setReminder() {
    alert("Lembretes ativados! Você receberá alertas a cada 2 horas.");
    // Simulação: Implementar notificações push
}

function loadWaterHistory() {
    fetch("/backend/water_intake.php")
        .then(response => response.json())
        .then(data => {
            const list = document.getElementById("water-history");
            list.innerHTML = "";
            data.history.forEach(item => {
                list.innerHTML += `<li>${item.date} - ${item.amount} mL</li>`;
            });
        });
}