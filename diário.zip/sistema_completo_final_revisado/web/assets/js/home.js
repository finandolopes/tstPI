document.addEventListener("DOMContentLoaded", function () {
    const todayDate = new Date().toLocaleDateString("pt-BR", {
        weekday: "long",
        day: "2-digit",
        month: "long",
        year: "numeric"
    });

    document.getElementById("current-date").textContent = todayDate;
    
    const icons = document.querySelectorAll(".icon-box");
    
    icons.forEach(icon => {
        icon.addEventListener("click", function () {
            const page = this.getAttribute("data-page");
            window.location.href = page;
        });
    });
});