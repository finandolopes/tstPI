document.addEventListener("DOMContentLoaded", function () {
    const entryList = document.getElementById("entry-list");
    const today = new Date().toLocaleDateString("pt-BR");

    document.getElementById("current-date").textContent = today;

    function addEntry(text) {
        let entry = document.createElement("li");
        entry.className = "entry";
        entry.innerHTML = `${text} <button onclick="removeEntry(this)">Remover</button>`;
        entryList.appendChild(entry);
    }

    document.getElementById("add-entry").addEventListener("click", function () {
        let newEntry = prompt("Digite sua nova entrada:");
        if (newEntry) {
            addEntry(newEntry);
        }
    });

    window.removeEntry = function (button) {
        button.parentElement.remove();
    };
});
