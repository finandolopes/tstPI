function goBack() {
    window.history.back();
}

function openCamera() {
    alert("Abrindo câmera para escanear alimento...");
}

function addMeal() {
    let mealName = document.getElementById('meal-name').value;
    let mealQuantity = document.getElementById('meal-quantity').value;
    let mealCategory = document.getElementById('meal-category').value;

    if (mealName && mealQuantity) {
        let list = document.getElementById('meal-list');
        let listItem = document.createElement('li');
        listItem.textContent = `${mealName} - ${mealQuantity}g (${mealCategory})`;
        listItem.className = "list-group-item";
        list.appendChild(listItem);
    } else {
        alert("Por favor, preencha todos os campos.");
    }
}

function saveMeal() {
    alert("Refeição salva com sucesso!");
}

function startScanner() {
    document.getElementById('barcode-scanner').style.display = 'block';
    Quagga.init({
        inputStream: {
            type: "LiveStream",
            constraints: {
                width: 640,
                height: 480,
                facingMode: "environment"
            },
            target: document.querySelector("#barcode-scanner")
        },
        decoder: {
            readers: ["ean_reader"]
        }
    }, function(err) {
        if (err) {
            console.log(err);
            return;
        }
        Quagga.start();
    });

    Quagga.onDetected(function(data) {
        document.getElementById('barcode-result').textContent = "Código: " + data.codeResult.code;
        Quagga.stop();
    });
}