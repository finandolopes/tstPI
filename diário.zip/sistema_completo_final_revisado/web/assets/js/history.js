document.addEventListener("DOMContentLoaded", function () {
    fetchHistory();
});

function fetchHistory() {
    fetch("/backend/history.php")
        .then(response => response.json())
        .then(data => {
            const list = document.getElementById("history-list");
            list.innerHTML = "";
            data.meals.forEach(meal => {
                list.innerHTML += `<li>${meal.date} - ${meal.name} (${meal.quantity}g)</li>`;
            });
        });
}

function filterHistory() {
    const date = document.getElementById("date-filter").value;
    fetch(`/backend/history.php?date=${date}`)
        .then(response => response.json())
        .then(data => {
            const list = document.getElementById("history-list");
            list.innerHTML = "";
            data.meals.forEach(meal => {
                list.innerHTML += `<li>${meal.date} - ${meal.name} (${meal.quantity}g)</li>`;
            });
        });
}