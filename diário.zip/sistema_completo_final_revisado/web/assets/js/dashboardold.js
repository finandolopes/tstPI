document.addEventListener("DOMContentLoaded", function () {
    fetchDashboardData();
});

function fetchDashboardData() {
    fetch("/backend/dashboard.php")
        .then(response => response.json())
        .then(data => {
            document.getElementById("meals-count").textContent = data.meals;
            document.getElementById("water-intake").textContent = `${data.water} mL`;
            document.getElementById("symptom-checks").textContent = data.symptoms;
            renderProgressChart(data.progress);
        });
}

function renderProgressChart(progressData) {
    let ctx = document.getElementById("progressChart").getContext("2d");
    new Chart(ctx, {
        type: "line",
        data: {
            labels: progressData.dates,
            datasets: [{
                label: "Evolução",
                data: progressData.values,
                borderColor: "#2196F3",
                fill: false,
            }]
        }
    });
}