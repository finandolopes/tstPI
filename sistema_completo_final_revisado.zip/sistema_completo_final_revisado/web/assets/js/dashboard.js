document.addEventListener("DOMContentLoaded", function () {
    const currentDate = new Date();
    updateDay(currentDate);

    document.getElementById("prev-day").addEventListener("click", function () {
        currentDate.setDate(currentDate.getDate() - 1);
        updateDay(currentDate);
    });

    document.getElementById("next-day").addEventListener("click", function () {
        currentDate.setDate(currentDate.getDate() + 1);
        updateDay(currentDate);
    });

    document.getElementById("add-entry").addEventListener("click", function () {
        Swal.fire("Adicionar Registro", "Funcionalidade em desenvolvimento!", "info");
    });
});

function updateDay(date) {
    const options = { day: '2-digit', month: 'long' };
    document.getElementById("current-day").textContent = date.toLocaleDateString('pt-BR', options);
}