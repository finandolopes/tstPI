document.addEventListener("DOMContentLoaded", function () {
    loadReports();
});

function loadReports() {
    const startDate = document.getElementById("start-date").value;
    const endDate = document.getElementById("end-date").value;

    fetch(`/backend/reports.php?start_date=${startDate}&end_date=${endDate}`)
        .then(response => response.json())
        .then(data => {
            renderNutritionChart(data.nutrition);
            renderSymptomsChart(data.symptoms);
        });
}

// Gráfico de Nutrientes
function renderNutritionChart(nutritionData) {
    let ctx = document.getElementById("nutritionChart").getContext("2d");
    new Chart(ctx, {
        type: "pie",
        data: {
            labels: Object.keys(nutritionData),
            datasets: [{
                data: Object.values(nutritionData),
                backgroundColor: ["#FF6384", "#36A2EB", "#FFCE56", "#4CAF50"],
            }]
        }
    });
}

// Gráfico de Sintomas
function renderSymptomsChart(symptomsData) {
    let ctx = document.getElementById("symptomsChart").getContext("2d");
    new Chart(ctx, {
        type: "bar",
        data: {
            labels: Object.keys(symptomsData),
            datasets: [{
                label: "Ocorrências",
                data: Object.values(symptomsData),
                backgroundColor: "#FF6384",
            }]
        }
    });
}

// Exportação para PDF
function exportPDF() {
    alert("Simulação de exportação para PDF. Implementação com jsPDF pode ser feita.");
}

// Exportação para Excel
function exportExcel() {
    alert("Simulação de exportação para Excel. Implementação pode ser feita com SheetJS.");
}