document.addEventListener("DOMContentLoaded", function () {
    loadGamificationData();
});

function loadGamificationData() {
    fetch("/backend/gamification.php")
        .then(response => response.json())
        .then(data => {
            document.getElementById("user-level").innerText = `Nível ${data.level} - ${data.points} pontos`;

            let progressPercent = (data.points % 100) + "%";
            document.getElementById("progress-fill").style.width = progressPercent;
            document.getElementById("progress-text").innerText = `${data.points % 100} / 100 para o próximo nível`;

            const achievementsList = document.getElementById("achievements");
            achievementsList.innerHTML = "";
            data.achievements.forEach(achiev => {
                achievementsList.innerHTML += `<li>${achiev}</li>`;
            });
        });
}