document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("scan-barcode").addEventListener("click", startBarcodeScanner);
});

let mealList = [];

function addMeal() {
    const name = document.getElementById("meal-name").value;
    const quantity = document.getElementById("meal-quantity").value;
    const category = document.getElementById("meal-category").value;

    if (!name || !quantity) {
        alert("Por favor, preencha todos os campos!");
        return;
    }

    mealList.push({ name, quantity, category });
    updateMealList();
}

function updateMealList() {
    const list = document.getElementById("meal-list");
    list.innerHTML = "";
    mealList.forEach((meal, index) => {
        list.innerHTML += `<li>${meal.name} - ${meal.quantity}g (${meal.category}) 
            <button onclick="removeMeal(${index})">❌</button></li>`;
    });
}

function removeMeal(index) {
    mealList.splice(index, 1);
    updateMealList();
}

function saveMeal() {
    fetch("/backend/record_meal.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ meals: mealList })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("Refeição salva com sucesso!");
            mealList = [];
            updateMealList();
        } else {
            alert("Erro ao salvar a refeição.");
        }
    });
}

// Função para iniciar o scanner de código de barras
function startBarcodeScanner() {
    const scannerElement = document.getElementById("barcode-scanner");
    scannerElement.style.display = "block";

    Quagga.init({
        inputStream: {
            type: "LiveStream",
            constraints: {
                width: 640,
                height: 480,
                facingMode: "environment"
            },
            target: scannerElement
        },
        decoder: {
            readers: ["ean_reader"] // Leitor de código de barras EAN-13
        }
    }, function (err) {
        if (err) {
            console.error("Erro ao iniciar scanner: ", err);
            return;
        }
        Quagga.start();
    });

    Quagga.onDetected(function (result) {
        Quagga.stop();
        document.getElementById("barcode-result").innerText = `Produto identificado: ${result.codeResult.code}`;
    });
}