document.addEventListener("DOMContentLoaded", function () {
    checkSubscriptionStatus();
});

function subscribePremium(plan) {
    fetch("/backend/premium.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ plan })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert(`Plano ${plan.toUpperCase()} ativado com sucesso!`);
            checkSubscriptionStatus();
        } else {
            alert("Erro ao ativar o plano. Tente novamente.");
        }
    });
}

function checkSubscriptionStatus() {
    fetch("/backend/premium.php")
        .then(response => response.json())
        .then(data => {
            const statusDiv = document.getElementById("subscription-status");
            if (data.plan) {
                statusDiv.innerHTML = `
                    <strong>Status:</strong> ${data.plan.toUpperCase()} <br>
                    <strong>Expira em:</strong> ${data.expiration}
                `;
            } else {
                statusDiv.innerHTML = `<strong>Você está no plano gratuito.</strong>`;
            }
        });
}