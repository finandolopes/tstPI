function login() {
    let email = document.getElementById("email").value;
    let password = document.getElementById("password").value;

    fetch("/backend/auth.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ action: "login", email, password })
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            window.location.href = "dashboard.html";
        } else {
            alert("Credenciais inválidas. Tente novamente.");
        }
    });
}

function socialLogin(provider) {
    alert(`Login com ${provider} ainda em desenvolvimento.`);
}