document.addEventListener("DOMContentLoaded", function () {
    document.getElementById("login-form")?.addEventListener("submit", function (e) {
        e.preventDefault();
        loginUser();
    });

    document.getElementById("register-form")?.addEventListener("submit", function (e) {
        e.preventDefault();
        registerUser();
    });

    document.getElementById("google-login")?.addEventListener("click", googleAuth);
    document.getElementById("facebook-login")?.addEventListener("click", facebookAuth);
    document.getElementById("apple-login")?.addEventListener("click", appleAuth);
});

function loginUser() {
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    fetch("/backend/auth.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, password })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            localStorage.setItem("user", JSON.stringify(data.user));
            window.location.href = "dashboard.html";
        } else {
            alert("Erro: " + data.message);
        }
    });
}

function registerUser() {
    const name = document.getElementById("name").value;
    const email = document.getElementById("email").value;
    const password = document.getElementById("password").value;

    fetch("/backend/register.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ name, email, password })
    })
    .then(res => res.json())
    .then(data => {
        if (data.success) {
            alert("Conta criada com sucesso! Faça login.");
            window.location.href = "login.html";
        } else {
            alert("Erro: " + data.message);
        }
    });
}

// Simulação de login social (Google, Facebook, Apple)
function googleAuth() {
    alert("Autenticando via Google...");
    window.location.href = "/backend/google_auth.php"; // Implementar Google OAuth no backend
}

function facebookAuth() {
    alert("Autenticando via Facebook...");
    window.location.href = "/backend/facebook_auth.php"; // Implementar Facebook OAuth no backend
}

function appleAuth() {
    alert("Autenticando via Apple ID...");
    window.location.href = "/backend/apple_auth.php"; // Implementar Apple OAuth no backend
}