document.addEventListener("DOMContentLoaded", function () {
    loadSIIHistory();
});

function saveChecklist() {
    const symptoms = [];
    document.querySelectorAll(".symptom-list input:checked").forEach(el => symptoms.push(el.value));

    const data = {
        symptoms,
        food_intake: document.getElementById("food-intake").value,
        water_intake: document.getElementById("water-intake").value,
        exercise: document.getElementById("exercise").value
    };

    fetch("/backend/sii_checklist.php", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify(data)
    })
    .then(response => response.json())
    .then(data => {
        if (data.success) {
            alert("Registro salvo com sucesso!");
            loadSIIHistory();
        } else {
            alert("Erro ao salvar.");
        }
    });
}

function loadSIIHistory() {
    fetch("/backend/sii_checklist.php")
        .then(response => response.json())
        .then(data => {
            const list = document.getElementById("sii-history");
            list.innerHTML = "";
            data.history.forEach(item => {
                list.innerHTML += `<li>${item.date}: ${item.symptoms.join(", ")} - Alimentação: ${item.food_intake}</li>`;
            });
        });
}