<?php
require 'config.php';
header("Content-Type: application/json");

$user_id = 1; // Substituir pelo usuário logado

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $data = json_decode(file_get_contents("php://input"), true);
    $goal = $data["goal"];

    $query = "UPDATE users SET water_goal = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $goal, $user_id);
    $stmt->execute();
    echo json_encode(["success" => true]);
}
?>