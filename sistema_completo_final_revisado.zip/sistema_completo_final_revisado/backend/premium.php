<?php
require 'config.php';
header("Content-Type: application/json");

$user_id = 1; // Substituir pelo usuário logado

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $data = json_decode(file_get_contents("php://input"), true);
    $plan = $data["plan"];
    $expiration = date("Y-m-d", strtotime("+1 month"));

    if ($plan === "anual") {
        $expiration = date("Y-m-d", strtotime("+1 year"));
    }

    $query = "UPDATE users SET plan = ?, expiration = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ssi", $plan, $expiration, $user_id);
    $stmt->execute();

    echo json_encode(["success" => true]);
    exit;
}

$query = "SELECT plan, expiration FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();

echo json_encode([
    "plan" => $result["plan"],
    "expiration" => $result["expiration"]
]);
?>