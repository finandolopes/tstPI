<?php
require 'config.php';
header("Content-Type: application/json");

$data = json_decode(file_get_contents("php://input"), true);
$question = strtolower($data["question"]);
$user_id = 1; // Substituir pelo usuário logado

$response = "";

// Buscar dados do paciente no banco
$query = "SELECT symptoms, food_intake FROM sii_checklist WHERE user_id = ? ORDER BY date DESC LIMIT 10";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$history = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

// Analisar padrões de sintomas e alimentação
$symptoms_count = [];
$foods_count = [];

foreach ($history as $record) {
    $symptoms = explode(", ", $record["symptoms"]);
    foreach ($symptoms as $symptom) {
        $symptoms_count[$symptom] = ($symptoms_count[$symptom] ?? 0) + 1;
    }

    $foods = explode(", ", $record["food_intake"]);
    foreach ($foods as $food) {
        $foods_count[$food] = ($foods_count[$food] ?? 0) + 1;
    }
}

// Determinar sugestões baseadas no histórico
if (stripos($question, "sintomas") !== false) {
    if (!empty($symptoms_count)) {
        arsort($symptoms_count);
        $top_symptoms = array_slice(array_keys($symptoms_count), 0, 3);
        $response = "Os sintomas mais frequentes registrados são: " . implode(", ", $top_symptoms) . ".";
    } else {
        $response = "Nenhum sintoma significativo foi registrado nos últimos dias.";
    }
} elseif (stripos($question, "alimentação") !== false) {
    if (!empty($foods_count)) {
        arsort($foods_count);
        $top_foods = array_slice(array_keys($foods_count), 0, 3);
        $response = "Os alimentos mais consumidos recentemente são: " . implode(", ", $top_foods) . ".";
    } else {
        $response = "Nenhuma informação relevante sobre alimentação foi encontrada.";
    }
} elseif (stripos($question, "intolerância") !== false || stripos($question, "reação") !== false) {
    if (!empty($foods_count) && !empty($symptoms_count)) {
        arsort($symptoms_count);
        arsort($foods_count);
        $top_food = array_keys($foods_count)[0];
        $top_symptom = array_keys($symptoms_count)[0];
        $response = "Existe uma possível relação entre o consumo de '$top_food' e a presença do sintoma '$top_symptom'. Recomendamos uma análise mais detalhada.";
    } else {
        $response = "Ainda não há dados suficientes para identificar padrões de intolerância.";
    }
} else {
    $response = "Desculpe, não consegui entender sua pergunta. Tente perguntar sobre 'sintomas', 'alimentação' ou 'intolerância'.";
}

echo json_encode(["response" => $response]);
?>