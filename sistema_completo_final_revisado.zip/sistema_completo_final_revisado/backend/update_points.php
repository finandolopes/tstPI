<?php
require 'config.php';
header("Content-Type: application/json");

$user_id = 1; // Substituir pelo usuário logado
$action = $_POST["action"];

// Definir pontos para diferentes ações
$points_map = [
    "register_meal" => 10,
    "record_symptom" => 15,
    "complete_checklist" => 20,
    "drink_water" => 5
];

if (array_key_exists($action, $points_map)) {
    $points = $points_map[$action];

    // Atualizar pontos do usuário
    $query = "UPDATE users SET points = points + ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("ii", $points, $user_id);
    $stmt->execute();

    echo json_encode(["success" => true, "points_added" => $points]);
} else {
    echo json_encode(["success" => false, "error" => "Ação inválida"]);
}
?>