<?php
header('Content-Type: application/json');
require '../config/config.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $action = $_POST['action'] ?? '';

    switch ($action) {
        case 'add_patient':
            $name = $_POST['name'] ?? '';
            $age = $_POST['age'] ?? '';
            $gender = $_POST['gender'] ?? '';
            $medical_history = $_POST['medical_history'] ?? '';

            $stmt = $conn->prepare("INSERT INTO patients (name, age, gender, medical_history) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("siss", $name, $age, $gender, $medical_history);
            if ($stmt->execute()) {
                echo json_encode(["status" => "success", "message" => "Paciente registrado com sucesso"]);
            } else {
                echo json_encode(["status" => "error", "message" => "Erro ao registrar paciente"]);
            }
            break;

        case 'get_patients':
            $result = $conn->query("SELECT * FROM patients");
            $patients = [];
            while ($row = $result->fetch_assoc()) {
                $patients[] = $row;
            }
            echo json_encode(["status" => "success", "data" => $patients]);
            break;

        case 'delete_patient':
            $id = $_POST['id'] ?? '';
            $stmt = $conn->prepare("DELETE FROM patients WHERE id = ?");
            $stmt->bind_param("i", $id);
            if ($stmt->execute()) {
                echo json_encode(["status" => "success", "message" => "Paciente removido com sucesso"]);
            } else {
                echo json_encode(["status" => "error", "message" => "Erro ao remover paciente"]);
            }
            break;

        default:
            echo json_encode(["status" => "error", "message" => "Ação inválida"]);
            break;
    }
} else {
    echo json_encode(["status" => "error", "message" => "Método não permitido"]);
}
?>
