<?php
header('Content-Type: application/json');
require '../config/config.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $action = $_POST['action'] ?? '';

    switch ($action) {
        case 'add_record':
            $patient_id = $_POST['patient_id'] ?? '';
            $meal = $_POST['meal'] ?? '';
            $symptoms = $_POST['symptoms'] ?? '';
            $date = $_POST['date'] ?? date('Y-m-d');

            $stmt = $conn->prepare("INSERT INTO records (patient_id, meal, symptoms, date) VALUES (?, ?, ?, ?)");
            $stmt->bind_param("isss", $patient_id, $meal, $symptoms, $date);
            if ($stmt->execute()) {
                echo json_encode(["status" => "success", "message" => "Registro de alimentação e sintomas salvo com sucesso"]);
            } else {
                echo json_encode(["status" => "error", "message" => "Erro ao salvar registro"]);
            }
            break;

        case 'get_records':
            $patient_id = $_POST['patient_id'] ?? '';
            $stmt = $conn->prepare("SELECT * FROM records WHERE patient_id = ? ORDER BY date DESC");
            $stmt->bind_param("i", $patient_id);
            $stmt->execute();
            $result = $stmt->get_result();
            $records = [];
            while ($row = $result->fetch_assoc()) {
                $records[] = $row;
            }
            echo json_encode(["status" => "success", "data" => $records]);
            break;

        default:
            echo json_encode(["status" => "error", "message" => "Ação inválida"]);
            break;
    }
} else {
    echo json_encode(["status" => "error", "message" => "Método não permitido"]);
}
?>
