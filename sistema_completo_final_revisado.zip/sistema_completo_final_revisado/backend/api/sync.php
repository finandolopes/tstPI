<?php
header('Content-Type: application/json');
require '../config/config.php';

$method = $_SERVER['REQUEST_METHOD'];

if ($method === 'POST') {
    $action = $_POST['action'] ?? '';

    switch ($action) {
        case 'analyze_symptoms':
            $patient_id = $_POST['patient_id'] ?? '';
            
            $stmt = $conn->prepare("SELECT symptoms FROM records WHERE patient_id = ? ORDER BY date DESC LIMIT 10");
            $stmt->bind_param("i", $patient_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $symptoms_data = [];
            while ($row = $result->fetch_assoc()) {
                $symptoms_data[] = $row['symptoms'];
            }
            
            if (!empty($symptoms_data)) {
                echo json_encode(["status" => "success", "analysis" => "Padrões detectados nos últimos sintomas registrados.", "data" => $symptoms_data]);
            } else {
                echo json_encode(["status" => "error", "message" => "Nenhum dado disponível para análise"]);
            }
            break;

        case 'suggest_meal_plan':
            $patient_id = $_POST['patient_id'] ?? '';
            
            $stmt = $conn->prepare("SELECT meal FROM records WHERE patient_id = ? ORDER BY date DESC LIMIT 10");
            $stmt->bind_param("i", $patient_id);
            $stmt->execute();
            $result = $stmt->get_result();
            
            $meal_data = [];
            while ($row = $result->fetch_assoc()) {
                $meal_data[] = $row['meal'];
            }
            
            if (!empty($meal_data)) {
                echo json_encode(["status" => "success", "suggestion" => "Sugestão de plano alimentar gerada com base nos últimos registros.", "data" => $meal_data]);
            } else {
                echo json_encode(["status" => "error", "message" => "Nenhum dado disponível para sugestão"]);
            }
            break;

        default:
            echo json_encode(["status" => "error", "message" => "Ação inválida"]);
            break;
    }
} else {
    echo json_encode(["status" => "error", "message" => "Método não permitido"]);
}
?>
