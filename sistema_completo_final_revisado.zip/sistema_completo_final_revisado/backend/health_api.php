<?php
require 'config.php';
header("Content-Type: application/json");

$user_id = 1; // Substituir pelo usuário logado

if ($_SERVER["REQUEST_METHOD"] === "POST") {
    $data = json_decode(file_get_contents("php://input"), true);
    $source = $data["source"];
    $steps = $data["steps"] ?? 0;
    $heart_rate = $data["heart_rate"] ?? 0;
    $calories = $data["calories"] ?? 0;

    $query = "INSERT INTO health_data (user_id, source, steps, heart_rate, calories, date) VALUES (?, ?, ?, ?, ?, NOW())";
    $stmt = $conn->prepare($query);
    $stmt->bind_param("isiii", $user_id, $source, $steps, $heart_rate, $calories);
    $stmt->execute();

    echo json_encode(["success" => true]);
    exit;
}

$query = "SELECT source, steps, heart_rate, calories, date FROM health_data WHERE user_id = ? ORDER BY date DESC LIMIT 10";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

echo json_encode(["health_data" => $result]);
?>