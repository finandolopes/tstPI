<?php
require 'config.php';
header("Content-Type: application/json");

$user_id = 1; // Substituir pelo usuário logado

// Buscar pontuação do usuário
$query = "SELECT points FROM users WHERE id = ?";
$stmt = $conn->prepare($query);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$result = $stmt->get_result()->fetch_assoc();
$points = $result["points"];
$level = floor($points / 100);

// Conquistas desbloqueadas
$query_achievements = "SELECT name FROM achievements WHERE user_id = ?";
$stmt = $conn->prepare($query_achievements);
$stmt->bind_param("i", $user_id);
$stmt->execute();
$achievements = $stmt->get_result()->fetch_all(MYSQLI_ASSOC);

$achievements_list = array_map(function ($achiev) {
    return $achiev["name"];
}, $achievements);

echo json_encode([
    "level" => $level,
    "points" => $points,
    "achievements" => $achievements_list
]);
?>