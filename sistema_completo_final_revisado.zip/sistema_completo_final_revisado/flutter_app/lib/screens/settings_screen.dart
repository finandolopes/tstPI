import 'package:flutter/material.dart';
import 'package:flutter_app/services/api_service.dart';
import 'package:flutter_app/utils/theme.dart';

class SettingsScreen extends StatefulWidget {
  @override
  _SettingsScreenState createState() => _SettingsScreenState();
}

class _SettingsScreenState extends State<SettingsScreen> {
  String _selectedLanguage = "pt";
  bool _darkMode = false;
  bool _notificationsEnabled = true;
  bool isLoading = false;

  @override
  void initState() {
    super.initState();
    _loadSettings();
  }

  Future<void> _loadSettings() async {
    final settings = await ApiService.getUserSettings();
    setState(() {
      _selectedLanguage = settings["language"];
      _darkMode = settings["darkMode"];
      _notificationsEnabled = settings["notifications"];
    });
  }

  Future<void> _saveSettings() async {
    setState(() {
      isLoading = true;
    });

    await ApiService.saveUserSettings({
      "language": _selectedLanguage,
      "darkMode": _darkMode,
      "notifications": _notificationsEnabled,
    });

    setState(() {
      isLoading = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text("Configurações salvas com sucesso!")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Configurações")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            DropdownButtonFormField(
              value: _selectedLanguage,
              items: [
                DropdownMenuItem(value: "pt", child: Text("Português")),
                DropdownMenuItem(value: "en", child: Text("Inglês")),
                DropdownMenuItem(value: "es", child: Text("Espanhol")),
              ],
              onChanged: (value) => setState(() => _selectedLanguage = value.toString()),
              decoration: InputDecoration(labelText: "Idioma"),
            ),
            SwitchListTile(
              title: Text("Modo Escuro"),
              value: _darkMode,
              onChanged: (value) => setState(() => _darkMode = value),
            ),
            SwitchListTile(
              title: Text("Notificações"),
              value: _notificationsEnabled,
              onChanged: (value) => setState(() => _notificationsEnabled = value),
            ),
            SizedBox(height: 20),
            isLoading
                ? CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: _saveSettings,
                    child: Text("Salvar Configurações"),
                  ),
          ],
        ),
      ),
    );
  }
}