import 'package:flutter/material.dart';
import 'package:flutter_app/services/api_service.dart';

class SymptomsChecklistScreen extends StatefulWidget {
  @override
  _SymptomsChecklistScreenState createState() => _SymptomsChecklistScreenState();
}

class _SymptomsChecklistScreenState extends State<SymptomsChecklistScreen> {
  Map<String, bool> symptoms = {
    "Dor Abdominal": false,
    "Inchaço": false,
    "Diarreia": false,
    "Constipação": false,
    "Náusea": false,
    "Refluxo": false,
    "Fadiga": false,
  };
  bool isLoading = false;

  void _saveSymptoms() async {
    setState(() {
      isLoading = true;
    });

    bool success = await ApiService.saveSymptoms(symptoms);

    setState(() {
      isLoading = false;
    });

    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(
        content: Text(success ? "Sintomas salvos com sucesso!" : "Erro ao salvar sintomas."),
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Checklist de Sintomas")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            Expanded(
              child: ListView(
                children: symptoms.keys.map((String key) {
                  return CheckboxListTile(
                    title: Text(key),
                    value: symptoms[key],
                    onChanged: (bool? value) {
                      setState(() {
                        symptoms[key] = value!;
                      });
                    },
                  );
                }).toList(),
              ),
            ),
            isLoading
                ? CircularProgressIndicator()
                : ElevatedButton(
                    onPressed: _saveSymptoms,
                    child: Text("Salvar Sintomas"),
                  ),
          ],
        ),
      ),
    );
  }
}