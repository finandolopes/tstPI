import 'package:flutter/material.dart';
import 'package:flutter_app/services/nutritionist_service.dart';

class NutritionistPortalScreen extends StatefulWidget {
  @override
  _NutritionistPortalScreenState createState() => _NutritionistPortalScreenState();
}

class _NutritionistPortalScreenState extends State<NutritionistPortalScreen> {
  List<Map<String, dynamic>> patients = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchPatients();
  }

  Future<void> _fetchPatients() async {
    final data = await NutritionistService.getPatients();
    setState(() {
      patients = data;
      isLoading = false;
    });
  }

  void _assignDietPlan(int patientId) async {
    bool success = await NutritionistService.assignDietPlan(patientId);
    ScaffoldMessenger.of(context).showSnackBar(
      SnackBar(content: Text(success ? "Plano alimentar enviado!" : "Erro ao enviar plano.")),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Portal do Nutricionista")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: isLoading
            ? Center(child: CircularProgressIndicator())
            : ListView.builder(
                itemCount: patients.length,
                itemBuilder: (context, index) {
                  final patient = patients[index];
                  return Card(
                    child: ListTile(
                      title: Text(patient["name"]),
                      subtitle: Text("Idade: ${patient["age"]} - Diagnóstico: ${patient["diagnosis"]}"),
                      trailing: ElevatedButton(
                        onPressed: () => _assignDietPlan(patient["id"]),
                        child: Text("Enviar Plano"),
                      ),
                    ),
                  );
                },
              ),
      ),
    );
  }
}