import 'package:flutter/material.dart';
import 'package:flutter_app/services/gamification_service.dart';

class GamificationScreen extends StatefulWidget {
  @override
  _GamificationScreenState createState() => _GamificationScreenState();
}

class _GamificationScreenState extends State<GamificationScreen> {
  Map<String, dynamic> achievements = {};
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _loadAchievements();
  }

  Future<void> _loadAchievements() async {
    final data = await GamificationService.getUserAchievements();
    setState(() {
      achievements = data;
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Gamificação")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: isLoading
            ? Center(child: CircularProgressIndicator())
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Conquistas",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  achievements.isEmpty
                      ? Text("Nenhuma conquista desbloqueada ainda.")
                      : Expanded(
                          child: ListView.builder(
                            itemCount: achievements.length,
                            itemBuilder: (context, index) {
                              String key = achievements.keys.elementAt(index);
                              return Card(
                                child: ListTile(
                                  leading: Icon(
                                    Icons.emoji_events,
                                    color: achievements[key] ? Colors.green : Colors.grey,
                                  ),
                                  title: Text(key),
                                  subtitle: Text(achievements[key]
                                      ? "Conquistado!"
                                      : "Ainda não atingido"),
                                ),
                              );
                            },
                          ),
                        ),
                ],
              ),
      ),
    );
  }
}