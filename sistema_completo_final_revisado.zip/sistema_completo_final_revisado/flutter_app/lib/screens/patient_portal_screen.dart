import 'package:flutter/material.dart';
import 'package:flutter_app/services/api_service.dart';

class PatientPortalScreen extends StatefulWidget {
  @override
  _PatientPortalScreenState createState() => _PatientPortalScreenState();
}

class _PatientPortalScreenState extends State<PatientPortalScreen> {
  Map<String, dynamic> patientData = {};
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchPatientData();
  }

  Future<void> _fetchPatientData() async {
    final data = await ApiService.getPatientData();
    setState(() {
      patientData = data;
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Portal do Paciente")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: isLoading
            ? Center(child: CircularProgressIndicator())
            : Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(
                    "Dados do Paciente",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  Text("Nome: ${patientData['name']}"),
                  Text("Idade: ${patientData['age']} anos"),
                  Text("Histórico Clínico: ${patientData['medical_history']}"),
                  SizedBox(height: 20),
                  Text(
                    "Planos de Tratamento",
                    style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold),
                  ),
                  SizedBox(height: 10),
                  patientData["treatment_plans"] == null
                      ? Text("Nenhum plano de tratamento registrado.")
                      : ListView.builder(
                          shrinkWrap: true,
                          itemCount: patientData["treatment_plans"].length,
                          itemBuilder: (context, index) {
                            final plan = patientData["treatment_plans"][index];
                            return Card(
                              child: ListTile(
                                title: Text(plan["title"]),
                                subtitle: Text(plan["description"]),
                              ),
                            );
                          },
                        ),
                ],
              ),
      ),
    );
  }
}