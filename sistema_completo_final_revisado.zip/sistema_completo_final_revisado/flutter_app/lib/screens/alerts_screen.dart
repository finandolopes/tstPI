import 'package:flutter/material.dart';
import 'package:flutter_app/services/api_service.dart';

class AlertsScreen extends StatefulWidget {
  @override
  _AlertsScreenState createState() => _AlertsScreenState();
}

class _AlertsScreenState extends State<AlertsScreen> {
  List<Map<String, String>> alerts = [];
  bool isLoading = true;

  @override
  void initState() {
    super.initState();
    _fetchAlerts();
  }

  Future<void> _fetchAlerts() async {
    final response = await ApiService.getAlerts();
    setState(() {
      alerts = response;
      isLoading = false;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Alertas e Notificações")),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: isLoading
            ? Center(child: CircularProgressIndicator())
            : alerts.isEmpty
                ? Center(child: Text("Nenhum alerta disponível."))
                : ListView.builder(
                    itemCount: alerts.length,
                    itemBuilder: (context, index) {
                      final alert = alerts[index];
                      return Card(
                        elevation: 4,
                        margin: EdgeInsets.symmetric(vertical: 8),
                        child: ListTile(
                          leading: Icon(Icons.notification_important, color: Colors.red),
                          title: Text(alert['title']!),
                          subtitle: Text(alert['message']!),
                          trailing: Text(alert['date']!),
                        ),
                      );
                    },
                  ),
      ),
    );
  }
}