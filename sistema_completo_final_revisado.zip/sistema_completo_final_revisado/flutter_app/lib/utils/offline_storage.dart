import 'package:shared_preferences/shared_preferences.dart';
import 'dart:convert';

class OfflineStorage {
  static Future<void> saveOfflineData(List<Map<String, dynamic>> data) async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String jsonData = jsonEncode(data);
    await prefs.setString('offline_data', jsonData);
  }

  static Future<List<Map<String, dynamic>>> getOfflineData() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    String? jsonData = prefs.getString('offline_data');
    if (jsonData != null) {
      return List<Map<String, dynamic>>.from(jsonDecode(jsonData));
    }
    return [];
  }

  static Future<bool> syncOfflineData() async {
    List<Map<String, dynamic>> data = await getOfflineData();
    // Simulação de envio para a API (implementar ApiService)
    if (data.isNotEmpty) {
      await saveOfflineData([]); // Limpa os dados locais após sincronização
      return true;
    }
    return false;
  }
}