import 'package:http/http.dart' as http;
import 'dart:convert';

class NutritionService {
  static Future<Map<String, dynamic>> getFoodNutrition(String barcode) async {
    final response = await http.get(Uri.parse('https://world.openfoodfacts.org/api/v0/product/$barcode.json'));

    if (response.statusCode == 200) {
      return jsonDecode(response.body)["product"] ?? {};
    } else {
      return {};
    }
  }
}