import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_app/utils/constants.dart';

class ApiService {
  static Future<List<dynamic>> getMealHistory() async {
    final response = await http.get(Uri.parse('${Constants.apiUrl}/meal_history'));

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      return [];
    }
  }

  static Future<Map<String, dynamic>> getPatientData() async {
    final response = await http.get(Uri.parse('${Constants.apiUrl}/patient_data'));

    if (response.statusCode == 200) {
      return jsonDecode(response.body);
    } else {
      return {};
    }
  }

  static Future<List<Map<String, dynamic>>> getReports() async {
    final response = await http.get(Uri.parse('${Constants.apiUrl}/reports'));

    if (response.statusCode == 200) {
      return List<Map<String, dynamic>>.from(jsonDecode(response.body));
    } else {
      return [];
    }
  }

  static Future<bool> startTelemedicineCall() async {
    final response = await http.post(Uri.parse('${Constants.apiUrl}/telemedicine/start'));

    return response.statusCode == 200;
  }

  static Future<bool> connectWearableDevice() async {
    final response = await http.post(Uri.parse('${Constants.apiUrl}/wearables/connect'));

    return response.statusCode == 200;
  }
}