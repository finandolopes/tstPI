import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_app/utils/constants.dart';

class PaymentService {
  static Future<bool> subscribeToPremium() async {
    final response = await http.post(
      Uri.parse('${Constants.apiUrl}/subscribe_premium'),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"user_id": 123}), // Substituir pelo ID real do usuário logado
    );

    return response.statusCode == 200;
  }
}