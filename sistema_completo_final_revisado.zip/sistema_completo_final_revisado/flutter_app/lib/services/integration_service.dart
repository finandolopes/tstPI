import 'package:http/http.dart' as http;
import 'dart:convert';
import 'package:flutter_app/utils/constants.dart';

class IntegrationService {
  static Future<bool> connectGoogleFit() async {
    final response = await http.post(
      Uri.parse('${Constants.apiUrl}/connect_google_fit'),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"user_id": 123}), // Substituir pelo ID real do usuário logado
    );

    return response.statusCode == 200;
  }

  static Future<bool> connectAppleHealth() async {
    final response = await http.post(
      Uri.parse('${Constants.apiUrl}/connect_apple_health'),
      headers: {"Content-Type": "application/json"},
      body: jsonEncode({"user_id": 123}),
    );

    return response.statusCode == 200;
  }
}