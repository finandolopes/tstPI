USE GLPI;
SELECT 
t.id 										AS 'ID_Chamado',
case when t.entities_id = '0' then 'CROSS'
	 when t.entities_id = '2' then 'Manutenção'
     when t.entities_id = '3' then 'Informação'
     when t.entities_id = '4' then 'T.I'
     when t.entities_id = '5' then 'Cadastrox'
     when t.entities_id = '6' then 'NEP'
     when t.entities_id = '7' then 'Implantação'
	 when t.entities_id = '8' then 'Monitoramento'
     when t.entities_id = '9' then 'SIRESP'
     when t.entities_id = '10' then 'Monitoramento'
     when t.entities_id = '11' then 'T.I_Sistemas'
end 										AS 'Centro_de_custo',
case when t.entities_id = '0' then 'Nº Chamados CROSS'
	 when t.entities_id = '2' then 'Nº Chamados Manutenção'
     when t.entities_id = '3' then 'Nº Chamados Informação'
     when t.entities_id = '4' then 'Nº Chamados T.I'
     when t.entities_id = '5' then 'Nº Chamados Cadastrox'
     when t.entities_id = '6' then 'Nº Chamados NEP'
     when t.entities_id = '7' then 'Nº Chamados Implantação'
	 when t.entities_id = '8' then 'Nº Chamados Monitoramento'
     when t.entities_id = '9' then 'Nº Chamados SIRESP'
     when t.entities_id = '10' then 'Nº Chamados Monitoramento'
     when t.entities_id = '11' then 'Nº Chamados T.I_Sistemas'
end 										AS 'Produto',
t.name 										AS 'Descrição_Chamado',
t.urgency,
t.priority,
t.impact,
L.Urgencia,
L.Prioridade,
L.Impacto,
L.Pontuacao,
c.completename 								AS 'Categoria_chamado',
tp.desc_type 								AS 'Tipo',
t.internal_time_to_resolve 					AS 'Temp_int_solução',
t.internal_time_to_own 						AS 'Temp_int_atendimento', 
t.time_to_resolve 							AS 'Temp_solução', 
t.time_to_own 								AS 'Temp_atendimento', 
t.date  									AS 'Dt_abertura_chamado', 
t.solvedate 								AS 'Dt_solucao_chamado', 
t.closedate 								AS 'Dt_fechamento_chamado', 
t.date_mod									AS 'Dt_ultima_atualizacao', 
s.descricao                                	AS 'Descrição_status_chamado', 
CONCAT(u.firstname,' ',u.realname) 			AS 'Nome_abriu_chamado', 
A.REQUERENTE								AS 'Nome_requerente',
A.groups_id									AS 'Id_requerente',
Z.OBSERVADOR								AS 'Nome_observador',
X.ATRIBUIDO									AS 'Nome_atribuido',
Y.groups_id									AS 'Id_grupo_requerente',
case when  Y.GRUPO_REQUERENTE is null and Y.groups_id in ('0','3')	 		    THEN 'SES'
	 when  Y.GRUPO_REQUERENTE like '%SESSP%' OR Y.GRUPO_REQUERENTE like '%SES%' THEN 'SES'
	 when  Y.GRUPO_REQUERENTE like 'DRS%' and LOCATE('>', Y.GRUPO_REQUERENTE) > 0  then LEFT (Y.GRUPO_REQUERENTE,LOCATE('>',Y.GRUPO_REQUERENTE)-2)
	 when  Y.GRUPO_REQUERENTE like 'DRS%' and LOCATE('>', Y.GRUPO_REQUERENTE) < 1  then Y.GRUPO_REQUERENTE
	else 'CROSS' 
	END 									AS 'Nome_grupo_requerente',    
F.GRUPO_ATRIBUIDO							AS 'Nome_grupo_atribuido',
K.GRUPO_OBSERVADOR							AS 'Nome_grupo_observador',
case when tt.id is null then t.id 
	 else tt.id 
     end 									AS 'ID_tarefa',
REPLACE(REPLACE(REPLACE(tt.content,'&lt;br /&gt;',''),'&lt;p&gt;',''),'&lt;/p&gt;','') AS 'Descrição_tarefa',
CONCAT(ut.firstname,' ',ut.realname) 		AS 'Nome_requerente_tarefa',
 
case when tt.end is null and LOCATE(',', X.ATRIBUIDO) > 0 then LEFT (X.ATRIBUIDO,LOCATE(',',X.ATRIBUIDO)-1)
     when tt.end is null then X.ATRIBUIDO
     else CONCAT(utt.firstname,' ',utt.realname)
     end  									AS 'Nome_responsavel_tarefa',
tt.date 									AS 'Data_abertura_tarefa',  
tt.begin          							AS 'Data_execucao_tarefa',
case when tt.end is null then t.solvedate
	 else tt.end    	
     end									AS 'Data_finalizacao_tarefa',
tt.state									AS 'ID_Status_tarefa', 
tc.name 									AS 'Nivel_da_tarefa',
case when tt.state is null and tt.end is not null or t.closedate is not null then 'Fechada'
	 when tt.state is null and tt.end is null then 'Aberta'
     when tt.state = 1 then 'Aberta'
	 when tt.state = 2 then 'Fechada'
	 else null    	
     end									AS 'Status_tarefa',
case when tt.id is null then L.Pontuacao
	 when tc.name is null then '1'
	 else tc.comment end 						AS   'pontuacao_tarefa',
gr.name										AS 'Modulo_tarefa'
 
FROM GLPI.glpi_tickets			as t
LEFT JOIN glpi_users 			as u 		ON u.id=t.users_id_recipient
LEFT JOIN glpi_itilcategories 	AS c		ON c.id=t.itilcategories_id
LEFT JOIN glpi_tickets_status 	AS s		on s.id=t.status
left join glpi_tickettasks 		as tt 		on tt.tickets_id=t.id
left join glpi_groups			as gr		on gr.id = tt.groups_id_tech
left JOIN glpi_users 			as ut 		ON ut.id=tt.users_id
left JOIN glpi_users			as utt 		ON utt.id=tt.users_id_tech
left join (SELECT idglpi_Types,
			CASE WHEN cod_type = '3' THEN '111'
			ELSE cod_type
			END AS cod_type,
			CASE WHEN desc_type = 'Melhorias' THEN 'Melhoria'
			ELSE desc_type
			END AS desc_type
			FROM GLPI.glpi_Types)	as tp 		on tp.cod_type=t.type
left join glpi_taskcategories 	as tc 		ON tt.taskcategories_id =  tc.id
left join (SELECT tickets_id,GROUP_CONCAT(nome) AS REQUERENTE,groups_id
			FROM 
			(SELECT B.tickets_id,B.users_id,CONCAT(u.firstname,' ',u.realname) as 'nome',u.groups_id
			FROM GLPI.glpi_tickets_users B
			LEFT JOIN glpi_users AS u  ON u.id =  B.users_id
			where B.type = '1') AS A
			GROUP BY tickets_id)	 AS	A		ON 	A.tickets_id = t.id	
left join (SELECT tickets_id,GROUP_CONCAT(nome) AS ATRIBUIDO 
			FROM 
			(SELECT B.tickets_id,B.users_id AS REQUERENTE,CONCAT(u.firstname,' ',u.realname) as 'nome'
			FROM GLPI.glpi_tickets_users B
			LEFT JOIN glpi_users AS u  ON u.id =  B.users_id
			where B.type = '2') AS A
			GROUP BY tickets_id)	 AS	X		ON 	X.tickets_id = t.id	
left join (SELECT tickets_id,GROUP_CONCAT(nome) AS OBSERVADOR 
			FROM 
			(SELECT B.tickets_id,B.users_id AS REQUERENTE,CONCAT(u.firstname,' ',u.realname) as 'nome'
			FROM GLPI.glpi_tickets_users B
			LEFT JOIN glpi_users AS u  ON u.id =  B.users_id
			where B.type = '3') AS A
			GROUP BY tickets_id)	 AS	Z		ON 	Z.tickets_id = t.id	
left join 	(SELECT tickets_id,GROUP_CONCAT(completename) AS GRUPO_REQUERENTE,groups_id FROM (SELECT B.tickets_id,B.groups_id,u.completename
			FROM GLPI.glpi_groups_tickets B
			LEFT JOIN glpi_groups AS u  ON u.id =  B.groups_id
			where B.type = '1') AS A
			GROUP BY tickets_id)  AS Y        ON 	Y.tickets_id = t.id				
left join 	(SELECT tickets_id,GROUP_CONCAT(name) AS GRUPO_ATRIBUIDO FROM (SELECT B.tickets_id,B.groups_id,u.name
			FROM GLPI.glpi_groups_tickets B
			LEFT JOIN glpi_groups AS u  ON u.id =  B.groups_id
			where B.type = '2') AS A
			GROUP BY tickets_id) AS F		ON 	F.tickets_id = t.id				
left join 	(SELECT tickets_id,GROUP_CONCAT(name) AS GRUPO_OBSERVADOR FROM (SELECT B.tickets_id,B.groups_id,u.name
			FROM GLPI.glpi_groups_tickets B
			LEFT JOIN glpi_groups AS u  ON u.id =  B.groups_id
			where B.type = '3') AS A
			GROUP BY tickets_id) AS K		ON 	K.tickets_id = t.id	
left join (select * , (Urgencia + Impacto + Prioridade) AS 'Soma',
	   case 	
       when (Urgencia + Impacto + Prioridade) between '8' and '9' then '3'
	   when (Urgencia + Impacto + Prioridade) between '6' and '7' then '2'
	   when (Urgencia + Impacto + Prioridade) between '3' and '5' then '1'
	   end 								AS 'Pontuacao'
       from  (select id,case when urgency = '1' or urgency = '2' then '1'
	   when urgency = '4' or urgency = '3' then '2'
	   when urgency = '6' or urgency = '5' then '3'
	   end									AS 'Urgencia',
case   when impact = '1' or impact = '2' then '1'
	   when impact = '4' or impact = '3' then '2'
	   when impact = '6' or impact = '5' then '3'
	   end									AS 'Impacto', 
case   when priority = '1' or priority = '2' then '1'
	   when priority = '4' or priority = '3' then '2'
	   when priority = '6' or priority = '5' then '3'
	   end									AS 'Prioridade'
       from GLPI.glpi_tickets) AS J) AS L 		ON 	L.id = t.id	
 
where t.entities_id='4'
and t.date > '2022-05-31 23:59:59'