<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório GLPI</title>
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.1.0/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="css/custom.css">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
        </ul>
    </nav>
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <a href="#" class="brand-link">
            <span class="brand-text font-weight-light">Relatório GLPI</span>
        </a>
        <div class="sidebar">
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                    <li class="nav-item">
                        <a href="index.php" class="nav-link active">
                            <i class="nav-icon fas fa-home"></i>
                            <p>Home</p>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Relatório de Produtividade</h1>
                    </div>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="container-fluid">
                <form id="filterForm">
                    <div class="row">
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="status">Status</label>
                                <select class="form-control" id="status" name="status">
                                    <option value="">Todos</option>
                                    <option value="Aberta">Aberta</option>
                                    <option value="Fechada">Fechada</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="date_from">Data de Início</label>
                                <input type="date" class="form-control" id="date_from" name="date_from">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="date_to">Data de Fim</label>
                                <input type="date" class="form-control" id="date_to" name="date_to">
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="centro_custo">Centro de Custo</label>
                                <select class="form-control" id="centro_custo" name="centro_custo">
                                    <option value="">Todos</option>
                                    <option value="CROSS">CROSS</option>
                                    <option value="Manutenção">Manutenção</option>
                                    <option value="Informação">Informação</option>
                                    <option value="T.I">T.I</option>
                                    <option value="Cadastrox">Cadastrox</option>
                                    <option value="NEP">NEP</option>
                                    <option value="Implantação">Implantação</option>
                                    <option value="Monitoramento">Monitoramento</option>
                                    <option value="SIRESP">SIRESP</option>
                                    <option value="T.I_Sistemas">T.I_Sistemas</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label for="origem">Origem</label>
                                <select class="form-control" id="origem" name="origem">
                                    <option value="">Todos</option>
                                    <option value="Nº Chamados CROSS">Nº Chamados CROSS</option>
                                    <option value="Nº Chamados Manutenção">Nº Chamados Manutenção</option>
                                    <option value="Nº Chamados Informação">Nº Chamados Informação</option>
                                    <option value="Nº Chamados T.I">Nº Chamados T.I</option>
                                    <option value="Nº Chamados Cadastrox">Nº Chamados Cadastrox</option>
                                    <option value="Nº Chamados NEP">Nº Chamados NEP</option>
                                    <option value="Nº Chamados Implantação">Nº Chamados Implantação</option>
                                    <option value="Nº Chamados Monitoramento">Nº Chamados Monitoramento</option>
                                    <option value="Nº Chamados SIRESP">Nº Chamados SIRESP</option>
                                    <option value="Nº Chamados T.I_Sistemas">Nº Chamados T.I_Sistemas</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-md-3">
                            <div class="form-group">
                                <label>&nbsp;</label>
                                <button type="submit" class="btn btn-primary btn-block">Filtrar</button>
                            </div>
                        </div>
                    </div>
                </form>
                <div id="reportContainer"></div>
            </div>
        </div>
    </div>
</div>
<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.1.3/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.1.0/dist/js/adminlte.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
<script src="js/custom.js"></script>
</body>
</html>