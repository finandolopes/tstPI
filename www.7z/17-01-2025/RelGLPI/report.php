<?php
include 'db.php';

$status = $_GET['status'] ?? '';
$date_from = $_GET['date_from'] ?? '';
$date_to = $_GET['date_to'] ?? '';
$centro_custo = $_GET['centro_custo'] ?? '';
$origem = $_GET['origem'] ?? '';

$query = "SELECT t.id AS ID_Chamado,
                 CASE WHEN t.entities_id = '0' THEN 'CROSS'
                      WHEN t.entities_id = '2' THEN 'Manutenção'
                      WHEN t.entities_id = '3' THEN 'Informação'
                      WHEN t.entities_id = '4' THEN 'T.I'
                      WHEN t.entities_id = '5' THEN 'Cadastrox'
                      WHEN t.entities_id = '6' THEN 'NEP'
                      WHEN t.entities_id = '7' THEN 'Implantação'
                      WHEN t.entities_id = '8' THEN 'Monitoramento'
                      WHEN t.entities_id = '9' THEN 'SIRESP'
                      WHEN t.entities_id = '10' THEN 'Monitoramento'
                      WHEN t.entities_id = '11' THEN 'T.I_Sistemas'
                 END AS Centro_de_custo,
                 CASE WHEN t.entities_id = '0' THEN 'Nº Chamados CROSS'
                      WHEN t.entities_id = '2' THEN 'Nº Chamados Manutenção'
                      WHEN t.entities_id = '3' THEN 'Nº Chamados Informação'
                      WHEN t.entities_id = '4' THEN 'Nº Chamados T.I'
                      WHEN t.entities_id = '5' THEN 'Nº Chamados Cadastrox'
                      WHEN t.entities_id = '6' THEN 'Nº Chamados NEP'
                      WHEN t.entities_id = '7' THEN 'Nº Chamados Implantação'
                      WHEN t.entities_id = '8' THEN 'Nº Chamados Monitoramento'
                      WHEN t.entities_id = '9' THEN 'Nº Chamados SIRESP'
                      WHEN t.entities_id = '10' THEN 'Nº Chamados Monitoramento'
                      WHEN t.entities_id = '11' THEN 'Nº Chamados T.I_Sistemas'
                 END AS Origem,
                 CONCAT(ut.firstname,' ',ut.realname) AS Nome_requerente_tarefa,
                 CASE WHEN tt.end IS NULL AND LOCATE(',', X.ATRIBUIDO) > 0 THEN LEFT(X.ATRIBUIDO, LOCATE(',', X.ATRIBUIDO) - 1)
                      WHEN tt.end IS NULL THEN X.ATRIBUIDO
                      ELSE CONCAT(utt.firstname,' ',utt.realname)
                 END AS Nome_responsavel_tarefa,
                 tt.date AS Data_abertura_tarefa,
                 tt.begin AS Data_execucao_tarefa,
                 CASE WHEN tt.end IS NULL THEN t.solvedate ELSE tt.end END AS Data_finalizacao_tarefa,
                 tt.state AS ID_Status_tarefa,
                 tc.name AS Nivel_da_tarefa,
                 CASE WHEN tt.state IS NULL AND tt.end IS NOT NULL OR t.closedate IS NOT NULL THEN 'Fechada'
                      WHEN tt.state IS NULL AND tt.end IS NULL THEN 'Aberta'
                      WHEN tt.state = 1 THEN 'Aberta'
                      WHEN tt.state = 2 THEN 'Fechada'
                      ELSE NULL
                 END AS Status_tarefa,
                 CASE WHEN tt.id IS NULL THEN L.Pontuacao
                      WHEN tc.name IS NULL THEN '1'
                      ELSE tc.comment
                 END AS pontuacao_tarefa,
                 gr.name AS Modulo_tarefa
          FROM GLPI.glpi_tickets AS t
          LEFT JOIN glpi_users AS u ON u.id = t.users_id_recipient
          LEFT JOIN glpi_itilcategories AS c ON c.id = t.itilcategories_id
          LEFT JOIN glpi_tickets_status AS s ON s.id = t.status
          LEFT JOIN glpi_tickettasks AS tt ON tt.tickets_id = t.id
          LEFT JOIN glpi_groups AS gr ON gr.id = tt.groups_id_tech
          LEFT JOIN glpi_users AS ut ON ut.id = tt.users_id
          LEFT JOIN glpi_users AS utt ON utt.id = tt.users_id_tech
          LEFT JOIN (SELECT idglpi_Types,
                            CASE WHEN cod_type = '3' THEN '111' ELSE cod_type END AS cod_type,
                            CASE WHEN desc_type = 'Melhorias' THEN 'Melhoria' ELSE desc_type END AS desc_type
                     FROM GLPI.glpi_Types) AS tp ON tp.cod_type = t.type
          LEFT JOIN glpi_taskcategories AS tc ON tt.taskcategories_id = tc.id
          LEFT JOIN (SELECT tickets_id, GROUP_CONCAT(nome) AS REQUERENTE, groups_id
                     FROM (SELECT B.tickets_id, B.users_id, CONCAT(u.firstname, ' ', u.realname) AS 'nome', u.groups_id
                           FROM GLPI.glpi_tickets_users B
                           LEFT JOIN glpi_users AS u ON u.id = B.users_id
                           WHERE B.type = '1') AS A
                     GROUP BY tickets_id) AS A ON A.tickets_id = t.id
          WHERE 1=1";

if ($status) {
    $query .= " AND (CASE WHEN tt.state IS NULL AND tt.end IS NOT NULL OR t.closedate IS NOT NULL THEN 'Fechada'
                          WHEN tt.state IS NULL AND tt.end IS NULL THEN 'Aberta'
                          WHEN tt.state = 1 THEN 'Aberta'
                          WHEN tt.state = 2 THEN 'Fechada'
                          ELSE NULL
                     END) = '$status'";
}

if ($date_from) {
    $query .= " AND tt.date >= '$date_from'";
}

if ($date_to) {
    $query .= " AND tt.date <= '$date_to'";
}

if ($centro_custo) {
    $query .= " AND (CASE WHEN t.entities_id = '0' THEN 'CROSS'
                          WHEN t.entities_id = '2' THEN 'Manutenção'
                          WHEN t.entities_id = '3' THEN 'Informação'
                          WHEN t.entities_id = '4' THEN 'T.I'
                          WHEN t.entities_id = '5' THEN 'Cadastrox'
                          WHEN t.entities_id = '6' THEN 'NEP'
                          WHEN t.entities_id = '7' THEN 'Implantação'
                          WHEN t.entities_id = '8' THEN 'Monitoramento'
                          WHEN t.entities_id = '9' THEN 'SIRESP'
                          WHEN t.entities_id = '10' THEN 'Monitoramento'
                          WHEN t.entities_id = '11' THEN 'T.I_Sistemas'
                     END) = '$centro_custo'";
}

if ($origem) {
    $query .= " AND (CASE WHEN t.entities_id = '0' THEN 'Nº Chamados CROSS'
                          WHEN t.entities_id = '2' THEN 'Nº Chamados Manutenção'
                          WHEN t.entities_id = '3' THEN 'Nº Chamados Informação'
                          WHEN t.entities_id = '4' THEN 'Nº Chamados T.I'
                          WHEN t.entities_id = '5' THEN 'Nº Chamados Cadastrox'
                          WHEN t.entities_id = '6' THEN 'Nº Chamados NEP'
                          WHEN t.entities_id = '7' THEN 'Nº Chamados Implantação'
                          WHEN t.entities_id = '8' THEN 'Nº Chamados Monitoramento'
                          WHEN t.entities_id = '9' THEN 'Nº Chamados SIRESP'
                          WHEN t.entities_id = '10' THEN 'Nº Chamados Monitoramento'
                          WHEN t.entities_id = '11' THEN 'Nº Chamados T.I_Sistemas'
                     END) = '$origem'";
}

$result = $conn->query($query);

if ($result->num_rows > 0) {
    echo '<table class="table table-bordered">';
    echo '<thead><tr><th>ID Chamado</th><th>Centro de Custo</th><th>Origem</th><th>Nome Requerente</th><th>Nome Responsável</th><th>Data Abertura</th><th>Data Execução</th><th>Data Finalização</th><th>Status</th><th>Nível</th><th>Pontuação</th><th>Módulo</th></tr></thead>';
    echo '<tbody>';
    while ($row = $result->fetch_assoc()) {
        echo '<tr>';
        echo '<td>' . $row['ID_Chamado'] . '</td>';
        echo '<td>' . $row['Centro_de_custo'] . '</td>';
        echo '<td>' . $row['Origem'] . '</td>';
        echo '<td>' . $row['Nome_requerente_tarefa'] . '</td>';
        echo '<td>' . $row['Nome_responsavel_tarefa'] . '</td>';
        echo '<td>' . $row['Data_abertura_tarefa'] . '</td>';
        echo '<td>' . $row['Data_execucao_tarefa'] . '</td>';
        echo '<td>' . $row['Data_finalizacao_tarefa'] . '</td>';
        echo '<td>' . $row['Status_tarefa'] . '</td>';
        echo '<td>' . $row['Nivel_da_tarefa'] . '</td>';
        echo '<td>' . $row['pontuacao_tarefa'] . '</td>';
        echo '<td>' . $row['Modulo_tarefa'] . '</td>';
        echo '</tr>';
    }
    echo '</tbody></table>';
} else {
    echo '<p>Nenhum resultado encontrado.</p>';
}

$conn->close();
?>