$(document).ready(function() {
    $('#filterForm').on('submit', function(e) {
        e.preventDefault();
        $.ajax({
            url: 'report.php',
            type: 'GET',
            data: $(this).serialize(),
            success: function(response) {
                $('#reportContainer').html(response);
            },
            error: function() {
                Swal.fire('Erro', 'Não foi possível gerar o relatório.', 'error');
            }
        });
    });
});