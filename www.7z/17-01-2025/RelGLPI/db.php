<?php
$servername = "honduras";
$username = "root";
$password = "6kUV6QWPXDFude7DmGad";
$dbname = "glpi";

$conn = new mysqli($servername, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}
?>