-- Recriação do Banco de Dados
DROP DATABASE IF EXISTS sistema_atendimento;
CREATE DATABASE sistema_atendimento;
USE sistema_atendimento;

-- Tabela de Perfis
CREATE TABLE perfis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL UNIQUE
);

-- Inserção de Perfis
INSERT INTO perfis (id, nome) VALUES
    (1, 'Administrador Sistema'),
    (2, 'Administrador'),
    (3, 'Coordenador Atendimento'),
    (4, 'Atendente CAT'),
    (5, 'Relatorios');

-- Tabela de Usuários
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    login VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    perfil_id INT NOT NULL,
    status ENUM('ativo', 'inativo') DEFAULT 'ativo',
    bloqueado BOOLEAN DEFAULT FALSE,
    data_bloqueio DATETIME NULL,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (perfil_id) REFERENCES perfis(id) ON DELETE CASCADE
);

-- Inserção do Usuário Administrador Sistema
INSERT INTO usuarios (id, nome, email, login, senha, perfil_id, status) VALUES
    (1, 'Fernando Lopes', 'fernando.lopes@exemplo.com', 'fernando.lopes', '$2y$12$VnqTzQ7RfGqE8O7N5eOgROkA7Q8jR.aIgHsnT4m5XGnvY0nBcga3e', 1, 'ativo');

-- Tabela de Permissões
CREATE TABLE permissoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    descricao TEXT DEFAULT NULL
);

-- Inserção de Permissões
INSERT INTO permissoes (id, nome, descricao) VALUES
    (1, 'Acessar Dashboard', 'Permissão para acessar o dashboard'),
    (2, 'Gerenciar Usuários', 'Permissão para gerenciar usuários'),
    (3, 'Visualizar Relatórios', 'Permissão para visualizar relatórios'),
    (4, 'Criar Atendimentos', 'Permissão para criar novos atendimentos'),
    (5, 'Editar Atendimentos', 'Permissão para editar atendimentos existentes'),
    (6, 'Excluir Atendimentos', 'Permissão para excluir atendimentos'),
    (7, 'Configurar Sistema', 'Permissão para configurar o sistema'),
    (8, 'Visualizar Logs', 'Permissão para visualizar logs de auditoria'),
    (9, 'Gerenciar Unidades', 'Permissão para gerenciar unidades'),
    (10, 'Gerenciar Municípios', 'Permissão para gerenciar municípios'),
    (11, 'Gerenciar DRS', 'Permissão para gerenciar DRS'),
    (12, 'Gerenciar Macro Regiões', 'Permissão para gerenciar macro-regiões'),
    (13, 'Gerenciar Origens de Atendimento', 'Permissão para gerenciar origens de atendimento'),
    (14, 'Gerenciar Motivos de Atendimento', 'Permissão para gerenciar motivos de atendimento'),
    (15, 'Gerenciar Recursos de Atendimento', 'Permissão para gerenciar recursos de atendimento');

-- Tabela de Relacionamento Usuário-Permissões
CREATE TABLE usuario_permissoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    permissao_id INT NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (permissao_id) REFERENCES permissoes(id) ON DELETE CASCADE
);

-- Concessão de Permissões ao Administrador Sistema
INSERT INTO usuario_permissoes (usuario_id, permissao_id)
SELECT 1, id FROM permissoes;

-- Tabela de Municípios
CREATE TABLE municipios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    estado_id INT NOT NULL,
    status ENUM('ativo', 'inativo') DEFAULT 'ativo',
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de Unidades
CREATE TABLE unidades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    municipio_id INT NOT NULL,
    status ENUM('ativo', 'inativo') DEFAULT 'ativo',
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (municipio_id) REFERENCES municipios(id) ON DELETE CASCADE
);

-- Tabela de DRS
CREATE TABLE drs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    status ENUM('ativo', 'inativo') DEFAULT 'ativo',
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de Macro Regiões
CREATE TABLE macro_regioes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    status ENUM('ativo', 'inativo') DEFAULT 'ativo',
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);