<?php
require 'backend/conexao.php';

$query = isset($_GET['q']) ? trim($_GET['q']) : '';
$results = [];

if ($query !== '') {
    // Busca em diferentes tabelas
    $stmt = $conn->prepare("SELECT id, nome FROM pacientes WHERE nome LIKE :query OR codigo LIKE :query");
    $stmt->execute([':query' => "%$query%"]);
    $results['Pacientes'] = $stmt->fetchAll(PDO::FETCH_ASSOC);

    $stmt = $conn->prepare("SELECT id, nome FROM usuarios WHERE nome LIKE :query OR email LIKE :query");
    $stmt->execute([':query' => "%$query%"]);
    $results['Usuários'] = $stmt->fetchAll(PDO::FETCH_ASSOC);
}

require 'includes/header.php';
?>
<div class="container mt-4">
    <h1>Resultados para "<?= htmlspecialchars($query) ?>"</h1>
    <?php if (empty($results)): ?>
        <p class="text-muted">Nenhum resultado encontrado.</p>
    <?php else: ?>
        <?php foreach ($results as $type => $items): ?>
            <h3><?= htmlspecialchars($type) ?></h3>
            <ul>
                <?php foreach ($items as $item): ?>
                    <li>
                        <a href="detalhes.php?type=<?= urlencode($type) ?>&id=<?= $item['id'] ?>">
                            <?= htmlspecialchars($item['nome']) ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endforeach; ?>
    <?php endif; ?>
</div>
<?php require 'includes/footer.php'; ?>