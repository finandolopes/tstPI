<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="dashboard.php" class="brand-link">
        <img src="../assets/img/CROSS-.png" alt="Logo" class="brand-image img-circle elevation-3" style="opacity: .8;">
        <span class="brand-text font-weight-light">SA - CAT</span>
    </a>
    <div class="sidebar">
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <li class="nav-item">
                    <a href="../dashboard.php" class="nav-link">
                        <i class="nav-icon fas fa-home"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li class="nav-item">
                <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-headset"></i>
                        <p>
                            Atendimentos
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="atendimentos/novo_atendimento.php" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Novo Atendimento</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="../atendimentos/listar_atendimentos.php" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Listar Atendimentos</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-headset"></i>
                        <p>
                            Cadastros
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="../cadastros/drs.php" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>DRS</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="../cadastros/macro_regioes.php" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Macro-Regiões</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="../cadastros/motivos_atendimento.php" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Motivo do Atendimento</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="../cadastros/municipios.php" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Municípios</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="../cadastros/origens_atendimento.php" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Origem do Atendimento</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="../cadastros/recursos.php" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Recursos</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="../cadastros/unidades.php" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Unidades</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <li class="nav-item">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-chart-bar"></i>
                        <p>
                            Relatórios
                            <i class="right fas fa-angle-left"></i>
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="../relatorios/sla.php" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Relatório de SLA</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="../relatorios/produtividade.php" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Relatório de Produtividade</p>
                            </a>
                        </li>
                    </ul>
                </li>               
                <li class="nav-item">
                <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-cogs"></i>
                        <p>
                            Configurações
                            
                        </p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="../configuraçoes/backup_configuracoes.php" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Backup</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="../configuracoes/permissoes.php" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Permissões</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="../configuracoes/configuracoes_prot_csrf.php" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Proteção CSRF</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="../configuracoes/integracao_api.php" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Integração API</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="../logs/logs_acoes.php" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Logs Ações</p>
                            </a>
                        </li>                       
                        <li class="nav-item">
                            <a href="../logs/acessos.php" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Acessos</p>
                            </a>
                        </li>
                    </ul>
                </li>
            </ul>
        </nav>
    </div>
</aside>