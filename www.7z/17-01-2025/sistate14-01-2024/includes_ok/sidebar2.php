<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Logo -->
    <a href="dashboard.php" class="brand-link">
        <img src="assets/img/CROSS-.png" alt="Logo" class="brand-image img-circle elevation-3">
        <span class="brand-text font-weight-light">SA-CAT</span>
    </a>
    <!-- Menu Lateral -->
    <div class="sidebar">
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column">
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link">
                        <i class="nav-icon fas fa-home"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="novo_atendimento.php" class="nav-link">
                        <i class="nav-icon fas fa-plus-circle"></i>
                        <p>Novo Atendimento</p>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>