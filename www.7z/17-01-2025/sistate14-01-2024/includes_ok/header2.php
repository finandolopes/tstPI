<nav class="main-header navbar navbar-expand navbar-white navbar-light">
    <!-- Botão de alternar menu lateral -->
    <ul class="navbar-nav">
        <li class="nav-item">
            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
        </li>
    </ul>
    <!-- Mensagem de boas-vindas -->
    <ul class="navbar-nav ml-auto">
        <li class="nav-item">
            <span class="navbar-text">Bem-vindo, <span id="userName"></span></span>
        </li>
        <!-- Menu do usuário -->
        <li class="nav-item dropdown">
            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                <i class="fas fa-user"></i>
            </a>
            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#userModal">Minha Conta</a></li>
                <li><hr class="dropdown-divider"></li>
                <li><a class="dropdown-item" href="logout.php">Sair</a></li>
            </ul>
        </li>
    </ul>
</nav>