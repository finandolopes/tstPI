<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

require_once 'backend/conexao.php';
require_once 'backend/validar_permissoes.php';

// Validação de permissão para acessar o dashboard
validarPermissao('Acessar Dashboard');

// Dados para o dashboard
$totalAtendimentos = $conn->query("SELECT COUNT(*) FROM atendimentos")->fetchColumn();
$atendimentosFechados = $conn->query("SELECT COUNT(*) FROM atendimentos WHERE status = 'Fechado'")->fetchColumn();
$atendimentosAbertos = $conn->query("SELECT COUNT(*) FROM atendimentos WHERE status = 'Aberto'")->fetchColumn();
$atendimentosPendentes = $conn->query("SELECT COUNT(*) FROM atendimentos WHERE status = 'Pendente'")->fetchColumn();

$ultimosAtendimentos = $conn->query("SELECT id, data_inicio, atendente, origem, status FROM atendimentos ORDER BY data_inicio DESC LIMIT 10")
    ->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistema de Atendimento</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
    <!-- Header e Sidebar -->
    <?php include 'includes/header.php'; ?>
    <?php include 'includes/sidebar.php'; ?>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Dashboard</h1>
                    </div>
                </div>
            </div>
        </div>

        <!-- Main Content -->
        <section class="content">
            <div class="container-fluid">
                <!-- Cards de Dados -->
                <div class="row">
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-info">
                            <div class="inner">
                                <h3><?= $totalAtendimentos ?></h3>
                                <p>Total de Atendimentos</p>
                            </div>
                            <div class="icon"><i class="fas fa-headset"></i></div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-success">
                            <div class="inner">
                                <h3><?= $atendimentosFechados ?></h3>
                                <p>Atendimentos Finalizados</p>
                            </div>
                            <div class="icon"><i class="fas fa-check"></i></div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-warning">
                            <div class="inner">
                                <h3><?= $atendimentosAbertos ?></h3>
                                <p>Atendimentos Abertos</p>
                            </div>
                            <div class="icon"><i class="fas fa-exclamation-circle"></i></div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-danger">
                            <div class="inner">
                                <h3><?= $atendimentosPendentes ?></h3>
                                <p>Atendimentos Pendentes</p>
                            </div>
                            <div class="icon"><i class="fas fa-times-circle"></i></div>
                        </div>
                    </div>
                </div>

                <!-- Monitoramento em Tempo Real -->
                <div class="row">
                    <div class="col-lg-6 col-12">
                        <div class="small-box bg-primary">
                            <div class="inner">
                                <h3 id="usuariosOnline">0</h3>
                                <p>Usuários Online</p>
                            </div>
                            <div class="icon"><i class="fas fa-users"></i></div>
                        </div>
                    </div>
                    <div class="col-lg-6 col-12">
                        <div class="small-box bg-success">
                            <div class="inner">
                                <h3 id="novosAtendimentos">0</h3>
                                <p>Novos Atendimentos (24h)</p>
                            </div>
                            <div class="icon"><i class="fas fa-calendar-plus"></i></div>
                        </div>
                    </div>
                </div>

                <!-- Tabela de Últimos Atendimentos -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Últimos Atendimentos</h3>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered">
                                    <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Data de Início</th>
                                        <th>Atendente</th>
                                        <th>Origem</th>
                                        <th>Status</th>
                                        <th>Ações</th>
                                    </tr>
                                    </thead>
                                    <tbody>
                                    <?php foreach ($ultimosAtendimentos as $atendimento): ?>
                                        <tr>
                                            <td><?= $atendimento['id'] ?></td>
                                            <td><?= $atendimento['data_inicio'] ?></td>
                                            <td><?= $atendimento['atendente'] ?></td>
                                            <td><?= $atendimento['origem'] ?></td>
                                            <td><?= $atendimento['status'] ?></td>
                                            <td>
                                                <a href="detalhes.php?id=<?= $atendimento['id'] ?>" class="btn btn-info btn-sm">
                                                    <i class="fas fa-eye"></i> Ver
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <?php include 'includes/footer.php'; ?>
</div>

<script>
    function atualizarMonitoramento() {
        fetch('backend/monitoramento_real.php')
            .then(response => response.json())
            .then(data => {
                document.getElementById('usuariosOnline').textContent = data.usuarios_online;
                document.getElementById('novosAtendimentos').textContent = data.novos_atendimentos;
            })
            .catch(err => console.error('Erro ao atualizar monitoramento:', err));
    }

    setInterval(atualizarMonitoramento, 10000);
    atualizarMonitoramento();
</script>
</body>
</html>
