<?php
require 'backend/conexao.php';

// Validação dos parâmetros recebidos
$type = isset($_GET['type']) ? $_GET['type'] : '';
$id = isset($_GET['id']) ? intval($_GET['id']) : 0;

if (empty($type) || $id <= 0) {
    die('Parâmetros inválidos.');
}

// Mapeamento para tabelas válidas
$validTypes = [
    'Pacientes' => 'pacientes',
    'Usuários' => 'usuarios'
];

if (!array_key_exists($type, $validTypes)) {
    die('Tipo inválido.');
}

// Consulta no banco de dados
$tabela = $validTypes[$type];
$stmt = $conn->prepare("SELECT * FROM $tabela WHERE id = :id");
$stmt->execute([':id' => $id]);
$item = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$item) {
    die('Registro não encontrado.');
}

require 'includes/header.php';
?>

<div class="container mt-4">
    <h1>Detalhes do <?= htmlspecialchars($type) ?></h1>
    <table class="table table-bordered">
        <tbody>
            <?php foreach ($item as $key => $value): ?>
                <tr>
                    <th><?= htmlspecialchars(ucfirst(str_replace('_', ' ', $key))) ?></th>
                    <td><?= htmlspecialchars($value) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
    <a href="buscar.php?q=" class="btn btn-secondary">Voltar</a>
</div>

<?php require 'includes/footer.php'; ?>