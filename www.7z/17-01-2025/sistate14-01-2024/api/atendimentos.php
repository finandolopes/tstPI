<?php
require '../backend/conexao.php';
header('Content-Type: application/json');

// Verificar se o token é válido
$token = $_GET['token'] ?? '';
$stmt = $conn->prepare("SELECT * FROM tokens WHERE token = ?");
$stmt->execute([$token]);
if ($stmt->rowCount() === 0) {
    http_response_code(403);
    echo json_encode(['error' => 'Token inválido']);
    exit;
}

// Rota: Listar Atendimentos
if ($_SERVER['REQUEST_METHOD'] === 'GET') {
    $stmt = $conn->query("SELECT * FROM atendimentos");
    echo json_encode($stmt->fetchAll(PDO::FETCH_ASSOC));
    exit;
}

// Rota: Criar Atendimento
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = json_decode(file_get_contents('php://input'), true);

    $stmt = $conn->prepare("INSERT INTO atendimentos (usuario_id, origem_id, recurso_id, motivo_id, codigo_paciente, descricao) VALUES (?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $data['usuario_id'],
        $data['origem_id'],
        $data['recurso_id'],
        $data['motivo_id'],
        $data['codigo_paciente'],
        $data['descricao']
    ]);
    echo json_encode(['success' => true]);
    exit;
}
?>