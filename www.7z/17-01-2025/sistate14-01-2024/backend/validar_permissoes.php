<?php
session_start();
require 'conexao.php';

function validarPermissao($permissao) {
    if (!isset($_SESSION['usuario_id'])) {
        header('Location: ../login.php');
        exit;
    }

    if (!isset($_SESSION['permissoes']) || !in_array($permissao, $_SESSION['permissoes'])) {
        die('Acesso negado: você não tem permissão para realizar esta ação.');
    }
}
?>