<?php
session_start();
require 'conexao.php';

$usuario_id = $_SESSION['usuario_id'];
$stmt = $conn->prepare("UPDATE usuarios SET tema = IF(tema = 'escuro', 'claro', 'escuro') WHERE id = ?");
$stmt->execute([$usuario_id]);

echo json_encode(['success' => true]);
?>