<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}
require 'backend/conexao.php';

// Obter lista de usuários
$usuarios = $conn->query('SELECT id, nome FROM usuarios')->fetchAll(PDO::FETCH_ASSOC);

// Obter lista de permissões
$permissoes = $conn->query('SELECT id, nome FROM permissoes')->fetchAll(PDO::FETCH_ASSOC);

?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Permissões</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
    <?php include 'includes/header.php'; ?>
    <?php include 'includes/sidebar.php'; ?>

    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <h1 class="m-0">Gerenciar Permissões</h1>
            </div>
        </div>
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <div class="col-md-6">
                        <h3>Usuários</h3>
                        <select id="usuarios" class="form-control">
                            <option value="">Selecione um usuário</option>
                            <?php foreach ($usuarios as $usuario): ?>
                                <option value="<?= $usuario['id'] ?>"><?= htmlspecialchars($usuario['nome']) ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                </div>

                <div class="row mt-4">
                    <div class="col-md-6">
                        <h4>Permissões Disponíveis</h4>
                        <ul id="disponiveis" class="list-group">
                            <?php foreach ($permissoes as $permissao): ?>
                                <li class="list-group-item" data-id="<?= $permissao['id'] ?>">
                                    <?= htmlspecialchars($permissao['nome']) ?>
                                </li>
                            <?php endforeach; ?>
                        </ul>
                    </div>
                    <div class="col-md-6">
                        <h4>Permissões do Usuário</h4>
                        <ul id="usuario-permissoes" class="list-group">
                            <!-- As permissões atribuídas serão carregadas aqui -->
                        </ul>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <?php include 'includes/footer.php'; ?>
</div>

<script>
    $(document).ready(function () {
        // Carregar permissões do usuário ao selecionar
        $('#usuarios').change(function () {
            const userId = $(this).val();
            if (userId) {
                $.get('backend/obter_permissoes.php', { usuario_id: userId }, function (data) {
                    $('#usuario-permissoes').empty();
                    data.forEach(permissao => {
                        $('#usuario-permissoes').append(`
                            <li class="list-group-item" data-id="${permissao.id}">${permissao.nome}</li>
                        `);
                    });
                });
            } else {
                $('#usuario-permissoes').empty();
            }
        });

        // Implementação do drag-and-drop
        $('.list-group').on('dragstart', '.list-group-item', function (e) {
            e.originalEvent.dataTransfer.setData('id', $(this).data('id'));
        });

        $('#usuario-permissoes').on('dragover', function (e) {
            e.preventDefault();
        }).on('drop', function (e) {
            e.preventDefault();
            const id = e.originalEvent.dataTransfer.getData('id');
            const item = $(`[data-id="${id}"]`).clone();
            item.appendTo('#usuario-permissoes');

            // Salvar permissão no backend
            const userId = $('#usuarios').val();
            $.post('backend/adicionar_permissao.php', { usuario_id: userId, permissao_id: id });
        });

        $('#disponiveis').on('dragover', function (e) {
            e.preventDefault();
        }).on('drop', function (e) {
            e.preventDefault();
            const id = e.originalEvent.dataTransfer.getData('id');
            $(`#usuario-permissoes [data-id="${id}"]`).remove();

            // Remover permissão no backend
            const userId = $('#usuarios').val();
            $.post('backend/remover_permissao.php', { usuario_id: userId, permissao_id: id });
        });
    });
</script>
</body>
</html>