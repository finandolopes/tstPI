<?php
require 'conexao.php';

$backupFile = '../backups/backup_' . date('Y_m_d_H_i_s') . '.sql';
$command = "mysqldump -u username -p'password' sistema_atendimento > $backupFile";

exec($command, $output, $return_var);

if ($return_var === 0) {
    echo json_encode(['success' => true, 'file' => $backupFile]);
} else {
    echo json_encode(['success' => false, 'error' => $output]);
}
?>