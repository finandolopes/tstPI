<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Acesso não autorizado']);
    exit;
}

require 'conexao.php';

if (!isset($_GET['usuario_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'ID do usuário não informado']);
    exit;
}

$usuarioId = (int)$_GET['usuario_id'];

try {
    $stmt = $conn->prepare("SELECT p.id, p.nome 
                            FROM permissoes p
                            INNER JOIN usuario_permissoes up ON p.id = up.permissao_id
                            WHERE up.usuario_id = ?");
    $stmt->execute([$usuarioId]);
    $permissoes = $stmt->fetchAll(PDO::FETCH_ASSOC);

    header('Content-Type: application/json');
    echo json_encode($permissoes);
} catch (PDOException $e) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Erro ao buscar permissões: ' . $e->getMessage()]);
}
?>