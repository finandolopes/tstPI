<?php
session_start();
require 'conexao.php';

header('Content-Type: application/json');

// Atualiza ou insere o status do usuário na tabela de sessões
$usuarioId = $_SESSION['usuario_id'] ?? null;

if ($usuarioId) {
    $stmt = $conn->prepare("
        INSERT INTO sessoes_ativas (usuario_id, ultimo_acesso)
        VALUES (:usuario_id, NOW())
        ON DUPLICATE KEY UPDATE ultimo_acesso = NOW()
    ");
    $stmt->execute(['usuario_id' => $usuarioId]);

    // Remove sessões inativas (10 minutos de inatividade)
    $conn->exec("DELETE FROM sessoes_ativas WHERE TIMESTAMPDIFF(MINUTE, ultimo_acesso, NOW()) > 10");
}

// Conta o número de sessões ativas
$totalSessoes = $conn->query("SELECT COUNT(*) AS total FROM sessoes_ativas")->fetch(PDO::FETCH_ASSOC);

echo json_encode($totalSessoes);