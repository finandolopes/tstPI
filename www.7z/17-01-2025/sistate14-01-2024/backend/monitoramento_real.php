<?php
session_start();
require 'conexao.php';

// Número de usuários online
$stmt = $conn->prepare("SELECT COUNT(DISTINCT usuario_id) AS usuarios_online FROM sessions WHERE last_activity > NOW() - INTERVAL 5 MINUTE");
$stmt->execute();
$usuariosOnline = $stmt->fetch(PDO::FETCH_ASSOC)['usuarios_online'];

// Novos atendimentos no último dia
$stmt = $conn->prepare("SELECT COUNT(*) AS novos_atendimentos FROM atendimentos WHERE data_inicio >= NOW() - INTERVAL 1 DAY");
$stmt->execute();
$novosAtendimentos = $stmt->fetch(PDO::FETCH_ASSOC)['novos_atendimentos'];

// Retorna os dados como JSON
header('Content-Type: application/json');
echo json_encode([
    'usuarios_online' => $usuariosOnline,
    'novos_atendimentos' => $novosAtendimentos
]);
?>