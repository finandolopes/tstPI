<?php
session_start();
require 'conexao.php';

if (!isset($_SESSION['usuario_id'])) {
    http_response_code(401);
    exit('Usuário não autenticado.');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $novaSenha = password_hash($_POST['senha'], PASSWORD_DEFAULT);
    $usuarioId = $_SESSION['usuario_id'];

    $stmt = $conn->prepare('UPDATE usuarios SET senha = ? WHERE id = ?');
    if ($stmt->execute([$novaSenha, $usuarioId])) {
        echo 'Senha alterada com sucesso!';
    } else {
        http_response_code(500);
        echo 'Erro ao alterar a senha.';
    }
}
?>