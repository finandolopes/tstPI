<?php
function registrarLog($usuario_id, $acao, $descricao = '') {
    require 'conexao.php';

    $stmt = $conn->prepare("INSERT INTO logs_auditoria (usuario_id, acao, descricao, data) VALUES (?, ?, ?, NOW())");
    $stmt->execute([$usuario_id, $acao, $descricao]);
}
?>