<?php
session_start();
require_once 'backend/conexao.php';
require_once 'includes/verifica_permissao.php';

// Verifica se o usuário tem permissão
verificaPermissao('configuracoes_save');

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $backup = isset($_POST['backup']) ? intval($_POST['backup']) : 0;
    $integracao = isset($_POST['integracao']) ? intval($_POST['integracao']) : 0;

    try {
        // Atualizar configurações no banco
        $stmt = $conn->prepare("UPDATE configuracoes SET backup = ?, integracao = ? WHERE id = 1");
        $stmt->execute([$backup, $integracao]);

        $_SESSION['mensagem_sucesso'] = "Configurações salvas com sucesso!";
        header('Location: admin_panel.php');
        exit;
    } catch (Exception $e) {
        $_SESSION['mensagem_erro'] = "Erro ao salvar configurações: " . $e->getMessage();
        header('Location: admin_panel.php');
        exit;
    }
}
?>