<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

require 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tempoSessao = intval($_POST['tempoSessao']);
    $csrfToken = intval($_POST['csrfToken']);

    $stmt = $conn->prepare("UPDATE configuracoes SET tempo_sessao = ?, csrf_token = ? WHERE id = 1");
    if ($stmt->execute([$tempoSessao, $csrfToken])) {
        $_SESSION['success_message'] = 'Configurações salvas com sucesso!';
    } else {
        $_SESSION['error_message'] = 'Erro ao salvar configurações.';
    }
    header('Location: ../config/configuracoes_avancadas.php');
    exit;
}
?>