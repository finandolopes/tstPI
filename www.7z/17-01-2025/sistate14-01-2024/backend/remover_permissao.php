<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Acesso não autorizado']);
    exit;
}

require 'conexao.php';

$data = json_decode(file_get_contents('php://input'), true);

if (!isset($data['usuario_id']) || !isset($data['permissao_id'])) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Dados insuficientes para remover permissão']);
    exit;
}

$usuarioId = (int)$data['usuario_id'];
$permissaoId = (int)$data['permissao_id'];

try {
    $stmt = $conn->prepare("DELETE FROM usuario_permissoes WHERE usuario_id = ? AND permissao_id = ?");
    $stmt->execute([$usuarioId, $permissaoId]);

    header('Content-Type: application/json');
    echo json_encode(['success' => 'Permissão removida com sucesso']);
} catch (PDOException $e) {
    header('Content-Type: application/json');
    echo json_encode(['error' => 'Erro ao remover permissão: ' . $e->getMessage()]);
}
?>