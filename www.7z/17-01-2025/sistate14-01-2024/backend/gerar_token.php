<?php
require '../conexao.php';
$data = json_decode(file_get_contents('php://input'), true);

if (isset($data['usuario_id'])) {
    $usuarioId = $data['usuario_id'];
    $token = bin2hex(random_bytes(16));

    $stmt = $conn->prepare("INSERT INTO api_tokens (usuario_id, token, criado_em) VALUES (?, ?, NOW()) ON DUPLICATE KEY UPDATE token = VALUES(token), criado_em = NOW()");
    $stmt->execute([$usuarioId, $token]);

    echo json_encode(['success' => true, 'token' => $token]);
} else {
    echo json_encode(['success' => false]);
}