<?php
session_start();
require_once 'backend/conexao.php';
require_once 'includes/verifica_permissao.php';

// Verifica se o usuário tem permissão
verificaPermissao('desativar_sessao');

if (isset($_GET['id'])) {
    $id = intval($_GET['id']);

    try {
        // Desativar a sessão
        $stmt = $conn->prepare("UPDATE sessoes SET ativo = 0 WHERE id = ?");
        $stmt->execute([$id]);

        $_SESSION['mensagem_sucesso'] = "Sessão encerrada com sucesso!";
        header('Location: admin_panel.php');
        exit;
    } catch (Exception $e) {
        $_SESSION['mensagem_erro'] = "Erro ao encerrar sessão: " . $e->getMessage();
        header('Location: admin_panel.php');
        exit;
    }
}
?>