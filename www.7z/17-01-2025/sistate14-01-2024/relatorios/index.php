<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

// Ponto de entrada para todos os relatórios
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios - Sistema de Atendimento</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Relatórios</h1>
        <p>Selecione um relatório para visualizar:</p>
        <ul>
            <li><a href="sla.php">Relatório de SLA</a></li>
            <li><a href="atendimentos_por_drs.php">Atendimentos por DRS</a></li>
            <li><a href="produtividade_atendentes.php">Produtividade por Atendente</a></li>
        </ul>
    </div>
</body>
</html>