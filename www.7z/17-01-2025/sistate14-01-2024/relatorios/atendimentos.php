<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

require '../backend/conexao.php';

// Simulação de dados para o relatório de atendimentos gerais
$dadosAtendimentos = [
    ['mes' => 'Janeiro', 'atendimentos' => 150],
    ['mes' => 'Fevereiro', 'atendimentos' => 200],
    ['mes' => 'Março', 'atendimentos' => 180]
];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório de Atendimentos Gerais</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
    <?php include '../includes/header.php'; ?>
    <?php include '../includes/sidebar.php'; ?>

    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Relatório de Atendimentos Gerais</h1>
                    </div>
                </div>
            </div>
        </div>

        <section class="content">
            <div class="container-fluid">
                <div class="card">
                    <div class="card-body">
                        <h3>Atendimentos por Mês</h3>
                        <canvas id="atendimentosChart" style="height: 400px;"></canvas>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <?php include '../includes/footer.php'; ?>
</div>

<script>
    const ctx = document.getElementById('atendimentosChart').getContext('2d');
    const atendimentosChart = new Chart(ctx, {
        type: 'line',
        data: {
            labels: <?= json_encode(array_column($dadosAtendimentos, 'mes')) ?>,
            datasets: [{
                label: 'Atendimentos',
                data: <?= json_encode(array_column($dadosAtendimentos, 'atendimentos')) ?>,
                backgroundColor: 'rgba(54, 162, 235, 0.2)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 2,
                tension: 0.4
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: