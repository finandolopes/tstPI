<?php
require '../conexao.php';

$query = "SELECT drs.nome AS drs, COUNT(a.id) AS total_atendimentos 
          FROM atendimentos a
          JOIN drs ON a.drs_id = drs.id
          GROUP BY drs.id";
$stmt = $conn->query($query);
$resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($resultados);
?>