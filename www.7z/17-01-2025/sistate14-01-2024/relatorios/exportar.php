<?php
require '../conexao.php';
require '../lib/export.php';

$data = $_POST['data'] ?? [];

$exporter = new Export();
$file = $exporter->toExcel($data);

header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="relatorio.xls"');
echo $file;
?>