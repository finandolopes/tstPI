<?php
require '../conexao.php';

$query = "SELECT municipios.nome AS municipio, COUNT(a.id) AS total_atendimentos 
          FROM atendimentos a
          JOIN municipios ON a.municipio_id = municipios.id
          GROUP BY municipios.id";
$stmt = $conn->query($query);
$resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($resultados);
?>