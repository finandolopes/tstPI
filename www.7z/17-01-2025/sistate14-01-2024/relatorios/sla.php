<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

require '../backend/conexao.php';

// Filtrar dados por período (se fornecido)
$dataInicio = $_GET['data_inicio'] ?? date('Y-m-01');
$dataFim = $_GET['data_fim'] ?? date('Y-m-t');

// Query para calcular o SLA e obter os dados necessários
$query = $conn->prepare("
    SELECT 
        u.nome AS atendente,
        COUNT(a.id) AS total_atendimentos,
        AVG(TIMESTAMPDIFF(SECOND, a.data_inicio, a.data_fim)) AS tempo_medio_atendimento,
        SUM(CASE WHEN a.status = 'Fechado' THEN 1 ELSE 0 END) AS atendimentos_fechados,
        ROUND((SUM(CASE WHEN a.status = 'Fechado' THEN 1 ELSE 0 END) / COUNT(a.id)) * 100, 2) AS taxa_cumprimento_sla
    FROM atendimentos a
    INNER JOIN usuarios u ON a.usuario_id = u.id
    WHERE a.data_inicio BETWEEN ? AND ?
    GROUP BY u.id
    ORDER BY u.nome
");
$query->execute([$dataInicio, $dataFim]);
$dados = $query->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório de SLA</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="../assets/css/estilos.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<div class="container mt-4">
    <h1>Relatório de SLA</h1>
    <hr>

    <!-- Filtros -->
    <form method="GET" class="row g-3">
        <div class="col-md-3">
            <label for="data_inicio" class="form-label">Data de Início</label>
            <input type="date" id="data_inicio" name="data_inicio" class="form-control" value="<?= htmlspecialchars($dataInicio); ?>">
        </div>
        <div class="col-md-3">
            <label for="data_fim" class="form-label">Data Final</label>
            <input type="date" id="data_fim" name="data_fim" class="form-control" value="<?= htmlspecialchars($dataFim); ?>">
        </div>
        <div class="col-md-3 align-self-end">
            <button type="submit" class="btn btn-primary">Filtrar</button>
        </div>
        <div class="col-md-3 align-self-end">
            <button type="button" id="exportarRelatorio" class="btn btn-secondary">Exportar Relatório</button>
        </div>
    </form>

    <!-- Gráficos -->
    <div class="row mt-4">
        <div class="col-md-6">
            <canvas id="tempoMedioChart"></canvas>
        </div>
        <div class="col-md-6">
            <canvas id="taxaCumprimentoChart"></canvas>
        </div>
    </div>

    <!-- Tabela de Dados -->
    <div class="mt-4">
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Atendente</th>
                    <th>Total Atendimentos</th>
                    <th>Tempo Médio de Atendimento (segundos)</th>
                    <th>Atendimentos Fechados</th>
                    <th>Taxa de Cumprimento SLA (%)</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($dados as $linha): ?>
                    <tr>
                        <td><?= htmlspecialchars($linha['atendente']); ?></td>
                        <td><?= htmlspecialchars($linha['total_atendimentos']); ?></td>
                        <td><?= round($linha['tempo_medio_atendimento'], 2); ?></td>
                        <td><?= htmlspecialchars($linha['atendimentos_fechados']); ?></td>
                        <td><?= htmlspecialchars($linha['taxa_cumprimento_sla']); ?>%</td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
</div>

<script>
    // Dados para os gráficos
    const dados = <?= json_encode($dados); ?>;

    // Gráfico de Tempo Médio de Atendimento
    const tempoMedioCtx = document.getElementById('tempoMedioChart').getContext('2d');
    new Chart(tempoMedioCtx, {
        type: 'bar',
        data: {
            labels: dados.map(item => item.atendente),
            datasets: [{
                label: 'Tempo Médio de Atendimento (segundos)',
                data: dados.map(item => item.tempo_medio_atendimento),
                backgroundColor: 'rgba(54, 162, 235, 0.5)',
                borderColor: 'rgba(54, 162, 235, 1)',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: true
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });

    // Gráfico de Taxa de Cumprimento SLA
    const taxaCumprimentoCtx = document.getElementById('taxaCumprimentoChart').getContext('2d');
    new Chart(taxaCumprimentoCtx, {
        type: 'pie',
        data: {
            labels: dados.map(item => item.atendente),
            datasets: [{
                label: 'Taxa de Cumprimento SLA (%)',
                data: dados.map(item => item.taxa_cumprimento_sla),
                backgroundColor: [
                    'rgba(75, 192, 192, 0.5)',
                    'rgba(255, 99, 132, 0.5)',
                    'rgba(255, 206, 86, 0.5)',
                    'rgba(54, 162, 235, 0.5)',
                    'rgba(153, 102, 255, 0.5)'
                ],
                borderColor: [
                    'rgba(75, 192, 192, 1)',
                    'rgba(255, 99, 132, 1)',
                    'rgba(255, 206, 86, 1)',
                    'rgba(54, 162, 235, 1)',
                    'rgba(153, 102, 255, 1)'
                ],
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top'
                }
            }
        }
    });

    // Exportar Relatório
    document.getElementById('exportarRelatorio').addEventListener('click', function () {
        window.location.href = '../relatorios/exportar_sla.php?data_inicio=<?= htmlspecialchars($dataInicio); ?>&data_fim=<?= htmlspecialchars($dataFim); ?>';
    });
</script>
</body>
</html>