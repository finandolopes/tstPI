<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
        <!-- Navbar -->
        <?php include '../includes/header.php'; ?>

        <!-- Sidebar -->
        <?php include '../includes/sidebar.php'; ?>

        <!-- Content Wrapper -->
        <div class="content-wrapper">
            <div class="content-header">
                <div class="container-fluid">
                    <h1 class="m-0">Relatórios</h1>
                </div>
            </div>
            <div class="content">
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Selecione o Relatório</h3>
                        </div>
                        <div class="card-body">
                            <a href="sla.php" class="btn btn-info btn-block mb-3">Relatório de SLA</a>
                            <a href="produtividade.php" class="btn btn-success btn-block mb-3">Relatório de Produtividade</a>
                            <a href="atendimentos.php" class="btn btn-warning btn-block mb-3">Relatório de Atendimentos Gerais</a>
                            <a href="drs.php" class="btn btn-primary btn-block mb-3">Relatório por DRS</a>
                            <a href="municipios.php" class="btn btn-secondary btn-block">Relatório por Municípios</a>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <?php include '../includes/footer.php'; ?>
    </div>
</body>
</html>