<?php
require '../backend/conexao.php';
require '../backend/exportar.php'; // Script comum para exportação

$dataInicio = $_GET['data_inicio'] ?? date('Y-m-01');
$dataFim = $_GET['data_fim'] ?? date('Y-m-t');

$query = $conn->prepare("
    SELECT 
        u.nome AS atendente,
        COUNT(a.id) AS total_atendimentos,
        AVG(TIMESTAMPDIFF(SECOND, a.data_inicio, a.data_fim)) AS tempo_medio_atendimento,
        SUM(CASE WHEN a.status = 'Fechado' THEN 1 ELSE 0 END) AS atendimentos_fechados,
        ROUND((SUM(CASE WHEN a.status = 'Fechado' THEN 1 ELSE 0 END) / COUNT(a.id)) * 100, 2) AS taxa_cumprimento_sla
    FROM atendimentos a
    INNER JOIN usuarios u ON a.usuario_id = u.id
    WHERE a.data_inicio BETWEEN ? AND ?
    GROUP BY u.id
");
$query->execute([$dataInicio, $dataFim]);

$dados = $query->fetchAll(PDO::FETCH_ASSOC);

exportarRelatorio('Relatório de SLA', $dados);
?>