<?php
require '../conexao.php';

$query = "SELECT atendente, COUNT(*) AS total FROM atendimentos GROUP BY atendente ORDER BY total DESC";
$stmt = $conn->query($query);
$resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);

echo json_encode($resultados);
?>