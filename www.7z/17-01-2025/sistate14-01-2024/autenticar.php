<?php
session_start();
require 'backend/conexao.php'; // Arquivo que contém a conexão com o banco de dados

// Verifica se os dados foram enviados via POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $login = $_POST['login'] ?? '';
    $senha = $_POST['senha'] ?? '';
    $captcha = $_POST['captcha'] ?? '';

    // Verifica se o captcha está correto
    if ($captcha !== $_SESSION['captcha']) {
        $_SESSION['erro'] = 'Captcha incorreto.';
        header('Location: login.php');
        exit;
    }

    // Prepara a consulta SQL para verificar as credenciais do usuário
    $stmt = $conn->prepare('SELECT * FROM usuarios WHERE login = ?');
    $stmt->bind_param('s', $login);
    $stmt->execute();
    $result = $stmt->get_result();
    $usuario = $result->fetch_assoc();

    // Verifica se o usuário foi encontrado e se a senha está correta
    if ($usuario && password_verify($senha, $usuario['senha'])) {
        // Autenticação bem-sucedida
        $_SESSION['usuario'] = $usuario['login'];
        header('Location: dashboard.php'); // Redireciona para a página inicial
        exit;
    } else {
        // Autenticação falhou
        $_SESSION['erro'] = 'Usuário ou senha incorretos.';
        header('Location: login.php');
        exit;
    }
} else {
    // Redireciona para a página de login se o acesso não for via POST
    header('Location: login.php');
    exit;
}
?>