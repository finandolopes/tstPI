-- Recriação do Banco de Dados
DROP DATABASE IF EXISTS sistema_atendimento;
CREATE DATABASE sistema_atendimento;
USE sistema_atendimento;

-- Tabela de Perfis
CREATE TABLE perfis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL UNIQUE
);

-- Inserção de Perfis
INSERT INTO perfis (id, nome) VALUES
    (1, 'Administrador Sistema'),
    (2, 'Administrador'),
    (3, 'Coordenador Atendimento'),
    (4, 'Atendente CAT'),
    (5, 'Relatórios');

-- Tabela de Usuários
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    login VARCHAR(50) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    perfil_id INT NOT NULL,
    status ENUM('ativo', 'inativo') DEFAULT 'ativo',
    bloqueado BOOLEAN DEFAULT FALSE,
    data_bloqueio DATETIME NULL,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (perfil_id) REFERENCES perfis(id) ON DELETE CASCADE
);

-- Tabela de Permissões
CREATE TABLE permissoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    descricao TEXT DEFAULT NULL
);

-- Inserção de Permissões
INSERT INTO permissoes (nome, descricao) VALUES
    ('Acessar Dashboard', 'Permissão para acessar o dashboard'),
    ('Gerenciar Usuários', 'Permissão para gerenciar usuários'),
    ('Visualizar Relatórios', 'Permissão para visualizar relatórios'),
    ('Criar Atendimentos', 'Permissão para criar novos atendimentos'),
    ('Editar Atendimentos', 'Permissão para editar atendimentos existentes'),
    ('Excluir Atendimentos', 'Permissão para excluir atendimentos'),
    ('Configurar Sistema', 'Permissão para configurar o sistema'),
    ('Visualizar Logs', 'Permissão para visualizar logs de auditoria'),
    ('Gerenciar Unidades', 'Permissão para gerenciar unidades'),
    ('Gerenciar Municípios', 'Permissão para gerenciar municípios'),
    ('Gerenciar DRS', 'Permissão para gerenciar DRS'),
    ('Gerenciar Macro Regiões', 'Permissão para gerenciar macro-regiões'),
    ('Gerenciar Origens de Atendimento', 'Permissão para gerenciar origens de atendimento'),
    ('Gerenciar Motivos de Atendimento', 'Permissão para gerenciar motivos de atendimento'),
    ('Gerenciar Recursos de Atendimento', 'Permissão para gerenciar recursos de atendimento');

-- Tabela de Relacionamento Usuário-Permissões
CREATE TABLE usuario_permissoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    permissao_id INT NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (permissao_id) REFERENCES permissoes(id) ON DELETE CASCADE
);

-- Tabela de Atendimentos
CREATE TABLE atendimentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    data_inicio DATETIME DEFAULT CURRENT_TIMESTAMP,
    data_fim DATETIME DEFAULT NULL,
    origem_id INT NOT NULL,
    recurso_id INT NOT NULL,
    motivo_id INT NOT NULL,
    descricao TEXT DEFAULT NULL,
    codigo_paciente VARCHAR(50) DEFAULT NULL,
    unidade_solicitante VARCHAR(100) DEFAULT NULL,
    unidade_executante VARCHAR(100) DEFAULT NULL,
    status ENUM('Aberto', 'Pendente', 'Fechado') NOT NULL DEFAULT 'Aberto',
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Tabela de Configuração de Dashboard
CREATE TABLE config_dashboard (
    id INT AUTO_INCREMENT PRIMARY KEY,
    perfil_id INT NOT NULL,
    card_id VARCHAR(50) NOT NULL,
    ativo BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (perfil_id) REFERENCES perfis(id) ON DELETE CASCADE
);

-- Tabela de Configuração de Backups
CREATE TABLE configuracoes_backup (
    id INT AUTO_INCREMENT PRIMARY KEY,
    periodicidade ENUM('diário', 'semanal', 'mensal') NOT NULL DEFAULT 'diário',
    hora TIME NOT NULL DEFAULT '02:00:00',
    caminho_backup VARCHAR(255) NOT NULL DEFAULT '../backups',
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de Configuração de Integração API
CREATE TABLE configuracoes_integracao (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome_app VARCHAR(100) NOT NULL,
    api_key VARCHAR(255) NOT NULL UNIQUE,
    ativo BOOLEAN DEFAULT TRUE,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de Logs de Login
CREATE TABLE login_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT DEFAULT NULL,
    ip_address VARCHAR(45) NOT NULL,
    status ENUM('success', 'failed') NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

-- Tabela de Unidades
CREATE TABLE unidades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cnes VARCHAR(15) NOT NULL UNIQUE,
    nome VARCHAR(100) NOT NULL,
    municipio_id INT NOT NULL,
    status ENUM('ativo', 'inativo') DEFAULT 'ativo',
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (municipio_id) REFERENCES municipios(id) ON DELETE CASCADE
);

-- Tabela de Origens de Atendimento
CREATE TABLE origens_atendimento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    status ENUM('ativo', 'inativo') DEFAULT 'ativo'
);

-- Tabela de Motivos de Atendimento
CREATE TABLE motivos_atendimento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    descricao TEXT,
    obrigatorio BOOLEAN DEFAULT FALSE,
    status ENUM('ativo', 'inativo') DEFAULT 'ativo',
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de Recursos
CREATE TABLE recursos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    status ENUM('ativo', 'inativo') DEFAULT 'ativo'
);

-- Inserção de Usuário Master com Todas as Permissões
INSERT INTO usuarios (nome, email, login, senha, perfil_id) VALUES
    ('Administrador Master', 'master@sistema.com', 'admin', '$2y$10$7p/NHHzszKHNlP7r6dFbMeaDsAXN60DujmD/U2JvIo/yxwwj8UdcO', 1);

INSERT INTO usuario_permissoes (usuario_id, permissao_id)
SELECT 1, id FROM permissoes;