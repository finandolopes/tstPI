<?php
// Configurações do banco de dados
$host = '127.0.0.1';
$db = 'sistema_atendimento';
$user = 'root';
$pass = '';
$charset = 'utf8mb4';
$socket = '/data/data/com.termux/files/usr/tmp/mysqld.sock'; // Caminho do socket no Termux

// DSN de conexão
$dsn = "mysql:host=$host;dbname=$db;charset=$charset;unix_socket=$socket";

try {
    // Conexão com o banco de dados
    $pdo = new PDO($dsn, $user, $pass);
    $pdo->setAttribute(PDO::ATTR_ERRMODE, PDO::ERRMODE_EXCEPTION);

    // Dados do novo usuário
    $nome = 'Fernando Lopes';
    $email = 'fernando.lopes@exemplo.com';
    $login = 'Fernando.lopes';
    $senha = '@m0r3Brun@love';
    $perfil_id = 1; // Perfil de Administrador Sistema
    $status = 'ativo';

    // Criptografa a senha usando bcrypt
    $senhaHash = password_hash($senha, PASSWORD_BCRYPT);

    // Insere o novo usuário no banco de dados
    $sql = "INSERT INTO usuarios (nome, email, login, senha, perfil_id, status) 
            VALUES (:nome, :email, :login, :senha, :perfil_id, :status)";

    $stmt = $pdo->prepare($sql);
    $stmt->execute([
        ':nome' => $nome,
        ':email' => $email,
        ':login' => $login,
        ':senha' => $senhaHash,
        ':perfil_id' => $perfil_id,
        ':status' => $status
    ]);

    echo "Usuário inserido com sucesso!";
} catch (PDOException $e) {
    die("Erro ao inserir usuário: " . $e->getMessage());
}
?>
