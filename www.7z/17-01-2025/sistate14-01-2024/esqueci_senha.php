<?php
session_start();
$erro = '';
$sucesso = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require 'backend/conexao.php';

    $email = $_POST['email'];

    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ? AND status = 'ativo'");
    $stmt->execute([$email]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($usuario) {
        $token = bin2hex(random_bytes(32));
        $stmt = $conn->prepare("INSERT INTO redefinicoes_senha (usuario_id, token, expira_em) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 1 HOUR))");
        $stmt->execute([$usuario['id'], $token]);

        // Enviar e-mail com o link
        $link = "http://seusistema.com/redefinir_senha.php?token=$token";
        mail($email, "Redefinição de Senha", "Clique no link para redefinir sua senha: $link");

        $sucesso = 'Um link para redefinir sua senha foi enviado para o e-mail informado.';
    } else {
        $erro = 'E-mail não encontrado.';
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Esqueci Minha Senha</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <div class="container d-flex justify-content-center align-items-center vh-100">
        <div class="card shadow-sm p-4" style="width: 400px;">
            <h3 class="text-center mb-4">Esqueci Minha Senha</h3>
            <?php if ($erro): ?>
                <div class="alert alert-danger"><?= $erro ?></div>
            <?php elseif ($sucesso): ?>
                <div class="alert alert-success"><?= $sucesso ?></div>
            <?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label for="email" class="form-label">E-mail</label>
                    <input type="email" class="form-control" id="email" name="email" required>
                </div>                
                <div class="container-login100-form-btn" style="margin-top:20px">
					<div class="col-sm-12">
						<button type="submit" class="btn btn-primary" style="padding-right:50px; padding-left:50px; font-size:13px">
							Enviar
						</button>
					</div>
					<a href="login.php" class="dis-block hov1 p-r-30 p-t-10 p-b-10 p-l-10">
						Voltar
						<i class="fa fa-long-arrow-right m-l-5"></i>
					</a>
				</div>
        </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>