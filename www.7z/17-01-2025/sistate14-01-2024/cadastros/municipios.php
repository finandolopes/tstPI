<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

require '../backend/conexao.php';
// Capturar ações
$acao = $_GET['acao'] ?? '';
$id = $_GET['id'] ?? null;

// Processar formulário de cadastro/edição
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $estado_id = $_POST['estado_id'];
    $status = $_POST['status'];

    if ($acao === 'editar' && $id) {
        $stmt = $conn->prepare("UPDATE municipios SET nome = ?, estado_id = ?, status = ? WHERE id = ?");
        $stmt->execute([$nome, $estado_id, $status, $id]);
        $mensagem = 'Município atualizado com sucesso!';
    } else {
        $stmt = $conn->prepare("INSERT INTO municipios (nome, estado_id, status) VALUES (?, ?, ?)");
        $stmt->execute([$nome, $estado_id, $status]);
        $mensagem = 'Município criado com sucesso!';
    }

    header('Location: municipios.php?mensagem=' . urlencode($mensagem));
    exit;
}

// Buscar municípios existentes
$municipios = $conn->query("SELECT m.*, e.nome AS estado_nome FROM municipios m JOIN estados e ON m.estado_id = e.id")->fetchAll(PDO::FETCH_ASSOC);
$estados = $conn->query("SELECT * FROM estados")->fetchAll(PDO::FETCH_ASSOC);

require '../includes/header.php';
require '../includes/sidebar.php';
?>
<div class="content-wrapper">
    <section class="content">
        <div class="container-fluid">
            <h1>Cadastro de Municípios</h1>

            <?php if (isset($_GET['mensagem'])): ?>
                <div class="alert alert-success"><?= htmlspecialchars($_GET['mensagem']) ?></div>
            <?php endif; ?>

            <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#modalMunicipio">Novo Município</button>

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Estado</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($municipios as $municipio): ?>
                        <tr>
                            <td><?= $municipio['id'] ?></td>
                            <td><?= $municipio['nome'] ?></td>
                            <td><?= $municipio['estado_nome'] ?></td>
                            <td><?= $municipio['status'] ?></td>
                            <td>
                                <a href="municipios.php?acao=editar&id=<?= $municipio['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                                <a href="municipios.php?acao=excluir&id=<?= $municipio['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir este município?')">Excluir</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
</div>

<!-- Modal -->
<div class="modal fade" id="modalMunicipio" tabindex="-1" aria-labelledby="modalMunicipioLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalMunicipioLabel"><?= $acao === 'editar' ? 'Editar' : 'Novo' ?> Município</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="nome" class="form-label">Nome</label>
                        <input type="text" name="nome" id="nome" class="form-control" value="<?= $acao === 'editar' && $id ? $municipio['nome'] : '' ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="estado_id" class="form-label">Estado</label>
                        <select name="estado_id" id="estado_id" class="form-control" required>
                            <?php foreach ($estados as $estado): ?>
                                <option value="<?= $estado['id'] ?>" <?= $acao === 'editar' && $id && $municipio['estado_id'] == $estado['id'] ? 'selected' : '' ?>><?= $estado['nome'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select name="status" id="status" class="form-control">
                            <option value="ativo" <?= $acao === 'editar' && $id && $municipio['status'] === 'ativo' ? 'selected' : '' ?>>Ativo</option>
                            <option value="inativo" <?= $acao === 'editar' && $id && $municipio['status'] === 'inativo' ? 'selected' : '' ?>>Inativo</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require '../includes/footer.php'; ?>