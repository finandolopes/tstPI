<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

require '../backend/conexao.php';

// Capturar ações
$acao = $_GET['acao'] ?? '';
$id = $_GET['id'] ?? null;

// Processar formulário de cadastro/edição
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $status = $_POST['status'];

    if ($acao === 'editar' && $id) {
        $stmt = $conn->prepare("UPDATE drs SET nome = ?, status = ? WHERE id = ?");
        $stmt->execute([$nome, $status, $id]);
        $mensagem = 'DRS atualizado com sucesso!';
    } else {
        $stmt = $conn->prepare("INSERT INTO drs (nome, status) VALUES (?, ?)");
        $stmt->execute([$nome, $status]);
        $mensagem = 'DRS criado com sucesso!';
    }

    header('Location: drs.php?mensagem=' . urlencode($mensagem));
    exit;
}

// Buscar DRS existentes
$drsList = $conn->query("SELECT * FROM drs")->fetchAll(PDO::FETCH_ASSOC);

require '../includes/header.php';
require '../includes/sidebar.php';
?>
<div class="content-wrapper">
    <section class="content">
        <div class="container-fluid">
            <h1>Cadastro de DRS</h1>

            <?php if (isset($_GET['mensagem'])): ?>
                <div class="alert alert-success"><?= htmlspecialchars($_GET['mensagem']) ?></div>
            <?php endif; ?>

            <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#modalDrs">Novo DRS</button>

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($drsList as $drs): ?>
                        <tr>
                            <td><?= $drs['id'] ?></td>
                            <td><?= $drs['nome'] ?></td>
                            <td><?= $drs['status'] ?></td>
                            <td>
                                <a href="drs.php?acao=editar&id=<?= $drs['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                                <a href="drs.php?acao=excluir&id=<?= $drs['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir este DRS?')">Excluir</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
</div>

<!-- Modal -->
<div class="modal fade" id="modalDrs" tabindex="-1" aria-labelledby="modalDrsLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalDrsLabel"><?= $acao === 'editar' ? 'Editar' : 'Novo' ?> DRS</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="nome" class="form-label">Nome</label>
                        <input type="text" name="nome" id="nome" class="form-control" value="<?= $acao === 'editar' && $id ? $drs['nome'] : '' ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select name="status" id="status" class="form-control">
                            <option value="ativo" <?= $acao === 'editar' && $id && $drs['status'] === 'ativo' ? 'selected' : '' ?>>Ativo</option>
                            <option value="inativo" <?= $acao === 'editar' && $id && $drs['status'] === 'inativo' ? 'selected' : '' ?>>Inativo</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require '../includes/footer.php'; ?>