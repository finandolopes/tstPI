<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

require '../backend/conexao.php';

// Processar formulário de cadastro/edição
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $descricao = $_POST['descricao'];
    $obrigatorio = isset($_POST['obrigatorio']) ? 1 : 0;
    $status = $_POST['status'];
    $id = $_POST['id'] ?? null;

    if ($id) {
        $stmt = $conn->prepare("UPDATE motivos_atendimento SET nome = ?, descricao = ?, obrigatorio = ?, status = ? WHERE id = ?");
        $stmt->execute([$nome, $descricao, $obrigatorio, $status, $id]);
        $mensagem = 'Motivo atualizado com sucesso!';
    } else {
        $stmt = $conn->prepare("INSERT INTO motivos_atendimento (nome, descricao, obrigatorio, status) VALUES (?, ?, ?, ?)");
        $stmt->execute([$nome, $descricao, $obrigatorio, $status]);
        $mensagem = 'Motivo criado com sucesso!';
    }

    header('Location: motivos_atendimento.php?mensagem=' . urlencode($mensagem));
    exit;
}

// Buscar Motivos existentes
$motivos = $conn->query("SELECT * FROM motivos_atendimento")->fetchAll(PDO::FETCH_ASSOC);

require '../includes/header.php';
require '../includes/sidebar.php';
?>
<div class="content-wrapper">
    <section class="content">
        <div class="container-fluid">
            <h1>Motivos de Atendimento</h1>

            <?php if (isset($_GET['mensagem'])): ?>
                <div class="alert alert-success"><?= htmlspecialchars($_GET['mensagem']) ?></div>
            <?php endif; ?>

            <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#modalMotivo">Novo Motivo</button>

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Descrição</th>
                        <th>Obrigatório</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($motivos as $motivo): ?>
                        <tr>
                            <td><?= $motivo['id'] ?></td>
                            <td><?= $motivo['nome'] ?></td>
                            <td><?= $motivo['descricao'] ?></td>
                            <td><?= $motivo['obrigatorio'] ? 'Sim' : 'Não' ?></td>
                            <td><?= ucfirst($motivo['status']) ?></td>
                            <td>
                                <a href="#" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modalMotivo" 
                                    data-id="<?= $motivo['id'] ?>"
                                    data-nome="<?= $motivo['nome'] ?>"
                                    data-descricao="<?= $motivo['descricao'] ?>"
                                    data-obrigatorio="<?= $motivo['obrigatorio'] ?>"
                                    data-status="<?= $motivo['status'] ?>">Editar</a>
                                <a href="excluir_motivo.php?id=<?= $motivo['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir este motivo?')">Excluir</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
</div>

<!-- Modal -->
<div class="modal fade" id="modalMotivo" tabindex="-1" aria-labelledby="modalMotivoLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="id" id="motivoId">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalMotivoLabel">Novo Motivo</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="nome" class="form-label">Nome</label>
                        <input type="text" name="nome" id="nome" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="descricao" class="form-label">Descrição</label>
                        <textarea name="descricao" id="descricao" class="form-control" rows="3"></textarea>
                    </div>
                    <div class="form-check">
                        <input type="checkbox" name="obrigatorio" id="obrigatorio" class="form-check-input">
                        <label for="obrigatorio" class="form-check-label">Obrigatório</label>
                    </div>
                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select name="status" id="status" class="form-control">
                            <option value="ativo">Ativo</option>
                            <option value="inativo">Inativo</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    const modalMotivo = document.getElementById('modalMotivo');
    modalMotivo.addEventListener('show.bs.modal', function (event) {
        const button = event.relatedTarget;
        const id = button.getAttribute('data-id') || '';
        const nome = button.getAttribute('data-nome') || '';
        const descricao = button.getAttribute('data-descricao') || '';
        const obrigatorio = button.getAttribute('data-obrigatorio') == '1';
        const status = button.getAttribute('data-status') || 'ativo';

        modalMotivo.querySelector('#motivoId').value = id;
        modalMotivo.querySelector('#nome').value = nome;
        modalMotivo.querySelector('#descricao').value = descricao;
        modalMotivo.querySelector('#obrigatorio').checked = obrigatorio;
        modalMotivo.querySelector('#status').value = status;
    });
</script>

<?php require '../includes/footer.php'; ?>