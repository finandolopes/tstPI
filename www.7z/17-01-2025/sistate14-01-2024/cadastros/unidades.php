<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

require '../backend/conexao.php';
// Capturar ações
$acao = $_GET['acao'] ?? '';
$id = $_GET['id'] ?? null;

// Processar formulário de cadastro/edição
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $cnes = $_POST['cnes'];
    $municipio_id = $_POST['municipio_id'];
    $status = $_POST['status'];

    if ($acao === 'editar' && $id) {
        $stmt = $conn->prepare("UPDATE unidades SET nome = ?, cnes = ?, municipio_id = ?, status = ? WHERE id = ?");
        $stmt->execute([$nome, $cnes, $municipio_id, $status, $id]);
        $mensagem = 'Unidade atualizada com sucesso!';
    } else {
        $stmt = $conn->prepare("INSERT INTO unidades (nome, cnes, municipio_id, status) VALUES (?, ?, ?, ?)");
        $stmt->execute([$nome, $cnes, $municipio_id, $status]);
        $mensagem = 'Unidade criada com sucesso!';
    }

    header('Location: unidades.php?mensagem=' . urlencode($mensagem));
    exit;
}

// Buscar unidades existentes
$unidades = $conn->query("SELECT u.*, m.nome AS municipio_nome FROM unidades u JOIN municipios m ON u.municipio_id = m.id")->fetchAll(PDO::FETCH_ASSOC);
$municipios = $conn->query("SELECT * FROM municipios")->fetchAll(PDO::FETCH_ASSOC);

require '../includes/header.php';
require '../includes/sidebar.php';
?>
<div class="content-wrapper">
    <section class="content">
        <div class="container-fluid">
            <h1>Cadastro de Unidades</h1>

            <?php if (isset($_GET['mensagem'])): ?>
                <div class="alert alert-success"><?= htmlspecialchars($_GET['mensagem']) ?></div>
            <?php endif; ?>

            <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#modalUnidade">Nova Unidade</button>

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>CNES</th>
                        <th>Município</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($unidades as $unidade): ?>
                        <tr>
                            <td><?= $unidade['id'] ?></td>
                            <td><?= $unidade['nome'] ?></td>
                            <td><?= $unidade['cnes'] ?></td>
                            <td><?= $unidade['municipio_nome'] ?></td>
                            <td><?= $unidade['status'] ?></td>
                            <td>
                                <a href="unidades.php?acao=editar&id=<?= $unidade['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                                <a href="unidades.php?acao=excluir&id=<?= $unidade['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir esta unidade?')">Excluir</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
</div>
<!-- Modal -->
<div class="modal fade" id="modalUnidade" tabindex="-1" aria-labelledby="modalUnidadeLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalUnidadeLabel"><?= $acao === 'editar' ? 'Editar' : 'Nova' ?> Unidade</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="nome" class="form-label">Nome</label>
                        <input type="text" name="nome" id="nome" class="form-control" value="<?= $acao === 'editar' && $id ? $unidade['nome'] : '' ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="cnes" class="form-label">CNES</label>
                        <input type="text" name="cnes" id="cnes" class="form-control" value="<?= $acao === 'editar' && $id ? $unidade['cnes'] : '' ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="municipio_id" class="form-label">Município</label>
                        <select name="municipio_id" id="municipio_id" class="form-control" required>
                            <?php foreach ($municipios as $municipio): ?>
                                <option value="<?= $municipio['id'] ?>" <?= $acao === 'editar' && $id && $unidade['municipio_id'] == $municipio['id'] ? 'selected' : '' ?>><?= $municipio['nome'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select name="status" id="status" class="form-control">
                            <option value="ativo" <?= $acao === 'editar' && $id && $unidade['status'] === 'ativo' ? 'selected' : '' ?>>Ativo</option>
                            <option value="inativo" <?= $acao === 'editar' && $id && $unidade['status'] === 'inativo' ? 'selected' : '' ?>>Inativo</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require '../includes/footer.php'; ?>
