<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

require '../backend/conexao.php';

// Capturar ações
$acao = $_GET['acao'] ?? '';
$id = $_GET['id'] ?? null;

// Processar formulário de cadastro/edição
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $status = $_POST['status'];

    if ($acao === 'editar' && $id) {
        $stmt = $conn->prepare("UPDATE macro_regioes SET nome = ?, status = ? WHERE id = ?");
        $stmt->execute([$nome, $status, $id]);
        $mensagem = 'Macro-Região atualizada com sucesso!';
    } else {
        $stmt = $conn->prepare("INSERT INTO macro_regioes (nome, status) VALUES (?, ?)");
        $stmt->execute([$nome, $status]);
        $mensagem = 'Macro-Região criada com sucesso!';
    }

    header('Location: macro_regioes.php?mensagem=' . urlencode($mensagem));
    exit;
}

// Buscar Macro-Regiões existentes
$macroRegioes = $conn->query("SELECT * FROM macro_regioes")->fetchAll(PDO::FETCH_ASSOC);

require '../includes/header.php';
require '../includes/sidebar.php';
?>
<div class="content-wrapper">
    <section class="content">
        <div class="container-fluid">
            <h1>Cadastro de Macro-Regiões</h1>

            <?php if (isset($_GET['mensagem'])): ?>
                <div class="alert alert-success"><?= htmlspecialchars($_GET['mensagem']) ?></div>
            <?php endif; ?>

            <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#modalMacroRegiao">Nova Macro-Região</button>

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($macroRegioes as $macroRegiao): ?>
                        <tr>
                            <td><?= $macroRegiao['id'] ?></td>
                            <td><?= $macroRegiao['nome'] ?></td>
                            <td><?= $macroRegiao['status'] ?></td>
                            <td>
                                <a href="macro_regioes.php?acao=editar&id=<?= $macroRegiao['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                                <a href="macro_regioes.php?acao=excluir&id=<?= $macroRegiao['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir esta Macro-Região?')">Excluir</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
</div>

<!-- Modal -->
<div class="modal fade" id="modalMacroRegiao" tabindex="-1" aria-labelledby="modalMacroRegiaoLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalMacroRegiaoLabel"><?= $acao === 'editar' ? 'Editar' : 'Nova' ?> Macro-Região</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="nome" class="form-label">Nome</label>
                        <input type="text" name="nome" id="nome" class="form-control" value="<?= $acao === 'editar' && $id ? $macroRegiao['nome'] : '' ?>" required>
                    </div>
                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select name="status" id="status" class="form-control">
                            <option value="ativo" <?= $acao === 'editar' && $id && $macroRegiao['status'] === 'ativo' ? 'selected' : '' ?>>Ativo</option>
                            <option value="inativo" <?= $acao === 'editar' && $id && $macroRegiao['status'] === 'inativo' ? 'selected' : '' ?>>Inativo</option>
                        </select>
                    </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<?php require '../includes/footer.php'; ?>