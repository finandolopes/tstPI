<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

require '../backend/conexao.php';

// Processar formulário de cadastro/edição
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $status = $_POST['status'];
    $id = $_POST['id'] ?? null;

    if ($id) {
        $stmt = $conn->prepare("UPDATE origens_atendimento SET nome = ?, status = ? WHERE id = ?");
        $stmt->execute([$nome, $status, $id]);
        $mensagem = 'Origem de Atendimento atualizada com sucesso!';
    } else {
        $stmt = $conn->prepare("INSERT INTO origens_atendimento (nome, status) VALUES (?, ?)");
        $stmt->execute([$nome, $status]);
        $mensagem = 'Origem de Atendimento criada com sucesso!';
    }

    header('Location: origens_atendimento.php?mensagem=' . urlencode($mensagem));
    exit;
}

// Buscar Origens de Atendimento existentes
$origens = $conn->query("SELECT * FROM origens_atendimento")->fetchAll(PDO::FETCH_ASSOC);

require '../includes/header.php';
require '../includes/sidebar.php';
?>
<div class="content-wrapper">
    <section class="content">
        <div class="container-fluid">
            <h1>Origens de Atendimento</h1>

            <?php if (isset($_GET['mensagem'])): ?>
                <div class="alert alert-success"><?= htmlspecialchars($_GET['mensagem']) ?></div>
            <?php endif; ?>

            <button class="btn btn-primary mb-3" data-bs-toggle="modal" data-bs-target="#modalOrigem">Nova Origem</button>

            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Nome</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($origens as $origem): ?>
                        <tr>
                            <td><?= $origem['id'] ?></td>
                            <td><?= $origem['nome'] ?></td>
                            <td><?= ucfirst($origem['status']) ?></td>
                            <td>
                                <a href="#" class="btn btn-warning btn-sm" data-bs-toggle="modal" data-bs-target="#modalOrigem" 
                                    data-id="<?= $origem['id'] ?>"
                                    data-nome="<?= $origem['nome'] ?>"
                                    data-status="<?= $origem['status'] ?>">Editar</a>
                                <a href="excluir_origem.php?id=<?= $origem['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir esta origem de atendimento?')">Excluir</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
</div>

<!-- Modal -->
<div class="modal fade" id="modalOrigem" tabindex="-1" aria-labelledby="modalOrigemLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <form method="POST">
                <input type="hidden" name="id" id="origemId">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalOrigemLabel">Nova Origem</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <div class="mb-3">
                        <label for="nome" class="form-label">Nome</label>
                        <input type="text" name="nome" id="nome" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="status" class="form-label">Status</label>
                        <select name="status" id="status" class="form-control">
                            <option value="ativo">Ativo</option>
                            <option value="inativo">Inativo</option>
                        </select>
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </div>
            </form>
        </div>
    </div>
</div>

<script>
    const modalOrigem = document.getElementById('modalOrigem');
    modalOrigem.addEventListener('show.bs.modal', function (event) {
        const button = event.relatedTarget;
        const id = button.getAttribute('data-id') || '';
        const nome = button.getAttribute('data-nome') || '';
        const status = button.getAttribute('data-status') || 'ativo';

        modalOrigem.querySelector('#origemId').value = id;
        modalOrigem.querySelector('#nome').value = nome;
        modalOrigem.querySelector('#status').value = status;
    });
</script>

<?php require '../includes/footer.php'; ?>