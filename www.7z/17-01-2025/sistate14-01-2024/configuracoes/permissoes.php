<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

require '../backend/conexao.php';

// Consulta permissões
$stmt = $conn->prepare("SELECT * FROM permissoes");
$stmt->execute();
$permissoes = $stmt->fetchAll(PDO::FETCH_ASSOC);

require '../includes/header.php';
?>
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Gerenciar Permissões</h1>
                </div>
            </div>
        </div>
    </div>
    <section class="content">
        <div class="container-fluid">
            <div class="card">
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nome</th>
                                <th>Descrição</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($permissoes as $permissao): ?>
                                <tr>
                                    <td><?= htmlspecialchars($permissao['id']) ?></td>
                                    <td><?= htmlspecialchars($permissao['nome']) ?></td>
                                    <td><?= htmlspecialchars($permissao['descricao']) ?></td>
                                    <td>
                                        <a href="editar_permissao.php?id=<?= $permissao['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                                        <a href="excluir_permissao.php?id=<?= $permissao['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir esta permissão?')">Excluir</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer">
                    <a href="criar_permissao.php" class="btn btn-primary">Adicionar Nova Permissão</a>
                </div>
            </div>
        </div>
    </section>
</div>
<?php require '../includes/footer.php'; ?>