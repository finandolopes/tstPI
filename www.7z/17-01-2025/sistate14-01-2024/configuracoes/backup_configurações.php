<?php
session_start();
require '../backend/conexao.php';
require '../backend/csrf.php';
verificarPermissao('configurar_sistema'); // Validação de permissão

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verificarTokenCSRF($_POST['csrf_token'])) {
        die('Falha na validação de segurança.');
    }
    // Processa as configurações enviadas
}

$csrf_token = gerarTokenCSRF();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurações</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
    <?php include '../includes/header.php'; ?>
    <?php include '../includes/sidebar.php'; ?>

    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Backup</h1>
                    </div>
                </div>
            </div>
        </div>

        <section class="content">
            <div class="container-fluid">
                <form method="POST">
                    <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
                    <div class="card">
                        <div class="card-header">
                            <h3>Configuração de Backups</h3>
                        </div>
                        <div class="card-body">
                            <label for="backup" class="form-label">Periodicidade</label>
                            <select id="backup" class="form-control" name="backup_periodicidade">
                                <option value="diário">Diário</option>
                                <option value="semanal">Semanal</option>
                                <option value="mensal">Mensal</option>
                            </select>
                            <button type="submit" class="btn btn-primary mt-3">Salvar Configuração</button>
                        </div>
                    </div>
                </form>
            </div>
        </section>
    </div>

    <?php include '../includes/footer.php'; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>