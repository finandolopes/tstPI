<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

require '../backend/conexao.php';

// Obtém configurações existentes
$stmt = $conn->prepare("SELECT * FROM configuracoes_backup LIMIT 1");
$stmt->execute();
$configBackup = $stmt->fetch(PDO::FETCH_ASSOC);

// Processa o formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $periodicidade = $_POST['periodicidade'];
    $hora = $_POST['hora'];
    $caminho_backup = $_POST['caminho_backup'];

    if ($configBackup) {
        $stmt = $conn->prepare("UPDATE configuracoes_backup SET periodicidade = :periodicidade, hora = :hora, caminho_backup = :caminho_backup");
        $stmt->execute([':periodicidade' => $periodicidade, ':hora' => $hora, ':caminho_backup' => $caminho_backup]);
    } else {
        $stmt = $conn->prepare("INSERT INTO configuracoes_backup (periodicidade, hora, caminho_backup) VALUES (:periodicidade, :hora, :caminho_backup)");
        $stmt->execute([':periodicidade' => $periodicidade, ':hora' => $hora, ':caminho_backup' => $caminho_backup]);
    }

    header('Location: backups.php');
    exit;
}

require '../includes/header.php';
?>
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Configurações de Backup</h1>
                </div>
            </div>
        </div>
    </div>
    <section class="content">
        <div class="container-fluid">
            <form method="POST">
                <div class="form-group">
                    <label for="periodicidade">Periodicidade</label>
                    <select class="form-control" id="periodicidade" name="periodicidade" required>
                        <option value="diário" <?= $configBackup['periodicidade'] === 'diário' ? 'selected' : '' ?>>Diário</option>
                        <option value="semanal" <?= $configBackup['periodicidade'] === 'semanal' ? 'selected' : '' ?>>Semanal</option>
                        <option value="mensal" <?= $configBackup['periodicidade'] === 'mensal' ? 'selected' : '' ?>>Mensal</option>
                    </select>
                </div>
                <div class="form-group">
                    <label for="hora">Hora</label>
                    <input type="time" class="form-control" id="hora" name="hora" value="<?= htmlspecialchars($configBackup['hora'] ?? '02:00:00') ?>" required>
                </div>
                <div class="form-group">
                    <label for="caminho_backup">Caminho de Backup</label>
                    <input type="text" class="form-control" id="caminho_backup" name="caminho_backup" value="<?= htmlspecialchars($configBackup['caminho_backup'] ?? '../backups') ?>" required>
                </div>
                <button type="submit" class="btn btn-primary">Salvar Configurações</button>
            </form>
        </div>
    </section>
</div>
<?php require '../includes/footer.php'; ?>