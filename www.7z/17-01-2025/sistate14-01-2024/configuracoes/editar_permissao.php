<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

require '../backend/conexao.php';

// Obtém a permissão a ser editada
if (!isset($_GET['id'])) {
    header('Location: permissoes.php');
    exit;
}

$id = intval($_GET['id']);
$stmt = $conn->prepare("SELECT * FROM permissoes WHERE id = :id");
$stmt->execute([':id' => $id]);
$permissao = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$permissao) {
    header('Location: permissoes.php');
    exit;
}

// Processa o formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome']);
    $descricao = trim($_POST['descricao']);

    if ($nome !== '') {
        $stmt = $conn->prepare("UPDATE permissoes SET nome = :nome, descricao = :descricao WHERE id = :id");
        $stmt->execute([':nome' => $nome, ':descricao' => $descricao, ':id' => $id]);
        header('Location: permissoes.php');
        exit;
    }
}

require '../includes/header.php';
?>
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Editar Permissão</h1>
                </div>
            </div>
        </div>
    </div>
    <section class="content">
        <div class="container-fluid">
            <form method="POST">
                <div class="form-group">
                    <label for="nome">Nome da Permissão</label>
                    <input type="text" class="form-control" id="nome" name="nome" value="<?= htmlspecialchars($permissao['nome']) ?>" required>
                </div>
                <div class="form-group">
                    <label for="descricao">Descrição</label>
                    <textarea class="form-control" id="descricao" name="descricao"><?= htmlspecialchars($permissao['descricao']) ?></textarea>
                </div>
                <button type="submit" class="btn btn-primary">Salvar Alterações</button>
            </form>
        </div>
    </section>
</div>
<?php require '../includes/footer.php'; ?>