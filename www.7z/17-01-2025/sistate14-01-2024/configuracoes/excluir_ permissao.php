<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

require '../backend/conexao.php';

// Verifica se o ID foi fornecido
if (!isset($_GET['id'])) {
    header('Location: permissoes.php');
    exit;
}

$id = intval($_GET['id']);

// Exclui a permissão
$stmt = $conn->prepare("DELETE FROM permissoes WHERE id = :id");
$stmt->execute([':id' => $id]);

header('Location: permissoes.php');
exit;
?>