<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

require '../backend/conexao.php';

// Consulta usuários
$stmt = $conn->prepare("SELECT u.id, u.nome, u.email, u.login, p.nome AS perfil, u.status
                        FROM usuarios u
                        LEFT JOIN perfis p ON u.perfil_id = p.id");
$stmt->execute();
$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

require '../includes/header.php';
?>
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Gerenciar Usuários</h1>
                </div>
            </div>
        </div>
    </div>
    <section class="content">
        <div class="container-fluid">
            <div class="card">
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Nome</th>
                                <th>E-mail</th>
                                <th>Login</th>
                                <th>Perfil</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($usuarios as $usuario): ?>
                                <tr>
                                    <td><?= htmlspecialchars($usuario['id']) ?></td>
                                    <td><?= htmlspecialchars($usuario['nome']) ?></td>
                                    <td><?= htmlspecialchars($usuario['email']) ?></td>
                                    <td><?= htmlspecialchars($usuario['login']) ?></td>
                                    <td><?= htmlspecialchars($usuario['perfil']) ?></td>
                                    <td><?= htmlspecialchars($usuario['status']) ?></td>
                                    <td>
                                        <a href="editar_usuario.php?id=<?= $usuario['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                                        <a href="excluir_usuario.php?id=<?= $usuario['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Deseja excluir este usuário?')">Excluir</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
                <div class="card-footer">
                    <a href="criar_usuario.php" class="btn btn-primary">Adicionar Novo Usuário</a>
                </div>
            </div>
        </div>
    </section>
</div>
<?php require '../includes/footer.php'; ?>