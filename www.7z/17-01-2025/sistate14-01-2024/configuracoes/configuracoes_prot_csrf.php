<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}
require '../backend/conexao.php';
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Proteção contra CSRF</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
    <?php include '../includes/header.php'; ?>
    <?php include '../includes/sidebar.php'; ?>

    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Proteção contra CSRF</h1>
                    </div>
                </div>
            </div>
        </div>

        <section class="content">
            <div class="container-fluid">
                <div class="card">
                    <div class="card-body">
                        <h3>Segurança</h3>
                        <form method="POST" action="salvar_configuracoes_avancadas.php">
                            <div class="form-group">
                                <label for="tempoSessao">Tempo de Sessão (minutos)</label>
                                <input type="number" id="tempoSessao" name="tempoSessao" class="form-control" value="30" required>
                            </div>
                            <div class="form-group">
                                <label for="csrfToken">Proteção contra CSRF</label>
                                <select id="csrfToken" name="csrfToken" class="form-control">
                                    <option value="1" selected>Ativado</option>
                                    <option value="0">Desativado</option>
                                </select>
                            </div>
                            <button type="submit" class="btn btn-primary mt-3">Salvar Configurações</button>
                        </form>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <?php include '../includes/footer.php'; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>