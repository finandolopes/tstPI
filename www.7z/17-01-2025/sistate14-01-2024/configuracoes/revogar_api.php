<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

require '../backend/conexao.php';

// Verifica se o ID foi fornecido
if (!isset($_GET['id'])) {
    header('Location: integracao_api.php');
    exit;
}

$id = intval($_GET['id']);

// Revoga a integração
$stmt = $conn->prepare("DELETE FROM configuracoes_integracao WHERE id = :id");
$stmt->execute([':id' => $id]);

header('Location: integracao_api.php');
exit;
?>