<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

require '../backend/conexao.php';

// Processa o formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome_app = trim($_POST['nome_app']);
    $api_key = bin2hex(random_bytes(16)); // Gera um token aleatório
    $ativo = isset($_POST['ativo']) ? 1 : 0;

    $stmt = $conn->prepare("INSERT INTO configuracoes_integracao (nome_app, api_key, ativo) VALUES (:nome_app, :api_key, :ativo)");
    $stmt->execute([':nome_app' => $nome_app, ':api_key' => $api_key, ':ativo' => $ativo]);

    header('Location: integracao_api.php');
    exit;
}

// Obtém as integrações existentes
$stmt = $conn->query("SELECT * FROM configuracoes_integracao");
$integracoes = $stmt->fetchAll(PDO::FETCH_ASSOC);

require '../includes/header.php';
?>
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Integrações com APIs</h1>
                </div>
            </div>
        </div>
    </div>
    <section class="content">
        <div class="container-fluid">
            <form method="POST">
                <div class="form-group">
                    <label for="nome_app">Nome da Aplicação</label>
                    <input type="text" class="form-control" id="nome_app" name="nome_app" required>
                </div>
                <div class="form-group form-check">
                    <input type="checkbox" class="form-check-input" id="ativo" name="ativo" checked>
                    <label class="form-check-label" for="ativo">Ativo</label>
                </div>
                <button type="submit" class="btn btn-primary">Adicionar Integração</button>
            </form>

            <hr>

            <h3>Integrações Atuais</h3>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Nome</th>
                        <th>API Key</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($integracoes as $integracao): ?>
                        <tr>
                            <td><?= htmlspecialchars($integracao['nome_app']) ?></td>
                            <td><?= htmlspecialchars($integracao['api_key']) ?></td>
                            <td><?= $integracao['ativo'] ? 'Ativo' : 'Inativo' ?></td>
                            <td>
                                <a href="revogar_api.php?id=<?= $integracao['id'] ?>" class="btn btn-danger btn-sm">Revogar</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </section>
</div>
<?php require '../includes/footer.php'; ?>