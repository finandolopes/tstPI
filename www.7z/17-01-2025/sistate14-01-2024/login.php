<?php
session_start();
require 'backend/conexao.php';
require 'backend/csrf.php';

$erro = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verificarTokenCSRF($_POST['csrf_token'])) {
        $erro = 'Falha na validação de segurança.';
    } else {
        $login = trim($_POST['login']);
        $senha = $_POST['senha'];

        $stmt = $conn->prepare("SELECT id, senha, nome, perfil_id FROM usuarios WHERE login = :login AND status = 'ativo'");
        $stmt->execute([':login' => $login]);
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

        if ($usuario && password_verify($senha, $usuario['senha'])) {
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['usuario_nome'] = $usuario['nome'];
            $_SESSION['usuario_perfil'] = $usuario['perfil_id'];
            header('Location: dashboard.php');
            exit;
        } else {
            $erro = 'Login ou senha inválidos.';
        }
    }
}

$csrf_token = gerarTokenCSRF();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistema de Atendimento</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css">
</head>
<body>
<div class="container d-flex justify-content-center align-items-center vh-100">
    <div class="card shadow p-4" style="width: 400px;">
        <h3 class="text-center mb-3">Sistema de Atendimento</h3>

        <?php if ($erro): ?>
            <div class="alert alert-danger"><?= htmlspecialchars($erro) ?></div>
        <?php endif; ?>

        <form method="POST">
            <input type="hidden" name="csrf_token" value="<?= htmlspecialchars($csrf_token) ?>">
            <div class="mb-3">
                <label for="login" class="form-label">Login</label>
                <input type="text" class="form-control" id="login" name="login" required>
            </div>
            <div class="mb-3">
                <label for="senha" class="form-label">Senha</label>
                <input type="password" class="form-control" id="senha" name="senha" required>
            </div>            
            <div class="container-login100-form-btn" style="margin-top:20px">
					<div class="col-sm-12">
						<button type="submit" class="btn btn-primary" style="padding-right:50px; padding-left:50px; font-size:13px">
							Entrar
						</button>
					</div>
					<a href="esqueci_senha.php" class="dis-block hov1 p-r-30 p-t-10 p-b-10 p-l-10">
						Esqueci Minha Senha
						<i class="fa fa-long-arrow-right m-l-5"></i>
					</a>
				</div>
        </form>
    </div>
</div>
</body>
</html>