<?php
session_start();

// Define o texto do CAPTCHA
if (!isset($_SESSION['captcha'])) {
    $_SESSION['captcha'] = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789'), 0, 6);
}

// Configurações do captcha
$largura = 120;
$altura = 40;
$imagem = imagecreate($largura, $altura);

// Cores
$fundo = imagecolorallocate($imagem, 255, 255, 255);
$texto = imagecolorallocate($imagem, 0, 0, 0);
$linhas = imagecolorallocate($imagem, 220, 220, 220);

// Adiciona linhas para dificultar a leitura automática
for ($i = 0; $i < 6; $i++) {
    imageline($imagem, rand(0, $largura), rand(0, $altura), rand(0, $largura), rand(0, $altura), $linhas);
}

// Verifica se a fonte existe
$fonte = dirname(__FILE__) . '/assets/fonts/arial.ttf';
if (!file_exists($fonte)) {
    die("Erro: Arquivo da fonte não encontrado.");
}

// Adiciona o texto do captcha
imagettftext($imagem, 20, rand(-10, 10), rand(10, 30), rand(25, 35), $texto, $fonte, $_SESSION['captcha']);

// Cabeçalho da imagem
header("Content-Type: image/png");
imagepng($imagem);
imagedestroy($imagem);
?>