<?php
session_start();
require_once 'backend/conexao.php';

// Verifica se o usuário está autenticado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

// Verifica se o ID foi fornecido
if (!isset($_GET['id']) || empty($_GET['id'])) {
    die('ID do atendimento não especificado.');
}

$id = (int)$_GET['id'];

// Busca os detalhes do atendimento
$stmt = $conn->prepare("SELECT a.*, u.nome AS atendente FROM atendimentos a JOIN usuarios u ON a.usuario_id = u.id WHERE a.id = ?");
$stmt->execute([$id]);
$atendimento = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$atendimento) {
    die('Atendimento não encontrado.');
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Detalhes do Atendimento</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
    <?php include 'includes/header.php'; ?>
    <?php include 'includes/sidebar.php'; ?>

    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Detalhes do Atendimento</h1>
                    </div>
                </div>
            </div>
        </div>

        <section class="content">
            <div class="container-fluid">
                <div class="card">
                    <div class="card-body">
                        <dl class="row">
                            <dt class="col-sm-4">ID do Atendimento</dt>
                            <dd class="col-sm-8"><?= htmlspecialchars($atendimento['id']) ?></dd>

                            <dt class="col-sm-4">Data de Início</dt>
                            <dd class="col-sm-8"><?= htmlspecialchars($atendimento['data_inicio']) ?></dd>

                            <dt class="col-sm-4">Atendente</dt>
                            <dd class="col-sm-8"><?= htmlspecialchars($atendimento['atendente']) ?></dd>

                            <dt class="col-sm-4">Origem</dt>
                            <dd class="col-sm-8"><?= htmlspecialchars($atendimento['origem_id']) ?></dd>

                            <dt class="col-sm-4">Recurso</dt>
                            <dd class="col-sm-8"><?= htmlspecialchars($atendimento['recurso_id']) ?></dd>

                            <dt class="col-sm-4">Motivo</dt>
                            <dd class="col-sm-8"><?= htmlspecialchars($atendimento['motivo_id']) ?></dd>

                            <dt class="col-sm-4">Descrição</dt>
                            <dd class="col-sm-8"><?= htmlspecialchars($atendimento['descricao']) ?></dd>

                            <dt class="col-sm-4">Status</dt>
                            <dd class="col-sm-8"><?= htmlspecialchars($atendimento['status']) ?></dd>
                        </dl>
                        <a href="editar_atendimento.php?id=<?= $id ?>" class="btn btn-warning">Editar</a>
                        <button class="btn btn-danger" id="btnExcluir">Excluir</button>
                        <a href="dashboard.php" class="btn btn-secondary">Voltar</a>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <?php include 'includes/footer.php'; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
<script>
    document.getElementById('btnExcluir').addEventListener('click', function () {
        if (confirm('Tem certeza de que deseja excluir este atendimento?')) {
            fetch('backend/excluir_atendimento.php?id=<?= $id ?>')
                .then(response => response.json())
                .then(data => {
                    if (data.success) {
                        alert('Atendimento excluído com sucesso!');
                        window.location.href = 'dashboard.php';
                    } else {
                        alert('Erro ao excluir atendimento: ' + data.message);
                    }
                });
        }
    });
</script>
</body>
</html>