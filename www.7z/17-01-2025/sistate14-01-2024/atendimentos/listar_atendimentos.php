<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

require '../backend/conexao.php';

// Filtros de busca
$filtro_atendente = $_GET['atendente'] ?? '';
$filtro_data_inicio = $_GET['data_inicio'] ?? '';
$filtro_data_fim = $_GET['data_fim'] ?? '';
$filtro_status = $_GET['status'] ?? '';

// Consulta com filtros dinâmicos
$query = "SELECT a.id, u.nome AS atendente, a.data_inicio, a.status, o.nome AS origem, a.descricao 
          FROM atendimentos a
          JOIN usuarios u ON a.usuario_id = u.id
          JOIN origens_atendimento o ON a.origem_id = o.id
          WHERE 1=1";

$params = [];
if (!empty($filtro_atendente)) {
    $query .= " AND u.nome LIKE ?";
    $params[] = "%$filtro_atendente%";
}
if (!empty($filtro_data_inicio)) {
    $query .= " AND a.data_inicio >= ?";
    $params[] = $filtro_data_inicio . ' 00:00:00';
}
if (!empty($filtro_data_fim)) {
    $query .= " AND a.data_inicio <= ?";
    $params[] = $filtro_data_fim . ' 23:59:59';
}
if (!empty($filtro_status)) {
    $query .= " AND a.status = ?";
    $params[] = $filtro_status;
}

$stmt = $conn->prepare($query);
$stmt->execute($params);
$atendimentos = $stmt->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listar Atendimentos</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
        <!-- Navbar -->
        <?php include '../includes/header.php'; ?>

        <!-- Sidebar -->
        <?php include '../includes/sidebar.php'; ?>

        <!-- Content Wrapper -->
        <div class="content-wrapper">
            <div class="content-header">
                <div class="container-fluid">
                    <h1 class="m-0">Listar Atendimentos</h1>
                </div>
            </div>
            <div class="content">
                <div class="container-fluid">
                    <!-- Filtros -->
                    <form method="GET" class="row mb-4">
                        <div class="col-md-3">
                            <label for="atendente" class="form-label">Atendente</label>
                            <input type="text" id="atendente" name="atendente" class="form-control" value="<?= htmlspecialchars($filtro_atendente) ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="data_inicio" class="form-label">Data Início</label>
                            <input type="date" id="data_inicio" name="data_inicio" class="form-control" value="<?= htmlspecialchars($filtro_data_inicio) ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="data_fim" class="form-label">Data Fim</label>
                            <input type="date" id="data_fim" name="data_fim" class="form-control" value="<?= htmlspecialchars($filtro_data_fim) ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="status" class="form-label">Status</label>
                            <select id="status" name="status" class="form-control">
                                <option value="">Todos</option>
                                <option value="Aberto" <?= $filtro_status === 'Aberto' ? 'selected' : '' ?>>Aberto</option>
                                <option value="Pendente" <?= $filtro_status === 'Pendente' ? 'selected' : '' ?>>Pendente</option>
                                <option value="Fechado" <?= $filtro_status === 'Fechado' ? 'selected' : '' ?>>Fechado</option>
                            </select>
                        </div>
                        <div class="col-md-12 mt-3">
                            <button type="submit" class="btn btn-primary">Filtrar</button>
                            <a href="listar_atendimentos.php" class="btn btn-secondary">Limpar Filtros</a>
                        </div>
                    </form>

                    <!-- Tabela -->
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Atendimentos</h3>
                        </div>
                        <div class="card-body table-responsive">
                            <table class="table table-bordered">
                                <thead>
                                    <tr>
                                        <th>ID</th>
                                        <th>Atendente</th>
                                        <th>Data Início</th>
                                        <th>Status</th>
                                        <th>Origem</th>
                                        <th>Descrição</th>
                                        <th>Ações</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php foreach ($atendimentos as $atendimento): ?>
                                        <tr>
                                            <td><?= $atendimento['id'] ?></td>
                                            <td><?= htmlspecialchars($atendimento['atendente']) ?></td>
                                            <td><?= htmlspecialchars($atendimento['data_inicio']) ?></td>
                                            <td><?= htmlspecialchars($atendimento['status']) ?></td>
                                            <td><?= htmlspecialchars($atendimento['origem']) ?></td>
                                            <td><?= htmlspecialchars($atendimento['descricao']) ?></td>
                                            <td>
                                                <a href="editar_atendimento.php?id=<?= $atendimento['id'] ?>" class="btn btn-warning btn-sm" title="Editar">
                                                    <i class="fas fa-edit"></i>
                                                </a>
                                                <a href="excluir_atendimento.php?id=<?= $atendimento['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja excluir este atendimento?');" title="Excluir">
                                                    <i class="fas fa-trash"></i>
                                                </a>
                                            </td>
                                        </tr>
                                    <?php endforeach; ?>
                                </tbody>
                            </table>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <?php include '../includes/footer.php'; ?>
    </div>
</body>
</html>