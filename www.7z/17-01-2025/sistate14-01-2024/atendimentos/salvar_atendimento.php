<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

require '../backend/conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $origem = $_POST['origem'] ?? null;
    $recurso = $_POST['recurso'] ?? null;
    $descricao = $_POST['descricao'] ?? null;

    if ($origem && $recurso && $descricao) {
        $stmt = $conn->prepare("INSERT INTO atendimentos (usuario_id, origem_id, recurso_id, descricao) VALUES (?, ?, ?, ?)");
        $stmt->execute([$_SESSION['usuario_id'], $origem, $recurso, $descricao]);
        $_SESSION['mensagem'] = "Atendimento criado com sucesso!";
    } else {
        $_SESSION['mensagem'] = "Erro ao criar atendimento. Preencha todos os campos.";
    }
}

header('Location: listar_atendimentos.php');
exit;
?>