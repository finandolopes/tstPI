<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

require '../backend/conexao.php';

// Buscar dados necessários para os campos dinâmicos
$origens = $conn->query("SELECT id, nome FROM origens_atendimento WHERE status = 'ativo'")->fetchAll(PDO::FETCH_ASSOC);
$recursos = $conn->query("SELECT id, nome FROM recursos WHERE status = 'ativo'")->fetchAll(PDO::FETCH_ASSOC);
$motivos = $conn->query("SELECT id, nome FROM motivos_atendimento WHERE status = 'ativo'")->fetchAll(PDO::FETCH_ASSOC);

// Processar o formulário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario_id = $_SESSION['usuario_id'];
    $data_inicio = date('Y-m-d H:i:s');
    $origem_id = $_POST['origem'];
    $recurso_id = $_POST['recurso'];
    $motivo_id = $_POST['motivo'];
    $codigo_paciente = $_POST['codigo_paciente'];
    $descricao = $_POST['descricao'];
    $unidade_solicitante = $_POST['unidade_solicitante'];
    $unidade_executante = $_POST['unidade_executante'];
    $status = 'Aberto';

    $stmt = $conn->prepare("INSERT INTO atendimentos (usuario_id, data_inicio, origem_id, recurso_id, motivo_id, codigo_paciente, descricao, unidade_solicitante, unidade_executante, status) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([$usuario_id, $data_inicio, $origem_id, $recurso_id, $motivo_id, $codigo_paciente, $descricao, $unidade_solicitante, $unidade_executante, $status]);

    header('Location: listar_atendimentos.php?status=sucesso');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Novo Atendimento - Sistema de Atendimento</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
        <!-- Navbar -->
        <?php include '../includes/header.php'; ?>

        <!-- Sidebar -->
        <?php include '../includes/sidebar.php'; ?>

        <!-- Content Wrapper -->
        <div class="content-wrapper">
            <div class="content-header">
                <div class="container-fluid">
                    <h1 class="m-0">Novo Atendimento</h1>
                </div>
            </div>

            <div class="content">
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Criar Novo Atendimento</h3>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <div class="row">
                                    <div class="col-md-6 mb-3">
                                        <label for="origem" class="form-label">Origem</label>
                                        <select name="origem" id="origem" class="form-control" required>
                                            <option value="">Selecione</option>
                                            <?php foreach ($origens as $origem): ?>
                                                <option value="<?= $origem['id'] ?>"><?= htmlspecialchars($origem['nome']) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="recurso" class="form-label">Recurso</label>
                                        <select name="recurso" id="recurso" class="form-control" required>
                                            <option value="">Selecione</option>
                                            <?php foreach ($recursos as $recurso): ?>
                                                <option value="<?= $recurso['id'] ?>"><?= htmlspecialchars($recurso['nome']) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="motivo" class="form-label">Motivo</label>
                                        <select name="motivo" id="motivo" class="form-control" required>
                                            <option value="">Selecione</option>
                                            <?php foreach ($motivos as $motivo): ?>
                                                <option value="<?= $motivo['id'] ?>"><?= htmlspecialchars($motivo['nome']) ?></option>
                                            <?php endforeach; ?>
                                        </select>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="codigo_paciente" class="form-label">Código do Paciente</label>
                                        <input type="text" name="codigo_paciente" id="codigo_paciente" class="form-control" required>
                                    </div>
                                    <div class="col-md-12 mb-3">
                                        <label for="descricao" class="form-label">Descrição</label>
                                        <textarea name="descricao" id="descricao" class="form-control" rows="3" required></textarea>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="unidade_solicitante" class="form-label">Unidade Solicitante</label>
                                        <input type="text" name="unidade_solicitante" id="unidade_solicitante" class="form-control" required>
                                    </div>
                                    <div class="col-md-6 mb-3">
                                        <label for="unidade_executante" class="form-label">Unidade Executante</label>
                                        <input type="text" name="unidade_executante" id="unidade_executante" class="form-control" required>
                                    </div>
                                </div>
                                <button type="submit" class="btn btn-primary">Salvar Atendimento</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <?php include '../includes/footer.php'; ?>
    </div>
</body>
</html>