<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

require '../backend/conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['id'])) {
    $id = $_GET['id'];

    $stmt = $conn->prepare("SELECT * FROM atendimentos WHERE id = ?");
    $stmt->execute([$id]);
    $atendimento = $stmt->fetch(PDO::FETCH_ASSOC);

    if (!$atendimento) {
        header('Location: listar_atendimentos.php');
        exit;
    }
} elseif ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['id'])) {
    $id = $_POST['id'];
    $codigo_paciente = $_POST['codigo_paciente'];
    $descricao = $_POST['descricao'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("UPDATE atendimentos SET codigo_paciente = ?, descricao = ?, status = ? WHERE id = ?");
    $stmt->execute([$codigo_paciente, $descricao, $status, $id]);

    header('Location: listar_atendimentos.php?status=editado');
    exit;
} else {
    header('Location: listar_atendimentos.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Atendimento</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
    <div class="wrapper">
        <!-- Navbar -->
        <?php include '../includes/header.php'; ?>

        <!-- Sidebar -->
        <?php include '../includes/sidebar.php'; ?>

        <!-- Content Wrapper -->
        <div class="content-wrapper">
            <div class="content-header">
                <div class="container-fluid">
                    <h1 class="m-0">Editar Atendimento</h1>
                </div>
            </div>
            <div class="content">
                <div class="container-fluid">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">Editar Atendimento</h3>
                        </div>
                        <div class="card-body">
                            <form method="POST">
                                <input type="hidden" name="id" value="<?= $atendimento['id'] ?>">
                                <div class="mb-3">
                                    <label for="codigo_paciente" class="form-label">Código do Paciente</label>
                                    <input type="text" name="codigo_paciente" id="codigo_paciente" class="form-control" value="<?= htmlspecialchars($atendimento['codigo_paciente']) ?>" required>
                                </div>
                                <div class="mb-3">
                                    <label for="descricao" class="form-label">Descrição</label>
                                    <textarea name="descricao" id="descricao" class="form-control" rows="3"><?= htmlspecialchars($atendimento['descricao']) ?></textarea>
                                </div>
                                <div class="mb-3">
                                    <label for="status" class="form-label">Status</label>
                                    <select name="status" id="status" class="form-control">
                                        <option value="Aberto" <?= $atendimento['status'] === 'Aberto' ? 'selected' : '' ?>>Aberto</option>
                                        <option value="Fechado" <?= $atendimento['status'] === 'Fechado' ? 'selected' : '' ?>>Fechado</option>
                                    </select>
                                </div>
                                <button type="submit" class="btn btn-primary">Salvar Alterações</button>
                                <a href="listar_atendimentos.php" class="btn btn-secondary">Cancelar</a>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>

        <!-- Footer -->
        <?php include '../includes/footer.php'; ?>
    </div>
</body>
</html>