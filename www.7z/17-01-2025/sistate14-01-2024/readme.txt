sistema_atendimento/
├── index.php
├── login.php
├── esqueci_senha.php
├── dashboard.php
├── conexao.php
├── config/
│   ├── configuracoes.php
│   ├── permissoes.php
│   ├── api.php
│   ├── backup.php
├── cadastros/
│   ├── usuarios.php
│   ├── unidades.php
│   ├── municipios.php
│   ├── drs.php
│   ├── macro_regioes.php
│   ├── motivos_atendimento.php
│   ├── origens_atendimento.php
│   ├── recursos_atendimento.php
├── relatorios/
│   ├── sla.php
│   ├── produtividade.php
│   ├── comparativo.php
├── logs/
│   ├── acessos.php
│   ├── auditoria.php
├── includes/
│   ├── header.php
│   ├── footer.php
│   ├── sidebar.php
├── assets/
│   ├── css/
│   ├── js/
│   ├── img/
├── sql/
│   ├── sistema_atendimento.sql
│   ├── dados_iniciais.sql