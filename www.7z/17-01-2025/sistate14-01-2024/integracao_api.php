<?php
session_start();
require_once 'backend/conexao.php';
require_once 'includes/verifica_permissao.php';

// Verifica permissão
verificaPermissao('config_integracao');

// Gerar um novo token de integração
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['gerar_token'])) {
    $novo_token = bin2hex(random_bytes(32));
    $stmt = $conn->prepare("UPDATE configuracoes SET valor = ? WHERE chave = 'api_token'");
    $stmt->execute([$novo_token]);
    $_SESSION['mensagem_sucesso'] = 'Novo token gerado com sucesso.';
    header('Location: integracao_api.php');
    exit;
}

// Obter token atual
$stmt = $conn->prepare("SELECT valor FROM configuracoes WHERE chave = 'api_token'");
$stmt->execute();
$token_atual = $stmt->fetchColumn();
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Integração com API</title>
    <link rel="stylesheet" href="assets/css/estilos.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
</head>
<body>
<?php include 'includes/header.php'; ?>
<?php include 'includes/sidebar.php'; ?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>Integração com API</h1>
    </section>
    <section class="content">
        <div class="container-fluid">
            <!-- Mensagens -->
            <?php if (!empty($_SESSION['mensagem_sucesso'])): ?>
                <div class="alert alert-success"><?= $_SESSION['mensagem_sucesso'] ?></div>
                <?php unset($_SESSION['mensagem_sucesso']); ?>
            <?php endif; ?>
            <?php if (!empty($_SESSION['mensagem_erro'])): ?>
                <div class="alert alert-danger"><?= $_SESSION['mensagem_erro'] ?></div>
                <?php unset($_SESSION['mensagem_erro']); ?>
            <?php endif; ?>

            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Token de Integração</h3>
                </div>
                <div class="card-body">
                    <p><strong>Token Atual:</strong></p>
                    <div class="input-group mb-3">
                        <input type="text" class="form-control" value="<?= htmlspecialchars($token_atual) ?>" readonly>
                        <button class="btn btn-secondary" onclick="navigator.clipboard.writeText('<?= htmlspecialchars($token_atual) ?>')">
                            <i class="fas fa-copy"></i> Copiar
                        </button>
                    </div>
                    <form method="POST">
                        <button type="submit" name="gerar_token" class="btn btn-primary">
                            <i class="fas fa-sync-alt"></i> Gerar Novo Token
                        </button>
                    </form>
                </div>
            </div>

            <div class="card mt-4">
                <div class="card-header">
                    <h3 class="card-title">Endpoints Disponíveis</h3>
                </div>
                <div class="card-body">
                    <p>Use os seguintes endpoints para integração:</p>
                    <ul>
                        <li><strong>Listar Atendimentos:</strong> <code>GET /api.php?rota=listar_atendimentos&token=SEU_TOKEN</code></li>
                        <li><strong>Criar Atendimento:</strong> <code>POST /api.php?rota=criar_atendimento&token=SEU_TOKEN</code></li>
                        <li><strong>Atualizar Atendimento:</strong> <code>PUT /api.php?rota=atualizar_atendimento&token=SEU_TOKEN</code></li>
                        <li><strong>Excluir Atendimento:</strong> <code>DELETE /api.php?rota=excluir_atendimento&id=ID&token=SEU_TOKEN</code></li>
                    </ul>
                </div>
            </div>
        </div>
    </section>
</div>

<?php include 'includes/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>