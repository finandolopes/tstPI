<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

require '../backend/conexao.php';

// Consulta para buscar logs de auditoria
$stmt = $conn->prepare("SELECT la.id, la.usuario_id, u.nome AS usuario_nome, la.acao, la.descricao, la.data
                        FROM logs_auditoria la
                        LEFT JOIN usuarios u ON la.usuario_id = u.id
                        ORDER BY la.data DESC");
$stmt->execute();
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

require '../includes/header.php';
?>
<div class="content-wrapper">
    <div class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1 class="m-0">Logs de Auditoria</h1>
                </div>
            </div>
        </div>
    </div>
    <section class="content">
        <div class="container-fluid">
            <div class="card">
                <div class="card-body">
                    <table class="table table-bordered table-striped">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Usuário</th>
                                <th>Ação</th>
                                <th>Descrição</th>
                                <th>Data</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($logs as $log): ?>
                                <tr>
                                    <td><?= htmlspecialchars($log['id']) ?></td>
                                    <td><?= htmlspecialchars($log['usuario_nome']) ?></td>
                                    <td><?= htmlspecialchars($log['acao']) ?></td>
                                    <td><?= htmlspecialchars($log['descricao']) ?></td>
                                    <td><?= htmlspecialchars($log['data']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
</div>
<?php require '../includes/footer.php'; ?>