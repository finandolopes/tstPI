<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}

require '../backend/conexao.php';

// Obter logs do banco de dados
$query = $conn->query("SELECT l.id, l.acao, l.usuario_id, u.nome AS usuario, l.data_acao 
                       FROM <div class="card mt-3">
    <div class="card-header">
        <h4>Logs de Ações</h4>
    </div>
    <div class="card-body">
        <form id="filterLogs">
            <div class="form-group">
                <label for="filterUser">Usuário</label>
                <input type="text" id="filterUser" class="form-control" placeholder="Digite o nome do usuário">
            </div>
            <div class="form-group mt-2">
                <label for="filterDate">Data</label>
                <input type="date" id="filterDate" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary mt-3">Filtrar</button>
        </form>

        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Usuário</th>
                    <th>Ação</th>
                    <th>Data</th>
                </tr>
            </thead>
            <tbody id="logTableBody">
                <!-- Logs serão preenchidos via AJAX -->
            </tbody>
        </table>
    </div>
</div>

<script>
    document.getElementById('filterLogs').addEventListener('submit', function (e) {
        e.preventDefault();
        const user = document.getElementById('filterUser').value;
        const date = document.getElementById('filterDate').value;

        fetch(`backend/logs.php?user=${user}&date=${date}`)
            .then(response => response.json())
            .then(data => {
                const tbody = document.getElementById('logTableBody');
                tbody.innerHTML = '';
                data.forEach(log => {
                    tbody.innerHTML += `
                        <tr>
                            <td>${log.id}</td>
                            <td>${log.usuario}</td>
                            <td>${log.acao}</td>
                            <td>${log.data}</td>
                        </tr>
                    `;
                });
            });
    });
</script><div class="card mt-3">
    <div class="card-header">
        <h4>Logs de Ações</h4>
    </div>
    <div class="card-body">
        <form id="filterLogs">
            <div class="form-group">
                <label for="filterUser">Usuário</label>
                <input type="text" id="filterUser" class="form-control" placeholder="Digite o nome do usuário">
            </div>
            <div class="form-group mt-2">
                <label for="filterDate">Data</label>
                <input type="date" id="filterDate" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary mt-3">Filtrar</button>
        </form>

        <table class="table table-bordered mt-3">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Usuário</th>
                    <th>Ação</th>
                    <th>Data</th>
                </tr>
            </thead>
            <tbody id="logTableBody">
                <!-- Logs serão preenchidos via AJAX -->
            </tbody>
        </table>
    </div>
</div>

<script>
    document.getElementById('filterLogs').addEventListener('submit', function (e) {
        e.preventDefault();
        const user = document.getElementById('filterUser').value;
        const date = document.getElementById('filterDate').value;

        fetch(`backend/logs.php?user=${user}&date=${date}`)
            .then(response => response.json())
            .then(data => {
                const tbody = document.getElementById('logTableBody');
                tbody.innerHTML = '';
                data.forEach(log => {
                    tbody.innerHTML += `
                        <tr>
                            <td>${log.id}</td>
                            <td>${log.usuario}</td>
                            <td>${log.acao}</td>
                            <td>${log.data}</td>
                        </tr>
                    `;
                });
            });
    });
</script> l 
                       JOIN usuarios u ON l.usuario_id = u.id 
                       ORDER BY l.data_acao DESC");
$logs = $query->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório de Logs</title>
    <link rel="stylesheet" href="assets/css/estilos.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
</head>
<body>
<?php include 'includes/header.php'; ?>
<?php include 'includes/sidebar.php'; ?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>Relatório de Logs</h1>
    </section>
    <section class="content">
        <div class="container-fluid">
            <div class="card">
                <div class="card-header">
                    <h3 class="card-title">Logs de Ações</h3>
                </div>
                <div class="card-body">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Usuário</th>
                                <th>Ação</th>
                                <th>Data</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($logs as $log): ?>
                                <tr>
                                    <td><?= htmlspecialchars($log['id']) ?></td>
                                    <td><?= htmlspecialchars($log['usuario']) ?></td>
                                    <td><?= htmlspecialchars($log['acao']) ?></td>
                                    <td><?= htmlspecialchars($log['data_acao']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </section>
</div>

<?php include 'includes/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>