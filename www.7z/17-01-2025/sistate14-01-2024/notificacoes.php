<?php
session_start();
require_once 'backend/conexao.php';
require_once 'includes/verifica_permissao.php';

// Verifica permissão
verificaPermissao('config_notificacoes');

// Função para enviar e-mail
function enviarEmail($assunto, $mensagem, $destinatarios = []) {
    $headers = "From: sistema@exemplo.com\r\n";
    $headers .= "Reply-To: suporte@exemplo.com\r\n";
    $headers .= "Content-Type: text/html; charset=UTF-8\r\n";

    foreach ($destinatarios as $email) {
        mail($email, $assunto, $mensagem, $headers);
    }
}

// Salvar configurações de notificações
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $notificacao_backup = isset($_POST['notificacao_backup']) ? 1 : 0;
    $notificacao_falha_login = isset($_POST['notificacao_falha_login']) ? 1 : 0;

    $stmt = $conn->prepare("UPDATE configuracoes SET valor = ? WHERE chave = 'notificacao_backup'");
    $stmt->execute([$notificacao_backup]);

    $stmt = $conn->prepare("UPDATE configuracoes SET valor = ? WHERE chave = 'notificacao_falha_login'");
    $stmt->execute([$notificacao_falha_login]);

    $_SESSION['mensagem_sucesso'] = 'Configurações de notificações atualizadas com sucesso.';
    header('Location: notificacoes.php');
    exit;
}

// Obter configurações atuais
$stmt = $conn->query("SELECT chave, valor FROM configuracoes WHERE chave IN ('notificacao_backup', 'notificacao_falha_login')");
$configuracoes = $stmt->fetchAll(PDO::FETCH_KEY_PAIR);

// Lógica para envio de notificações automáticas (exemplo)
if (!empty($configuracoes['notificacao_backup']) && $configuracoes['notificacao_backup'] == 1) {
    $assunto = "Notificação de Backup";
    $mensagem = "<p>O backup automático foi realizado com sucesso em " . date('d/m/Y H:i:s') . ".</p>";
    enviarEmail($assunto, $mensagem, ['admin@exemplo.com', 'coordenador@exemplo.com']);
}

if (!empty($configuracoes['notificacao_falha_login']) && $configuracoes['notificacao_falha_login'] == 1) {
    $stmtFalhas = $conn->query("SELECT COUNT(*) FROM login_attempts WHERE status = 'failed' AND timestamp > NOW() - INTERVAL 1 HOUR");
    $falhas = $stmtFalhas->fetchColumn();

    if ($falhas > 10) {
        $assunto = "Alerta de Falhas de Login";
        $mensagem = "<p>Foram detectadas mais de 10 tentativas de login falhas na última hora.</p>";
        enviarEmail($assunto, $mensagem, ['admin@exemplo.com']);
    }
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuração de Notificações</title>
    <link rel="stylesheet" href="assets/css/estilos.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
</head>
<body>
<?php include 'includes/header.php'; ?>
<?php include 'includes/sidebar.php'; ?>

<div class="content-wrapper">
    <section class="content-header">
        <h1>Configuração de Notificações</h1>
    </section>
    <section class="content">
        <div class="container-fluid">
            <!-- Mensagens -->
            <?php if (!empty($_SESSION['mensagem_sucesso'])): ?>
                <div class="alert alert-success"><?= $_SESSION['mensagem_sucesso'] ?></div>
                <?php unset($_SESSION['mensagem_sucesso']); ?>
            <?php endif; ?>

            <form method="POST">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Notificações</h3>
                    </div>
                    <div class="card-body">
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="notificacao_backup" name="notificacao_backup" 
                                <?= isset($configuracoes['notificacao_backup']) && $configuracoes['notificacao_backup'] == 1 ? 'checked' : '' ?>>
                            <label class="form-check-label" for="notificacao_backup">Notificar sobre backups automáticos</label>
                        </div>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="notificacao_falha_login" name="notificacao_falha_login" 
                                <?= isset($configuracoes['notificacao_falha_login']) && $configuracoes['notificacao_falha_login'] == 1 ? 'checked' : '' ?>>
                            <label class="form-check-label" for="notificacao_falha_login">Notificar sobre falhas de login</label>
                        </div>
                    </div>
                    <div class="card-footer">
                        <button type="submit" class="btn btn-primary">Salvar Configurações</button>
                    </div>
                </div>
            </form>
        </div>
    </section>
</div>

<?php include 'includes/footer.php'; ?>

<script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>