<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <!-- Brand Logo -->
    <a href="../../modules/dashboard/index.php" class="brand-link">
        <img src="assets/img/CROSS-.png" alt="Sistema Logo" class="brand-image img-circle elevation-3" style="opacity: .8">       
        <span class="brand-text font-weight-light">SA-CAT</span>
    </a>
    <!-- Sidebar -->
    <div class="sidebar">      
       
        <!-- Sidebar Menu -->
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
                <!-- Dashboard -->
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link">
                        <i class="nav-icon fas fa-tachometer-alt"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <!-- Atendimentos -->
                <li class="nav-item">
                    <a href="modulos/atendimentos/novo_atendimento.php" class="nav-link">
                        <i class="nav-icon fas fa-phone-alt"></i>
                        <p>Atendimentos</p>
                    </a>
                </li>
                <!-- Outros Módulos -->
                <li class="nav-item">
                    <a href="relatorios/index.php" class="nav-link">
                        <i class="nav-icon fas fa-chart-bar"></i>
                        <p>Relatórios</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="configuracoes/backup.php" class="nav-link">
                        <i class="nav-icon fas fa-trophy"></i>
                        <p>Gamificação</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="auditoria/logs_acoes.php" class="nav-link">
                        <i class="nav-icon fas fa-clock"></i>
                        <p>Auditoria</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="modulos/map/coverage.php" class="nav-link">
                        <i class="nav-icon fas fa-map"></i>
                        <p>Mapa de Cobertura</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="modulos/acessibilidade/accessibility.php" class="nav-link">
                        <i class="nav-icon fas fa-universal-access"></i>
                        <p>Acessibilidade</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="modulos/customizacao/customization.php" class="nav-link">
                        <i class="nav-icon fas fa-paint-brush"></i>
                        <p>Customização</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="modulos/feedback/feedback.php" class="nav-link">
                        <i class="nav-icon fas fa-comments"></i>
                        <p>Feedback</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="modulos/permissoes/manage_permissions.php" class="nav-link">
                        <i class="nav-icon fas fa-user-shield"></i>
                        <p>Permissões</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="modulos/auditoria/logs.php" class="nav-link">
                        <i class="nav-icon fas fa-history"></i>
                        <p>Auditoria</p>
                    </a>
                </li>
                <li class="nav-item">
                    <a href="modulos/backup/backup_recovery.php" class="nav-link">
                        <i class="nav-icon fas fa-database"></i>
                        <p>Backup</p>
                    </a>
                </li>
            </ul>
        </nav>
    </div>
</aside>