<?php
session_start();

// Redireciona para a tela de login caso o usuário não esteja logado
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
} else {
    header('Location: dashboard.php');
    exit;
}
?>