<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

// Atualizar configurações de personalização
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_customization'])) {
    $theme_color = htmlspecialchars($_POST['theme_color']);
    $logo = $_FILES['logo']['name'];

    // Processar upload do logotipo
    if (!empty($logo)) {
        $target_dir = "../../assets/images/";
        $target_file = $target_dir . basename($logo);
        move_uploaded_file($_FILES['logo']['tmp_name'], $target_file);
    }

    $stmt = $pdo->prepare("
        UPDATE system_config SET theme_color = :theme_color, logo = :logo WHERE id = 1
    ");
    $stmt->execute([
        ':theme_color' => $theme_color,
        ':logo' => $logo ? $logo : $_POST['current_logo'],
    ]);

    $_SESSION['success_message'] = 'Configurações atualizadas com sucesso!';
    header('Location: customization.php');
    exit();
}

// Buscar configurações atuais
$stmt = $pdo->query("SELECT * FROM system_config WHERE id = 1");
$config = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<?php include '../../includes/header.php'; ?>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
    <?php include '../../includes/navbar.php'; ?>
    <?php include '../../includes/sidebar.php'; ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Customização e Personalização</h1>
        </section>
        <section class="content">
            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success"><?= $_SESSION['success_message']; ?></div>
                <?php unset($_SESSION['success_message']); ?>
            <?php endif; ?>
            <form action="" method="POST" enctype="multipart/form-data">
                <div class="form-group">
                    <label for="theme_color">Cor do Tema</label>
                    <input type="color" name="theme_color" class="form-control" value="<?= htmlspecialchars($config['theme_color']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="logo">Logotipo</label>
                    <input type="file" name="logo" class="form-control">
                    <input type="hidden" name="current_logo" value="<?= htmlspecialchars($config['logo']); ?>">
                    <p>Logo atual: <img src="../../assets/images/<?= htmlspecialchars($config['logo']); ?>" alt="Logo" width="100"></p>
                </div>
                <button type="submit" name="update_customization" class="btn btn-primary">Salvar Alterações</button>
            </form>
        </section>
    </div>
    <?php include '../../includes/footer.php'; ?>
</div>
</body>
</html>