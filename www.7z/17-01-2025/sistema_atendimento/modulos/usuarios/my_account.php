<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user'])) {
    header('Location: ../login.php');
    exit();
}

// Atualizar informações do usuário
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_account'])) {
    $name = htmlspecialchars($_POST['name']);
    $email = htmlspecialchars($_POST['email']);
    $user_id = $_SESSION['user']['id'];

    $stmt = $pdo->prepare("UPDATE users SET name = :name, email = :email WHERE id = :id");
    $stmt->execute([
        ':name' => $name,
        ':email' => $email,
        ':id' => $user_id,
    ]);

    $_SESSION['user']['name'] = $name;
    $_SESSION['user']['email'] = $email;
    $_SESSION['success_message'] = 'Informações atualizadas com sucesso!';
    header('Location: my_account.php');
    exit();
}

// Buscar informações do usuário logado
$stmt = $pdo->prepare("SELECT * FROM users WHERE id = :id");
$stmt->execute([':id' => $_SESSION['user']['id']]);
$user_data = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<?php include '../../includes/header.php'; ?>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
    <?php include '../../includes/navbar.php'; ?>
    <?php include '../../includes/sidebar.php'; ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Minha Conta</h1>
        </section>
        <section class="content">
            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success"><?= $_SESSION['success_message']; ?></div>
                <?php unset($_SESSION['success_message']); ?>
            <?php endif; ?>
            <form action="" method="POST" class="mb-4">
                <h3>Editar Informações</h3>
                <div class="form-group">
                    <label for="name">Nome</label>
                    <input type="text" name="name" class="form-control" value="<?= htmlspecialchars($user_data['name']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="email">E-mail</label>
                    <input type="email" name="email" class="form-control" value="<?= htmlspecialchars($user_data['email']); ?>" required>
                </div>
                <button type="submit" name="update_account" class="btn btn-primary">Salvar Alterações</button>
            </form>
            <h3>Meus Logs de Atividade</h3>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Ação</th>
                        <th>Descrição</th>
                        <th>Data e Hora</th>
                        <th>IP</th>
                    </tr>
                </thead>
                <tbody>
                    <?php
                    $logs = $pdo->prepare("
                        SELECT * FROM audit_logs 
                        WHERE user_id = :id 
                        ORDER BY timestamp DESC
                    ");
                    $logs->execute([':id' => $_SESSION['user']['id']]);
                    foreach ($logs->fetchAll(PDO::FETCH_ASSOC) as $log): ?>
                        <tr>
                            <td><?= $log['id']; ?></td>
                            <td><?= ucfirst($log['action_type']); ?></td>
                            <td><?= $log['description']; ?></td>
                            <td><?= $log['timestamp']; ?></td>
                            <td><?= $log['ip_address']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    </div>
    <?php include '../../includes/footer.php'; ?>
</div>
</body>
</html>