<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

require '../backend/conexao.php';

// Buscar dados de atendimentos por região
$regions_data = $pdo->query("
    SELECT r.name AS region_name, COUNT(a.id) AS total 
    FROM attendances a 
    JOIN regions r ON a.region_id = r.id 
    GROUP BY r.name
")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<?php include '../../includes/header.php'; ?>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
    <?php include '../../includes/navbar.php'; ?>
    <?php include '../../includes/sidebar.php'; ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Mapa de Cobertura Regional</h1>
        </section>
        <section class="content">
            <div id="map" style="width: 100%; height: 600px;"></div>
        </section>
    </div>
    <?php include '../../includes/footer.php'; ?>
</div>
<script src="https://unpkg.com/leaflet/dist/leaflet.js"></script>
<script>
// Inicializando o mapa
const map = L.map('map').setView([-14.2350, -51.9253], 4); // Coordenadas do Brasil
L.tileLayer('https://{s}.tile.openstreetmap.org/{z}/{x}/{y}.png', {
    attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors'
}).addTo(map);

// Dados das regiões
const regions = <?= json_encode($regions_data); ?>;

// Adicionando marcadores ao mapa
regions.forEach(region => {
    const marker = L.marker([region.lat, region.lng]).addTo(map);
    marker.bindPopup(`<strong>${region.region_name}</strong><br>Total de Atendimentos: ${region.total}`);
});
</script>
<link rel="stylesheet" href="https://unpkg.com/leaflet/dist/leaflet.css" />
</body>
</html>