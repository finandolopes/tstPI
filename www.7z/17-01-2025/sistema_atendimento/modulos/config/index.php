<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user']) || $_SESSION['user']['role'] !== 'admin') {
    header('Location: ../login.php');
    exit();
}

// Atualizar configurações gerais do sistema
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['update_config'])) {
    $system_name = htmlspecialchars($_POST['system_name']);
    $footer_text = htmlspecialchars($_POST['footer_text']);

    $stmt = $pdo->prepare("UPDATE system_config SET system_name = :system_name, footer_text = :footer_text WHERE id = 1");
    $stmt->execute([
        ':system_name' => $system_name,
        ':footer_text' => $footer_text,
    ]);
    $_SESSION['success_message'] = 'Configurações atualizadas com sucesso!';
    header('Location: index.php');
    exit();
}

// Buscar configurações atuais
$stmt = $pdo->query("SELECT * FROM system_config WHERE id = 1");
$config = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<?php include '../../includes/header.php'; ?>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
    <?php include '../../includes/navbar.php'; ?>
    <?php include '../../includes/sidebar.php'; ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Configuração Geral do Sistema</h1>
        </section>
        <section class="content">
            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success"><?= $_SESSION['success_message']; ?></div>
                <?php unset($_SESSION['success_message']); ?>
            <?php endif; ?>
            <form action="" method="POST">
                <div class="form-group">
                    <label for="system_name">Nome do Sistema</label>
                    <input type="text" name="system_name" class="form-control" value="<?= htmlspecialchars($config['system_name']); ?>" required>
                </div>
                <div class="form-group">
                    <label for="footer_text">Texto do Rodapé</label>
                    <input type="text" name="footer_text" class="form-control" value="<?= htmlspecialchars($config['footer_text']); ?>" required>
                </div>
                <button type="submit" name="update_config" class="btn btn-primary">Salvar Alterações</button>
            </form>
        </section>
    </div>
    <?php include '../../includes/footer.php'; ?>
</div>
</body>
</html>