<?php
session_start();
require_once '../../config/database.php';

if (!isset($_SESSION['user'])) {
    header('Location: ../login.php');
    exit();
}

// Adicionar novo agendamento
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['add_scheduling'])) {
    $patient_code = htmlspecialchars($_POST['patient_code']);
    $resource = htmlspecialchars($_POST['resource']);
    $date = htmlspecialchars($_POST['date']);
    $time = htmlspecialchars($_POST['time']);
    $description = htmlspecialchars($_POST['description']);

    $stmt = $pdo->prepare("INSERT INTO scheduling (patient_code, resource, date, time, description, user_id, created_at) 
                           VALUES (:patient_code, :resource, :date, :time, :description, :user_id, NOW())");
    $stmt->execute([
        ':patient_code' => $patient_code,
        ':resource' => $resource,
        ':date' => $date,
        ':time' => $time,
        ':description' => $description,
        ':user_id' => $_SESSION['user']['id'],
    ]);
    $_SESSION['success_message'] = 'Agendamento realizado com sucesso!';
    header('Location: index.php');
    exit();
}

// Buscar agendamentos existentes
$query = "
    SELECT s.*, u.name AS user_name 
    FROM scheduling s 
    JOIN users u ON s.user_id = u.id 
    ORDER BY s.date DESC, s.time DESC
";

$schedulings = $pdo->query($query)->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<?php include '../../includes/header.php'; ?>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
    <?php include '../../includes/navbar.php'; ?>
    <?php include '../../includes/sidebar.php'; ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Agendamentos e Ligações</h1>
        </section>
        <section class="content">
            <?php if (isset($_SESSION['success_message'])): ?>
                <div class="alert alert-success"><?= $_SESSION['success_message']; ?></div>
                <?php unset($_SESSION['success_message']); ?>
            <?php endif; ?>
            <form action="" method="POST" class="mb-4">
                <h3>Adicionar Novo Agendamento</h3>
                <div class="form-group">
                    <label for="patient_code">Código do Paciente</label>
                    <input type="text" name="patient_code" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="resource">Recurso</label>
                    <input type="text" name="resource" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="date">Data</label>
                    <input type="date" name="date" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="time">Hora</label>
                    <input type="time" name="time" class="form-control" required>
                </div>
                <div class="form-group">
                    <label for="description">Descrição</label>
                    <textarea name="description" class="form-control" rows="4"></textarea>
                </div>
                <button type="submit" name="add_scheduling" class="btn btn-primary">Salvar</button>
            </form>
            <h3>Agendamentos Realizados</h3>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Código do Paciente</th>
                        <th>Recurso</th>
                        <th>Data</th>
                        <th>Hora</th>
                        <th>Usuário</th>
                        <th>Descrição</th>
                        <th>Data de Criação</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($schedulings as $scheduling): ?>
                        <tr>
                            <td><?= $scheduling['id']; ?></td>
                            <td><?= $scheduling['patient_code']; ?></td>
                            <td><?= $scheduling['resource']; ?></td>
                            <td><?= $scheduling['date']; ?></td>
                            <td><?= $scheduling['time']; ?></td>
                            <td><?= $scheduling['user_name']; ?></td>
                            <td><?= $scheduling['description']; ?></td>
                            <td><?= $scheduling['created_at']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    </div>
    <?php include '../../includes/footer.php'; ?>
</div>
</body>
</html>