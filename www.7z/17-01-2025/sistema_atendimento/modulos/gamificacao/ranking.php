<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

require 'backend/conexao.php';

// Ranking de Atendentes
$ranking = $pdo->query("
    SELECT u.name AS user_name, COUNT(a.id) AS total_attendances 
    FROM users u 
    LEFT JOIN attendances a ON u.id = a.user_id 
    GROUP BY u.name 
    ORDER BY total_attendances DESC 
    LIMIT 10
")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<?php include '../../includes/header.php'; ?>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
    <?php include '../../includes/navbar.php'; ?>
    <?php include '../../includes/sidebar.php'; ?>
    <div class="content-wrapper">
        <section class="content-header">
            <h1>Gamificação e Engajamento</h1>
        </section>
        <section class="content">
            <h3>Ranking dos Atendentes</h3>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>Posição</th>
                        <th>Nome do Atendente</th>
                        <th>Total de Atendimentos</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($ranking as $index => $user): ?>
                        <tr>
                            <td><?= $index + 1; ?></td>
                            <td><?= htmlspecialchars($user['user_name']); ?></td>
                            <td><?= $user['total_attendances']; ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    </div>
    <?php include '../../includes/footer.php'; ?>
</div>
</body>
</html>