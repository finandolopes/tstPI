-- Criação do banco de dados
CREATE DATABASE IF NOT EXISTS sistema_atendimento;
USE sistema_atendimento;

-- Tabela de Perfis com Dados Pré-Definidos
CREATE TABLE perfis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL UNIQUE
);

-- Inserção dos Perfis Pré-Definidos
INSERT INTO perfis (id, nome) VALUES
    (1, 'Atendente'),
    (2, 'Coordenador Atendimento'),
    (3, 'Administrador'),
    (4, 'Administrador Sistema');

-- Tabela de Usuários com Senha em Hash
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL, -- Agora a senha será armazenada como hash
    perfil_id INT NOT NULL,
    ativo BOOLEAN DEFAULT TRUE,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (perfil_id) REFERENCES perfis(id)
);

-- Tabela de Grupos
CREATE TABLE grupos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    descricao TEXT,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de Permissões
CREATE TABLE permissoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    descricao TEXT
);

-- Tabela de Recursos
CREATE TABLE recursos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE
);

-- Tabela de Relação Usuário-Grupo
CREATE TABLE usuario_grupo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    grupo_id INT NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (grupo_id) REFERENCES grupos(id) ON DELETE CASCADE
);

-- Tabela de Relação Grupo-Permissão
CREATE TABLE grupo_permissao (
    id INT AUTO_INCREMENT PRIMARY KEY,
    grupo_id INT NOT NULL,
    permissao_id INT NOT NULL,
    FOREIGN KEY (grupo_id) REFERENCES grupos(id) ON DELETE CASCADE,
    FOREIGN KEY (permissao_id) REFERENCES permissoes(id) ON DELETE CASCADE
);

-- Tabela de Origens de Atendimento
CREATE TABLE origens_atendimento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE
);

-- Tabela de Motivos de Atendimento
CREATE TABLE motivos_atendimento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    descricao TEXT,
    obrigatorio BOOLEAN DEFAULT FALSE,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de Atendimentos
CREATE TABLE atendimentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    data_inicio DATETIME DEFAULT CURRENT_TIMESTAMP,
    data_fim DATETIME,
    origem_id INT NOT NULL,
    recurso_id INT NOT NULL,
    motivo_id INT NOT NULL,
    descricao TEXT,
    codigo_paciente VARCHAR(50),
    unidade_solicitante VARCHAR(100),
    unidade_executante VARCHAR(100),
    status ENUM('Aberto', 'Pendente', 'Fechado') NOT NULL DEFAULT 'Aberto',
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    FOREIGN KEY (origem_id) REFERENCES origens_atendimento(id),
    FOREIGN KEY (recurso_id) REFERENCES recursos(id),
    FOREIGN KEY (motivo_id) REFERENCES motivos_atendimento(id)
);

-- Tabela de Departamentos
CREATE TABLE departamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    descricao TEXT,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de Colegiados
CREATE TABLE colegiados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    drs_id INT NOT NULL,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (drs_id) REFERENCES drs(id)
);

-- Tabela de DRS (Diretoria Regional de Saúde)
CREATE TABLE drs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    macro_regiao_id INT NOT NULL,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (macro_regiao_id) REFERENCES macro_regioes(id)
);

-- Tabela de Macro Regiões
CREATE TABLE macro_regioes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de Municípios (Atualizada com os campos exigidos)
CREATE TABLE municipios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    co_ibge VARCHAR(7) NOT NULL UNIQUE, -- Código IBGE do município
    nome VARCHAR(100) NOT NULL, -- Nome do município
    no_municipio_cross VARCHAR(100), -- Nome do município em formato CROSS
    no_regiao_saude VARCHAR(100), -- Nome da região de saúde
    no_drs VARCHAR(100), -- Nome da DRS (Diretoria Regional de Saúde)
    nu_rras VARCHAR(50), -- Número da RRAS (Regional de Saúde)
    no_estado VARCHAR(100), -- Nome do estado
    cg_lat_municipio DECIMAL(9, 6), -- Latitude do município
    cg_lon_municipio DECIMAL(9, 6), -- Longitude do município
    qt_populacao_2018 INT, -- População de 2018
    qtd_populacao_2022 INT, -- População de 2022
    colegiado_id INT NOT NULL, -- Colegiado associado ao município
    estado_id INT NOT NULL, -- ID do estado (associado à tabela de estados)
    drs_id INT NOT NULL, -- ID da DRS (Diretoria Regional de Saúde) associada
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (colegiado_id) REFERENCES colegiados(id),
    FOREIGN KEY (estado_id) REFERENCES estados(id),
    FOREIGN KEY (drs_id) REFERENCES drs(id)
);

-- Tabela de Unidades (Atualizada com os campos exigidos)
CREATE TABLE unidades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cnes VARCHAR(15) NOT NULL UNIQUE,
    nome VARCHAR(100) NOT NULL,
    municipio_id INT NOT NULL, -- Relacionamento com o município
    tipo_unidade_id INT NOT NULL,
    co_ibge VARCHAR(7),
    no_municipio VARCHAR(100),
    no_municipio_cross VARCHAR(100),
    no_regiao_saude VARCHAR(100),
    no_drs VARCHAR(100),
    nu_rras VARCHAR(50),
    no_estado VARCHAR(100),
    cg_lat_municipio DECIMAL(9, 6),
    cg_lon_municipio DECIMAL(9, 6),
    qt_populacao_2018 INT,
    qtd_populacao_2022 INT,
    qtd_populacao_2023 INT,
    qtd_populacao_2024 INT,
    qtd_populacao_2025 INT,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (municipio_id) REFERENCES municipios(id) ON DELETE CASCADE,
    FOREIGN KEY (tipo_unidade_id) REFERENCES tipos_unidade(id)
);

-- Tabela de Tipos de Unidades
CREATE TABLE tipos_unidade (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    descricao TEXT,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de Relatórios
CREATE TABLE relatorios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    tipo_relatorio ENUM('Atendimentos por Mês/Ano', 'Atendimentos por Atendente', 'Chamados Finalizados', 'Top 10 Origem de Chamados') NOT NULL,
    periodo_inicio DATE,
    periodo_fim DATE,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de Permissões Detalhadas para Grupos de Usuários
CREATE TABLE permissoes_grupo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    grupo_id INT NOT NULL,
    permissao_id INT NOT NULL,
    FOREIGN KEY (grupo_id) REFERENCES grupos(id),
    FOREIGN KEY (permissao_id) REFERENCES permissoes(id)
);

-- Tabela de Logs de Atividades
CREATE TABLE logs_atividades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    tipo_atividade ENUM('Login', 'Alteração', 'Criação', 'Exclusão', 'Erro') NOT NULL,
    descricao TEXT,
    ip_endereco VARCHAR(45), -- Para registrar o IP de onde a ação foi realizada
    data_atividade DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Tabela de Agendamentos
CREATE TABLE agendamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    atendimento_id INT NOT NULL,
    data_agendamento DATETIME NOT NULL,
    status ENUM('Agendado', 'Cancelado', 'Concluído') NOT NULL DEFAULT 'Agendado',
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (atendimento_id) REFERENCES atendimentos(id)
);

-- Tabela de Histórico de Alterações no Atendimento
CREATE TABLE historico_atendimentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    atendimento_id INT NOT NULL,
    campo_modificado VARCHAR(100),
    valor_anterior TEXT,
    valor_novo TEXT,
    usuario_id INT NOT NULL,
    data_modificacao DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (atendimento_id) REFERENCES atendimentos(id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Tabela de Feedback de Atendimentos
CREATE TABLE feedback_atendimentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    atendimento_id INT NOT NULL,
    paciente_nome VARCHAR(100),
    feedback TEXT,
    nota INT CHECK (nota BETWEEN 1 AND 5), -- Nota de 1 a 5
    data_feedback DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (atendimento_id) REFERENCES atendimentos(id)
);

-- Tabela de Itens de Relatório
CREATE TABLE itens_relatorio (
    id INT AUTO_INCREMENT PRIMARY KEY,
    relatorio_id INT NOT NULL,
    campo VARCHAR(100) NOT NULL,
    tipo_dado ENUM('Texto', 'Número', 'Data', 'DataHora', 'Enum') NOT NULL,
    valor_padrão TEXT,
    FOREIGN KEY (relatorio_id) REFERENCES relatorios(id)
);

-- Tabela de Relacionamento de Usuários com Atendimentos
CREATE TABLE usuarios_atendimento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    atendimento_id INT NOT NULL,
    usuario_id INT NOT NULL,
    papel ENUM('Principal', 'Suporte', 'Observador') NOT NULL DEFAULT 'Principal',
    FOREIGN KEY (atendimento_id) REFERENCES atendimentos(id),
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Tabela de Configurações do Sistema
CREATE TABLE configuracoes_sistema (
    id INT AUTO_INCREMENT PRIMARY KEY,
    chave VARCHAR(100) NOT NULL UNIQUE,
    valor TEXT NOT NULL,
    descricao TEXT,
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);
