<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}
require_once '../backend/conexao.php';

// Paginação
$limit = 10; // Número de registros por página
$page = isset($_GET['page']) ? (int)$_GET['page'] : 1;
$offset = ($page - 1) * $limit;

// Obter atendimentos
$stmt = $conn->prepare("SELECT a.id, a.data_inicio, u.nome AS atendente, o.nome AS origem, a.status
                        FROM atendimentos a
                        JOIN usuarios u ON a.usuario_id = u.id
                        JOIN origens_atendimento o ON a.origem_id = o.id
                        ORDER BY a.data_inicio DESC
                        LIMIT ? OFFSET ?");
$stmt->bindValue(1, $limit, PDO::PARAM_INT);
$stmt->bindValue(2, $offset, PDO::PARAM_INT);
$stmt->execute();
$atendimentos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Total de registros para paginação
$totalStmt = $conn->query("SELECT COUNT(*) AS total FROM atendimentos");
$totalRegistros = $totalStmt->fetch(PDO::FETCH_ASSOC)['total'];
$totalPaginas = ceil($totalRegistros / $limit);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Listar Atendimentos - Sistema de Atendimento</title>
    <link rel="stylesheet" href="../assets/css/estilos.css">
</head>
<body>
<?php include '../includes/header.php'; ?>
<?php include '../includes/sidebar.php'; ?>
<div class="content">
    <h1>Atendimentos</h1>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>ID</th>
            <th>Data de Início</th>
            <th>Atendente</th>
            <th>Origem</th>
            <th>Status</th>
            <th>Ações</th>
        </tr>
        </thead>
        <tbody>
        <?php foreach ($atendimentos as $atendimento): ?>
            <tr>
                <td><?= htmlspecialchars($atendimento['id']) ?></td>
                <td><?= htmlspecialchars($atendimento['data_inicio']) ?></td>
                <td><?= htmlspecialchars($atendimento['atendente']) ?></td>
                <td><?= htmlspecialchars($atendimento['origem']) ?></td>
                <td><?= htmlspecialchars($atendimento['status']) ?></td>
                <td>
                    <a href="visualizar_atendimento.php?id=<?= $atendimento['id'] ?>" class="btn btn-info btn-sm">Visualizar</a>
                    <?php if ($_SESSION['perfil'] === 'Administrador' || $_SESSION['perfil'] === 'Coordenador'): ?>
                        <a href="editar_atendimento.php?id=<?= $atendimento['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                        <a href="excluir_atendimento.php?id=<?= $atendimento['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja excluir este atendimento?')">Excluir</a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; ?>
        </tbody>
    </table>

    <!-- Paginação -->
    <nav>
        <ul class="pagination">
            <?php for ($i = 1; $i <= $totalPaginas; $i++): ?>
                <li class="page-item <?= $i === $page ? 'active' : '' ?>">
                    <a class="page-link" href="?page=<?= $i ?>"><?= $i ?></a>
                </li>
            <?php endfor; ?>
        </ul>
    </nav>
</div>
</body>
</html>