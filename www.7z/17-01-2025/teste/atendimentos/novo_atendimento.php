<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}
require_once '../backend/conexao.php';
require_once '../backend/csrf_token.php';

// Geração do token CSRF
$csrfToken = gerarToken();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Novo Atendimento - Sistema de Atendimento</title>
    <link rel="stylesheet" href="../assets/css/estilos.css">
</head>
<body>
<?php include '../includes/header.php'; ?>
<?php include '../includes/sidebar.php'; ?>
<div class="content">
    <h1>Novo Atendimento</h1>
    <form action="salvar_atendimento.php" method="POST">
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
        <div class="form-group">
            <label for="origem">Origem:</label>
            <select name="origem" id="origem" class="form-control" required>
                <?php
                $stmt = $conn->query("SELECT id, nome FROM origens_atendimento WHERE status = 'ativo'");
                while ($origem = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo "<option value='{$origem['id']}'>{$origem['nome']}</option>";
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="recurso">Recurso:</label>
            <select name="recurso" id="recurso" class="form-control" required>
                <?php
                $stmt = $conn->query("SELECT id, nome FROM recursos WHERE status = 'ativo'");
                while ($recurso = $stmt->fetch(PDO::FETCH_ASSOC)) {
                    echo "<option value='{$recurso['id']}'>{$recurso['nome']}</option>";
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="descricao">Descrição:</label>
            <textarea name="descricao" id="descricao" class="form-control" required></textarea>
        </div>
        <button type="submit" class="btn btn-primary">Salvar Atendimento</button>
    </form>
</div>
</body>
</html>