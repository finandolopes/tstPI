<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}
require_once '../backend/conexao.php';

$id = isset($_GET['id']) ? (int)$_GET['id'] : 0;

// Verifica se o ID do atendimento é válido
$stmt = $conn->prepare("SELECT * FROM atendimentos WHERE id = ?");
$stmt->execute([$id]);
$atendimento = $stmt->fetch(PDO::FETCH_ASSOC);

if (!$atendimento) {
    die('Atendimento não encontrado.');
}

// Atualizar atendimento
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $origem_id = $_POST['origem_id'];
    $motivo_id = $_POST['motivo_id'];
    $recurso_id = $_POST['recurso_id'];
    $descricao = $_POST['descricao'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("UPDATE atendimentos 
                            SET origem_id = ?, motivo_id = ?, recurso_id = ?, descricao = ?, status = ? 
                            WHERE id = ?");
    $stmt->execute([$origem_id, $motivo_id, $recurso_id, $descricao, $status, $id]);

    header('Location: listar_atendimentos.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Atendimento - Sistema de Atendimento</title>
    <link rel="stylesheet" href="../assets/css/estilos.css">
</head>
<body>
<?php include '../includes/header.php'; ?>
<?php include '../includes/sidebar.php'; ?>
<div class="content">
    <h1>Editar Atendimento</h1>
    <form method="POST">
        <div class="form-group">
            <label for="origem_id">Origem:</label>
            <select name="origem_id" id="origem_id" class="form-control" required>
                <?php
                $origens = $conn->query("SELECT id, nome FROM origens_atendimento")->fetchAll(PDO::FETCH_ASSOC);
                foreach ($origens as $origem) {
                    $selected = $origem['id'] == $atendimento['origem_id'] ? 'selected' : '';
                    echo "<option value='{$origem['id']}' $selected>{$origem['nome']}</option>";
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="motivo_id">Motivo:</label>
            <select name="motivo_id" id="motivo_id" class="form-control" required>
                <?php
                $motivos = $conn->query("SELECT id, nome FROM motivos_atendimento")->fetchAll(PDO::FETCH_ASSOC);
                foreach ($motivos as $motivo) {
                    $selected = $motivo['id'] == $atendimento['motivo_id'] ? 'selected' : '';
                    echo "<option value='{$motivo['id']}' $selected>{$motivo['nome']}</option>";
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="recurso_id">Recurso:</label>
            <select name="recurso_id" id="recurso_id" class="form-control" required>
                <?php
                $recursos = $conn->query("SELECT id, nome FROM recursos")->fetchAll(PDO::FETCH_ASSOC);
                foreach ($recursos as $recurso) {
                    $selected = $recurso['id'] == $atendimento['recurso_id'] ? 'selected' : '';
                    echo "<option value='{$recurso['id']}' $selected>{$recurso['nome']}</option>";
                }
                ?>
            </select>
        </div>
        <div class="form-group">
            <label for="descricao">Descrição:</label>
            <textarea name="descricao" id="descricao" class="form-control" required><?= htmlspecialchars($atendimento['descricao']) ?></textarea>
        </div>
        <div class="form-group">
            <label for="status">Status:</label>
            <select name="status" id="status" class="form-control" required>
                <option value="Aberto" <?= $atendimento['status'] === 'Aberto' ? 'selected' : '' ?>>Aberto</option>
                <option value="Pendente" <?= $atendimento['status'] === 'Pendente' ? 'selected' : '' ?>>Pendente</option>
                <option value="Fechado" <?= $atendimento['status'] === 'Fechado' ? 'selected' : '' ?>>Fechado</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Salvar Alterações</button>
        <a href="listar_atendimentos.php" class="btn btn-secondary">Cancelar</a>
    </form>
</div>
</body>
</html>