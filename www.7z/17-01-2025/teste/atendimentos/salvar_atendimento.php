<?php
session_start();
require_once '../backend/conexao.php';
require_once '../backend/csrf_token.php';

// Verificar token CSRF
if (!verificarToken($_POST['csrf_token'])) {
    die('Erro: Token CSRF inválido.');
}

// Dados do formulário
$usuarioId = $_SESSION['usuario_id'];
$origem = $_POST['origem'];
$recurso = $_POST['recurso'];
$descricao = $_POST['descricao'];

// Inserir no banco de dados
$stmt = $conn->prepare("INSERT INTO atendimentos (usuario_id, origem_id, recurso_id, descricao) VALUES (?, ?, ?, ?)");
if ($stmt->execute([$usuarioId, $origem, $recurso, $descricao])) {
    header('Location: listar_atendimentos.php?success=1');
    exit;
} else {
    die('Erro ao salvar atendimento.');
}
?>