<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

require 'backend/conexao.php';

// Dados para os gráficos e monitoramento
$totalUsuarios = $conn->query("SELECT COUNT(*) FROM usuarios")->fetchColumn();
$usuariosAtivos = $conn->query("SELECT COUNT(*) FROM usuarios WHERE status = 'ativo'")->fetchColumn();
$atendimentosAbertos = $conn->query("SELECT COUNT(*) FROM atendimentos WHERE status = 'Aberto'")->fetchColumn();
$atendimentosPendentes = $conn->query("SELECT COUNT(*) FROM atendimentos WHERE status = 'Pendente'")->fetchColumn();
$atendimentosFechados = $conn->query("SELECT COUNT(*) FROM atendimentos WHERE status = 'Fechado'")->fetchColumn();

// Últimos atendimentos
$ultimosAtendimentos = $conn->query("SELECT * FROM atendimentos ORDER BY data_inicio DESC LIMIT 10")->fetchAll(PDO::FETCH_ASSOC);

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistema de Atendimento</title>
    <link href="favicon.ico" type="image/ico" rel="icon">
    <link href="favicon.ico" type="image/x-icon" rel="shortcut icon">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <!-- <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma/css/bulma.min.css"> Verificar layout        -->
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    
</head>

    <body class="hold-transition sidebar-mini layout-fixed">
        <div class="wrapper">
        <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
            <li class="nav-item">
                <span class="nav-link">Bem-vindo, <strong><?= htmlspecialchars($_SESSION['usuario_nome']); ?></strong></span>
            </li>
        </ul>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <span class="navbar-text" id="welcome-message"></span>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-user"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                    <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#userModal">Minha Conta</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="logout.php">Sair</a></li>
                </ul>
            </li>
        </ul>
    </nav>            
    
    <!-- Sidebar -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <a href="#" class="brand-link">
            <img src="../assets/img/CROSS-.png" alt="Logo" class="brand-image img-circle elevation-3">
            <span class="brand-text font-weight-light">SA-CAT</span>
        </a>
        <div class="sidebar">
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column">
                    <li class="nav-item">
                        <a href="dashboard.php" class="nav-link">
                            <i class="nav-icon fas fa-home"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>                    
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Dashboard</h1>
                    </div>
                </div>
            </div>
        </div>

        <!-- Content -->
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- Cards with dynamic data -->
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-info">
                            <div class="inner">
                                <h3><?= $totalAtendimentos ?></h3>
                                <p>Atendimentos Realizados</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-headset"></i>
                            </div>
                            <a href="#" class="small-box-footer" data-bs-toggle="modal" data-bs-target="#modalRealizados">Mais informações <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-success">
                            <div class="inner">
                                <h3><?= $atendimentosFechados ?></h3>
                                <p>Atendimentos Finalizados</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-check"></i>
                            </div>
                            <a href="#" class="small-box-footer" data-bs-toggle="modal" data-bs-target="#modalFinalizados">Mais informações <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-warning">
                            <div class="inner">
                                <h3><?= $atendimentosAbertos ?></h3>
                                <p>Atendimentos Abertos</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-exclamation-circle"></i>
                            </div>
                            <a href="#" class="small-box-footer" data-bs-toggle="modal" data-bs-target="#modalAbertos">Mais informações <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-danger">
                            <div class="inner">
                                <h3><?= $atendimentosPendentes ?></h3>
                                <p>Atendimentos Pendentes</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-times-circle"></i>
                            </div>
                            <a href="#" class="small-box-footer" data-bs-toggle="modal" data-bs-target="#modalPendentes">Mais informações <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                </div>

                <!-- Top 10 Atendentes -->
                <div class="row">
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Top 10 Atendentes</h3>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Atendente</th>
                                            <th>Total Atendimentos</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($topAtendentes as $atendente): ?>
                                            <tr>
                                                <td><?= $atendente['nome'] ?></td>
                                                <td><?= $atendente['total_atendimentos'] ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
<!-- Atendimentos por DRS -->
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Atendimentos por DRS</h3>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>DRS</th>
                                            <th>Total Atendimentos</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($atendimentosPorDRS as $drs): ?>
                                            <tr>
                                                <td><?= $drs['drs'] ?></td>
                                                <td><?= $drs['total_atendimentos'] ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Atendimentos por Município -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Atendimentos por Município</h3>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Município</th>
                                            <th>Total Atendimentos</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($atendimentosPorMunicipio as $municipio): ?>
                                            <tr>
                                                <td><?= $municipio['municipio'] ?></td>
                                                <td><?= $municipio['total_atendimentos'] ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Últimos 10 Atendimentos -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Últimos 10 Atendimentos</h3>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Início</th>
                                            <th>Atendente</th>
                                            <th>Origem</th>
                                            <th>Status</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($ultimosAtendimentos as $atendimento): ?>
                                            <tr>
                                                <td><?= $atendimento['id'] ?></td>
                                                <td><?= $atendimento['data_inicio'] ?></td>
                                                <td><?= $atendimento['atendente'] ?></td>
                                                <td><?= $atendimento['origem'] ?></td>
                                                <td><?= $atendimento['status'] ?></td>
                                                <td>
                                                    <button class="btn btn-info btn-sm btn-visualizar" label="Visualizar" data-id="<?= $atendimento['id'] ?>">
                                                                <i class="fas fa-eye"></i> 
                                                            </button>
                                                    <?php if (in_array($_SESSION['perfil'], ['coordenador', 'administrador'])): ?>
                                                        <a href="editar_atendimento.php?id=<?= $atendimento['id'] ?>" class="btn btn-warning btn-sm">
                                                            <i class="fas fa-edit"></i> 
                                                        </a>
                                                        <a href="novo_atendimento.php?delete_id=<?= $atendimento['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Confirma a exclusão deste atendimento?')">
                                                            <i class="fas fa-trash"></i> 
                                                        </a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="main-footer text-center">
        <div class="float-right d-none d-sm-block">
            <b>Versão</b> 0.0.1
        </div>
        <p>CROSS - CENTRAL DE REGULAÇÃO DE OFERTAS DE SERVIÇOS DE SAÚDE 
        &copy; <span id="current-year"></span> - Sistema de Atendimento</p>
    </footer>
</div>
<!-- Modal: Minha Conta -->
<div class="modal fade" id="userModal" tabindex="-1" aria-labelledby="userModalLabel" aria-hidden="true">
    <div class="modal-dialog">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="userModalLabel">Minha Conta</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <form id="userForm">
                    <div class="mb-3">
                        <label for="userName" class="form-label">Nome</label>
                        <input type="text" class="form-control" id="userName" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="userEmail" class="form-label">E-mail</label>
                        <input type="email" class="form-control" id="userEmail" readonly>
                    </div>
                    <div class="mb-3">
                        <label for="userLogin" class="form-label">Login</label>
                        <input type="text" class="form-control" id="userLogin" readonly>
                    </div>
                    <button type="button" class="btn btn-secondary" id="changePassword">Alterar Senha</button>
                    <div id="passwordFields" class="mt-3" style="display: none;">
                        <div class="mb-3">
                            <label for="newPassword" class="form-label">Nova Senha</label>
                            <div class="input-group">
                                <input type="password" class="form-control" id="newPassword">
                                <button class="btn btn-outline-secondary" type="button" id="toggleNewPassword">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                        <div class="mb-3">
                            <label for="confirmPassword" class="form-label">Confirmar Senha</label>
                            <div class="input-group">
                                <input type="password" class="form-control" id="confirmPassword">
                                <button class="btn btn-outline-secondary" type="button" id="toggleConfirmPassword">
                                    <i class="fas fa-eye"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <button type="button" class="btn btn-success" id="saveChanges">Salvar</button>
                <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        // Fetch user data
        $.getJSON('backend/obter-usuario.php', function (data) {
            $('#welcome-message').text(`Bem-vindo, ${data.nome}`);
            $('#userName').val(data.nome);
            $('#userEmail').val(data.email);
            $('#userLogin').val(data.login);
        });

        // Show password fields
        $('#changePassword').click(function () {
            $('#passwordFields').toggle();
        });

        // Toggle password visibility
        $('#toggleNewPassword').click(function () {
            togglePasswordVisibility('newPassword', this);
        });

        $('#toggleConfirmPassword').click(function () {
            togglePasswordVisibility('confirmPassword', this);
        });

        function togglePasswordVisibility(inputId, button) {
            const input = $(`#${inputId}`);
            const type = input.attr('type') === 'password' ? 'text' : 'password';
            input.attr('type', type);
            $(button).find('i').toggleClass('fa-eye fa-eye-slash');
        }
    });
</script>
<!-- Modal: Atendimentos Realizados -->
<div class="modal fade" id="modalRealizados" tabindex="-1" aria-labelledby="modalRealizadosLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalRealizadosLabel">Atendimentos Realizados</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Início</th>
                            <th>Atendente</th>
                            <th>Origem</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($ultimosAtendimentos as $atendimento): ?>
                            <tr>
                                <td><?= $atendimento['id'] ?></td>
                                <td><?= $atendimento['data_inicio'] ?></td>
                                <td><?= $atendimento['atendente'] ?></td>
                                <td><?= $atendimento['origem'] ?></td>
                                <td><?= $atendimento['status'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal: Atendimentos Finalizados -->
<div class="modal fade" id="modalFinalizados" tabindex="-1" aria-labelledby="modalFinalizadosLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalFinalizadosLabel">Atendimentos Finalizados</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Início</th>
                            <th>Atendente</th>
                            <th>Origem</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($ultimosAtendimentos as $atendimento): ?>
                            <tr>
                                <td><?= $atendimento['id'] ?></td>
                                <td><?= $atendimento['data_inicio'] ?></td>
                                <td><?= $atendimento['atendente'] ?></td>
                                <td><?= $atendimento['origem'] ?></td>
                                <td><?= $atendimento['status'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal: Atendimentos Abertos -->
<div class="modal fade" id="modalAbertos" tabindex="-1" aria-labelledby="modalAbertosLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalAbertosLabel">Atendimentos Abertos</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Início</th>
                            <th>Atendente</th>
                            <th>Origem</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($ultimosAtendimentos as $atendimento): ?>
                            <tr>
                                <td><?= $atendimento['id'] ?></td>
                                <td><?= $atendimento['data_inicio'] ?></td>
                                <td><?= $atendimento['atendente'] ?></td>
                                <td><?= $atendimento['origem'] ?></td>
                                <td><?= $atendimento['status'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<!-- Modal: Atendimentos Pendentes -->
<div class="modal fade" id="modalPendentes" tabindex="-1" aria-labelledby="modalPendentesLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalPendentesLabel">Atendimentos Pendentes</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Início</th>
                            <th>Atendente</th>
                            <th>Origem</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($ultimosAtendimentos as $atendimento): ?>
                            <tr>
                                <td><?= $atendimento['id'] ?></td>
                                <td><?= $atendimento['data_inicio'] ?></td>
                                <td><?= $atendimento['atendente'] ?></td>
                                <td><?= $atendimento['origem'] ?></td>
                                <td><?= $atendimento['status'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
<script>
    // Alternar Tema do Sidebar
    document.getElementById('theme-selector').addEventListener('change', function () {
        const sidebar = document.querySelector('.main-sidebar');
        sidebar.classList.toggle('sidebar-blue', this.value === 'blue');
        sidebar.classList.toggle('sidebar-darkblue', this.value === 'darkblue');
    });

    // Alternar Sidebar
    document.getElementById('toggle-sidebar').addEventListener('click', function () {
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('main-content');
        sidebar.classList.toggle('retracted');
        mainContent.classList.toggle('retracted');
    });

    // Alternar visibilidade da senha
    document.getElementById('togglePassword').addEventListener('click', function () {
        const password = document.getElementById('password');
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        this.querySelector('i').classList.toggle('fa-eye');
        this.querySelector('i').classList.toggle('fa-eye-slash');
    });

    document.getElementById('toggleConfirmPassword').addEventListener('click', function () {
        const confirmPassword = document.getElementById('confirmPassword');
        const type = confirmPassword.getAttribute('type') === 'password' ? 'text' : 'password';
        confirmPassword.setAttribute('type', type);
        this.querySelector('i').classList.toggle('fa-eye');
        this.querySelector('i').classList.toggle('fa-eye-slash');
    });

    // Salvar nova senha
    document.getElementById('userForm').addEventListener('submit', function (e) {
        e.preventDefault();
        // Lógica para salvar a nova senha
        alert('Senha alterada com sucesso!');
    });
</script>
<script>
    // Eventos para ações
    $('.btn-visualizar').on('click', function () {
        const atendimentoId = $(this).data('id');
        // Lógica para buscar e exibir detalhes no modal
        alert('Visualizar atendimento ID: ' + atendimentoId);
    });
</script>
<?php include 'includes/footer.php'; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
<script>
    function atualizarMonitoramento() {
        fetch('backend/monitoramento_real.php')
            .then(response => response.json())
            .then(data => {
                document.getElementById('usuariosOnline').textContent = data.usuarios_online;
                document.getElementById('novosAtendimentos').textContent = data.novos_atendimentos;
            })
            .catch(err => console.error('Erro ao atualizar monitoramento:', err));
    }

    setInterval(atualizarMonitoramento, 10000);
    atualizarMonitoramento();
</script>
</body>
</html>
