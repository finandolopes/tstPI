<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: login.php');
    exit;
}

require_once 'backend/conexao.php';
$totalAtendimentos = 150; // Exemplos
$atendimentosFechados = 120;
$atendimentosPendentes = 30;

$ultimosAtendimentos = [
    ['id' => 1, 'data_inicio' => '2025-01-12 09:00:00', 'atendente' => 'João', 'origem' => 'E-mail', 'status' => 'Aberto'],
    ['id' => 2, 'data_inicio' => '2025-01-12 10:00:00', 'atendente' => 'Maria', 'origem' => 'Telefone', 'status' => 'Fechado']
];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistema de Atendimento</title>
    <link rel="stylesheet" href="assets/css/estilos.css">
</head>
<body>
    <?php include 'includes/header.php'; ?>
    <?php include 'includes/sidebar.php'; ?>
    <div class="content">
        <h1>Bem-vindo, <?= htmlspecialchars($_SESSION['usuario_nome']) ?></h1>
        <div class="stats">
            <div class="stat-item">Atendimentos Realizados: <?= $totalAtendimentos ?></div>
            <div class="stat-item">Atendimentos Fechados: <?= $atendimentosFechados ?></div>
            <div class="stat-item">Atendimentos Pendentes: <?= $atendimentosPendentes ?></div>
        </div>
        <h2>Últimos Atendimentos</h2>
        <table>
            <tr>
                <th>ID</th>
                <th>Data</th>
                <th>Atendente</th>
                <th>Origem</th>
                <th>Status</th>
            </tr>
            <?php foreach ($ultimosAtendimentos as $atendimento): ?>
                <tr>
                    <td><?= $atendimento['id'] ?></td>
                    <td><?= $atendimento['data_inicio'] ?></td>
                    <td><?= htmlspecialchars($atendimento['atendente']) ?></td>
                    <td><?= htmlspecialchars($atendimento['origem']) ?></td>
                    <td><?= htmlspecialchars($atendimento['status']) ?></td>
                </tr>
            <?php endforeach; ?>
        </table>
    </div>
</body>
</html>