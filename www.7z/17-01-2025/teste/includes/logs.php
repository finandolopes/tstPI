<?php
function salvarLog($usuarioId, $acao, $descricao, $conn) {
    $stmt = $conn->prepare("INSERT INTO logs_auditoria (usuario_id, acao, descricao) VALUES (?, ?, ?)");
    $stmt->execute([$usuarioId, $acao, $descricao]);
}
?>