<footer class="main-footer text-center">
    <strong>CROSS - CENTRAL DE REGULAÇÃO DE OFERTAS DE SERVIÇOS DE SAÚDE</strong>
    <p>&copy; <span id="current-year"></span> Sistema de Atendimento</p>
    <script>
        document.getElementById('current-year').textContent = new Date().getFullYear();
    </script>
</footer>