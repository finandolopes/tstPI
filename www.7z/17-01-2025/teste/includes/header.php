<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Sistema de Atendimento</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <style>
        .dropdown-menu {
            right: 0 !important;
            left: auto !important;
        }

        .dropdown-item i {
            margin-right: 8px;
        }
    </style>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
        </ul>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item">
                <span class="navbar-text">Bem-vindo, <span id="userName"></span></span>
            </li>
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-user"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                    <li><a class="dropdown-item" href="#" data-bs-toggle="modal" data-bs-target="#userModal">Minha Conta</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="logout.php"><i class="fas fa-sign-out-alt"></i> Sair</a></li>
                </ul>
            </li>
        </ul>
    </nav>

    <!-- Modal: Minha Conta -->
    <div class="modal fade" id="userModal" tabindex="-1" aria-labelledby="userModalLabel" aria-hidden="true">
        <div class="modal-dialog">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="userModalLabel">Minha Conta</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
                </div>
                <div class="modal-body">
                    <form id="userForm">
                        <div class="mb-3">
                            <label for="userNameModal" class="form-label">Nome</label>
                            <input type="text" class="form-control" id="userNameModal" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="userEmail" class="form-label">E-mail</label>
                            <input type="email" class="form-control" id="userEmail" readonly>
                        </div>
                        <div class="mb-3">
                            <label for="userLogin" class="form-label">Login</label>
                            <input type="text" class="form-control" id="userLogin" readonly>
                        </div>
                        <button type="button" class="btn btn-secondary" id="changePassword">Alterar Senha</button>
                        <div id="passwordFields" class="mt-3" style="display: none;">
                            <div class="mb-3">
                                <label for="newPassword" class="form-label">Nova Senha</label>
                                <div class="input-group">
                                    <input type="password" class="form-control" id="newPassword">
                                    <button class="btn btn-outline-secondary" type="button" id="toggleNewPassword">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                            <div class="mb-3">
                                <label for="confirmPassword" class="form-label">Confirmar Senha</label>
                                <div class="input-group">
                                    <input type="password" class="form-control" id="confirmPassword">
                                    <button class="btn btn-outline-secondary" type="button" id="toggleConfirmPassword">
                                        <i class="fas fa-eye"></i>
                                    </button>
                                </div>
                            </div>
                        </div>
                    </form>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-primary" id="saveChanges">Salvar Alterações</button>
                    <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                </div>
            </div>
        </div>
    </div>
</div>

<script>
    $(document).ready(function () {
        // Carregar dados do usuário
        $.getJSON('backend/obter-usuario.php', function (data) {
            $('#userName').text(data.nome);
            $('#userNameModal').val(data.nome);
            $('#userEmail').val(data.email);
            $('#userLogin').val(data.login);
        });

        // Exibir/ocultar campos de senha
        $('#changePassword').click(function () {
            $('#passwordFields').toggle();
        });

        // Alternar visibilidade da senha
        $('#toggleNewPassword, #toggleConfirmPassword').click(function () {
            const input = $(this).parent().find('input');
            const type = input.attr('type') === 'password' ? 'text' : 'password';
            input.attr('type', type);
            $(this).find('i').toggleClass('fa-eye fa-eye-slash');
        });

        // Salvar alterações com SweetAlert2
        $('#saveChanges').click(function () {
            const newPassword = $('#newPassword').val();
            const confirmPassword = $('#confirmPassword').val();

            if (!newPassword || !confirmPassword) {
                Swal.fire({
                    icon: 'warning',
                    title: 'Campos Vazios',
                    text: 'Por favor, preencha todos os campos!',
                });
                return;
            }

            if (newPassword !== confirmPassword) {
                Swal.fire({
                    icon: 'error',
                    title: 'Erro',
                    text: 'As senhas não coincidem!',
                });
                return;
            }

            $.ajax({
                url: 'backend/alterar-senha.php',
                type: 'POST',
                data: { senha: newPassword },
                success: function () {
                    Swal.fire({
                        icon: 'success',
                        title: 'Sucesso',
                        text: 'Senha alterada com sucesso!',
                    }).then(() => {
                        $('#passwordFields').hide();
                    });
                },
                error: function () {
                    Swal.fire({
                        icon: 'error',
                        title: 'Erro',
                        text: 'Erro ao alterar a senha.',
                    });
                }
            });
        });
    });
</script>
</body>
</html>