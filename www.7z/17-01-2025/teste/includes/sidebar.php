<?php
$permissoes = $_SESSION['permissoes'] ?? [];
?>
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="dashboard.php" class="brand-link">
        <img src="assets/img/CROSS-.png" alt="Logo" class="brand-image img-circle elevation-3">
        <span class="brand-text font-weight-light">SA-CAT</span>
    </a>
    <div class="sidebar">
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column" role="menu" data-accordion="false">
                <!-- Dashboard -->
                <li class="nav-item">
                    <a href="dashboard.php" class="nav-link <?= basename($_SERVER['PHP_SELF']) === 'dashboard.php' ? 'active' : '' ?>">
                        <i class="nav-icon fas fa-home"></i>
                        <p>Dashboard</p>
                    </a>
                </li>
                <!-- Atendimentos -->
                <?php if (in_array('Criar Atendimentos', $permissoes)): ?>
                <li class="nav-item <?= strpos($_SERVER['PHP_SELF'], 'atendimentos') !== false ? 'menu-open' : '' ?>">
                    <a href="#" class="nav-link">
                        <i class="nav-icon fas fa-headset"></i>
                        <p>Atendimentos<i class="right fas fa-angle-left"></i></p>
                    </a>
                    <ul class="nav nav-treeview">
                        <li class="nav-item">
                            <a href="atendimentos/novo_atendimento.php" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Novo Atendimento</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="atendimentos/listar_atendimentos.php" class="nav-link">
                                <i class="far fa-circle nav-icon"></i>
                                <p>Listar Atendimentos</p>
                            </a>
                        </li>
                    </ul>
                </li>
                <?php endif; ?>
                <!-- Relatórios -->
                <?php if (in_array('Visualizar Relatórios', $permissoes)): ?>
                <li class="nav-item">
                    <a href="relatorios/sla.php" class="nav-link">
                        <i class="nav-icon fas fa-chart-bar"></i>
                        <p>Relatórios</p>
                    </a>
                </li>
                <?php endif; ?>
                <!-- Configurações -->
                <?php if (in_array('Configurar Sistema', $permissoes)): ?>
                <li class="nav-item">
                    <a href="config/configuracoes.php" class="nav-link">
                        <i class="nav-icon fas fa-cogs"></i>
                        <p>Configurações</p>
                    </a>
                </li>
                <?php endif; ?>
            </ul>
        </nav>
    </div>
</aside>