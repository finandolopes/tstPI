<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['perfil'] !== 'administrador_sistema') {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Capturar filtros
$filtros = [
    'usuario' => $_GET['usuario'] ?? null,
    'ip' => $_GET['ip'] ?? null,
    'resultado' => $_GET['resultado'] ?? null,
    'data_inicio' => $_GET['data_inicio'] ?? null,
    'data_fim' => $_GET['data_fim'] ?? null,
];

// Construir consulta dinâmica
$query = "
    SELECT l.data_hora, u.email AS usuario, l.ip, l.resultado, l.tentativas
    FROM logs_login l
    LEFT JOIN usuarios u ON l.usuario_id = u.id
    WHERE 1=1
";
$params = [];

if ($filtros['usuario']) {
    $query .= " AND u.email LIKE ?";
    $params[] = "%" . $filtros['usuario'] . "%";
}
if ($filtros['ip']) {
    $query .= " AND l.ip = ?";
    $params[] = $filtros['ip'];
}
if ($filtros['resultado']) {
    $query .= " AND l.resultado = ?";
    $params[] = $filtros['resultado'];
}
if ($filtros['data_inicio'] && $filtros['data_fim']) {
    $query .= " AND DATE(l.data_hora) BETWEEN ? AND ?";
    $params[] = $filtros['data_inicio'];
    $params[] = $filtros['data_fim'];
}

$query .= " ORDER BY l.data_hora DESC";

$stmt = $conn->prepare($query);
$stmt->execute($params);
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notificações de Segurança</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
    <!-- Navbar -->
    <?php include 'includes/navbar.php'; ?>
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>

    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Notificações de Segurança</h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                <!-- Filtros -->
                <form method="GET" class="mb-4">
                    <div class="row">
                        <div class="col-md-3">
                            <label for="usuario" class="form-label">Usuário (E-mail)</label>
                            <input type="text" name="usuario" id="usuario" class="form-control" value="<?= htmlspecialchars($filtros['usuario'] ?? '') ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="ip" class="form-label">Endereço IP</label>
                            <input type="text" name="ip" id="ip" class="form-control" value="<?= htmlspecialchars($filtros['ip'] ?? '') ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="resultado" class="form-label">Resultado</label>
                            <select name="resultado" id="resultado" class="form-select">
                                <option value="">Todos</option>
                                <option value="sucesso" <?= ($filtros['resultado'] == 'sucesso') ? 'selected' : '' ?>>Sucesso</option>
                                <option value="falha" <?= ($filtros['resultado'] == 'falha') ? 'selected' : '' ?>>Falha</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="data_inicio" class="form-label">Data Início</label>
                            <input type="date" name="data_inicio" id="data_inicio" class="form-control" value="<?= htmlspecialchars($filtros['data_inicio'] ?? '') ?>">
                        </div>
                        <div class="col-md-3 mt-3">
                            <label for="data_fim" class="form-label">Data Fim</label>
                            <input type="date" name="data_fim" id="data_fim" class="form-control" value="<?= htmlspecialchars($filtros['data_fim'] ?? '') ?>">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary mt-4 w-100">Filtrar Notificações</button>
                </form>

                <!-- Resultados -->
                <?php if (!empty($logs)): ?>
                    <table class="table table-bordered mt-4">
                        <thead>
                            <tr>
                                <th>Data e Hora</th>
                                <th>Usuário</th>
                                <th>Endereço IP</th>
                                <th>Resultado</th>
                                <th>Tentativas Consecutivas</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($logs as $log): ?>
                                <tr>
                                    <td><?= $log['data_hora'] ?></td>
                                    <td><?= $log['usuario'] ?? 'Não registrado' ?></td>
                                    <td><?= $log['ip'] ?></td>
                                    <td><?= ucfirst($log['resultado']) ?></td>
                                    <td><?= $log['tentativas'] ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <!-- Botões de Exportação -->
                    <div class="mt-4">
                        <a href="exportar_notificacoes.php?formato=pdf" class="btn btn-danger">Exportar para PDF</a>
                        <a href="exportar_notificacoes.php?formato=excel" class="btn btn-success">Exportar para Excel</a>
                        <a href="exportar_notificacoes.php?formato=word" class="btn btn-primary">Exportar para Word</a>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">Nenhuma notificação encontrada para os filtros selecionados.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>