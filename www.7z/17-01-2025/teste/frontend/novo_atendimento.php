<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Novo Atendimento - Sistema de Atendimento</title>
    <link href="favicon.ico" type="image/ico" rel="icon">
    <link href="favicon.ico" type="image/x-icon" rel="shortcut icon">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma/css/bulma.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- Navbar -->
    
        <body class="hold-transition sidebar-mini layout-fixed">
            <div class="wrapper">
            
                <!-- Navbar -->
                <nav class="main-header navbar navbar-expand navbar-white navbar-light">
                    <ul class="navbar-nav">
                        <li class="nav-item">
                            <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
                        </li>
                        <li class="nav-item">
                            <span class="nav-link">Bem-vindo, <strong>Usuário</strong></span>
                        </li>
                    </ul>
                    <ul class="navbar-nav ml-auto">
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                                <i class="fas fa-user"></i>
                            </a>
                            <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                                <li><a class="dropdown-item" href="#">Minha Conta</a></li>
                                <li><hr class="dropdown-divider"></li>
                                <li><a class="dropdown-item" href="logout.php">Sair</a></li>
                            </ul>
                        </li>
                    </ul>
                </nav>    

        <!-- Sidebar -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <a href="#" class="brand-link">
            <img src="../assets/img/CROSS-.png" alt="Logo" class="brand-image img-circle elevation-3">
            <span class="brand-text font-weight-light">SA-CAT</span>
        </a>
        <div class="sidebar">
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column">
                    <li class="nav-item">
                        <a href="dashboard.html" class="nav-link">
                            <i class="nav-icon fas fa-home"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="novo_atendimento.html" class="nav-link active">
                            <i class="nav-icon fas fa-plus-circle"></i>
                            <p>Novo Atendimento</p>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>

         <!-- Content Wrapper -->
         
         <div class="content-wrapper">
            <section class="content-header">
                <div class="container-fluid">
         <div class="card mt-4">
                    <div class="card-header">
                        <h3 class="card-title">+Novo Atendimento</h3>
                    </div>
                    <div class="card-body">
                        <div class="row">
                            <!-- Atendente -->
                            <div class="col-lg-2 col-md-6 col-12 mb-3">
                                <div class="form-group">
                                    <label for="atendente">Atendente</label>
                                    <input type="text" class="form-control" value="<?= htmlspecialchars($user['nome']); ?>" readonly>
                                </div>
                            </div>
                            <!-- Data Atendimento Inicial/Hora -->
                            <div class="col-lg-2 col-md-6 col-12 mb-3">
                                <div class="form-group">
                                    <label for="inicio">Data/Hora de Início</label>
                                    <input type="text" class="form-control" value="<?= date('Y-m-d H:i:s'); ?>" readonly>
                                </div>
                            </div>
        
                            <!-- Origem do Atendimento -->
                            <div class="col-lg-6 col-md-6 col-12 mb-3">
                                <div class="form-group">
                                    <label for="origem">Origem</label>
                                    <select name="origem" id="origem" class="form-control" required>
                                        <option value="">Selecione</option>
                                        <?php while ($row = $result_origens->fetch_assoc()): ?>
                                            <option value="<?= $row['id']; ?>"><?= htmlspecialchars($row['nome']); ?></option>
                                        <?php endwhile; ?>
                                    </select>
                                </div>
                            </div>
        
                            <!-- Recurso -->
                            <div class="col-lg-2 col-md-6 col-12 mb-3">
                                <div class="form-group">
                                    <label for="recurso">Recurso</label>
                                    <select name="recurso" id="recurso" class="form-control" required>
                                    <option value="">Selecione</option>
                                    <?php while ($row = $result_recurso->fetch_assoc()): ?>
                                        <option value="<?= $row['id']; ?>"><?= htmlspecialchars($row['nome']); ?></option>
                                    <?php endwhile; ?>
                                </select>
                                </div>
                            </div>
        
                            <!-- Motivo do Atendimento -->
                            <div class="col-lg-5 col-md-6 col-12 mb-3">
                                <div class="form-group">
                                    <label for="motivo">Motivo do Atendimento</label>                                            
                                    <select name="motivo" id="motivo" class="form-control" required>
                                    <option value="">Selecione</option>
                                    <?php while ($row = $result_motivos->fetch_assoc()): ?>
                                        <option value="<?= $row['id']; ?>"><?= htmlspecialchars($row['nome']); ?></option>
                                    <?php endwhile; ?>
                                </select>
                                </div>
                            </div>  
                             <!-- Código do Paciente -->
                             <div class="col-lg-2 col-md-6 col-12 mb-3">
                                <div class="form-group">
                                    <label for="codigo-paciente">Código do Paciente</label>
                                            <input type="text" class="form-control" id="codigo-paciente" placeholder="Código do Paciente" required>
                                </div>
                            </div>   
                            <!-- Origem do Atendimento -->
                            <div class="col-lg-5 col-md-6 col-12 mb-3">
                                <div class="form-group">
                                    <label for="origem-atendimento">Origem do Atendimento</label>
                                    <select name="origem" id="origem" class="form-control" required>
                                    <option value="">Selecione</option>
                                    <?php while ($row = $result_origem->fetch_assoc()): ?>
                                        <option value="<?= $row['id']; ?>"><?= htmlspecialchars($row['nome']); ?></option>
                                    <?php endwhile; ?>
                                </select>
                                </div>
                            </div>    
                            <!-- Descrição do Motivo -->
                            <div class="col-lg-7 col-md-6 col-12 mb-3">
                                <div class="form-group">
                                    <label for="descricaoMotivo" class="form-label">Descrição do Motivo</label>
                                            <textarea id="descricaoMotivo" class="form-control" rows="3" placeholder="Adicione descrição do Motivo"></textarea>
                                </div>
                            </div>                      
                            <!-- Unidade Solicitante -->
                            <div class="col-lg-6 col-md-6 col-12 mb-3">
                                <div class="form-group">
                                    <label for="unidade-solicitante">Unidade Solicitante</label>
                                    <input type="text" name="unidade_solicitante" class="form-control" placeholder="Pesquise a Unidade" required>
                                </div>
                            </div>   
                            <!-- Unidade Executante -->
                            <div class="col-lg-6 col-md-6 col-12 mb-3">
                                <div class="form-group">
                                    <label for="unidade-executante">Unidade Executante</label>
                                    <input type="text" name="unidade_executante" class="form-control" placeholder="Pesquise a Unidade" required>
                                </div>
                            </div>   
                            <!-- Botões -->
                            <div class="col-lg-12 text-right">
                                <button type="button" id="clearForm" class="btn btn-secondary clearForm"><i class="fa fa-eraser"></i>Limpar</button>
                                <button type="submit" class="btn btn-primary"><i class="fa-solid fa-check"></i>Finalizar</button>
                            </div>
                            
                        </div>
                    </div>
                </div>
            </div>
        </section>
        </div>


        <footer class="main-footer text-center">
            <div class="float-right d-none d-sm-block">
                <b>Versão</b> 0.0.1
            </div>
            <p>CROSS - CENTRAL DE REGULAÇÃO DE OFERTAS DE SERVIÇOS DE SAÚDE</p>
            <p>&copy; <span id="current-year"></span> - Sistema de Atendimento</p>
        </footer>
    </div>
    <script>
        $(document).ready(function () {
            // Configurar envio do formulário com SweetAlert2
            $('#novoAtendimentoForm').on('submit', function (e) {
                e.preventDefault();
    
                const data = $(this).serialize(); // Serializar os dados do formulário
    
                $.post('backend/novo_atendimento.php', data, function (response) {
                    if (response.success) {
                        Swal.fire('Sucesso', 'Atendimento criado com sucesso!', 'success').then(() => {
                            location.reload();
                        });
                    } else {
                        Swal.fire('Erro', 'Não foi possível criar o atendimento.', 'error');
                    }
                }, 'json');
            });
    
            // Dropdown do usuário funcionando com Bootstrap
            $('#userDropdown').on('click', function (e) {
                e.preventDefault();
                $(this).dropdown('toggle');
            });
        });
    </script>
    <script>
        document.getElementById('current-year').textContent = new Date().getFullYear();
    </script>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>
