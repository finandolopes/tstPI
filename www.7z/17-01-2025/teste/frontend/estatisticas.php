<?php
session_start();
if (!isset($_SESSION['usuario_id']) || !in_array($_SESSION['perfil'], ['coordenador', 'administrador', 'administrador_sistema'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

try {
    // Obter estatísticas
    $totalAtendimentos = $conn->query("SELECT COUNT(*) AS total FROM atendimentos")->fetch(PDO::FETCH_ASSOC)['total'];
    $atendimentosHoje = $conn->query("SELECT COUNT(*) AS total FROM atendimentos WHERE DATE(data_inicio) = CURDATE()")->fetch(PDO::FETCH_ASSOC)['total'];
    $atendimentosAbertos = $conn->query("SELECT COUNT(*) AS total FROM atendimentos WHERE UPPER(status) = 'ABERTO'")->fetch(PDO::FETCH_ASSOC)['total'];
    $atendimentosFinalizados = $conn->query("SELECT COUNT(*) AS total FROM atendimentos WHERE UPPER(status) = 'FINALIZADO'")->fetch(PDO::FETCH_ASSOC)['total'];
} catch (Exception $e) {
    die("Erro ao carregar estatísticas: " . $e->getMessage());
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Estatísticas em Tempo Real</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <!-- Botão de Menu -->
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
            <li class="nav-item d-none d-sm-inline-block">
                <a href="dashboard.php" class="nav-link">Início</a>
            </li>
            <li class="nav-item d-none d-sm-inline-block">
                <a href="contato.php" class="nav-link">Contato</a>
            </li>
        </ul>
        <!-- User Dropdown -->
        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
                <a class="nav-link" data-toggle="dropdown" href="#">
                    <i class="fas fa-user"></i> <?= htmlspecialchars($_SESSION['usuario_nome']); ?>
                </a>
                <div class="dropdown-menu dropdown-menu-right">
                    <a href="perfil.php" class="dropdown-item">Meu Perfil</a>
                    <div class="dropdown-divider"></div>
                    <a href="logout.php" class="dropdown-item">Sair</a>
                </div>
            </li>
        </ul>
    </nav>

    <!-- Sidebar -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <!-- Logo -->
        <a href="#" class="brand-link">
            <img src="assets/img/CROSS-.png" alt="Logo" class="brand-image img-circle elevation-3">
            <span class="brand-text font-weight-light">SA-CAT</span>
        </a>
        <!-- Menu -->
        <div class="sidebar">
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column">
                    <li class="nav-item">
                        <a href="dashboard.php" class="nav-link active">
                            <i class="nav-icon fas fa-chart-bar"></i>
                            <p>Estatísticas</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="novo-atendimento.php" class="nav-link">
                            <i class="nav-icon fas fa-plus-circle"></i>
                            <p>Novo Atendimento</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="configuracoes.php" class="nav-link">
                            <i class="nav-icon fas fa-cogs"></i>
                            <p>Configurações</p>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Estatísticas em Tempo Real</h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                <!-- Cards -->
                <div class="row">
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-primary">
                            <div class="inner">
                                <h3><?= $totalAtendimentos ?></h3>
                                <p>Total de Atendimentos</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-headset"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-success">
                            <div class="inner">
                                <h3><?= $atendimentosHoje ?></h3>
                                <p>Atendimentos Hoje</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-calendar-day"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-warning">
                            <div class="inner">
                                <h3><?= $atendimentosAbertos ?></h3>
                                <p>Atendimentos Abertos</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-exclamation-circle"></i>
                            </div>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-danger">
                            <div class="inner">
                                <h3><?= $atendimentosFinalizados ?></h3>
                                <p>Atendimentos Finalizados</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-check-circle"></i>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Gráfico -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Resumo Gráfico</h3>
                            </div>
                            <div class="card-body">
                                <canvas id="chartAtendimentos"></canvas>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="main-footer text-center">
        <strong>&copy; <?= date('Y') ?> SA-CAT</strong>
    </footer>
</div>

<script>
    // Gráfico
    const ctx = document.getElementById('chartAtendimentos').getContext('2d');
    new Chart(ctx, {
        type: 'doughnut',
        data: {
            labels: ['Abertos', 'Finalizados'],
            datasets: [{
                data: [<?= $atendimentosAbertos ?>, <?= $atendimentosFinalizados ?>],
                backgroundColor: ['#ffc107', '#28a745']
            }]
        }
    });
</script>
</body>
</html>