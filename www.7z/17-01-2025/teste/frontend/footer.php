<script>
    let timeout;
    const warningTime = 840000; // 14 minutos (em milissegundos)
    const logoutTime = 900000; // 15 minutos (em milissegundos)

    function startSessionTimer() {
        clearTimeout(timeout);

        // Exibir aviso após 14 minutos
        timeout = setTimeout(() => {
            if (confirm("Você está inativo há algum tempo. Deseja continuar logado?")) {
                fetch("keep_alive.php"); // Requisição para manter a sessão ativa
                startSessionTimer();
            } else {
                window.location.href = "index.php?message=session_expired";
            }
        }, warningTime);
    }

    window.onload = startSessionTimer;
    document.onmousemove = startSessionTimer;
    document.onkeypress = startSessionTimer;
</script>