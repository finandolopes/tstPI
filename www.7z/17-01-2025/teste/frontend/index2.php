<?php if (isset($_GET['message']) && $_GET['message'] === 'session_expired'): ?>
    <div class="alert alert-warning text-center">Sua sessão expirou devido à inatividade. Faça login novamente.</div>
<?php endif; ?>