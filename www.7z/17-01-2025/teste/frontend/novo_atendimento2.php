<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Novo Atendimento - Sistema de Atendimento</title>
    <link href="favicon.ico" type="image/ico" rel="icon">
    <link href="favicon.ico" type="image/x-icon" rel="shortcut icon">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
            <li class="nav-item">
                <span class="nav-link">Bem-vindo, <strong>Usuário</strong></span>
            </li>
        </ul>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
                <a class="nav-link" data-bs-toggle="dropdown" href="#">
                    <i class="fas fa-user"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a href="#" class="dropdown-item">Minha Conta</a></li>
                    <li><a href="logout.php" class="dropdown-item">Sair</a></li>
                </ul>
            </li>
        </ul>
    </nav>

    <!-- Sidebar -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <a href="#" class="brand-link">
            <img src="../assets/img/CROSS-.png" alt="Logo" class="brand-image img-circle elevation-3">
            <span class="brand-text font-weight-light">SA-CAT</span>
        </a>
        <div class="sidebar">
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column">
                    <li class="nav-item">
                        <a href="dashboard.html" class="nav-link">
                            <i class="nav-icon fas fa-home"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="novo_atendimento.html" class="nav-link active">
                            <i class="nav-icon fas fa-plus-circle"></i>
                            <p>Novo Atendimento</p>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <h3>+ Novo Atendimento</h3>
                <div class="card">
                    <div class="card-body">
                        <!-- Formulário de Novo Atendimento -->
                        <form id="novoAtendimentoForm">
                            <div class="row">
                                <div class="col-lg-4">
                                    <label for="codigo-paciente">Código do Paciente</label>
                                    <input type="text" class="form-control" id="codigo-paciente" name="codigo_paciente" required>
                                </div>
                                <div class="col-lg-4">
                                    <label for="origem">Origem</label>
                                    <select id="origem" name="origem" class="form-control" required>
                                        <option value="">Selecione</option>
                                        <!-- Preenchido dinamicamente -->
                                    </select>
                                </div>
                                <div class="col-lg-4">
                                    <label for="motivo">Motivo</label>
                                    <select id="motivo" name="motivo" class="form-control" required>
                                        <option value="">Selecione</option>
                                        <!-- Preenchido dinamicamente -->
                                    </select>
                                </div>
                            </div>
                            <button type="submit" class="btn btn-primary mt-3">Finalizar</button>
                        </form>
                    </div>
                </div>

                <!-- Tabela de Últimos Atendimentos -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h3>Últimos 10 Atendimentos</h3>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Atendente</th>
                                    <th>Status</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <!-- Dados preenchidos dinamicamente -->
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- Modais -->
    <!-- Visualizar Atendimento -->
    <div class="modal fade" id="modalVisualizarAtendimento" tabindex="-1" aria-labelledby="modalVisualizarAtendimentoLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title" id="modalVisualizarAtendimentoLabel">Visualizar Atendimento</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                </div>
                <div class="modal-body">
                    <div id="detalhesAtendimento"></div>
                </div>
            </div>
        </div>
    </div>

    <!-- Editar Atendimento -->
    <div class="modal fade" id="modalEditarAtendimento" tabindex="-1" aria-labelledby="modalEditarAtendimentoLabel" aria-hidden="true">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <form id="formEditarAtendimento">
                    <div class="modal-header">
                        <h5 class="modal-title" id="modalEditarAtendimentoLabel">Editar Atendimento</h5>
                        <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Fechar"></button>
                    </div>
                    <div class="modal-body">
                        <input type="hidden" id="editar-id">
                        <label for="editar-status">Status</label>
                        <select id="editar-status" class="form-control">
                            <option value="Aberto">Aberto</option>
                            <option value="Pendente">Pendente</option>
                            <option value="Fechado">Fechado</option>
                        </select>
                        <label for="editar-descricao" class="mt-3">Descrição</label>
                        <textarea id="editar-descricao" class="form-control"></textarea>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-bs-dismiss="modal">Fechar</button>
                        <button type="submit" class="btn btn-primary">Salvar</button>
                    </div>
                </form>
            </div>
        </div>
    </div>

    <footer class="main-footer text-center">
        <strong>&copy; 2025 Sistema de Atendimento</strong>
    </footer>
</div>

<script>
    $(document).ready(function () {
        // Submissão do formulário de novo atendimento
        $('#novoAtendimentoForm').on('submit', function (e) {
            e.preventDefault();
            $.post('backend/novo_atendimento.php', $(this).serialize(), function (response) {
                if (response.success) {
                    Swal.fire('Sucesso', 'Atendimento registrado!', 'success').then(() => location.reload());
                } else {
                    Swal.fire('Erro', 'Ocorreu um erro ao registrar o atendimento.', 'error');
                }
            }, 'json');
        });

        // Manipulação dos botões Visualizar e Editar
        $('.btn-visualizar').on('click', function () {
            const id = $(this).data('id');
            $.get(`backend/visualizar_atendimento.php?id=${id}`, function (data) {
                $('#detalhesAtendimento').html(data);
                $('#modalVisualizarAtendimento').modal('show');
            });
        });

        $('.btn-editar').on('click', function () {
            const id = $(this).data('id');
            $.get(`backend/editar_atendimento.php?id=${id}`, function (data) {
                const atendimento = JSON.parse(data);
                $('#editar-id').val(atendimento.id);
                $('#editar-status').val(atendimento.status);
                $('#editar-descricao').val(atendimento.descricao);
                $('#modalEditarAtendimento').modal('show');
            });
        });

        // Submissão do formulário de edição
        $('#formEditarAtendimento').on('submit', function (e) {
            e.preventDefault();
            $.post('backend/editar_atendimento.php', $(this).serialize(), function (response) {
                if (response.success) {
                    Swal.fire('Sucesso', 'Atendimento atualizado!', 'success').then(() => location.reload());
                } else {
                    Swal.fire('Erro', 'Não foi possível atualizar o atendimento.', 'error');
                }
            }, 'json');
        });
    });
</script>
</body>
</html>