<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Processar novo cadastro
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $cnes = $_POST['cnes'];
    $nome = $_POST['nome'];
    $municipio_id = $_POST['municipio_id'];
    $tipo_unidade_id = $_POST['tipo_unidade_id'];

    try {
        $stmt = $conn->prepare("INSERT INTO unidades (cnes, nome, municipio_id, tipo_unidade_id) VALUES (?, ?, ?, ?)");
        $stmt->execute([$cnes, $nome, $municipio_id, $tipo_unidade_id]);
        $mensagemSucesso = "Unidade cadastrada com sucesso!";
    } catch (Exception $e) {
        $mensagemErro = "Erro ao cadastrar unidade: " . $e->getMessage();
    }
}

// Obter lista de municípios e tipos de unidade
$municipios = $conn->query("SELECT id, nome FROM municipios")->fetchAll(PDO::FETCH_ASSOC);
$tiposUnidade = $conn->query("SELECT id, nome FROM tipos_unidade")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Unidades</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
<div class="wrapper">
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <!-- Navbar content -->
    </nav>
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <!-- Sidebar content -->
    </aside>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <h1>Cadastro de Unidades</h1>
            </div>
        </div>
        <div class="content">
            <div class="container-fluid">
                <?php if (isset($mensagemErro)): ?>
                    <script>
                        Swal.fire('Erro', '<?= $mensagemErro ?>', 'error');
                    </script>
                <?php elseif (isset($mensagemSucesso)): ?>
                    <script>
                        Swal.fire('Sucesso', '<?= $mensagemSucesso ?>', 'success');
                    </script>
                <?php endif; ?>

                <form method="POST">
                    <div class="mb-3">
                        <label for="cnes" class="form-label">CNES</label>
                        <input type="text" id="cnes" name="cnes" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="nome" class="form-label">Nome da Unidade</label>
                        <input type="text" id="nome" name="nome" class="form-control" required>
                    </div>
                    <div class="mb-3">
                        <label for="municipio_id" class="form-label">Município</label>
                        <select id="municipio_id" name="municipio_id" class="form-select" required>
                            <option value="">Selecione</option>
                            <?php foreach ($municipios as $municipio): ?>
                                <option value="<?= $municipio['id'] ?>"><?= $municipio['nome'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="tipo_unidade_id" class="form-label">Tipo de Unidade</label>
                        <select id="tipo_unidade_id" name="tipo_unidade_id" class="form-select" required>
                            <option value="">Selecione</option>
                            <?php foreach ($tiposUnidade as $tipo): ?>
                                <option value="<?= $tipo['id'] ?>"><?= $tipo['nome'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Salvar</button>
                </form>

                <hr>

                <h3>Unidades Cadastradas</h3>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>CNES</th>
                            <th>Nome</th>
                            <th>Município</th>
                            <th>Tipo</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $unidades = $conn->query("
                            SELECT u.id, u.cnes, u.nome, m.nome AS municipio, t.nome AS tipo
                            FROM unidades u
                            JOIN municipios m ON u.municipio_id = m.id
                            JOIN tipos_unidade t ON u.tipo_unidade_id = t.id
                        ")->fetchAll(PDO::FETCH_ASSOC);
                        foreach ($unidades as $unidade): ?>
                            <tr>
                                <td><?= $unidade['id'] ?></td>
                                <td><?= $unidade['cnes'] ?></td>
                                <td><?= $unidade['nome'] ?></td>
                                <td><?= $unidade['municipio'] ?></td>
                                <td><?= $unidade['tipo'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <footer class="main-footer text-center">
        <strong>&copy; <?= date('Y') ?> SA-CAT</strong>
    </footer>
</div>
</body>
</html>