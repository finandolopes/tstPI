<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['perfil'] !== 'Administrador') {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Buscar todos os usuários e grupos
$usuarios = $conn->query("SELECT id, nome FROM usuarios")->fetchAll(PDO::FETCH_ASSOC);
$permissoes = $conn->query("SELECT id, nome FROM permissoes")->fetchAll(PDO::FETCH_ASSOC);

// Salvar Permissões
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuarioId = $_POST['usuario_id'];
    $permissoesSelecionadas = $_POST['permissoes'] ?? [];

    // Limpar permissões anteriores
    $stmtLimpar = $conn->prepare("DELETE FROM usuario_permissoes WHERE usuario_id = ?");
    $stmtLimpar->execute([$usuarioId]);

    // Inserir novas permissões
    $stmtInserir = $conn->prepare("INSERT INTO usuario_permissoes (usuario_id, permissao_id) VALUES (?, ?)");
    foreach ($permissoesSelecionadas as $permissaoId) {
        $stmtInserir->execute([$usuarioId, $permissaoId]);
    }

    header('Location: permissoes.php?status=sucesso');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Permissões</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
<div class="container mt-4">
    <h1>Gerenciar Permissões</h1>
    <?php if (isset($_GET['status']) && $_GET['status'] === 'sucesso'): ?>
        <div class="alert alert-success">Permissões atualizadas com sucesso!</div>
    <?php endif; ?>

    <!-- Seleção de Usuário -->
    <form method="POST" id="formPermissoes">
        <div class="mb-3">
            <label for="usuario_id" class="form-label">Selecione o Usuário</label>
            <select name="usuario_id" id="usuario_id" class="form-control" required>
                <option value="">-- Selecione --</option>
                <?php foreach ($usuarios as $usuario): ?>
                    <option value="<?= $usuario['id'] ?>"><?= $usuario['nome'] ?></option>
                <?php endforeach; ?>
            </select>
        </div>

        <!-- Permissões -->
        <div class="row">
            <div class="col-md-6">
                <h5>Itens Disponíveis</h5>
                <ul id="listaDisponiveis" class="list-group">
                    <?php foreach ($permissoes as $permissao): ?>
                        <li class="list-group-item" data-id="<?= $permissao['id'] ?>"><?= $permissao['nome'] ?></li>
                    <?php endforeach; ?>
                </ul>
            </div>
            <div class="col-md-6">
                <h5>Itens Permitidos</h5>
                <ul id="listaPermitidos" class="list-group"></ul>
            </div>
        </div>

        <button type="submit" class="btn btn-primary mt-3">Salvar Permissões</button>
    </form>
</div>

<script>
    // Arrastar e soltar permissões
    $('#listaDisponiveis').on('click', '.list-group-item', function () {
        $(this).appendTo('#listaPermitidos');
    });
    $('#listaPermitidos').on('click', '.list-group-item', function () {
        $(this).appendTo('#listaDisponiveis');
    });

    // Enviar permissões selecionadas
    $('#formPermissoes').on('submit', function (e) {
        const permissoesSelecionadas = [];
        $('#listaPermitidos .list-group-item').each(function () {
            permissoesSelecionadas.push($(this).data('id'));
        });
        $('<input>').attr({
            type: 'hidden',
            name: 'permissoes',
            value: JSON.stringify(permissoesSelecionadas)
        }).appendTo(this);
    });
</script>
</body>
</html>