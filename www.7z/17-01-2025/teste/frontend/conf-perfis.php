<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['perfil'] !== 'administrador_sistema') {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Obter todos os perfis
$stmtPerfis = $conn->query("SELECT id, nome FROM perfis");
$perfis = $stmtPerfis->fetchAll(PDO::FETCH_ASSOC);

// Obter todos os módulos do sistema
$stmtModulos = $conn->query("SELECT id, nome FROM modulos");
$modulos = $stmtModulos->fetchAll(PDO::FETCH_ASSOC);

// Salvar configurações de acesso
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $perfil_id = $_POST['perfil'];
    $acessos = $_POST['acessos'] ?? [];

    // Limpar acessos antigos
    $stmtLimpar = $conn->prepare("DELETE FROM perfil_modulos WHERE perfil_id = ?");
    $stmtLimpar->execute([$perfil_id]);

    // Inserir novos acessos
    $stmtInserir = $conn->prepare("INSERT INTO perfil_modulos (perfil_id, modulo_id) VALUES (?, ?)");
    foreach ($acessos as $modulo_id) {
        $stmtInserir->execute([$perfil_id, $modulo_id]);
    }

    header('Location: configurar-perfis.php?status=sucesso');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurar Perfis de Acesso</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Configurar Perfis de Acesso</h1>
        <?php if (isset($_GET['status']) && $_GET['status'] === 'sucesso'): ?>
            <div class="alert alert-success">Acessos atualizados com sucesso!</div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label for="perfil" class="form-label">Selecione um Perfil</label>
                <select id="perfil" name="perfil" class="form-select" required>
                    <?php foreach ($perfis as $perfil): ?>
                        <option value="<?= $perfil['id'] ?>"><?= $perfil['nome'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="acessos" class="form-label">Módulos Disponíveis</label>
                <div id="acessos">
                    <?php foreach ($modulos as $modulo): ?>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="modulo_<?= $modulo['id'] ?>" name="acessos[]" value="<?= $modulo['id'] ?>">
                            <label class="form-check-label" for="modulo_<?= $modulo['id'] ?>">
                                <?= $modulo['nome'] ?>
                            </label>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Salvar Acessos</button>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
