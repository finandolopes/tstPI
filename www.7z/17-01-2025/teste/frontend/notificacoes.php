<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Obter notificações recentes
$stmt = $conn->query("SELECT * FROM notificacoes WHERE lida = 0 ORDER BY data_hora DESC");
$notificacoes = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Notificações</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/jquery.min.js"></script>
</head>
<body>
    <div class="container my-4">
        <h1>Notificações</h1>
        <ul id="listaNotificacoes" class="list-group">
            <?php foreach ($notificacoes as $notificacao): ?>
                <li class="list-group-item">
                    <?= $notificacao['mensagem'] ?>
                    <span class="badge bg-primary float-end"><?= $notificacao['data_hora'] ?></span>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <script>
        function atualizarNotificacoes() {
            $.ajax({
                url: 'backend/notificacoes-atualizar.php',
                method: 'GET',
                dataType: 'json',
                success: function (data) {
                    const lista = $('#listaNotificacoes');
                    lista.empty();
                    data.forEach(notificacao => {
                        lista.append(`<li class="list-group-item">${notificacao.mensagem}<span class="badge bg-primary float-end">${notificacao.data_hora}</span></li>`);
                    });
                }
            });
        }

        setInterval(atualizarNotificacoes, 5000); // Atualizar a cada 5 segundos
    </script>
</body>
</html>
