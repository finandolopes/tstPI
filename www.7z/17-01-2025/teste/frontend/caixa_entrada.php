<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

$usuario_id = $_SESSION['usuario_id'];

// Obter mensagens recebidas
$stmtMensagens = $conn->prepare("
    SELECT m.id, u.nome AS remetente, m.assunto, m.data_envio, m.lida
    FROM mensagens m
    JOIN usuarios u ON m.remetente_id = u.id
    WHERE m.destinatario_id = ?
    ORDER BY m.data_envio DESC
");
$stmtMensagens->execute([$usuario_id]);
$mensagens = $stmtMensagens->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Caixa de Entrada</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Caixa de Entrada</h1>
        <a href="nova_mensagem.php" class="btn btn-primary mb-3">+ Nova Mensagem</a>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Remetente</th>
                    <th>Assunto</th>
                    <th>Data</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($mensagens as $mensagem): ?>
                    <tr>
                        <td><?= $mensagem['remetente'] ?></td>
                        <td><?= $mensagem['assunto'] ?></td>
                        <td><?= $mensagem['data_envio'] ?></td>
                        <td><?= $mensagem['lida'] ? 'Lida' : 'Não Lida' ?></td>
                        <td>
                            <a href="visualizar_mensagem.php?id=<?= $mensagem['id'] ?>" class="btn btn-info btn-sm">Abrir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>