<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

$filtros = [];
$params = [];

// Filtros de entrada
if (!empty($_GET['programa'])) {
    $filtros[] = "programa = ?";
    $params[] = $_GET['programa'];
}
if (!empty($_GET['data_inicio']) && !empty($_GET['data_fim'])) {
    $filtros[] = "DATE(data_inicio) BETWEEN ? AND ?";
    $params[] = $_GET['data_inicio'];
    $params[] = $_GET['data_fim'];
}

$where = $filtros ? "WHERE " . implode(" AND ", $filtros) : "";

// Dados por DRS
$queryDRS = "
    SELECT d.nome AS drs, COUNT(a.id) AS quantidade
    FROM atendimentos a
    JOIN drs d ON a.drs_id = d.id
    $where
    GROUP BY d.id
    ORDER BY quantidade DESC
";
$stmt = $conn->prepare($queryDRS);
$stmt->execute($params);
$dadosDRS = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Total geral
$queryTotal = "
    SELECT COUNT(*) AS total
    FROM atendimentos a
    $where
";
$stmtTotal = $conn->prepare($queryTotal);
$stmtTotal->execute($params);
$total = $stmtTotal->fetchColumn();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório Quantitativo por DRS</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="container my-4">
        <h1>Relatório Quantitativo por DRS</h1>
        <form method="GET" class="mb-4">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label for="programa" class="form-label">Programa</label>
                    <select id="programa" name="programa" class="form-select">
                        <option value="">Selecione o programa</option>
                        <!-- Adicione os programas do banco -->
                        <option value="Programa1">Programa 1</option>
                        <option value="Programa2">Programa 2</option>
                    </select>
                </div>
                <div class="col-md-4 mb-3">
                    <label for="data_inicio" class="form-label">Data Início</label>
                    <input type="date" id="data_inicio" name="data_inicio" class="form-control">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="data_fim" class="form-label">Data Fim</label>
                    <input type="date" id="data_fim" name="data_fim" class="form-control">
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Gerar Relatório</button>
        </form>

        <h3>Gráfico Quantitativo por DRS</h3>
        <canvas id="chartHorizontal" class="mb-4"></canvas>

        <h3>Gráfico com Totais</h3>
        <canvas id="chartVertical" class="mb-4"></canvas>

        <h3>Resumo</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>DRS</th>
                    <th>Quantidade</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($dadosDRS as $drs): ?>
                    <tr>
                        <td><?= $drs['drs'] ?></td>
                        <td><?= $drs['quantidade'] ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr>
                    <th>Total</th>
                    <th><?= $total ?></th>
                </tr>
            </tfoot>
        </table>

        <div class="mt-4">
            <button class="btn btn-success">Exportar para PDF</button>
            <button class="btn btn-info">Exportar para Excel</button>
            <button class="btn btn-warning">Exportar para Word</button>
        </div>
    </div>

    <script>
        const ctxHorizontal = document.getElementById('chartHorizontal').getContext('2d');
        const dataHorizontal = {
            labels: <?= json_encode(array_column($dadosDRS, 'drs')) ?>,
            datasets: [{
                label: 'Atendimentos por DRS',
                data: <?= json_encode(array_column($dadosDRS, 'quantidade')) ?>,
                backgroundColor: '#007bff'
            }]
        };
        new Chart(ctxHorizontal, {
            type: 'horizontalBar',
            data: dataHorizontal,
        });

        const ctxVertical = document.getElementById('chartVertical').getContext('2d');
        const dataVertical = {
            labels: <?= json_encode(array_column($dadosDRS, 'drs')) ?>,
            datasets: [{
                label: 'Total por DRS',
                data: <?= json_encode(array_column($dadosDRS, 'quantidade')) ?>,
                backgroundColor: '#28a745'
            }]
        };
        new Chart(ctxVertical, {
            type: 'bar',
            data: dataVertical,
        });
    </script>
</body>
</html>