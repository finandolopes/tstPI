<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Obter lista de DRS
$stmtDRS = $conn->query("SELECT id, nome FROM drs");
$drsList = $stmtDRS->fetchAll(PDO::FETCH_ASSOC);

// Relatórios de produtividade por DRS
$relatorioDRS = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST' && isset($_POST['drs_id'])) {
    $drs_id = $_POST['drs_id'];
    $stmt = $conn->prepare("
        SELECT u.nome AS atendente, COUNT(a.id) AS total
        FROM atendimentos a
        JOIN usuarios u ON a.atendente_id = u.id
        WHERE a.drs_id = ?
        GROUP BY u.nome
        ORDER BY total DESC
    ");
    $stmt->execute([$drs_id]);
    $relatorioDRS = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios Avançados</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Relatórios Avançados</h1>
        <form method="POST">
            <div class="mb-3">
                <label for="drs_id" class="form-label">Selecione o DRS</label>
                <select id="drs_id" name="drs_id" class="form-select" required>
                    <option value="">Selecione um DRS</option>
                    <?php foreach ($drsList as $drs): ?>
                        <option value="<?= $drs['id'] ?>"><?= $drs['nome'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Gerar Relatório</button>
        </form>
        <?php if (!empty($relatorioDRS)): ?>
            <div class="mt-4">
                <h2>Produtividade por DRS</h2>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Atendente</th>
                            <th>Total Atendimentos</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($relatorioDRS as $item): ?>
                            <tr>
                                <td><?= $item['atendente'] ?></td>
                                <td><?= $item['total'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
