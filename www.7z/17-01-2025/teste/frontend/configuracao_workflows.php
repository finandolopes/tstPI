<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configuração de Workflows</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Configuração de Workflows</h1>
        <?php if (isset($_GET['status']) && $_GET['status'] === 'sucesso'): ?>
            <div class="alert alert-success">Workflow criado com sucesso!</div>
        <?php endif; ?>
        
        <!-- Formulário de Novo Workflow -->
        <form method="POST">
            <div class="mb-3">
                <label for="nome" class="form-label">Nome do Workflow</label>
                <input type="text" id="nome" name="nome" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="tipo_atendimento" class="form-label">Tipo de Atendimento</label>
                <select id="tipo_atendimento" name="tipo_atendimento" class="form-select" required>
                    <option value="">Selecione</option>
                    <?php foreach ($tiposAtendimento as $tipo): ?>
                        <option value="<?= $tipo['id'] ?>"><?= $tipo['nome'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Etapas do Workflow</label>
                <div id="etapas-container">
                    <div class="mb-2">
                        <input type="text" name="etapas[0][nome]" class="form-control mb-1" placeholder="Nome da Etapa" required>
                        <textarea name="etapas[0][descricao]" class="form-control" placeholder="Descrição da Etapa" required></textarea>
                    </div>
                </div>
                <button type="button" id="add-etapa" class="btn btn-secondary">Adicionar Etapa</button>
            </div>
            <button type="submit" class="btn btn-primary">Salvar Workflow</button>
        </form>

        <hr>

        <!-- Lista de Workflows -->
        <h2>Workflows Cadastrados</h2>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Tipo de Atendimento</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($workflows as $workflow): ?>
                    <tr>
                        <td><?= $workflow['nome'] ?></td>
                        <td><?= $workflow['tipo_atendimento_id'] ?></td>
                        <td>
                            <a href="visualizar_workflow.php?id=<?= $workflow['id'] ?>" class="btn btn-info btn-sm">Visualizar</a>
                            <a href="editar_workflow.php?id=<?= $workflow['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                            <a href="deletar_workflow.php?id=<?= $workflow['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja excluir este workflow?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('add-etapa').addEventListener('click', function () {
            const container = document.getElementById('etapas-container');
            const index = container.children.length;
            const etapaDiv = document.createElement('div');
            etapaDiv.classList.add('mb-2');
            etapaDiv.innerHTML = `
                <input type="text" name="etapas[${index}][nome]" class="form-control mb-1" placeholder="Nome da Etapa" required>
                <textarea name="etapas[${index}][descricao]" class="form-control" placeholder="Descrição da Etapa" required></textarea>
            `;
            container.appendChild(etapaDiv);
        });
    </script>
</body>
</html>