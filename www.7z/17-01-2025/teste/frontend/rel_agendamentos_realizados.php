<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

$resultados = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipo_finalizacao = $_POST['tipo_finalizacao'] ?? null;
    $origem = $_POST['origem'] ?? null;
    $data_inicio = $_POST['data_inicio'] ?? null;
    $data_fim = $_POST['data_fim'] ?? null;

    $query = "
        SELECT a.id, a.data_inicio, a.data_fim, o.nome AS origem, a.status
        FROM atendimentos a
        JOIN origens_atendimento o ON a.origem_id = o.id
        WHERE 1=1
    ";
    $params = [];
    if ($tipo_finalizacao) {
        $query .= " AND a.status = ?";
        $params[] = $tipo_finalizacao;
    }
    if ($origem) {
        $query .= " AND o.id = ?";
        $params[] = $origem;
    }
    if ($data_inicio && $data_fim) {
        $query .= " AND a.data_inicio BETWEEN ? AND ?";
        $params[] = $data_inicio;
        $params[] = $data_fim;
    }

    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório de Agendamentos</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
    <?php include 'layout/navbar.php'; ?>
    <?php include 'layout/sidebar.php'; ?>
    <div class="content-wrapper">
        <div class="content-header">
            <h1>Relatório de Agendamentos Realizados</h1>
        </div>
        <div class="content">
            <form method="POST" class="mb-4">
                <div class="row">
                    <div class="col-md-4">
                        <label for="tipo_finalizacao">Tipo de Finalização</label>
                        <select id="tipo_finalizacao" name="tipo_finalizacao" class="form-control">
                            <option value="">Todos</option>
                            <option value="Aberto">Aberto</option>
                            <option value="Pendente">Pendente</option>
                            <option value="Fechado">Fechado</option>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="origem">Origem</label>
                        <select id="origem" name="origem" class="form-control">
                            <option value="">Todas</option>
                            <?php
                            $origens = $conn->query("SELECT id, nome FROM origens_atendimento")->fetchAll(PDO::FETCH_ASSOC);
                            foreach ($origens as $o) {
                                echo "<option value='{$o['id']}'>{$o['nome']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="data_inicio">Data Início</label>
                        <input type="date" id="data_inicio" name="data_inicio" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <label for="data_fim">Data Fim</label>
                        <input type="date" id="data_fim" name="data_fim" class="form-control">
                    </div>
                </div>
                <button type="submit" class="btn btn-primary mt-3">Gerar Relatório</button>
            </form>
            <hr>
            <?php if ($resultados): ?>
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Data Início</th>
                        <th>Data Fim</th>
                        <th>Origem</th>
                        <th>Status</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($resultados as $row): ?>
                        <tr>
                            <td><?= $row['id'] ?></td>
                            <td><?= $row['data_inicio'] ?></td>
                            <td><?= $row['data_fim'] ?></td>
                            <td><?= $row['origem'] ?></td>
                            <td><?= $row['status'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="mt-3">
                    <a href="exportar-pdf.php" class="btn btn-danger">Exportar PDF</a>
                    <a href="exportar-excel.php" class="btn btn-success">Exportar Excel</a>
                    <a href="exportar-word.php" class="btn btn-primary">Exportar Word</a>
                </div>
            <?php else: ?>
                <p>Nenhum resultado encontrado.</p>
            <?php endif; ?>
        </div>
    </div>
    <?php include 'layout/footer.php'; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>