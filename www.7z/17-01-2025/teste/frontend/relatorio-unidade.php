<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Obter lista de unidades
$unidades = $conn->query("SELECT id, nome FROM unidades")->fetchAll(PDO::FETCH_ASSOC);

// Verificar se foi selecionada uma unidade para relatório
$atendimentos = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $unidade_id = $_POST['unidade_id'];

    $stmt = $conn->prepare("
        SELECT a.id, a.data_inicio, a.status, u.nome AS atendente
        FROM atendimentos a
        JOIN usuarios u ON a.atendente_id = u.id
        WHERE a.unidade_id = ?
        ORDER BY a.data_inicio DESC
    ");
    $stmt->execute([$unidade_id]);
    $atendimentos = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório por Unidade</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Relatório por Unidade</h1>
        <form method="POST">
            <div class="mb-3">
                <label for="unidade_id" class="form-label">Selecione a Unidade</label>
                <select id="unidade_id" name="unidade_id" class="form-select" required>
                    <option value="">Selecione uma unidade</option>
                    <?php foreach ($unidades as $unidade): ?>
                        <option value="<?= $unidade['id'] ?>"><?= $unidade['nome'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Gerar Relatório</button>
        </form>
        <?php if (!empty($atendimentos)): ?>
            <div class="mt-4">
                <h2>Atendimentos</h2>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Atendente</th>
                            <th>Data Início</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($atendimentos as $atendimento): ?>
                            <tr>
                                <td><?= $atendimento['id'] ?></td>
                                <td><?= $atendimento['atendente'] ?></td>
                                <td><?= $atendimento['data_inicio'] ?></td>
                                <td><?= ucfirst($atendimento['status']) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        <?php endif; ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
