<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['perfil'] !== 'administrador_sistema') {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Obter municípios e tipos de unidade
$municipios = $conn->query("SELECT id, nome FROM municipios")->fetchAll(PDO::FETCH_ASSOC);
$tiposUnidade = $conn->query("SELECT id, nome FROM tipos_unidade")->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $cnes = $_POST['cnes'];
    $municipio_id = $_POST['municipio_id'];
    $tipo_unidade_id = $_POST['tipo_unidade_id'];

    $stmt = $conn->prepare("INSERT INTO unidades (nome, cnes, municipio_id, tipo_unidade_id) VALUES (?, ?, ?, ?)");
    $stmt->execute([$nome, $cnes, $municipio_id, $tipo_unidade_id]);

    header('Location: gerenciar-unidades.php?status=criado');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nova Unidade</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>+ Nova Unidade</h1>
        <form method="POST">
            <div class="mb-3">
                <label for="nome" class="form-label">Nome da Unidade</label>
                <input type="text" id="nome" name="nome" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="cnes" class="form-label">CNES</label>
                <input type="text" id="cnes" name="cnes" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="municipio_id" class="form-label">Município</label>
                <select id="municipio_id" name="municipio_id" class="form-select" required>
                    <?php foreach ($municipios as $municipio): ?>
                        <option value="<?= $municipio['id'] ?>"><?= $municipio['nome'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="tipo_unidade_id" class="form-label">Tipo de Unidade</label>
                <select id="tipo_unidade_id" name="tipo_unidade_id" class="form-select" required>
                    <?php foreach ($tiposUnidade as $tipo): ?>
                        <option value="<?= $tipo['id'] ?>"><?= $tipo['nome'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <button type="submit" class="btn btn-primary">Salvar</button>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>