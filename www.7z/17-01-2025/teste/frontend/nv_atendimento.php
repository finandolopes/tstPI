<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Buscar últimos atendimentos
$atendimentos = $conn->query("
    SELECT a.id, a.codigo_paciente, a.data_inicio, u.nome AS atendente, a.status
    FROM atendimentos a
    JOIN usuarios u ON a.usuario_id = u.id
    ORDER BY a.data_inicio DESC
    LIMIT 10
")->fetchAll(PDO::FETCH_ASSOC);

// Filtros para busca
$search = $_GET['search'] ?? null;
if ($search) {
    $stmt = $conn->prepare("
        SELECT a.id, a.codigo_paciente, a.data_inicio, u.nome AS atendente, a.status
        FROM atendimentos a
        JOIN usuarios u ON a.usuario_id = u.id
        WHERE a.codigo_paciente LIKE ? OR u.nome LIKE ? OR a.data_inicio LIKE ?
        ORDER BY a.data_inicio DESC
    ");
    $stmt->execute(["%$search%", "%$search%", "%$search%"]);
    $atendimentos = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Novo Atendimento</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <!-- Outros itens -->
    </nav>
    <!-- Sidebar -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <!-- Logo e menus -->
    </aside>

    <div class="content-wrapper">
        <!-- Formulário de Novo Atendimento -->
        <section class="content-header">
            <div class="container-fluid">
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Novo Atendimento</h3>
                    </div>
                    <div class="card-body">
                        <form id="novoAtendimentoForm">
                            <!-- Campos do formulário -->
                        </form>
                        <button class="btn btn-primary" data-bs-toggle="modal" data-bs-target="#modalNovoAtendimento">
                            Novo Atendimento
                        </button>
                    </div>
                </div>

                <!-- Listagem de Atendimentos -->
                <div class="card mt-4">
                    <div class="card-header">
                        <h3 class="card-title">Últimos Atendimentos</h3>
                        <div class="card-tools">
                            <form method="GET">
                                <div class="input-group input-group-sm" style="width: 300px;">
                                    <input type="text" name="search" class="form-control" placeholder="Pesquisar atendimentos">
                                    <div class="input-group-append">
                                        <button type="submit" class="btn btn-default"><i class="fas fa-search"></i></button>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>ID</th>
                                    <th>Código do Paciente</th>
                                    <th>Data de Início</th>
                                    <th>Atendente</th>
                                    <th>Status</th>
                                    <th>Ações</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($atendimentos as $atendimento): ?>
                                    <tr>
                                        <td><?= $atendimento['id'] ?></td>
                                        <td><?= htmlspecialchars($atendimento['codigo_paciente']) ?></td>
                                        <td><?= htmlspecialchars($atendimento['data_inicio']) ?></td>
                                        <td><?= htmlspecialchars($atendimento['atendente']) ?></td>
                                        <td>
                                            <span class="badge badge-<?= $atendimento['status'] === 'Fechado' ? 'success' : ($atendimento['status'] === 'Pendente' ? 'warning' : 'primary') ?>">
                                                <?= htmlspecialchars($atendimento['status']) ?>
                                            </span>
                                        </td>
                                        <td>
                                            <button class="btn btn-info btn-sm" data-bs-toggle="modal" data-bs-target="#modalVisualizar<?= $atendimento['id'] ?>">
                                                <i class="fas fa-eye"></i> Visualizar
                                            </button>
                                            <?php if (in_array($_SESSION['perfil'], ['coordenador', 'administrador'])): ?>
                                                <a href="editar_atendimento.php?id=<?= $atendimento['id'] ?>" class="btn btn-warning btn-sm">
                                                    <i class="fas fa-edit"></i> Editar
                                                </a>
                                                <a href="novo_atendimento.php?delete_id=<?= $atendimento['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Confirma a exclusão deste atendimento?')">
                                                    <i class="fas fa-trash"></i> Excluir
                                                </a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>

                                    <!-- Modal Visualizar -->
                                    <div class="modal fade" id="modalVisualizar<?= $atendimento['id'] ?>" tabindex="-1">
                                        <div class="modal-dialog modal-lg">
                                            <div class="modal-content">
                                                <div class="modal-header">
                                                    <h5 class="modal-title">Atendimento #<?= $atendimento['id'] ?></h5>
                                                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                                                </div>
                                                <div class="modal-body">
                                                    <p><strong>Código do Paciente:</strong> <?= htmlspecialchars($atendimento['codigo_paciente']) ?></p>
                                                    <p><strong>Data de Início:</strong> <?= htmlspecialchars($atendimento['data_inicio']) ?></p>
                                                    <p><strong>Status:</strong> <?= htmlspecialchars($atendimento['status']) ?></p>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </section>
    </div>

    <!-- Modal Novo Atendimento -->
    <div class="modal fade" id="modalNovoAtendimento" tabindex="-1">
        <div class="modal-dialog modal-lg">
            <div class="modal-content">
                <div class="modal-header">
                    <h5 class="modal-title">Novo Atendimento</h5>
                    <button type="button" class="btn-close" data-bs-dismiss="modal"></button>
                </div>
                <div class="modal-body">
                    <!-- Campos do formulário de novo atendimento -->
                </div>
            </div>
        </div>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>