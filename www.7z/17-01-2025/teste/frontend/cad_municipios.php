<?php
require 'backend/conexao.php';

// Inicializar mensagens
$mensagem = null;
$tipo_mensagem = null;

// Processar cadastro, edição e exclusão
try {
    if ($_SERVER['REQUEST_METHOD'] === 'POST') {
        if (isset($_POST['acao']) && $_POST['acao'] === 'cadastrar') {
            // Cadastro
            $nome_municipio = $_POST['nome_municipio'];
            $populacao = $_POST['populacao'];
            $colegiado_id = $_POST['colegiado_id'];

            $stmt = $conn->prepare("INSERT INTO municipios (nome, qt_populacao_2022, colegiado_id) VALUES (?, ?, ?)");
            $stmt->execute([$nome_municipio, $populacao, $colegiado_id]);

            $mensagem = "Município cadastrado com sucesso!";
            $tipo_mensagem = "success";
        } elseif (isset($_POST['acao']) && $_POST['acao'] === 'editar') {
            // Edição
            $id = $_POST['id'];
            $nome_municipio = $_POST['nome_municipio'];
            $populacao = $_POST['populacao'];
            $colegiado_id = $_POST['colegiado_id'];

            $stmt = $conn->prepare("UPDATE municipios SET nome = ?, qt_populacao_2022 = ?, colegiado_id = ? WHERE id = ?");
            $stmt->execute([$nome_municipio, $populacao, $colegiado_id, $id]);

            $mensagem = "Município editado com sucesso!";
            $tipo_mensagem = "success";
        }
    }

    if ($_SERVER['REQUEST_METHOD'] === 'GET' && isset($_GET['excluir'])) {
        // Exclusão
        $id = $_GET['excluir'];

        $stmt = $conn->prepare("DELETE FROM municipios WHERE id = ?");
        $stmt->execute([$id]);

        $mensagem = "Município excluído com sucesso!";
        $tipo_mensagem = "success";
    }
} catch (Exception $e) {
    $mensagem = "Ocorreu um erro: " . $e->getMessage();
    $tipo_mensagem = "error";
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro de Municípios - Sistema de Atendimento</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
        </ul>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-user"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                    <li><a class="dropdown-item" href="#">Minha Conta</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="logout.php">Sair</a></li>
                </ul>
            </li>
        </ul>
    </nav>

    <!-- Sidebar -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <a href="#" class="brand-link">
            <img src="assets/img/CROSS-.png" alt="Logo" class="brand-image img-circle elevation-3">
            <span class="brand-text font-weight-light">SA-CAT</span>
        </a>
        <div class="sidebar">
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column">
                    <li class="nav-item">
                        <a href="dashboard.php" class="nav-link">
                            <i class="nav-icon fas fa-home"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="cadastro_municipios.php" class="nav-link active">
                            <i class="nav-icon fas fa-city"></i>
                            <p>Cadastro de Municípios</p>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Cadastro de Municípios</h1>
                    </div>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="container-fluid">
                <form method="POST">
                    <input type="hidden" name="acao" value="cadastrar">
                    <div class="mb-3">
                        <label for="nome_municipio" class="form-label">Nome do Município</label>
                        <input type="text" class="form-control" id="nome_municipio" name="nome_municipio" required>
                    </div>
                    <div class="mb-3">
                        <label for="populacao" class="form-label">População</label>
                        <input type="number" class="form-control" id="populacao" name="populacao" required>
                    </div>
                    <div class="mb-3">
                        <label for="colegiado_id" class="form-label">Colegiado</label>
                        <select class="form-control" id="colegiado_id" name="colegiado_id" required>
                            <?php
                            $stmt = $conn->query("SELECT id, nome FROM colegiados");
                            while ($row = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
                                <option value="<?= $row['id'] ?>"><?= $row['nome'] ?></option>
                            <?php endwhile; ?>
                        </select>
                    </div>
                    <button type="submit" class="btn btn-primary">Cadastrar</button>
                </form>
                <hr>
                <h2>Municípios Cadastrados</h2>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>População</th>
                            <th>Colegiado</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php
                        $stmt = $conn->query("SELECT m.id, m.nome, m.qt_populacao_2022, c.nome AS colegiado FROM municipios m JOIN colegiados c ON m.colegiado_id = c.id");
                        while ($row = $stmt->fetch(PDO::FETCH_ASSOC)): ?>
                            <tr>
                                <td><?= $row['id'] ?></td>
                                <td><?= $row['nome'] ?></td>
                                <td><?= $row['qt_populacao_2022'] ?></td>
                                <td><?= $row['colegiado'] ?></td>
                                <td>
                                    <a href="editar_municipio.php?id=<?= $row['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                                    <a href="?excluir=<?= $row['id'] ?>" class="btn btn-danger btn-sm excluir" data-id="<?= $row['id'] ?>">Excluir</a>
                                </td>
                            </tr>
                        <?php endwhile; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <!-- Footer -->
    <footer class="main-footer text-center">
        <strong>&copy; <?= date('Y'); ?> SA-CAT</strong>
    </footer>
</div>

<script>
    // Mensagem de sucesso ou erro
    <?php if ($mensagem): ?>
        Swal.fire({
            icon: '<?= $tipo_mensagem ?>',
            title: '<?= $tipo_mensagem === "success" ? "Sucesso" : "Erro" ?>',
            text: '<?= $mensagem ?>'
        });
    <?php endif; ?>
</script>
</body>
</html>