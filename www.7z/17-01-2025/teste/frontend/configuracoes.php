<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['perfil'] !== 'administrador_sistema') {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Atualizar configurações
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $emailSuporte = $_POST['email_suporte'];
    $telefoneSuporte = $_POST['telefone_suporte'];

    $stmt = $conn->prepare("UPDATE configuracoes SET email_suporte = ?, telefone_suporte = ? WHERE id = 1");
    $stmt->execute([$emailSuporte, $telefoneSuporte]);

    header('Location: configuracoes.php?status=sucesso');
    exit;
}

// Obter configurações atuais
$config = $conn->query("SELECT email_suporte, telefone_suporte FROM configuracoes WHERE id = 1")->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurações Gerais</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Configurações Gerais</h1>
        <?php if (isset($_GET['status']) && $_GET['status'] === 'sucesso'): ?>
            <div class="alert alert-success">Configurações atualizadas com sucesso!</div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label for="email_suporte" class="form-label">E-mail de Suporte</label>
                <input type="email" id="email_suporte" name="email_suporte" class="form-control" value="<?= $config['email_suporte'] ?>" required>
            </div>
            <div class="mb-3">
                <label for="telefone_suporte" class="form-label">Telefone de Suporte</label>
                <input type="text" id="telefone_suporte" name="telefone_suporte" class="form-control" value="<?= $config['telefone_suporte'] ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Salvar</button>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
