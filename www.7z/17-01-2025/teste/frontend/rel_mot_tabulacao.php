<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

$filtros = [];
$params = [];

// Filtros de entrada
if (!empty($_GET['programa'])) {
    $filtros[] = "programa = ?";
    $params[] = $_GET['programa'];
}
if (!empty($_GET['data_inicio']) && !empty($_GET['data_fim'])) {
    $filtros[] = "DATE(data_inicio) BETWEEN ? AND ?";
    $params[] = $_GET['data_inicio'];
    $params[] = $_GET['data_fim'];
}

$where = $filtros ? "WHERE " . implode(" AND ", $filtros) : "";

// Dados do relatório por motivo de tabulação
$queryRelatorio = "
    SELECT
        a.programa,
        t.categoria,
        t.motivo AS motivo_tabulacao,
        MONTH(a.data_inicio) AS mes,
        COUNT(DISTINCT a.id) AS total_ligacoes
    FROM atendimentos a
    JOIN motivos_atendimento t ON a.motivo_id = t.id
    $where
    GROUP BY a.programa, t.categoria, t.motivo, MONTH(a.data_inicio)
    ORDER BY t.categoria, t.motivo
";
$stmt = $conn->prepare($queryRelatorio);
$stmt->execute($params);
$dadosRelatorio = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Organizar dados por meses e calcular totais
$dadosAgrupados = [];
$totaisPorMes = [];
$totalGeral = 0;

foreach ($dadosRelatorio as $row) {
    $programa = $row['programa'];
    $categoria = $row['categoria'];
    $motivo = $row['motivo_tabulacao'];
    $mes = $row['mes'];
    $total = $row['total_ligacoes'];

    $dadosAgrupados[$programa][$categoria][$motivo][$mes] = $total;
    $totaisPorMes[$mes] = ($totaisPorMes[$mes] ?? 0) + $total;
    $totalGeral += $total;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório por Motivo de Tabulação</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="container my-4">
        <h1>Relatório por Motivo de Tabulação</h1>
        <form method="GET" class="mb-4">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label for="programa" class="form-label">Programa</label>
                    <select id="programa" name="programa" class="form-select">
                        <option value="">Selecione o programa</option>
                        <!-- Adicione os programas do banco -->
                        <option value="Programa1">Programa 1</option>
                        <option value="Programa2">Programa 2</option>
                    </select>
                </div>
                <div class="col-md-4 mb-3">
                    <label for="data_inicio" class="form-label">Data Início</label>
                    <input type="date" id="data_inicio" name="data_inicio" class="form-control">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="data_fim" class="form-label">Data Fim</label>
                    <input type="date" id="data_fim" name="data_fim" class="form-control">
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Gerar Relatório</button>
        </form>

        <h3>Resumo</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>Programa</th>
                    <th>Categoria</th>
                    <th>Motivo Atendimento/Tabulação</th>
                    <?php foreach (array_keys($totaisPorMes) as $mes): ?>
                        <th><?= DateTime::createFromFormat('!m', $mes)->format('F') ?></th>
                    <?php endforeach; ?>
                    <th>Total Geral</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($dadosAgrupados as $programa => $categorias): ?>
                    <?php foreach ($categorias as $categoria => $motivos): ?>
                        <?php foreach ($motivos as $motivo => $meses): ?>
                            <tr>
                                <td><?= $programa ?></td>
                                <td><?= $categoria ?></td>
                                <td><?= $motivo ?></td>
                                <?php foreach (array_keys($totaisPorMes) as $mes): ?>
                                    <td><?= $meses[$mes] ?? 0 ?></td>
                                <?php endforeach; ?>
                                <td><?= array_sum($meses) ?></td>
                            </tr>
                        <?php endforeach; ?>
                    <?php endforeach; ?>
                <?php endforeach; ?>
            </tbody>
            <tfoot>
                <tr>
                    <th colspan="3">Total Geral</th>
                    <?php foreach ($totaisPorMes as $totalMes): ?>
                        <th><?= $totalMes ?></th>
                    <?php endforeach; ?>
                    <th><?= $totalGeral ?></th>
                </tr>
            </tfoot>
        </table>

        <div class="mt-4">
            <button class="btn btn-success">Exportar para PDF</button>
            <button class="btn btn-info">Exportar para Excel</button>
            <button class="btn btn-warning">Exportar para Word</button>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>