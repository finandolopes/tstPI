<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Filtros de entrada
$filtros = [];
$params = [];

if (!empty($_GET['programa'])) {
    $filtros[] = "a.programa = ?";
    $params[] = $_GET['programa'];
}
if (!empty($_GET['atendente'])) {
    $filtros[] = "u.nome LIKE ?";
    $params[] = "%" . $_GET['atendente'] . "%";
}
if (!empty($_GET['drs'])) {
    $filtros[] = "(ue.no_drs = ? OR us.no_drs = ?)";
    $params[] = $_GET['drs'];
    $params[] = $_GET['drs'];
}
if (!empty($_GET['mes_ano'])) {
    $filtros[] = "DATE_FORMAT(a.data_inicio, '%Y-%m') = ?";
    $params[] = $_GET['mes_ano'];
}
if (!empty($_GET['motivo'])) {
    $filtros[] = "m.nome = ?";
    $params[] = $_GET['motivo'];
}
if (!empty($_GET['recurso'])) {
    $filtros[] = "r.nome = ?";
    $params[] = $_GET['recurso'];
}

$where = $filtros ? "WHERE " . implode(" AND ", $filtros) : "";

// Query para o relatório geral
$queryRelatorio = "
    SELECT 
        a.id AS chamado_id,
        a.codigo_paciente,
        a.data_inicio,
        u.nome AS atendente,
        a.programa,
        r.nome AS recurso,
        ue.no_drs AS drs_executante,
        ue.no_municipio AS municipio_executante,
        ue.nome AS unidade_executante,
        m.nome AS motivo,
        us.no_drs AS drs_solicitante,
        us.no_municipio AS municipio_solicitante
    FROM atendimentos a
    JOIN usuarios u ON a.usuario_id = u.id
    JOIN recursos r ON a.recurso_id = r.id
    JOIN motivos_atendimento m ON a.motivo_id = m.id
    LEFT JOIN unidades ue ON a.unidade_executante = ue.id
    LEFT JOIN unidades us ON a.unidade_solicitante = us.id
    $where
    ORDER BY a.data_inicio DESC
";
$stmt = $conn->prepare($queryRelatorio);
$stmt->execute($params);
$relatorio = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório Geral</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Relatório Geral</h1>
        <form method="GET" class="mb-4">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label for="programa" class="form-label">Programa</label>
                    <input type="text" id="programa" name="programa" class="form-control" value="<?= htmlspecialchars($_GET['programa'] ?? '') ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="atendente" class="form-label">Atendente</label>
                    <input type="text" id="atendente" name="atendente" class="form-control" value="<?= htmlspecialchars($_GET['atendente'] ?? '') ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="drs" class="form-label">DRS</label>
                    <input type="text" id="drs" name="drs" class="form-control" value="<?= htmlspecialchars($_GET['drs'] ?? '') ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="mes_ano" class="form-label">Mês/Ano</label>
                    <input type="month" id="mes_ano" name="mes_ano" class="form-control" value="<?= htmlspecialchars($_GET['mes_ano'] ?? '') ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="motivo" class="form-label">Motivo do Atendimento</label>
                    <input type="text" id="motivo" name="motivo" class="form-control" value="<?= htmlspecialchars($_GET['motivo'] ?? '') ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="recurso" class="form-label">Recurso</label>
                    <input type="text" id="recurso" name="recurso" class="form-control" value="<?= htmlspecialchars($_GET['recurso'] ?? '') ?>">
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Gerar Relatório</button>
        </form>

        <h3>Dados do Relatório</h3>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID Chamado</th>
                    <th>Código Paciente</th>
                    <th>Data/Hora Início</th>
                    <th>Atendente</th>
                    <th>Programa</th>
                    <th>Recurso</th>
                    <th>DRS Executante</th>
                    <th>Município Executante</th>
                    <th>Unidade Executante</th>
                    <th>Motivo</th>
                    <th>DRS Solicitante</th>
                    <th>Município Solicitante</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($relatorio): ?>
                    <?php foreach ($relatorio as $row): ?>
                        <tr>
                            <td><?= $row['chamado_id'] ?></td>
                            <td><?= $row['codigo_paciente'] ?></td>
                            <td><?= $row['data_inicio'] ?></td>
                            <td><?= $row['atendente'] ?></td>
                            <td><?= $row['programa'] ?></td>
                            <td><?= $row['recurso'] ?></td>
                            <td><?= $row['drs_executante'] ?></td>
                            <td><?= $row['municipio_executante'] ?></td>
                            <td><?= $row['unidade_executante'] ?></td>
                            <td><?= $row['motivo'] ?></td>
                            <td><?= $row['drs_solicitante'] ?></td>
                            <td><?= $row['municipio_solicitante'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="12" class="text-center">Nenhum dado encontrado.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>

        <div class="mt-4">
            <button class="btn btn-success">Exportar para PDF</button>
            <button class="btn btn-info">Exportar para Excel</button>
            <button class="btn btn-warning">Exportar para Word</button>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>