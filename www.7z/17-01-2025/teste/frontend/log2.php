<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['perfil'] !== 'administrador_sistema') {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Filtros
$whereClauses = [];
$params = [];

if (!empty($_GET['usuario'])) {
    $whereClauses[] = "u.nome LIKE ?";
    $params[] = "%" . $_GET['usuario'] . "%";
}

if (!empty($_GET['acao'])) {
    $whereClauses[] = "l.acao = ?";
    $params[] = $_GET['acao'];
}

if (!empty($_GET['tabela'])) {
    $whereClauses[] = "l.tabela = ?";
    $params[] = $_GET['tabela'];
}

if (!empty($_GET['data_inicio']) && !empty($_GET['data_fim'])) {
    $whereClauses[] = "DATE(l.data_hora) BETWEEN ? AND ?";
    $params[] = $_GET['data_inicio'];
    $params[] = $_GET['data_fim'];
}

$where = $whereClauses ? "WHERE " . implode(" AND ", $whereClauses) : "";

$query = "
    SELECT l.data_hora, u.nome AS usuario, l.acao, l.tabela, l.registro_id, l.detalhes
    FROM logs l
    JOIN usuarios u ON l.usuario_id = u.id
    $where
    ORDER BY l.data_hora DESC
";

$stmt = $conn->prepare($query);
$stmt->execute($params);
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Exportação lógica
if (isset($_GET['exportar'])) {
    $tipo = $_GET['exportar'];
    include "exportar_logs.php";
    exportar_logs($logs, $tipo);
    exit;
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logs do Sistema</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
    <!-- Navbar -->
    <?php include 'navbar.php'; ?>

    <!-- Sidebar -->
    <?php include 'sidebar.php'; ?>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <h1 class="m-0">Logs do Sistema</h1>
            </div>
        </div>
        <div class="content">
            <div class="container-fluid">
                <!-- Filtros -->
                <form method="GET" class="mb-4">
                    <div class="row">
                        <div class="col-md-3 mb-3">
                            <label for="usuario" class="form-label">Usuário</label>
                            <input type="text" id="usuario" name="usuario" class="form-control" value="<?= htmlspecialchars($_GET['usuario'] ?? '') ?>">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="acao" class="form-label">Ação</label>
                            <select id="acao" name="acao" class="form-select">
                                <option value="">Selecione</option>
                                <option value="criar" <?= (isset($_GET['acao']) && $_GET['acao'] === 'criar') ? 'selected' : '' ?>>Criar</option>
                                <option value="editar" <?= (isset($_GET['acao']) && $_GET['acao'] === 'editar') ? 'selected' : '' ?>>Editar</option>
                                <option value="excluir" <?= (isset($_GET['acao']) && $_GET['acao'] === 'excluir') ? 'selected' : '' ?>>Excluir</option>
                            </select>
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="tabela" class="form-label">Tabela</label>
                            <input type="text" id="tabela" name="tabela" class="form-control" value="<?= htmlspecialchars($_GET['tabela'] ?? '') ?>">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="data_inicio" class="form-label">Data Início</label>
                            <input type="date" id="data_inicio" name="data_inicio" class="form-control" value="<?= htmlspecialchars($_GET['data_inicio'] ?? '') ?>">
                        </div>
                        <div class="col-md-3 mb-3">
                            <label for="data_fim" class="form-label">Data Fim</label>
                            <input type="date" id="data_fim" name="data_fim" class="form-control" value="<?= htmlspecialchars($_GET['data_fim'] ?? '') ?>">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Filtrar</button>
                </form>

                <!-- Tabela de Logs -->
                <div class="card">
                    <div class="card-header">
                        <h3 class="card-title">Resultados dos Logs</h3>
                        <div class="card-tools">
                            <a href="?<?= http_build_query(array_merge($_GET, ['exportar' => 'pdf'])) ?>" class="btn btn-danger btn-sm"><i class="fas fa-file-pdf"></i> PDF</a>
                            <a href="?<?= http_build_query(array_merge($_GET, ['exportar' => 'excel'])) ?>" class="btn btn-success btn-sm"><i class="fas fa-file-excel"></i> Excel</a>
                            <a href="?<?= http_build_query(array_merge($_GET, ['exportar' => 'word'])) ?>" class="btn btn-primary btn-sm"><i class="fas fa-file-word"></i> Word</a>
                        </div>
                    </div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Data e Hora</th>
                                    <th>Usuário</th>
                                    <th>Ação</th>
                                    <th>Tabela</th>
                                    <th>Registro ID</th>
                                    <th>Detalhes</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php if ($logs): ?>
                                    <?php foreach ($logs as $log): ?>
                                        <tr>
                                            <td><?= $log['data_hora'] ?></td>
                                            <td><?= $log['usuario'] ?></td>
                                            <td><?= ucfirst($log['acao']) ?></td>
                                            <td><?= $log['tabela'] ?></td>
                                            <td><?= $log['registro_id'] ?></td>
                                            <td><?= $log['detalhes'] ?></td>
                                        </tr>
                                    <?php endforeach; ?>
                                <?php else: ?>
                                    <tr>
                                        <td colspan="6" class="text-center">Nenhum log encontrado.</td>
                                    </tr>
                                <?php endif; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include 'footer.php'; ?>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>