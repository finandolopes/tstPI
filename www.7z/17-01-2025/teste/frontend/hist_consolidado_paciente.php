<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Filtros de busca
$filtros = [
    'codigo_paciente' => $_GET['codigo_paciente'] ?? null,
    'nome_paciente' => $_GET['nome_paciente'] ?? null,
];

// Construção da query dinâmica
$query = "
    SELECT a.id, a.codigo_paciente, a.data_inicio, a.status, m.nome AS motivo, u.nome AS unidade_executante, at.nome AS atendente
    FROM atendimentos a
    LEFT JOIN motivos_atendimento m ON a.motivo_id = m.id
    LEFT JOIN unidades u ON a.unidade_executante = u.nome
    LEFT JOIN usuarios at ON a.usuario_id = at.id
    WHERE 1=1
";
$params = [];

if ($filtros['codigo_paciente']) {
    $query .= " AND a.codigo_paciente = ?";
    $params[] = $filtros['codigo_paciente'];
}

if ($filtros['nome_paciente']) {
    $query .= " AND a.codigo_paciente IN (
        SELECT codigo_paciente FROM atendimentos WHERE descricao LIKE ?
    )";
    $params[] = "%" . $filtros['nome_paciente'] . "%";
}

$query .= " ORDER BY a.data_inicio DESC";
$stmt = $conn->prepare($query);
$stmt->execute($params);
$historico = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Histórico Consolidado por Paciente</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
    <!-- Navbar -->
    <?php include 'includes/navbar.php'; ?>
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>

    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Histórico Consolidado por Paciente</h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                <!-- Filtros -->
                <form method="GET" class="mb-4">
                    <div class="row">
                        <div class="col-md-6">
                            <label for="codigo_paciente" class="form-label">Código do Paciente</label>
                            <input type="text" name="codigo_paciente" id="codigo_paciente" class="form-control" value="<?= htmlspecialchars($filtros['codigo_paciente'] ?? '') ?>">
                        </div>
                        <div class="col-md-6">
                            <label for="nome_paciente" class="form-label">Nome do Paciente</label>
                            <input type="text" name="nome_paciente" id="nome_paciente" class="form-control" value="<?= htmlspecialchars($filtros['nome_paciente'] ?? '') ?>">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary mt-3 w-100">Buscar Histórico</button>
                </form>

                <!-- Histórico -->
                <?php if (!empty($historico)): ?>
                    <div class="d-flex justify-content-end mb-2">
                        <a href="exportar_historico.php?<?= http_build_query($filtros) ?>&format=pdf" class="btn btn-danger btn-sm">Exportar PDF</a>
                        <a href="exportar_historico.php?<?= http_build_query($filtros) ?>&format=excel" class="btn btn-success btn-sm">Exportar Excel</a>
                        <a href="exportar_historico.php?<?= http_build_query($filtros) ?>&format=word" class="btn btn-primary btn-sm">Exportar Word</a>
                    </div>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Código Paciente</th>
                                <th>Data Início</th>
                                <th>Motivo</th>
                                <th>Unidade Executante</th>
                                <th>Atendente</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($historico as $atendimento): ?>
                                <tr>
                                    <td><?= $atendimento['id'] ?></td>
                                    <td><?= $atendimento['codigo_paciente'] ?></td>
                                    <td><?= $atendimento['data_inicio'] ?></td>
                                    <td><?= $atendimento['motivo'] ?></td>
                                    <td><?= $atendimento['unidade_executante'] ?></td>
                                    <td><?= $atendimento['atendente'] ?></td>
                                    <td><?= $atendimento['status'] ?></td>
                                    <td>
                                        <a href="visualizar_atendimento.php?id=<?= $atendimento['id'] ?>" class="btn btn-info btn-sm">Visualizar</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="alert alert-info">Nenhum histórico encontrado para os filtros selecionados.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>