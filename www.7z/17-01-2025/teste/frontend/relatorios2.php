<?php
session_start();
if (!isset($_SESSION['usuario_id']) || in_array($_SESSION['perfil'], ['atendente'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Filtros para relatórios
$whereClauses = [];
$params = [];

if (!empty($_GET['data_inicio']) && !empty($_GET['data_fim'])) {
    $whereClauses[] = "DATE(a.data_inicio) BETWEEN ? AND ?";
    $params[] = $_GET['data_inicio'];
    $params[] = $_GET['data_fim'];
}
if (!empty($_GET['status'])) {
    $whereClauses[] = "a.status = ?";
    $params[] = $_GET['status'];
}
if (!empty($_GET['usuario'])) {
    $whereClauses[] = "u.nome LIKE ?";
    $params[] = "%" . $_GET['usuario'] . "%";
}

$where = $whereClauses ? "WHERE " . implode(" AND ", $whereClauses) : "";

$query = "
    SELECT a.id, a.data_inicio, a.data_fim, a.status, u.nome AS atendente, o.descricao AS origem
    FROM atendimentos a
    JOIN usuarios u ON a.atendente_id = u.id
    JOIN origens o ON a.origem_id = o.id
    $where
    ORDER BY a.data_inicio DESC
";
$stmt = $conn->prepare($query);
$stmt->execute($params);
$atendimentos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios Avançados</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Relatórios Avançados</h1>
        <form method="GET" class="mb-4">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label for="data_inicio" class="form-label">Período Início</label>
                    <input type="date" id="data_inicio" name="data_inicio" class="form-control" value="<?= htmlspecialchars($_GET['data_inicio'] ?? '') ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="data_fim" class="form-label">Período Fim</label>
                    <input type="date" id="data_fim" name="data_fim" class="form-control" value="<?= htmlspecialchars($_GET['data_fim'] ?? '') ?>">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="status" class="form-label">Status</label>
                    <select id="status" name="status" class="form-select">
                        <option value="">Todos</option>
                        <option value="aberto" <?= (isset($_GET['status']) && $_GET['status'] === 'aberto') ? 'selected' : '' ?>>Aberto</option>
                        <option value="finalizado" <?= (isset($_GET['status']) && $_GET['status'] === 'finalizado') ? 'selected' : '' ?>>Finalizado</option>
                    </select>
                </div>
                <div class="col-md-4 mb-3">
                    <label for="usuario" class="form-label">Atendente</label>
                    <input type="text" id="usuario" name="usuario" class="form-control" value="<?= htmlspecialchars($_GET['usuario'] ?? '') ?>">
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Gerar Relatório</button>
        </form>

        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Data Início</th>
                    <th>Data Fim</th>
                    <th>Atendente</th>
                    <th>Origem</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php if ($atendimentos): ?>
                    <?php foreach ($atendimentos as $atendimento): ?>
                        <tr>
                            <td><?= $atendimento['id'] ?></td>
                            <td><?= $atendimento['data_inicio'] ?></td>
                            <td><?= $atendimento['data_fim'] ?? 'N/A' ?></td>
                            <td><?= $atendimento['atendente'] ?></td>
                            <td><?= $atendimento['origem'] ?></td>
                            <td><?= ucfirst($atendimento['status']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                <?php else: ?>
                    <tr>
                        <td colspan="6" class="text-center">Nenhum registro encontrado.</td>
                    </tr>
                <?php endif; ?>
            </tbody>
        </table>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
