<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Obter módulos disponíveis para o perfil do usuário logado
$perfil_id = $_SESSION['perfil_id'];
$stmtModulos = $conn->prepare("
    SELECT m.nome, m.caminho
    FROM perfil_modulos pm
    JOIN modulos m ON pm.modulo_id = m.id
    WHERE pm.perfil_id = ?
");
$stmtModulos->execute([$perfil_id]);
$modulos = $stmtModulos->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard Customizado</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Dashboard Customizado</h1>
        <div class="row">
            <?php foreach ($modulos as $modulo): ?>
                <div class="col-lg-3 col-md-4 col-sm-6 mb-3">
                    <div class="card">
                        <div class="card-body text-center">
                            <h5 class="card-title"><?= $modulo['nome'] ?></h5>
                            <a href="<?= $modulo['caminho'] ?>" class="btn btn-primary">Acessar</a>
                        </div>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
