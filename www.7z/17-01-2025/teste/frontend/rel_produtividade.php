<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Processar filtro
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $regiao = $_POST['regiao'] ?? null;
    $drs = $_POST['drs'] ?? null;
    $municipio = $_POST['municipio'] ?? null;
    $atendente = $_POST['atendente'] ?? null;
    $data_inicio = $_POST['data_inicio'] ?? null;
    $data_fim = $_POST['data_fim'] ?? null;

    $query = "
        SELECT r.nome AS regiao, d.nome AS drs, m.nome AS municipio, u.nome AS atendente, COUNT(a.id) AS total
        FROM atendimentos a
        JOIN regioes r ON r.id = a.regiao_id
        JOIN drs d ON d.id = a.drs_id
        JOIN municipios m ON m.id = a.municipio_id
        JOIN usuarios u ON u.id = a.usuario_id
        WHERE 1=1
    ";

    $params = [];
    if ($regiao) {
        $query .= " AND r.id = ?";
        $params[] = $regiao;
    }
    if ($drs) {
        $query .= " AND d.id = ?";
        $params[] = $drs;
    }
    if ($municipio) {
        $query .= " AND m.id = ?";
        $params[] = $municipio;
    }
    if ($atendente) {
        $query .= " AND u.id = ?";
        $params[] = $atendente;
    }
    if ($data_inicio && $data_fim) {
        $query .= " AND a.data_inicio BETWEEN ? AND ?";
        $params[] = $data_inicio;
        $params[] = $data_fim;
    }

    $query .= " GROUP BY r.nome, d.nome, m.nome, u.nome";
    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório de Produtividade</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body>
<div class="wrapper">
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <!-- Navbar content -->
    </nav>
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <!-- Sidebar content -->
    </aside>
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <h1>Relatório de Produtividade por Região</h1>
            </div>
        </div>
        <div class="content">
            <div class="container-fluid">
                <form method="POST">
                    <div class="row">
                        <div class="col-md-3">
                            <label for="regiao">Região</label>
                            <select id="regiao" name="regiao" class="form-control">
                                <!-- Preencher opções do BD -->
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="drs">DRS</label>
                            <select id="drs" name="drs" class="form-control">
                                <!-- Preencher opções do BD -->
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="municipio">Município</label>
                            <select id="municipio" name="municipio" class="form-control">
                                <!-- Preencher opções do BD -->
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="atendente">Atendente</label>
                            <select id="atendente" name="atendente" class="form-control">
                                <!-- Preencher opções do BD -->
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="data_inicio">Data Início</label>
                            <input type="date" id="data_inicio" name="data_inicio" class="form-control">
                        </div>
                        <div class="col-md-3">
                            <label for="data_fim">Data Fim</label>
                            <input type="date" id="data_fim" name="data_fim" class="form-control">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary mt-3">Gerar Relatório</button>
                </form>

                <hr>

                <?php if (!empty($resultados)): ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Região</th>
                                <th>DRS</th>
                                <th>Município</th>
                                <th>Atendente</th>
                                <th>Total de Atendimentos</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($resultados as $row): ?>
                                <tr>
                                    <td><?= $row['regiao'] ?></td>
                                    <td><?= $row['drs'] ?></td>
                                    <td><?= $row['municipio'] ?></td>
                                    <td><?= $row['atendente'] ?></td>
                                    <td><?= $row['total'] ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                    <div>
                        <a href="exportar-pdf.php" class="btn btn-danger">Exportar PDF</a>
                        <a href="exportar-excel.php" class="btn btn-success">Exportar Excel</a>
                        <a href="exportar-word.php" class="btn btn-primary">Exportar Word</a>
                    </div>
                <?php else: ?>
                    <p>Nenhum resultado encontrado.</p>
                <?php endif; ?>
            </div>
        </div>
    </div>
    <footer class="main-footer text-center">
        <strong>&copy; <?= date('Y') ?> SA-CAT</strong>
    </footer>
</div>
</body>
</html>