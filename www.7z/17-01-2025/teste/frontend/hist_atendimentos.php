<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

$historico = [];
$mensagemErro = null;

try {
    // Obter histórico de atendimentos
    $stmt = $conn->prepare("
        SELECT a.id, u.nome AS atendente, a.data_inicio, a.data_fim, a.status, m.nome AS motivo, o.nome AS origem
        FROM atendimentos a
        JOIN usuarios u ON a.atendente_id = u.id
        JOIN motivos m ON a.motivo_id = m.id
        JOIN origens o ON a.origem_id = o.id
        ORDER BY a.data_inicio DESC
    ");
    $stmt->execute();
    $historico = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $mensagemErro = "Erro ao carregar o histórico de atendimentos: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Histórico de Atendimentos</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
            <li class="nav-item">
                <span class="nav-link">Bem-vindo, <strong><?= htmlspecialchars($_SESSION['usuario_nome']); ?></strong></span>
            </li>
        </ul>
    </nav>

    <!-- Sidebar -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <a href="#" class="brand-link">
            <img src="assets/img/CROSS-.png" alt="Logo" class="brand-image img-circle elevation-3">
            <span class="brand-text font-weight-light">SA-CAT</span>
        </a>
        <div class="sidebar">
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column">
                    <li class="nav-item">
                        <a href="dashboard.php" class="nav-link">
                            <i class="nav-icon fas fa-home"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="historico.php" class="nav-link active">
                            <i class="nav-icon fas fa-history"></i>
                            <p>Histórico de Atendimentos</p>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Histórico de Atendimentos</h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                <?php if ($mensagemErro): ?>
                    <script>
                        Swal.fire('Erro', '<?= $mensagemErro ?>', 'error');
                    </script>
                <?php endif; ?>

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Atendente</th>
                                <th>Data Início</th>
                                <th>Data Fim</th>
                                <th>Status</th>
                                <th>Motivo</th>
                                <th>Origem</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($historico): ?>
                                <?php foreach ($historico as $atendimento): ?>
                                    <tr>
                                        <td><?= $atendimento['id'] ?></td>
                                        <td><?= $atendimento['atendente'] ?></td>
                                        <td><?= $atendimento['data_inicio'] ?></td>
                                        <td><?= $atendimento['data_fim'] ?></td>
                                        <td><?= ucfirst($atendimento['status']) ?></td>
                                        <td><?= $atendimento['motivo'] ?></td>
                                        <td><?= $atendimento['origem'] ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="7" class="text-center">Nenhum atendimento encontrado.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="main-footer text-center">
        <strong>&copy; <?= date('Y') ?> SA-CAT</strong>
    </footer>
</div>
</body>
</html>
