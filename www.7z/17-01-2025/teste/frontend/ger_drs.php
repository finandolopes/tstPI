<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['perfil'] !== 'administrador_sistema') {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Obter lista de DRS
$stmtDrs = $conn->query("SELECT id, nome FROM drs");
$drsList = $stmtDrs->fetchAll(PDO::FETCH_ASSOC);

// Lógica de exclusão
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $stmtDelete = $conn->prepare("DELETE FROM drs WHERE id = ?");
    $stmtDelete->execute([$delete_id]);
    header('Location: gerenciar-drs.php?status=excluido');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar DRS</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Gerenciar DRS</h1>
        <?php if (isset($_GET['status']) && $_GET['status'] === 'excluido'): ?>
            <div class="alert alert-success">DRS excluído com sucesso!</div>
        <?php endif; ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($drsList as $drs): ?>
                    <tr>
                        <td><?= $drs['id'] ?></td>
                        <td><?= $drs['nome'] ?></td>
                        <td>
                            <a href="editar-drs.php?id=<?= $drs['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                            <a href="gerenciar-drs.php?delete_id=<?= $drs['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja excluir este DRS?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <a href="novo-drs.php" class="btn btn-primary">+ Novo DRS</a>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>