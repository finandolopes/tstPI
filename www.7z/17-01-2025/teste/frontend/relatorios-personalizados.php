<?php
session_start();
if (!isset($_SESSION['usuario_id']) || !in_array($_SESSION['perfil'], ['coordenador', 'administrador', 'administrador_sistema'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Processar o formulário de relatórios
$relatorio = [];
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $filtro = $_POST['filtro'];
    $periodoInicio = $_POST['periodo_inicio'];
    $periodoFim = $_POST['periodo_fim'];

    // Consulta ao banco de dados baseada no filtro selecionado
    $query = "";
    switch ($filtro) {
        case 'produtividade_atendente':
            $query = "
                SELECT u.nome AS atendente, COUNT(a.id) AS total_atendimentos
                FROM atendimentos a
                JOIN usuarios u ON a.atendente_id = u.id
                WHERE a.data_inicio BETWEEN ? AND ?
                GROUP BY u.nome
                ORDER BY total_atendimentos DESC";
            break;
        case 'atendimentos_drs':
            $query = "
                SELECT d.nome AS drs, COUNT(a.id) AS total_atendimentos
                FROM atendimentos a
                JOIN drs d ON a.drs_id = d.id
                WHERE a.data_inicio BETWEEN ? AND ?
                GROUP BY d.nome
                ORDER BY total_atendimentos DESC";
            break;
        case 'status_atendimentos':
            $query = "
                SELECT a.status, COUNT(a.id) AS total
                FROM atendimentos a
                WHERE a.data_inicio BETWEEN ? AND ?
                GROUP BY a.status
                ORDER BY total DESC";
            break;
    }

    $stmt = $conn->prepare($query);
    $stmt->execute([$periodoInicio, $periodoFim]);
    $relatorio = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios Personalizados</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Relatórios Personalizados</h1>
        <form method="POST" class="mb-4">
            <div class="mb-3">
                <label for="filtro" class="form-label">Tipo de Relatório</label>
                <select id="filtro" name="filtro" class="form-select" required>
                    <option value="produtividade_atendente">Produtividade por Atendente</option>
                    <option value="atendimentos_drs">Atendimentos por DRS</option>
                    <option value="status_atendimentos">Status dos Atendimentos</option>
                </select>
            </div>
            <div class="row">
                <div class="col-md-6 mb-3">
                    <label for="periodo_inicio" class="form-label">Período Início</label>
                    <input type="date" id="periodo_inicio" name="periodo_inicio" class="form-control" required>
                </div>
                <div class="col-md-6 mb-3">
                    <label for="periodo_fim" class="form-label">Período Fim</label>
                    <input type="date" id="periodo_fim" name="periodo_fim" class="form-control" required>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Gerar Relatório</button>
        </form>

        <?php if (!empty($relatorio)): ?>
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <?php foreach (array_keys($relatorio[0]) as $coluna): ?>
                            <th><?= ucfirst(str_replace('_', ' ', $coluna)) ?></th>
                        <?php endforeach; ?>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($relatorio as $linha): ?>
                        <tr>
                            <?php foreach ($linha as $valor): ?>
                                <td><?= $valor ?></td>
                            <?php endforeach; ?>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        <?php endif; ?>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
