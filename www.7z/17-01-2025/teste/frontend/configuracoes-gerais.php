<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['perfil'] !== 'administrador_sistema') {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Atualizar configurações gerais
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $titulo_sistema = $_POST['titulo_sistema'];
    $email_suporte = $_POST['email_suporte'];

    $stmt = $conn->prepare("UPDATE configuracoes SET titulo_sistema = ?, email_suporte = ? WHERE id = 1");
    $stmt->execute([$titulo_sistema, $email_suporte]);

    header('Location: configuracoes-gerais.php?status=sucesso');
    exit;
}

// Obter configurações atuais
$stmt = $conn->query("SELECT * FROM configuracoes WHERE id = 1");
$configuracoes = $stmt->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurações Gerais</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Configurações Gerais do Sistema</h1>
        <?php if (isset($_GET['status']) && $_GET['status'] === 'sucesso'): ?>
            <div class="alert alert-success">Configurações atualizadas com sucesso!</div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label for="titulo_sistema" class="form-label">Título do Sistema</label>
                <input type="text" id="titulo_sistema" name="titulo_sistema" class="form-control" value="<?= htmlspecialchars($configuracoes['titulo_sistema']) ?>" required>
            </div>
            <div class="mb-3">
                <label for="email_suporte" class="form-label">E-mail de Suporte</label>
                <input type="email" id="email_suporte" name="email_suporte" class="form-control" value="<?= htmlspecialchars($configuracoes['email_suporte']) ?>" required>
            </div>
            <button type="submit" class="btn btn-primary">Salvar Configurações</button>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
