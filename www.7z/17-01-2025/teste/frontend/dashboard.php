<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Sistema de Atendimento</title>
    <link href="favicon.ico" type="image/ico" rel="icon">
    <link href="favicon.ico" type="image/x-icon" rel="shortcut icon">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>  
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma/css/bulma.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">
    <!-- Navbar -->

    <body class="hold-transition sidebar-mini layout-fixed">
        <div class="wrapper">
        
            <!-- Navbar -->
            <nav class="main-header navbar navbar-expand navbar-white navbar-light">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
                    </li>
                    <li class="nav-item">
                        <span class="nav-link">Bem-vindo, <strong>Usuário</strong></span>
                    </li>
                </ul>
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="#">Minha Conta</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php">Sair</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>    
    
    <!-- Sidebar -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <a href="#" class="brand-link">
            <img src="../assets/img/CROSS-.png" alt="Logo" class="brand-image img-circle elevation-3">
            <span class="brand-text font-weight-light">SA-CAT</span>
        </a>
        <div class="sidebar">
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column">
                    <li class="nav-item">
                        <a href="dashboard.php" class="nav-link">
                            <i class="nav-icon fas fa-home"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>                    
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Dashboard</h1>
                    </div>
                </div>
            </div>
        </div>

        <!-- Content -->
        <div class="content">
            <div class="container-fluid">
                <div class="row">
                    <!-- Cards with dynamic data -->
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-info">
                            <div class="inner">
                                <h3><?= $totalAtendimentos ?></h3>
                                <p>Atendimentos Realizados</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-headset"></i>
                            </div>
                            <a href="#" class="small-box-footer" data-bs-toggle="modal" data-bs-target="#modalRealizados">Mais informações <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-success">
                            <div class="inner">
                                <h3><?= $atendimentosFechados ?></h3>
                                <p>Atendimentos Finalizados</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-check"></i>
                            </div>
                            <a href="#" class="small-box-footer" data-bs-toggle="modal" data-bs-target="#modalFinalizados">Mais informações <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-warning">
                            <div class="inner">
                                <h3><?= $atendimentosAbertos ?></h3>
                                <p>Atendimentos Abertos</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-exclamation-circle"></i>
                            </div>
                            <a href="#" class="small-box-footer" data-bs-toggle="modal" data-bs-target="#modalAbertos">Mais informações <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                    <div class="col-lg-3 col-6">
                        <div class="small-box bg-danger">
                            <div class="inner">
                                <h3><?= $atendimentosPendentes ?></h3>
                                <p>Atendimentos Pendentes</p>
                            </div>
                            <div class="icon">
                                <i class="fas fa-times-circle"></i>
                            </div>
                            <a href="#" class="small-box-footer" data-bs-toggle="modal" data-bs-target="#modalPendentes">Mais informações <i class="fas fa-arrow-circle-right"></i></a>
                        </div>
                    </div>
                </div>

                <!-- Top 10 Atendentes -->
                <div class="row">
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Top 10 Atendentes</h3>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Atendente</th>
                                            <th>Total Atendimentos</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($topAtendentes as $atendente): ?>
                                            <tr>
                                                <td><?= $atendente['nome'] ?></td>
                                                <td><?= $atendente['total_atendimentos'] ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
<!-- Atendimentos por DRS -->
                    <div class="col-lg-6">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Atendimentos por DRS</h3>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>DRS</th>
                                            <th>Total Atendimentos</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($atendimentosPorDRS as $drs): ?>
                                            <tr>
                                                <td><?= $drs['drs'] ?></td>
                                                <td><?= $drs['total_atendimentos'] ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Atendimentos por Município -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Atendimentos por Município</h3>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>Município</th>
                                            <th>Total Atendimentos</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($atendimentosPorMunicipio as $municipio): ?>
                                            <tr>
                                                <td><?= $municipio['municipio'] ?></td>
                                                <td><?= $municipio['total_atendimentos'] ?></td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Últimos 10 Atendimentos -->
                <div class="row">
                    <div class="col-lg-12">
                        <div class="card">
                            <div class="card-header">
                                <h3 class="card-title">Últimos 10 Atendimentos</h3>
                            </div>
                            <div class="card-body">
                                <table class="table table-bordered">
                                    <thead>
                                        <tr>
                                            <th>ID</th>
                                            <th>Início</th>
                                            <th>Atendente</th>
                                            <th>Origem</th>
                                            <th>Status</th>
                                            <th>Ações</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php foreach ($ultimosAtendimentos as $atendimento): ?>
                                            <tr>
                                                <td><?= $atendimento['id'] ?></td>
                                                <td><?= $atendimento['data_inicio'] ?></td>
                                                <td><?= $atendimento['atendente'] ?></td>
                                                <td><?= $atendimento['origem'] ?></td>
                                                <td><?= $atendimento['status'] ?></td>
                                                <td>
                                                    <a href="#" class="btn btn-info btn-sm" title="Visualizar">
                                                        <i class="fas fa-eye"></i>
                                                    </a>
                                                    <a href="#" class="btn btn-warning btn-sm" title="Editar">
                                                        <i class="fas fa-edit"></i>
                                                    </a>
                                                    <a href="#" class="btn btn-danger btn-sm" title="Excluir">
                                                        <i class="fas fa-trash"></i>
                                                    </a>
                                                </td>
                                            </tr>
                                        <?php endforeach; ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="main-footer text-center">
        <div class="float-right d-none d-sm-block">
            <b>Versão</b> 0.0.1
        </div>
        <p>CROSS - CENTRAL DE REGULAÇÃO DE OFERTAS DE SERVIÇOS DE SAÚDE 
        &copy; <span id="current-year"></span> - Sistema de Atendimento</p>
    </footer>
</div>

<!-- Modal: Atendimentos Realizados -->
<div class="modal fade" id="modalRealizados" tabindex="-1" aria-labelledby="modalRealizadosLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="modalRealizadosLabel">Atendimentos Realizados</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body">
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Início</th>
                            <th>Atendente</th>
                            <th>Origem</th>
                            <th>Status</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($ultimosAtendimentos as $atendimento): ?>
                            <tr>
                                <td><?= $atendimento['id'] ?></td>
                                <td><?= $atendimento['data_inicio'] ?></td>
                                <td><?= $atendimento['atendente'] ?></td>
                                <td><?= $atendimento['origem'] ?></td>
                                <td><?= $atendimento['status'] ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script>
    // Alternar Tema do Sidebar
    document.getElementById('theme-selector').addEventListener('change', function () {
        const sidebar = document.querySelector('.main-sidebar');
        sidebar.classList.toggle('sidebar-blue', this.value === 'blue');
        sidebar.classList.toggle('sidebar-darkblue', this.value === 'darkblue');
    });

    // Alternar Sidebar
    document.getElementById('toggle-sidebar').addEventListener('click', function () {
        const sidebar = document.getElementById('sidebar');
        const mainContent = document.getElementById('main-content');
        sidebar.classList.toggle('retracted');
        mainContent.classList.toggle('retracted');
    });

    // Alternar visibilidade da senha
    document.getElementById('togglePassword').addEventListener('click', function () {
        const password = document.getElementById('password');
        const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
        password.setAttribute('type', type);
        this.querySelector('i').classList.toggle('fa-eye');
        this.querySelector('i').classList.toggle('fa-eye-slash');
    });

    document.getElementById('toggleConfirmPassword').addEventListener('click', function () {
        const confirmPassword = document.getElementById('confirmPassword');
        const type = confirmPassword.getAttribute('type') === 'password' ? 'text' : 'password';
        confirmPassword.setAttribute('type', type);
        this.querySelector('i').classList.toggle('fa-eye');
        this.querySelector('i').classList.toggle('fa-eye-slash');
    });

    // Salvar nova senha
    document.getElementById('userForm').addEventListener('submit', function (e) {
        e.preventDefault();
        // Lógica para salvar a nova senha
        alert('Senha alterada com sucesso!');
    });
</script>
</body>
</html>