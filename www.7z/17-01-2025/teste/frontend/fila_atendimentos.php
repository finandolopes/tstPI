<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Filtros de busca
$filtros = [
    'atendente' => $_GET['atendente'] ?? null,
    'status' => $_GET['status'] ?? null,
    'data_inicio' => $_GET['data_inicio'] ?? null,
    'data_fim' => $_GET['data_fim'] ?? null,
];

// Construção da query dinâmica
$query = "
    SELECT a.id, u.nome AS atendente, a.codigo_paciente, a.data_inicio, a.status
    FROM atendimentos a
    LEFT JOIN usuarios u ON a.usuario_id = u.id
    WHERE 1=1
";
$params = [];

if ($filtros['atendente']) {
    $query .= " AND u.nome LIKE ?";
    $params[] = "%" . $filtros['atendente'] . "%";
}
if ($filtros['status']) {
    $query .= " AND a.status = ?";
    $params[] = $filtros['status'];
}
if ($filtros['data_inicio'] && $filtros['data_fim']) {
    $query .= " AND DATE(a.data_inicio) BETWEEN ? AND ?";
    $params[] = $filtros['data_inicio'];
    $params[] = $filtros['data_fim'];
}

$query .= " ORDER BY a.data_inicio ASC";
$stmt = $conn->prepare($query);
$stmt->execute($params);
$atendimentos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fila de Atendimentos</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/dist/jquery.min.js"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
    <!-- Navbar -->
    <?php include 'includes/navbar.php'; ?>
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>

    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Fila de Atendimentos</h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                <!-- Filtros -->
                <form method="GET" class="mb-4">
                    <div class="row">
                        <div class="col-md-3">
                            <label for="atendente" class="form-label">Atendente</label>
                            <input type="text" name="atendente" id="atendente" class="form-control" value="<?= htmlspecialchars($filtros['atendente'] ?? '') ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="status" class="form-label">Status</label>
                            <select name="status" id="status" class="form-select">
                                <option value="">Todos</option>
                                <option value="Aberto" <?= ($filtros['status'] == 'Aberto') ? 'selected' : '' ?>>Aberto</option>
                                <option value="Pendente" <?= ($filtros['status'] == 'Pendente') ? 'selected' : '' ?>>Pendente</option>
                                <option value="Concluído" <?= ($filtros['status'] == 'Concluído') ? 'selected' : '' ?>>Concluído</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="data_inicio" class="form-label">Data Início</label>
                            <input type="date" name="data_inicio" id="data_inicio" class="form-control" value="<?= htmlspecialchars($filtros['data_inicio'] ?? '') ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="data_fim" class="form-label">Data Fim</label>
                            <input type="date" name="data_fim" id="data_fim" class="form-control" value="<?= htmlspecialchars($filtros['data_fim'] ?? '') ?>">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary mt-3 w-100">Filtrar Atendimentos</button>
                </form>

                <!-- Fila de Atendimentos -->
                <?php if (!empty($atendimentos)): ?>
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>ID</th>
                                <th>Paciente</th>
                                <th>Atendente</th>
                                <th>Data Início</th>
                                <th>Status</th>
                                <th>Ações</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($atendimentos as $atendimento): ?>
                                <tr>
                                    <td><?= $atendimento['id'] ?></td>
                                    <td><?= $atendimento['codigo_paciente'] ?></td>
                                    <td><?= $atendimento['atendente'] ?></td>
                                    <td><?= $atendimento['data_inicio'] ?></td>
                                    <td><?= $atendimento['status'] ?></td>
                                    <td>
                                        <a href="visualizar_atendimento.php?id=<?= $atendimento['id'] ?>" class="btn btn-info btn-sm">Visualizar</a>
                                        <a href="finalizar_atendimento.php?id=<?= $atendimento['id'] ?>" class="btn btn-success btn-sm">Finalizar</a>
                                        <a href="cancelar_atendimento.php?id=<?= $atendimento['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja cancelar este atendimento?')">Cancelar</a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>
                <?php else: ?>
                    <div class="alert alert-info">Nenhum atendimento encontrado para os filtros selecionados.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>