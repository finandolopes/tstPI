<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['perfil'] !== 'administrador_sistema') {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Obter lista de origens
$stmtOrigens = $conn->query("SELECT id, nome FROM origens_atendimento");
$origens = $stmtOrigens->fetchAll(PDO::FETCH_ASSOC);

// Lógica de exclusão
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $stmtDelete = $conn->prepare("DELETE FROM origens_atendimento WHERE id = ?");
    $stmtDelete->execute([$delete_id]);
    header('Location: gerenciar-origens.php?status=excluido');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Origens de Atendimento</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Gerenciar Origens de Atendimento</h1>
        <?php if (isset($_GET['status']) && $_GET['status'] === 'excluido'): ?>
            <div class="alert alert-success">Origem de Atendimento excluída com sucesso!</div>
        <?php endif; ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($origens as $origem): ?>
                    <tr>
                        <td><?= $origem['id'] ?></td>
                        <td><?= $origem['nome'] ?></td>
                        <td>
                            <a href="editar-origem.php?id=<?= $origem['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                            <a href="gerenciar-origens.php?delete_id=<?= $origem['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja excluir esta origem?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <a href="nova-origem.php" class="btn btn-primary">+ Nova Origem</a>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>