<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['perfil'] !== 'administrador_sistema') {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Capturar filtros
$filtros = [
    'usuario' => $_GET['usuario'] ?? null,
    'modulo' => $_GET['modulo'] ?? null,
    'acao' => $_GET['acao'] ?? null,
    'data_inicio' => $_GET['data_inicio'] ?? null,
    'data_fim' => $_GET['data_fim'] ?? null,
];

// Construir consulta dinâmica
$query = "
    SELECT l.data_hora, u.nome AS usuario, m.nome AS modulo, l.acao, l.detalhes
    FROM logs l
    JOIN usuarios u ON l.usuario_id = u.id
    JOIN modulos m ON l.modulo_id = m.id
    WHERE 1=1
";
$params = [];

if ($filtros['usuario']) {
    $query .= " AND u.nome LIKE ?";
    $params[] = "%" . $filtros['usuario'] . "%";
}
if ($filtros['modulo']) {
    $query .= " AND m.id = ?";
    $params[] = $filtros['modulo'];
}
if ($filtros['acao']) {
    $query .= " AND l.acao = ?";
    $params[] = $filtros['acao'];
}
if ($filtros['data_inicio'] && $filtros['data_fim']) {
    $query .= " AND DATE(l.data_hora) BETWEEN ? AND ?";
    $params[] = $filtros['data_inicio'];
    $params[] = $filtros['data_fim'];
}

$query .= " ORDER BY l.data_hora DESC";

$stmt = $conn->prepare($query);
$stmt->execute($params);
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logs Detalhados</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
    <!-- Navbar -->
    <?php include 'includes/navbar.php'; ?>
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>

    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Logs Detalhados de Ações</h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                <!-- Filtros -->
                <form method="GET" class="mb-4">
                    <div class="row">
                        <div class="col-md-3">
                            <label for="usuario" class="form-label">Usuário</label>
                            <input type="text" name="usuario" id="usuario" class="form-control" value="<?= htmlspecialchars($filtros['usuario'] ?? '') ?>">
                        </div>
                        <div class="col-md-3">
                            <label for="modulo" class="form-label">Módulo</label>
                            <select name="modulo" id="modulo" class="form-select">
                                <option value="">Todos</option>
                                <?php
                                $modulos = $conn->query("SELECT id, nome FROM modulos")->fetchAll(PDO::FETCH_ASSOC);
                                foreach ($modulos as $modulo) {
                                    $selected = ($filtros['modulo'] == $modulo['id']) ? 'selected' : '';
                                    echo "<option value='{$modulo['id']}' $selected>{$modulo['nome']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="acao" class="form-label">Ação</label>
                            <select name="acao" id="acao" class="form-select">
                                <option value="">Todas</option>
                                <option value="criar" <?= ($filtros['acao'] == 'criar') ? 'selected' : '' ?>>Criar</option>
                                <option value="editar" <?= ($filtros['acao'] == 'editar') ? 'selected' : '' ?>>Editar</option>
                                <option value="excluir" <?= ($filtros['acao'] == 'excluir') ? 'selected' : '' ?>>Excluir</option>
                                <option value="login" <?= ($filtros['acao'] == 'login') ? 'selected' : '' ?>>Login</option>
                                <option value="logout" <?= ($filtros['acao'] == 'logout') ? 'selected' : '' ?>>Logout</option>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="data_inicio" class="form-label">Data Início</label>
                            <input type="date" name="data_inicio" id="data_inicio" class="form-control" value="<?= htmlspecialchars($filtros['data_inicio'] ?? '') ?>">
                        </div>
                        <div class="col-md-3 mt-3">
                            <label for="data_fim" class="form-label">Data Fim</label>
                            <input type="date" name="data_fim" id="data_fim" class="form-control" value="<?= htmlspecialchars($filtros['data_fim'] ?? '') ?>">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary mt-4 w-100">Filtrar Logs</button>
                </form>

                <!-- Resultados -->
                <?php if (!empty($logs)): ?>
                    <table class="table table-bordered mt-4">
                        <thead>
                            <tr>
                                <th>Data e Hora</th>
                                <th>Usuário</th>
                                <th>Módulo</th>
                                <th>Ação</th>
                                <th>Detalhes</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($logs as $log): ?>
                                <tr>
                                    <td><?= $log['data_hora'] ?></td>
                                    <td><?= $log['usuario'] ?></td>
                                    <td><?= $log['modulo'] ?></td>
                                    <td><?= ucfirst($log['acao']) ?></td>
                                    <td><?= $log['detalhes'] ?></td>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <!-- Botões de Exportação -->
                    <div class="mt-4">
                        <a href="exportar_logs.php?formato=pdf" class="btn btn-danger">Exportar para PDF</a>
                        <a href="exportar_logs.php?formato=excel" class="btn btn-success">Exportar para Excel</a>
                        <a href="exportar_logs.php?formato=word" class="btn btn-primary">Exportar para Word</a>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">Nenhum log encontrado para os filtros selecionados.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>