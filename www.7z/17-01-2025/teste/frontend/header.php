<?php
session_start();

if (isset($_SESSION['last_activity']) && (time() - $_SESSION['last_activity'] > 900)) { // 15 minutos = 900 segundos
    session_unset(); // Remove as variáveis de sessão
    session_destroy(); // Encerra a sessão
    header("Location: index.php?message=session_expired");
    exit;
}

$_SESSION['last_activity'] = time(); // Atualiza o timestamp da última atividade
?>