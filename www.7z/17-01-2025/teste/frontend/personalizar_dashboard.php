<?php
session_start();
require 'backend/conexao.php';

// Verifica se o usuário tem permissão
if (!isset($_SESSION['usuario_id']) || !in_array($_SESSION['perfil'], ['Administrador', 'Coordenador Atendimento'])) {
    header('Location: index.php');
    exit;
}

// Obter lista de usuários para personalização
$usuarios = $conn->query("SELECT id, nome, email FROM usuarios WHERE perfil_id IN (3, 4, 5)")->fetchAll(PDO::FETCH_ASSOC);

// Salvar personalização
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario_id = $_POST['usuario_id'];
    $opcoes = json_encode($_POST['opcoes']);

    $stmt = $conn->prepare("INSERT INTO configuracoes_dashboard (usuario_id, opcoes) VALUES (?, ?)
                            ON DUPLICATE KEY UPDATE opcoes = VALUES(opcoes)");
    $stmt->execute([$usuario_id, $opcoes]);

    header('Location: personalizar_dashboard.php?status=sucesso');
    exit;
}

// Obter configurações do Dashboard de um usuário
$usuarioSelecionado = $_GET['usuario_id'] ?? null;
$configuracoes = [];
if ($usuarioSelecionado) {
    $stmt = $conn->prepare("SELECT opcoes FROM configuracoes_dashboard WHERE usuario_id = ?");
    $stmt->execute([$usuarioSelecionado]);
    $configuracoes = $stmt->fetch(PDO::FETCH_ASSOC);
    $configuracoes = $configuracoes ? json_decode($configuracoes['opcoes'], true) : [];
}
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Personalizar Dashboard</title>
    <link href="favicon.ico" type="image/ico" rel="icon">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body class="hold-transition sidebar-mini">
    <div class="wrapper">
        <!-- Navbar -->
        <nav class="main-header navbar navbar-expand navbar-white navbar-light">
            <ul class="navbar-nav">
                <li class="nav-item">
                    <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
                </li>
                <li class="nav-item">
                    <span class="nav-link">Bem-vindo, <strong><?= htmlspecialchars($_SESSION['usuario_nome']); ?></strong></span>
                </li>
            </ul>
            <ul class="navbar-nav ml-auto">
                <li class="nav-item">
                    <a href="logout.php" class="nav-link"><i class="fas fa-sign-out-alt"></i> Sair</a>
                </li>
            </ul>
        </nav>

        <!-- Sidebar -->
        <aside class="main-sidebar sidebar-dark-primary elevation-4">
            <a href="#" class="brand-link">
                <img src="../assets/img/CROSS-.png" alt="Logo" class="brand-image img-circle elevation-3">
                <span class="brand-text font-weight-light">SA-CAT</span>
            </a>
            <div class="sidebar">
                <nav class="mt-2">
                    <ul class="nav nav-pills nav-sidebar flex-column">
                        <li class="nav-item">
                            <a href="dashboard.php" class="nav-link">
                                <i class="nav-icon fas fa-home"></i>
                                <p>Dashboard</p>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a href="personalizar_dashboard.php" class="nav-link active">
                                <i class="nav-icon fas fa-cogs"></i>
                                <p>Personalizar Dashboard</p>
                            </a>
                        </li>
                    </ul>
                </nav>
            </div>
        </aside>

        <!-- Content Wrapper -->
        <div class="content-wrapper">
            <div class="content-header">
                <div class="container-fluid">
                    <h1 class="m-0">Personalizar Dashboard</h1>
                </div>
            </div>
            <div class="content">
                <div class="container-fluid">
                    <?php if (isset($_GET['status']) && $_GET['status'] === 'sucesso'): ?>
                        <div class="alert alert-success">Configuração salva com sucesso!</div>
                    <?php endif; ?>
                    <form method="POST">
                        <div class="mb-3">
                            <label for="usuario_id" class="form-label">Usuário</label>
                            <select id="usuario_id" name="usuario_id" class="form-control" required onchange="location.href='?usuario_id=' + this.value">
                                <option value="">Selecione o usuário</option>
                                <?php foreach ($usuarios as $usuario): ?>
                                    <option value="<?= $usuario['id'] ?>" <?= $usuarioSelecionado == $usuario['id'] ? 'selected' : '' ?>>
                                        <?= htmlspecialchars($usuario['nome']) ?> (<?= htmlspecialchars($usuario['email']) ?>)
                                    </option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="mb-3">
                            <label for="opcoes" class="form-label">Elementos do Dashboard</label>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="totalAtendimentos" name="opcoes[totalAtendimentos]" value="1" <?= isset($configuracoes['totalAtendimentos']) ? 'checked' : '' ?>>
                                <label class="form-check-label" for="totalAtendimentos">Atendimentos Realizados</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="atendimentosFechados" name="opcoes[atendimentosFechados]" value="1" <?= isset($configuracoes['atendimentosFechados']) ? 'checked' : '' ?>>
                                <label class="form-check-label" for="atendimentosFechados">Atendimentos Finalizados</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="atendimentosAbertos" name="opcoes[atendimentosAbertos]" value="1" <?= isset($configuracoes['atendimentosAbertos']) ? 'checked' : '' ?>>
                                <label class="form-check-label" for="atendimentosAbertos">Atendimentos Abertos</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="topAtendentes" name="opcoes[topAtendentes]" value="1" <?= isset($configuracoes['topAtendentes']) ? 'checked' : '' ?>>
                                <label class="form-check-label" for="topAtendentes">Top Atendentes</label>
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" id="ultimosAtendimentos" name="opcoes[ultimosAtendimentos]" value="1" <?= isset($configuracoes['ultimosAtendimentos']) ? 'checked' : '' ?>>
                                <label class="form-check-label" for="ultimosAtendimentos">Últimos Atendimentos</label>
                            </div>
                        </div>
                        <button type="submit" class="btn btn-primary">Salvar Configurações</button>
                    </form>
                </div>
            </div>
        </div>

        <footer class="main-footer text-center">
            <div class="float-right d-none d-sm-block">
                <b>Versão</b> 0.0.1
            </div>
            <p>&copy; <?= date('Y') ?> SA-CAT - Sistema de Atendimento</p>
        </footer>
    </div>
</body>
</html>