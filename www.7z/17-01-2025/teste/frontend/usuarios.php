<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

$erro = "";
$sucesso = "";

// Processar criação de usuário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $perfil_id = $_POST['perfil_id'];

    // Gerar login e senha
    $partes_nome = explode(' ', strtolower($nome));
    $login = $partes_nome[0] . '.' . end($partes_nome);

    // Verificar se o login já existe
    $contador = 1;
    $login_original = $login;
    while ($conn->query("SELECT id FROM usuarios WHERE email = '$email' OR login = '$login'")->rowCount() > 0) {
        $login = $login_original . $contador;
        $contador++;
    }

    $senha = substr(md5(uniqid(rand(), true)), 0, 8); // Gerar senha aleatória
    $senha_hash = password_hash($senha, PASSWORD_DEFAULT);

    try {
        $stmt = $conn->prepare("INSERT INTO usuarios (nome, email, login, senha, perfil_id, ativo) VALUES (?, ?, ?, ?, ?, ?)");
        $stmt->execute([$nome, $email, $login, $senha_hash, $perfil_id, 1]);
        $sucesso = "Usuário criado com sucesso! Login: $login, Senha: $senha (copie para enviar ao usuário).";
    } catch (Exception $e) {
        $erro = "Erro ao criar usuário: " . $e->getMessage();
    }
}

// Obter perfis para o dropdown
$stmtPerfis = $conn->query("SELECT id, nome FROM perfis WHERE id != 1"); // Excluir Administrador Sistema
$perfis = $stmtPerfis->fetchAll(PDO::FETCH_ASSOC);

// Obter últimos usuários criados
$stmtUltimosUsuarios = $conn->query("SELECT id, login, nome, email FROM usuarios ORDER BY criado_em DESC LIMIT 10");
$usuarios = $stmtUltimosUsuarios->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Criação de Usuários - Sistema de Atendimento</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="hold-transition sidebar-mini">
<div class="wrapper">

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
        </ul>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
                <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                    <i class="fas fa-user"></i> <?= $_SESSION['nome'] ?>
                </a>
                <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                    <li><a class="dropdown-item" href="#">Minha Conta</a></li>
                    <li><hr class="dropdown-divider"></li>
                    <li><a class="dropdown-item" href="logout.php">Sair</a></li>
                </ul>
            </li>
        </ul>
    </nav>

    <!-- Sidebar -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <a href="#" class="brand-link">
            <img src="assets/img/CROSS-.png" alt="Logo" class="brand-image img-circle elevation-3">
            <span class="brand-text font-weight-light">SA-CAT</span>
        </a>
        <div class="sidebar">
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column">
                    <li class="nav-item">
                        <a href="dashboard.php" class="nav-link">
                            <i class="nav-icon fas fa-home"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="usuarios.php" class="nav-link active">
                            <i class="nav-icon fas fa-users"></i>
                            <p>Usuários</p>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Criação de Usuários</h1>
                    </div>
                </div>
            </div>
        </div>
        <div class="content">
            <div class="container-fluid">
                <!-- Alerts -->
                <?php if ($sucesso): ?>
                    <div class="alert alert-success"><?= $sucesso ?></div>
                <?php elseif ($erro): ?>
                    <div class="alert alert-danger"><?= $erro ?></div>
                <?php endif; ?>

                <!-- Formulário -->
                <form method="POST" class="mb-4">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="nome">Nome Completo</label>
                                <input type="text" name="nome" id="nome" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="email">E-mail</label>
                                <input type="email" name="email" id="email" class="form-control" required>
                            </div>
                        </div>
                        <div class="col-lg-6">
                            <div class="form-group">
                                <label for="perfil_id">Perfil</label>
                                <select name="perfil_id" id="perfil_id" class="form-control" required>
                                    <?php foreach ($perfis as $perfil): ?>
                                        <option value="<?= $perfil['id'] ?>"><?= $perfil['nome'] ?></option>
                                    <?php endforeach; ?>
                                </select>
                            </div>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Criar Usuário</button>
                </form>

                <!-- Últimos usuários -->
                <h3>Últimos 10 Usuários</h3>
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th>ID</th>
                        <th>Login</th>
                        <th>Nome</th>
                        <th>Email</th>
                        <th>Ações</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($usuarios as $usuario): ?>
                        <tr>
                            <td><?= $usuario['id'] ?></td>
                            <td><?= $usuario['login'] ?></td>
                            <td><?= $usuario['nome'] ?></td>
                            <td><?= $usuario['email'] ?></td>
                            <td>
                                <a href="#" class="btn btn-info btn-sm">Visualizar</a>
                                <a href="#" class="btn btn-warning btn-sm">Editar</a>
                                <a href="#" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja excluir?')">Excluir</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="main-footer text-center">
        <strong>&copy; <?= date('Y') ?> SA-CAT</strong>
    </footer>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>