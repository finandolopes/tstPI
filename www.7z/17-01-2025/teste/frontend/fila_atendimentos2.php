<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Fila de Atendimentos</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Fila de Atendimentos</h1>
        
        <!-- Filtros -->
        <form method="GET" class="mb-4">
            <div class="row">
                <div class="col-md-3 mb-3">
                    <label for="atendente" class="form-label">Atendente</label>
                    <input type="text" id="atendente" name="atendente" class="form-control" placeholder="Nome do Atendente">
                </div>
                <div class="col-md-3 mb-3">
                    <label for="prioridade" class="form-label">Prioridade</label>
                    <select id="prioridade" name="prioridade" class="form-select">
                        <option value="">Todas</option>
                        <option value="Alta">Alta</option>
                        <option value="Média">Média</option>
                        <option value="Baixa">Baixa</option>
                    </select>
                </div>
                <div class="col-md-3 mb-3">
                    <label for="status" class="form-label">Status</label>
                    <select id="status" name="status" class="form-select">
                        <option value="">Todos</option>
                        <option value="Aberto">Aberto</option>
                        <option value="Pendente">Pendente</option>
                    </select>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Filtrar</button>
        </form>

        <!-- Tabela de Atendimentos -->
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Data/Hora Início</th>
                    <th>Atendente</th>
                    <th>Motivo</th>
                    <th>Origem</th>
                    <th>Status</th>
                    <th>Prioridade</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody id="fila-atendimentos">
                <?php foreach ($atendimentos as $atendimento): ?>
                    <tr>
                        <td><?= $atendimento['id'] ?></td>
                        <td><?= $atendimento['data_inicio'] ?></td>
                        <td><?= $atendimento['atendente'] ?></td>
                        <td><?= $atendimento['motivo'] ?></td>
                        <td><?= $atendimento['origem'] ?></td>
                        <td><?= $atendimento['status'] ?></td>
                        <td><?= $atendimento['prioridade'] ?></td>
                        <td>
                            <button class="btn btn-warning btn-sm" onclick="alterarPrioridade(<?= $atendimento['id'] ?>)">Alterar Prioridade</button>
                            <button class="btn btn-secondary btn-sm" onclick="transferirAtendimento(<?= $atendimento['id'] ?>)">Transferir</button>
                            <button class="btn btn-success btn-sm" onclick="finalizarAtendimento(<?= $atendimento['id'] ?>)">Finalizar</button>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </div>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        function alterarPrioridade(id) {
            const prioridade = prompt("Informe a nova prioridade (Alta, Média, Baixa):");
            if (prioridade) {
                fetch(`alterar_prioridade.php?id=${id}&prioridade=${prioridade}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert("Prioridade alterada com sucesso!");
                            location.reload();
                        } else {
                            alert("Erro ao alterar prioridade.");
                        }
                    });
            }
        }

        function transferirAtendimento(id) {
            const atendente = prompt("Informe o nome do atendente para transferir:");
            if (atendente) {
                fetch(`transferir_atendimento.php?id=${id}&atendente=${atendente}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert("Atendimento transferido com sucesso!");
                            location.reload();
                        } else {
                            alert("Erro ao transferir atendimento.");
                        }
                    });
            }
        }

        function finalizarAtendimento(id) {
            if (confirm("Tem certeza que deseja finalizar este atendimento?")) {
                fetch(`finalizar_atendimento.php?id=${id}`)
                    .then(response => response.json())
                    .then(data => {
                        if (data.success) {
                            alert("Atendimento finalizado com sucesso!");
                            location.reload();
                        } else {
                            alert("Erro ao finalizar atendimento.");
                        }
                    });
            }
        }
    </script>
</body>
</html>