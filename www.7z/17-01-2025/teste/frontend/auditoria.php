<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['perfil'] !== 'administrador_sistema') {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

$logs = [];
$mensagemErro = null;

try {
    // Filtros
    $whereClauses = [];
    $params = [];

    if (!empty($_GET['usuario'])) {
        $whereClauses[] = "u.nome LIKE ?";
        $params[] = "%" . $_GET['usuario'] . "%";
    }
    if (!empty($_GET['acao'])) {
        $whereClauses[] = "l.acao = ?";
        $params[] = $_GET['acao'];
    }
    if (!empty($_GET['data_inicio']) && !empty($_GET['data_fim'])) {
        $whereClauses[] = "DATE(l.data_hora) BETWEEN ? AND ?";
        $params[] = $_GET['data_inicio'];
        $params[] = $_GET['data_fim'];
    }

    $where = $whereClauses ? "WHERE " . implode(" AND ", $whereClauses) : "";

    $query = "
        SELECT l.data_hora, u.nome AS usuario, l.acao, l.tabela, l.detalhes
        FROM logs l
        JOIN usuarios u ON l.usuario_id = u.id
        $where
        ORDER BY l.data_hora DESC
    ";
    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $mensagemErro = "Erro ao carregar os logs: " . $e->getMessage();
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auditoria Completa</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
            <li class="nav-item">
                <span class="nav-link">Bem-vindo, <strong><?= htmlspecialchars($_SESSION['usuario_nome']); ?></strong></span>
            </li>
        </ul>
    </nav>

    <!-- Sidebar -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <a href="#" class="brand-link">
            <img src="assets/img/CROSS-.png" alt="Logo" class="brand-image img-circle elevation-3">
            <span class="brand-text font-weight-light">SA-CAT</span>
        </a>
        <div class="sidebar">
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column">
                    <li class="nav-item">
                        <a href="dashboard.php" class="nav-link">
                            <i class="nav-icon fas fa-home"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="auditoria.php" class="nav-link active">
                            <i class="nav-icon fas fa-clipboard-list"></i>
                            <p>Auditoria</p>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Auditoria Completa</h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                <?php if ($mensagemErro): ?>
                    <script>
                        Swal.fire('Erro', '<?= $mensagemErro ?>', 'error');
                    </script>
                <?php endif; ?>

                <form method="GET" class="mb-4">
                    <div class="row">
                        <div class="col-md-4 mb-3">
                            <label for="usuario" class="form-label">Usuário</label>
                            <input type="text" id="usuario" name="usuario" class="form-control" value="<?= htmlspecialchars($_GET['usuario'] ?? '') ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="acao" class="form-label">Ação</label>
                            <select id="acao" name="acao" class="form-select">
                                <option value="">Selecione</option>
                                <option value="inserir" <?= (isset($_GET['acao']) && $_GET['acao'] === 'inserir') ? 'selected' : '' ?>>Inserir</option>
                                <option value="editar" <?= (isset($_GET['acao']) && $_GET['acao'] === 'editar') ? 'selected' : '' ?>>Editar</option>
                                <option value="excluir" <?= (isset($_GET['acao']) && $_GET['acao'] === 'excluir') ? 'selected' : '' ?>>Excluir</option>
                            </select>
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="data_inicio" class="form-label">Período Início</label>
                            <input type="date" id="data_inicio" name="data_inicio" class="form-control" value="<?= htmlspecialchars($_GET['data_inicio'] ?? '') ?>">
                        </div>
                        <div class="col-md-4 mb-3">
                            <label for="data_fim" class="form-label">Período Fim</label>
                            <input type="date" id="data_fim" name="data_fim" class="form-control" value="<?= htmlspecialchars($_GET['data_fim'] ?? '') ?>">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Filtrar</button>
                </form>

                <div class="table-responsive">
                    <table class="table table-bordered">
                        <thead>
                            <tr>
                                <th>Data e Hora</th>
                                <th>Usuário</th>
                                <th>Ação</th>
                                <th>Tabela</th>
                                <th>Detalhes</th>
                            </tr>
                        </thead>
                        <tbody>
                            <?php if ($logs): ?>
                                <?php foreach ($logs as $log): ?>
                                    <tr>
                                        <td><?= $log['data_hora'] ?></td>
                                        <td><?= $log['usuario'] ?></td>
                                        <td><?= ucfirst($log['acao']) ?></td>
                                        <td><?= $log['tabela'] ?></td>
                                        <td><?= $log['detalhes'] ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            <?php else: ?>
                                <tr>
                                    <td colspan="5" class="text-center">Nenhum log encontrado.</td>
                                </tr>
                            <?php endif; ?>
                        </tbody>
                    </table>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="main-footer text-center">
        <strong>&copy; <?= date('Y') ?> SA-CAT</strong>
    </footer>
</div>
</body>
</html>