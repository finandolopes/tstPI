<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['perfil'] !== 'administrador_sistema') {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $descricao = $_POST['descricao'];
    $obrigatorio = isset($_POST['obrigatorio']) ? 1 : 0;

    $stmt = $conn->prepare("INSERT INTO motivos_atendimento (nome, descricao, obrigatorio) VALUES (?, ?, ?)");
    $stmt->execute([$nome, $descricao, $obrigatorio]);

    header('Location: gerenciar-motivos.php?status=criado');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Novo Motivo de Atendimento</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>+ Novo Motivo de Atendimento</h1>
        <form method="POST">
            <div class="mb-3">
                <label for="nome" class="form-label">Nome do Motivo</label>
                <input type="text" id="nome" name="nome" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="descricao" class="form-label">Descrição</label>
                <textarea id="descricao" name="descricao" class="form-control" rows="3" required></textarea>
            </div>
            <div class="form-check">
                <input class="form-check-input" type="checkbox" id="obrigatorio" name="obrigatorio">
                <label class="form-check-label" for="obrigatorio">Obrigatório</label>
            </div>
            <button type="submit" class="btn btn-primary mt-3">Salvar</button>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>