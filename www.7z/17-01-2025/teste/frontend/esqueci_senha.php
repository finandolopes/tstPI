<?php
require 'backend/conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $email = $_POST['email'];

    // Verificar se o e-mail está cadastrado
    $stmt = $conn->prepare("SELECT id FROM usuarios WHERE email = ? AND status = 'ativo'");
    $stmt->execute([$email]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($usuario) {
        // Gerar token único e seguro
        $token = bin2hex(random_bytes(32));
        $stmtToken = $conn->prepare("INSERT INTO recuperacao_senha (usuario_id, token, expiracao) VALUES (?, ?, DATE_ADD(NOW(), INTERVAL 1 HOUR))");
        $stmtToken->execute([$usuario['id'], $token]);

        // Enviar e-mail de recuperação
        $link = "http://seusite.com/redefinir_senha.php?token=$token";
        $mensagem = "Clique no link para redefinir sua senha: $link";

        // Função fictícia para envio de e-mail
        mail($email, "Recuperação de Senha", $mensagem);

        header('Location: recuperar_senha.php?status=enviado');
        exit;
    } else {
        $erro = "E-mail não encontrado ou inativo.";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Recuperação de Senha</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body class="d-flex justify-content-center align-items-center vh-100">
    <div class="card p-4" style="width: 400px;">
        <h3 class="text-center">Recuperar Senha</h3>
        <?php if (isset($_GET['status']) && $_GET['status'] === 'enviado'): ?>
            <div class="alert alert-success">E-mail enviado com instruções para redefinir sua senha.</div>
        <?php elseif (isset($erro)): ?>
            <div class="alert alert-danger"><?= $erro ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label for="email" class="form-label">E-mail</label>
                <input type="email" name="email" id="email" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Enviar</button>
        </form>
    </div>
</body>
</html>