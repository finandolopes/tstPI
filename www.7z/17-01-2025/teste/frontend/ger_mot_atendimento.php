<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['perfil'] !== 'administrador_sistema') {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Obter lista de motivos de atendimento
$stmtMotivos = $conn->query("SELECT id, nome, descricao, obrigatorio FROM motivos_atendimento");
$motivos = $stmtMotivos->fetchAll(PDO::FETCH_ASSOC);

// Lógica de exclusão
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $stmtDelete = $conn->prepare("DELETE FROM motivos_atendimento WHERE id = ?");
    $stmtDelete->execute([$delete_id]);
    header('Location: gerenciar-motivos.php?status=excluido');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Motivos de Atendimento</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Gerenciar Motivos de Atendimento</h1>
        <?php if (isset($_GET['status']) && $_GET['status'] === 'excluido'): ?>
            <div class="alert alert-success">Motivo de Atendimento excluído com sucesso!</div>
        <?php endif; ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Descrição</th>
                    <th>Obrigatório</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($motivos as $motivo): ?>
                    <tr>
                        <td><?= $motivo['id'] ?></td>
                        <td><?= $motivo['nome'] ?></td>
                        <td><?= $motivo['descricao'] ?></td>
                        <td><?= $motivo['obrigatorio'] ? 'Sim' : 'Não' ?></td>
                        <td>
                            <a href="editar-motivo.php?id=<?= $motivo['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                            <a href="gerenciar-motivos.php?delete_id=<?= $motivo['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja excluir este motivo?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <a href="novo-motivo.php" class="btn btn-primary">+ Novo Motivo</a>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>