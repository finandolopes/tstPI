<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

$resultados = [];

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario_id = $_POST['usuario_id'] ?? null;
    $data_inicio = $_POST['data_inicio'] ?? null;
    $data_fim = $_POST['data_fim'] ?? null;

    $query = "
        SELECT u.nome AS atendente, COUNT(a.id) AS total_atendimentos, 
               SUM(CASE WHEN a.status = 'Fechado' THEN 1 ELSE 0 END) AS total_finalizados,
               SUM(CASE WHEN a.status = 'Aberto' THEN 1 ELSE 0 END) AS total_abertos
        FROM atendimentos a
        JOIN usuarios u ON a.usuario_id = u.id
        WHERE 1=1
    ";
    $params = [];
    if ($usuario_id) {
        $query .= " AND u.id = ?";
        $params[] = $usuario_id;
    }
    if ($data_inicio && $data_fim) {
        $query .= " AND a.data_inicio BETWEEN ? AND ?";
        $params[] = $data_inicio;
        $params[] = $data_fim;
    }
    $query .= " GROUP BY u.nome ORDER BY total_atendimentos DESC";

    $stmt = $conn->prepare($query);
    $stmt->execute($params);
    $resultados = $stmt->fetchAll(PDO::FETCH_ASSOC);
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório de Produtividade por Usuário</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
    <?php include 'layout/navbar.php'; ?>
    <?php include 'layout/sidebar.php'; ?>
    <div class="content-wrapper">
        <div class="content-header">
            <h1>Relatório de Produtividade por Usuário</h1>
        </div>
        <div class="content">
            <form method="POST" class="mb-4">
                <div class="row">
                    <div class="col-md-4">
                        <label for="usuario_id">Usuário</label>
                        <select id="usuario_id" name="usuario_id" class="form-control">
                            <option value="">Todos</option>
                            <?php
                            $usuarios = $conn->query("SELECT id, nome FROM usuarios")->fetchAll(PDO::FETCH_ASSOC);
                            foreach ($usuarios as $usuario) {
                                echo "<option value='{$usuario['id']}'>{$usuario['nome']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-4">
                        <label for="data_inicio">Data Início</label>
                        <input type="date" id="data_inicio" name="data_inicio" class="form-control">
                    </div>
                    <div class="col-md-4">
                        <label for="data_fim">Data Fim</label>
                        <input type="date" id="data_fim" name="data_fim" class="form-control">
                    </div>
                </div>
                <button type="submit" class="btn btn-primary mt-3">Gerar Relatório</button>
            </form>
            <hr>
            <?php if ($resultados): ?>
                <table class="table table-bordered">
                    <thead>
                    <tr>
                        <th>Atendente</th>
                        <th>Total de Atendimentos</th>
                        <th>Atendimentos Finalizados</th>
                        <th>Atendimentos Abertos</th>
                    </tr>
                    </thead>
                    <tbody>
                    <?php foreach ($resultados as $row): ?>
                        <tr>
                            <td><?= $row['atendente'] ?></td>
                            <td><?= $row['total_atendimentos'] ?></td>
                            <td><?= $row['total_finalizados'] ?></td>
                            <td><?= $row['total_abertos'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
                <div class="mt-3">
                    <a href="exportar-pdf.php" class="btn btn-danger">Exportar PDF</a>
                    <a href="exportar-excel.php" class="btn btn-success">Exportar Excel</a>
                    <a href="exportar-word.php" class="btn btn-primary">Exportar Word</a>
                </div>
            <?php else: ?>
                <p>Nenhum resultado encontrado.</p>
            <?php endif; ?>
        </div>
    </div>
    <?php include 'layout/footer.php'; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>