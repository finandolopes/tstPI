<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Lógica para exportação
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipoRelatorio = $_POST['tipo_relatorio'];
    $periodoInicio = $_POST['periodo_inicio'];
    $periodoFim = $_POST['periodo_fim'];

    // Query para o tipo de relatório
    $query = "";
    switch ($tipoRelatorio) {
        case 'produtividade':
            $query = "
                SELECT u.nome AS atendente, COUNT(a.id) AS total
                FROM atendimentos a
                JOIN usuarios u ON a.atendente_id = u.id
                WHERE a.data_inicio BETWEEN ? AND ?
                GROUP BY u.nome
                ORDER BY total DESC";
            break;
        case 'drs':
            $query = "
                SELECT d.nome AS drs, COUNT(a.id) AS total
                FROM atendimentos a
                JOIN drs d ON a.drs_id = d.id
                WHERE a.data_inicio BETWEEN ? AND ?
                GROUP BY d.nome
                ORDER BY total DESC";
            break;
    }

    $stmt = $conn->prepare($query);
    $stmt->execute([$periodoInicio, $periodoFim]);
    $relatorio = $stmt->fetchAll(PDO::FETCH_ASSOC);

    // Exportar para CSV
    header('Content-Type: text/csv');
    header('Content-Disposition: attachment;filename="relatorio_exportado.csv"');
    $output = fopen('php://output', 'w');
    if (!empty($relatorio)) {
        fputcsv($output, array_keys($relatorio[0]));
        foreach ($relatorio as $row) {
            fputcsv($output, $row);
        }
    }
    fclose($output);
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Exportação de Relatórios Avançados</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Exportação Avançada de Relatórios</h1>
        <form method="POST">
            <div class="mb-3">
                <label for="tipo_relatorio" class="form-label">Tipo de Relatório</label>
                <select id="tipo_relatorio" name="tipo_relatorio" class="form-select" required>
                    <option value="produtividade">Produtividade por Atendente</option>
                    <option value="drs">Relatório por DRS</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="periodo_inicio" class="form-label">Período Início</label>
                <input type="date" id="periodo_inicio" name="periodo_inicio" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="periodo_fim" class="form-label">Período Fim</label>
                <input type="date" id="periodo_fim" name="periodo_fim" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary">Exportar</button>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
