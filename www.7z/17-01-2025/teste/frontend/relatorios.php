<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Obter estatísticas para relatórios
$stmtProdutividade = $conn->query("
    SELECT usuarios.nome, COUNT(atendimentos.id) AS total
    FROM atendimentos
    JOIN usuarios ON atendimentos.atendente_id = usuarios.id
    GROUP BY usuarios.nome
    ORDER BY total DESC
    LIMIT 10
");
$produtividade = $stmtProdutividade->fetchAll(PDO::FETCH_ASSOC);

// Obter chamados finalizados
$stmtChamadosFinalizados = $conn->query("
    SELECT COUNT(*) AS total FROM atendimentos WHERE status = 'fechado'
");
$totalChamadosFinalizados = $stmtChamadosFinalizados->fetch(PDO::FETCH_ASSOC)['total'];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Relatórios</h1>
        <div class="row mb-4">
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">Produtividade por Atendente</div>
                    <div class="card-body">
                        <table class="table table-bordered">
                            <thead>
                                <tr>
                                    <th>Atendente</th>
                                    <th>Total Atendimentos</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php foreach ($produtividade as $item): ?>
                                    <tr>
                                        <td><?= $item['nome'] ?></td>
                                        <td><?= $item['total'] ?></td>
                                    </tr>
                                <?php endforeach; ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-md-6">
                <div class="card">
                    <div class="card-header">Chamados Finalizados</div>
                    <div class="card-body">
                        <h5>Total: <?= $totalChamadosFinalizados ?></h5>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
