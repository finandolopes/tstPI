<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

$id = $_GET['id'];
$stmt = $conn->prepare("SELECT * FROM usuarios WHERE id = ?");
$stmt->execute([$id]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $login = $_POST['login'];
    $perfil = $_POST['perfil'];

    $stmtUpdate = $conn->prepare("UPDATE usuarios SET nome = ?, login = ?, perfil = ? WHERE id = ?");
    $stmtUpdate->execute([$nome, $login, $perfil, $id]);

    if (!empty($_POST['senha'])) {
        $senha = password_hash($_POST['senha'], PASSWORD_BCRYPT);
        $stmtSenha = $conn->prepare("UPDATE usuarios SET senha = ? WHERE id = ?");
        $stmtSenha->execute([$senha, $id]);
    }

    header('Location: usuarios-permissoes.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Usuário</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Editar Usuário</h1>
        <form method="POST">
            <div class="mb-3">
                <label for="nome" class="form-label">Nome</label>
                <input type="text" id="nome" name="nome" class="form-control" value="<?= $usuario['nome'] ?>" required>
            </div>
            <div class="mb-3">
                <label for="login" class="form-label">Login</label>
                <input type="text" id="login" name="login" class="form-control" value="<?= $usuario['login'] ?>" required>
            </div>
            <div class="mb-3">
                <label for="perfil" class="form-label">Perfil</label>
                <select id="perfil" name="perfil" class="form-select" required>
                    <option value="atendente" <?= $usuario['perfil'] == 'atendente' ? 'selected' : '' ?>>Atendente</option>
                    <option value="coordenador" <?= $usuario['perfil'] == 'coordenador' ? 'selected' : '' ?>>Coordenador</option>
                    <option value="administrador" <?= $usuario['perfil'] == 'administrador' ? 'selected' : '' ?>>Administrador</option>
                    <option value="administrador_sistema" <?= $usuario['perfil'] == 'administrador_sistema' ? 'selected' : '' ?>>Administrador do Sistema</option>
                </select>
            </div>
            <div class="mb-3">
                <label for="senha" class="form-label">Nova Senha (opcional)</label>
                <input type="password" id="senha" name="senha" class="form-control">
            </div>
            <button type="submit" class="btn btn-primary">Salvar Alterações</button>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
