<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['perfil'] !== 'administrador_sistema') {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

$filtros = [];
$params = [];

// Filtros de entrada
if (!empty($_GET['programa'])) {
    $filtros[] = "programa = ?";
    $params[] = $_GET['programa'];
}
if (!empty($_GET['data_inicio']) && !empty($_GET['data_fim'])) {
    $filtros[] = "DATE(data_inicio) BETWEEN ? AND ?";
    $params[] = $_GET['data_inicio'];
    $params[] = $_GET['data_fim'];
}
if (!empty($_GET['ano'])) {
    $filtros[] = "YEAR(data_inicio) = ?";
    $params[] = $_GET['ano'];
}

$where = $filtros ? "WHERE " . implode(" AND ", $filtros) : "";

// Obter dados principais
$query = "
    SELECT DATE(data_inicio) AS dia, COUNT(*) AS atendimentos, 
           SUM(CASE WHEN tipo_origem = 'fila_espera' THEN 1 ELSE 0 END) AS fila_espera,
           SUM(CASE WHEN tipo_origem = 'contato_ativo' THEN 1 ELSE 0 END) AS contato_ativo
    FROM atendimentos
    $where
    GROUP BY dia
    ORDER BY dia ASC
";
$stmt = $conn->prepare($query);
$stmt->execute($params);
$dadosDiarios = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Quantificação total
$queryTotal = "
    SELECT COUNT(DISTINCT id) AS ligacoes_recebidas,
           COUNT(DISTINCT CASE WHEN tipo_origem = 'fila_espera' THEN id END) AS fila_espera,
           COUNT(DISTINCT CASE WHEN tipo_origem = 'contato_ativo' THEN id END) AS contato_ativo,
           COUNT(DISTINCT id) AS agendamentos
    FROM atendimentos
    $where
";
$stmt = $conn->prepare($queryTotal);
$stmt->execute($params);
$totais = $stmt->fetch(PDO::FETCH_ASSOC);

// Eficiência
$eficiencia = ($totais['agendamentos'] > 0 && $totais['ligacoes_recebidas'] > 0)
    ? round(($totais['agendamentos'] / $totais['ligacoes_recebidas']) * 100, 2)
    : 0;
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório DRX vs Agendamento</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
    <div class="container my-4">
        <h1>Relatório DRX vs Agendamento</h1>
        <form method="GET" class="mb-4">
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label for="programa" class="form-label">Programa</label>
                    <select id="programa" name="programa" class="form-select">
                        <option value="">Selecione o programa</option>
                        <!-- Adicione os programas do banco -->
                        <option value="Programa1">Programa 1</option>
                        <option value="Programa2">Programa 2</option>
                    </select>
                </div>
                <div class="col-md-4 mb-3">
                    <label for="data_inicio" class="form-label">Data Início</label>
                    <input type="date" id="data_inicio" name="data_inicio" class="form-control">
                </div>
                <div class="col-md-4 mb-3">
                    <label for="data_fim" class="form-label">Data Fim</label>
                    <input type="date" id="data_fim" name="data_fim" class="form-control">
                </div>
            </div>
            <div class="row">
                <div class="col-md-4 mb-3">
                    <label for="ano" class="form-label">Ano</label>
                    <input type="number" id="ano" name="ano" class="form-control">
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Gerar Relatório</button>
        </form>

        <canvas id="chartQuantificacaoDiaria" class="mb-4"></canvas>

        <h3>Resumo</h3>
        <ul>
            <li><strong>Ligações Recebidas:</strong> <?= $totais['ligacoes_recebidas'] ?></li>
            <li><strong>Agendamentos por Fila de Espera:</strong> <?= $totais['fila_espera'] ?></li>
            <li><strong>Agendamentos por Contato Ativo:</strong> <?= $totais['contato_ativo'] ?></li>
            <li><strong>Eficiência:</strong> <?= $eficiencia ?>%</li>
        </ul>

        <div class="mt-4">
            <button class="btn btn-success">Exportar para PDF</button>
            <button class="btn btn-info">Exportar para Excel</button>
            <button class="btn btn-warning">Exportar para Word</button>
        </div>
    </div>

    <script>
        const ctx = document.getElementById('chartQuantificacaoDiaria').getContext('2d');
        const chartData = {
            labels: <?= json_encode(array_column($dadosDiarios, 'dia')) ?>,
            datasets: [{
                label: 'Atendimentos',
                data: <?= json_encode(array_column($dadosDiarios, 'atendimentos')) ?>,
                backgroundColor: '#007bff'
            }]
        };
        new Chart(ctx, {
            type: 'bar',
            data: chartData,
        });
    </script>
</body>
</html>