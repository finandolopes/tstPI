<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

$mensagem_id = $_GET['id'] ?? null;

if ($mensagem_id) {
    $stmtMensagem = $conn->prepare("
        SELECT u.nome AS remetente, m.assunto, m.mensagem, m.data_envio 
        FROM mensagens m 
        JOIN usuarios u ON m.remetente_id = u.id 
        WHERE m.id = ? AND m.destinatario_id = ?
    ");
    $stmtMensagem->execute([$mensagem_id, $_SESSION['usuario_id']]);
    $mensagem = $stmtMensagem->fetch(PDO::FETCH_ASSOC);

    if ($mensagem) {
        $conn->prepare("UPDATE mensagens SET lida = 1 WHERE id = ?")->execute([$mensagem_id]);
    } else {
        header('Location: caixa_entrada.php');
        exit;
    }
} else {
    header('Location: caixa_entrada.php');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Visualizar Mensagem</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1><?= htmlspecialchars($mensagem['assunto']) ?></h1>
        <p><strong>De:</strong> <?= htmlspecialchars($mensagem['remetente']) ?></p>
        <p><strong>Data:</strong> <?= $mensagem['data_envio'] ?></p>
        <hr>
        <p><?= nl2br(htmlspecialchars($mensagem['mensagem'])) ?></p>
        <a href="caixa_entrada.php" class="btn btn-secondary">Voltar</a>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>