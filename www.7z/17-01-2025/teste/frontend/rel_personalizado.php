<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Capturar filtros e campos selecionados
$campos = $_POST['campos'] ?? [];
$filtros = [
    'programa' => $_POST['programa'] ?? null,
    'atendente' => $_POST['atendente'] ?? null,
    'drs' => $_POST['drs'] ?? null,
    'status' => $_POST['status'] ?? null,
    'data_inicio' => $_POST['data_inicio'] ?? null,
    'data_fim' => $_POST['data_fim'] ?? null,
];

// Gerar consulta dinâmica
$query = "SELECT " . (empty($campos) ? "*" : implode(", ", $campos)) . " FROM atendimentos a";
$query .= " JOIN usuarios u ON a.usuario_id = u.id";
$query .= " JOIN programas p ON a.programa_id = p.id";
$query .= " JOIN recursos r ON a.recurso_id = r.id";
$query .= " WHERE 1=1";

$params = [];
if ($filtros['programa']) {
    $query .= " AND a.programa_id = ?";
    $params[] = $filtros['programa'];
}
if ($filtros['atendente']) {
    $query .= " AND a.usuario_id = ?";
    $params[] = $filtros['atendente'];
}
if ($filtros['drs']) {
    $query .= " AND a.drs_id = ?";
    $params[] = $filtros['drs'];
}
if ($filtros['status']) {
    $query .= " AND a.status = ?";
    $params[] = $filtros['status'];
}
if ($filtros['data_inicio'] && $filtros['data_fim']) {
    $query .= " AND DATE(a.data_inicio) BETWEEN ? AND ?";
    $params[] = $filtros['data_inicio'];
    $params[] = $filtros['data_fim'];
}

$stmt = $conn->prepare($query);
$stmt->execute($params);
$dados = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios Personalizados</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
    <!-- Navbar -->
    <?php include 'includes/navbar.php'; ?>
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>

    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Relatórios Personalizados</h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                <!-- Filtros -->
                <form method="POST" class="mb-4">
                    <div class="row">
                        <div class="col-md-3">
                            <label for="programa" class="form-label">Programa</label>
                            <select name="programa" id="programa" class="form-select">
                                <option value="">Todos</option>
                                <?php
                                $programas = $conn->query("SELECT id, nome FROM programas")->fetchAll(PDO::FETCH_ASSOC);
                                foreach ($programas as $prog) {
                                    echo "<option value='{$prog['id']}'>{$prog['nome']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="atendente" class="form-label">Atendente</label>
                            <select name="atendente" id="atendente" class="form-select">
                                <option value="">Todos</option>
                                <?php
                                $usuarios = $conn->query("SELECT id, nome FROM usuarios")->fetchAll(PDO::FETCH_ASSOC);
                                foreach ($usuarios as $usuario) {
                                    echo "<option value='{$usuario['id']}'>{$usuario['nome']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="drs" class="form-label">DRS</label>
                            <select name="drs" id="drs" class="form-select">
                                <option value="">Todos</option>
                                <?php
                                $drs = $conn->query("SELECT id, nome FROM drs")->fetchAll(PDO::FETCH_ASSOC);
                                foreach ($drs as $d) {
                                    echo "<option value='{$d['id']}'>{$d['nome']}</option>";
                                }
                                ?>
                            </select>
                        </div>
                        <div class="col-md-3">
                            <label for="status" class="form-label">Status</label>
                            <select name="status" id="status" class="form-select">
                                <option value="">Todos</option>
                                <option value="Aberto">Aberto</option>
                                <option value="Pendente">Pendente</option>
                                <option value="Fechado">Fechado</option>
                            </select>
                        </div>
                        <div class="col-md-3 mt-3">
                            <label for="data_inicio" class="form-label">Data Início</label>
                            <input type="date" name="data_inicio" id="data_inicio" class="form-control">
                        </div>
                        <div class="col-md-3 mt-3">
                            <label for="data_fim" class="form-label">Data Fim</label>
                            <input type="date" name="data_fim" id="data_fim" class="form-control">
                        </div>
                    </div>
                    <div class="mt-4">
                        <h5>Selecione os Campos para Exibir</h5>
                        <?php
                        $camposDisponiveis = [
                            'a.id' => 'ID do Atendimento',
                            'a.codigo_paciente' => 'Código do Paciente',
                            'a.data_inicio' => 'Data de Início',
                            'a.data_fim' => 'Data de Fim',
                            'u.nome' => 'Nome do Atendente',
                            'p.nome' => 'Programa',
                            'r.nome' => 'Recurso',
                            'a.unidade_solicitante' => 'Unidade Solicitante',
                            'a.unidade_executante' => 'Unidade Executante',
                            'a.motivo_id' => 'Motivo',
                            'a.origem_id' => 'Origem',
                            'a.drs_id' => 'DRS'
                        ];
                        foreach ($camposDisponiveis as $campo => $rotulo) {
                            echo "
                            <div class='form-check'>
                                <input class='form-check-input' type='checkbox' name='campos[]' value='$campo' id='$campo'>
                                <label class='form-check-label' for='$campo'>$rotulo</label>
                            </div>";
                        }
                        ?>
                    </div>
                    <button type="submit" class="btn btn-primary mt-4 w-100">Gerar Relatório</button>
                </form>

                <!-- Resultados -->
                <?php if (!empty($dados)): ?>
                    <table class="table table-bordered mt-4">
                        <thead>
                            <tr>
                                <?php foreach ($camposDisponiveis as $campo => $rotulo): ?>
                                    <?php if (in_array($campo, $campos)): ?>
                                        <th><?= $rotulo ?></th>
                                    <?php endif; ?>
                                <?php endforeach; ?>
                            </tr>
                        </thead>
                        <tbody>
                            <?php foreach ($dados as $linha): ?>
                                <tr>
                                    <?php foreach ($linha as $valor): ?>
                                        <td><?= $valor ?></td>
                                    <?php endforeach; ?>
                                </tr>
                            <?php endforeach; ?>
                        </tbody>
                    </table>

                    <!-- Botões de Exportação -->
                    <div class="mt-4">
                        <a href="exportar_relatorio.php?formato=pdf" class="btn btn-danger">Exportar para PDF</a>
                        <a href="exportar_relatorio.php?formato=excel" class="btn btn-success">Exportar para Excel</a>
                        <a href="exportar_relatorio.php?formato=word" class="btn btn-primary">Exportar para Word</a>
                    </div>
                <?php else: ?>
                    <div class="alert alert-info">Nenhum resultado encontrado para os filtros selecionados.</div>
                <?php endif; ?>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>