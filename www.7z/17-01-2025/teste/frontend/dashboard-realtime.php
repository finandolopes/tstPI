<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Contadores iniciais
$totalAtendimentos = $conn->query("SELECT COUNT(*) AS total FROM atendimentos")->fetch(PDO::FETCH_ASSOC)['total'];
$atendimentosAbertos = $conn->query("SELECT COUNT(*) AS total FROM atendimentos WHERE status = 'aberto'")->fetch(PDO::FETCH_ASSOC)['total'];
$atendimentosFechados = $conn->query("SELECT COUNT(*) AS total FROM atendimentos WHERE status = 'fechado'")->fetch(PDO::FETCH_ASSOC)['total'];
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard - Atualização em Tempo Real</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <script src="https://cdn.jsdelivr.net/npm/jquery@3.6.0/jquery.min.js"></script>
</head>
<body>
    <div class="container my-4">
        <h1>Dashboard - Atualização em Tempo Real</h1>
        <div class="row">
            <div class="col-lg-4 col-md-6">
                <div class="card text-center">
                    <div class="card-body">
                        <h2 id="totalAtendimentos"><?= $totalAtendimentos ?></h2>
                        <p>Total de Atendimentos</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="card text-center">
                    <div class="card-body">
                        <h2 id="atendimentosAbertos"><?= $atendimentosAbertos ?></h2>
                        <p>Atendimentos Abertos</p>
                    </div>
                </div>
            </div>
            <div class="col-lg-4 col-md-6">
                <div class="card text-center">
                    <div class="card-body">
                        <h2 id="atendimentosFechados"><?= $atendimentosFechados ?></h2>
                        <p>Atendimentos Fechados</p>
                    </div>
                </div>
            </div>
        </div>
    </div>
    <script>
        function atualizarDados() {
            $.ajax({
                url: 'backend/dashboard-dados.php',
                method: 'GET',
                dataType: 'json',
                success: function (data) {
                    $('#totalAtendimentos').text(data.totalAtendimentos);
                    $('#atendimentosAbertos').text(data.atendimentosAbertos);
                    $('#atendimentosFechados').text(data.atendimentosFechados);
                }
            });
        }

        setInterval(atualizarDados, 5000); // Atualizar a cada 5 segundos
    </script>
</body>
</html>
