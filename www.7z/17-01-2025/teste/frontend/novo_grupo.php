<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Novo Grupo - Sistema de Atendimento</title>
    <link href="favicon.ico" type="image/ico" rel="icon">
    <link href="favicon.ico" type="image/x-icon" rel="shortcut icon">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bulma/css/bulma.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
        <div class="wrapper">
        
            <!-- Navbar -->
            <nav class="main-header navbar navbar-expand navbar-white navbar-light">
                <ul class="navbar-nav">
                    <li class="nav-item">
                        <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
                    </li>
                    <li class="nav-item">
                        <span class="nav-link">Bem-vindo, <strong><?= htmlspecialchars($_SESSION['usuario_nome']); ?></strong></span>
                    </li>
                </ul>
                <ul class="navbar-nav ml-auto">
                    <li class="nav-item dropdown">
                        <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-bs-toggle="dropdown" aria-expanded="false">
                            <i class="fas fa-user"></i>
                        </a>
                        <ul class="dropdown-menu dropdown-menu-end" aria-labelledby="userDropdown">
                            <li><a class="dropdown-item" href="#">Minha Conta</a></li>
                            <li><hr class="dropdown-divider"></li>
                            <li><a class="dropdown-item" href="logout.php">Sair</a></li>
                        </ul>
                    </li>
                </ul>
            </nav>    
            <!-- Sidebar -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <a href="#" class="brand-link">
            <img src="../assets/img/CROSS-.png" alt="Logo" class="brand-image img-circle elevation-3">
            <span class="brand-text font-weight-light">SA-CAT</span>
        </a>
        <div class="sidebar">
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column">
                    <li class="nav-item">
                        <a href="novo_grupo.php" class="nav-link">
                            <i class="nav-icon fas fa-user-group"></i>
                            <p>Novo Grupo</p>
                        </a>
                    </li>                    
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Novo Grupo</h1>
                    </div>
                </div>
            </div>
        </div>

            <div class="content">
                <div class="container-fluid">
                    <form action="salvar-grupo.php" method="POST">
                        <div class="card">
                            <div class="card-body">
                                <div class="form-group">
                                    <label for="nome">Nome do Grupo</label>
                                    <input type="text" class="form-control" id="nome" name="nome" required>
                                </div>
                                <div class="form-group">
                                    <label for="descricao">Descrição</label>
                                    <textarea class="form-control" id="descricao" name="descricao" rows="3"></textarea>
                                </div>
                            </div>
                            <div class="card-footer">
                                <div class="col-lg-12 text-right">
                                    <button type="button" id="clearForm" class="btn btn-danger clearForm"><i class="fa fa-times"></i>Cancelar</button>
                                    <button type="submit" class="btn btn-success"><i class="fa-solid fa-check"></i>Salvar</button>
                                </div>  
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>

        <footer class="main-footer text-center">
            <div class="float-right d-none d-sm-block">
                <b>Versão</b> 0.0.1
            </div>
            <p>CROSS - CENTRAL DE REGULAÇÃO DE OFERTAS DE SERVIÇOS DE SAÚDE</p>
            <p>&copy; <span id="current-year"></span> - Sistema de Atendimento</p>
        </footer>
    </div>
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
    <script>
        document.getElementById('current-year').textContent = new Date().getFullYear();
    </script>
</body>
</html>
