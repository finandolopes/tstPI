<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['perfil'] !== 'administrador_sistema') {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Obter lista de unidades
$stmtUnidades = $conn->query("
    SELECT u.id, u.nome, u.cnes, t.nome AS tipo_unidade, m.nome AS municipio 
    FROM unidades u 
    JOIN tipos_unidade t ON u.tipo_unidade_id = t.id 
    JOIN municipios m ON u.municipio_id = m.id
");
$unidades = $stmtUnidades->fetchAll(PDO::FETCH_ASSOC);

// Lógica de exclusão
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $stmtDelete = $conn->prepare("DELETE FROM unidades WHERE id = ?");
    $stmtDelete->execute([$delete_id]);
    header('Location: gerenciar-unidades.php?status=excluido');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Unidades</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Gerenciar Unidades</h1>
        <?php if (isset($_GET['status']) && $_GET['status'] === 'excluido'): ?>
            <div class="alert alert-success">Unidade excluída com sucesso!</div>
        <?php endif; ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>CNES</th>
                    <th>Tipo de Unidade</th>
                    <th>Município</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($unidades as $unidade):