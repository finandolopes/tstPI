<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['perfil'] !== 'administrador_sistema') {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Obter registros de logs
$stmtLogs = $conn->query("
    SELECT l.id, l.acao, l.tabela, l.dados_antigos, l.dados_novos, l.data_hora, u.nome AS usuario
    FROM logs l
    JOIN usuarios u ON l.usuario_id = u.id
    ORDER BY l.data_hora DESC
");
$logs = $stmtLogs->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciamento de Logs</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Gerenciamento de Logs</h1>
        <div class="table-responsive">
            <table class="table table-bordered">
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Usuário</th>
                        <th>Ação</th>
                        <th>Tabela</th>
                        <th>Dados Antigos</th>
                        <th>Dados Novos</th>
                        <th>Data e Hora</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($logs as $log): ?>
                        <tr>
                            <td><?= $log['id'] ?></td>
                            <td><?= $log['usuario'] ?></td>
                            <td><?= $log['acao'] ?></td>
                            <td><?= $log['tabela'] ?></td>
                            <td><?= htmlspecialchars($log['dados_antigos']) ?></td>
                            <td><?= htmlspecialchars($log['dados_novos']) ?></td>
                            <td><?= $log['data_hora'] ?></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
