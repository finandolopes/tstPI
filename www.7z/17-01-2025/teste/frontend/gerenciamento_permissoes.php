<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['perfil'] !== 'administrador_sistema') {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Obter lista de perfis
$stmtPerfis = $conn->query("SELECT id, nome FROM perfis");
$perfis = $stmtPerfis->fetchAll(PDO::FETCH_ASSOC);

// Obter lista de usuários
$stmtUsuarios = $conn->query("SELECT id, nome FROM usuarios WHERE status = 'ativo'");
$usuarios = $stmtUsuarios->fetchAll(PDO::FETCH_ASSOC);

// Obter lista de módulos e ações
$stmtModulos = $conn->query("SELECT id, nome FROM modulos");
$modulos = $stmtModulos->fetchAll(PDO::FETCH_ASSOC);

// Salvar alterações de permissões
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipo = $_POST['tipo']; // perfil ou usuário
    $id = $_POST['id']; // ID do perfil ou usuário
    $permissoes_selecionadas = $_POST['permissoes'] ?? [];

    // Limpar permissões anteriores
    if ($tipo === 'perfil') {
        $stmtLimpar = $conn->prepare("DELETE FROM perfil_permissoes WHERE perfil_id = ?");
    } else {
        $stmtLimpar = $conn->prepare("DELETE FROM usuario_permissoes WHERE usuario_id = ?");
    }
    $stmtLimpar->execute([$id]);

    // Inserir novas permissões
    if ($tipo === 'perfil') {
        $stmtInserir = $conn->prepare("INSERT INTO perfil_permissoes (perfil_id, permissao_id) VALUES (?, ?)");
    } else {
        $stmtInserir = $conn->prepare("INSERT INTO usuario_permissoes (usuario_id, permissao_id) VALUES (?, ?)");
    }
    foreach ($permissoes_selecionadas as $permissao_id) {
        $stmtInserir->execute([$id, $permissao_id]);
    }

    header('Location: gerenciar_permissoes.php?status=sucesso');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Permissões</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Gerenciar Permissões</h1>
        <?php if (isset($_GET['status']) && $_GET['status'] === 'sucesso'): ?>
            <div class="alert alert-success">Permissões atualizadas com sucesso!</div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label for="tipo" class="form-label">Gerenciar Permissões para</label>
                <select id="tipo" name="tipo" class="form-select" required>
                    <option value="perfil">Perfil</option>
                    <option value="usuario">Usuário</option>
                </select>
            </div>
            <div class="mb-3" id="selecionar-id">
                <label for="id" class="form-label">Selecione</label>
                <select id="id" name="id" class="form-select" required>
                    <!-- Populado dinamicamente -->
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Permissões Disponíveis</label>
                <div id="permissoes">
                    <?php foreach ($modulos as $modulo): ?>
                        <div class="form-check">
                            <input class="form-check-input" type="checkbox" id="modulo-<?= $modulo['id'] ?>" name="permissoes[]" value="<?= $modulo['id'] ?>">
                            <label class="form-check-label" for="modulo-<?= $modulo['id'] ?>">
                                <?= $modulo['nome'] ?>
                            </label>
                        </div>
                    <?php endforeach; ?>
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Salvar Permissões</button>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script>
        document.getElementById('tipo').addEventListener('change', function () {
            const tipo = this.value;
            const idSelect = document.getElementById('id');
            idSelect.innerHTML = '';
            const options = <?= json_encode(['perfil' => $perfis, 'usuario' => $usuarios]) ?>;
            options[tipo].forEach(item => {
                const option = document.createElement('option');
                option.value = item.id;
                option.textContent = item.nome;
                idSelect.appendChild(option);
            });
        });
    </script>
</body>
</html>