<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Histórico Consolidado por Paciente</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Histórico Consolidado por Paciente</h1>
        
        <!-- Filtros -->
        <form method="GET" class="mb-4">
            <div class="row">
                <div class="col-md-3 mb-3">
                    <label for="paciente" class="form-label">Código ou Nome do Paciente</label>
                    <input type="text" id="paciente" name="paciente" class="form-control" value="<?= htmlspecialchars($paciente) ?>">
                </div>
                <div class="col-md-3 mb-3">
                    <label for="data_inicio" class="form-label">Data Início</label>
                    <input type="date" id="data_inicio" name="data_inicio" class="form-control" value="<?= htmlspecialchars($data_inicio) ?>">
                </div>
                <div class="col-md-3 mb-3">
                    <label for="data_fim" class="form-label">Data Fim</label>
                    <input type="date" id="data_fim" name="data_fim" class="form-control" value="<?= htmlspecialchars($data_fim) ?>">
                </div>
                <div class="col-md-3 mb-3">
                    <label for="status" class="form-label">Status</label>
                    <select id="status" name="status" class="form-select">
                        <option value="">Todos</option>
                        <option value="Aberto" <?= $status === 'Aberto' ? 'selected' : '' ?>>Aberto</option>
                        <option value="Pendente" <?= $status === 'Pendente' ? 'selected' : '' ?>>Pendente</option>
                        <option value="Fechado" <?= $status === 'Fechado' ? 'selected' : '' ?>>Fechado</option>
                    </select>
                </div>
                <div class="col-md-3 mb-3">
                    <label for="programa" class="form-label">Programa</label>
                    <input type="text" id="programa" name="programa" class="form-control" value="<?= htmlspecialchars($programa) ?>">
                </div>
                <div class="col-md-3 mb-3">
                    <label for="motivo" class="form-label">Motivo</label>
                    <input type="text" id="motivo" name="motivo" class="form-control" value="<?= htmlspecialchars($motivo) ?>">
                </div>
            </div>
            <button type="submit" class="btn btn-primary">Filtrar</button>
        </form>

        <!-- Tabela -->
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Código do Paciente</th>
                    <th>Data/Hora Início</th>
                    <th>Data/Hora Fim</th>
                    <th>Atendente</th>
                    <th>Programa</th>
                    <th>Motivo</th>
                    <th>Origem</th>
                    <th>Status</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($atendimentos as $atendimento): ?>
                    <tr>
                        <td><?= $atendimento['id'] ?></td>
                        <td><?= $atendimento['codigo_paciente'] ?></td>
                        <td><?= $atendimento['data_inicio'] ?></td>
                        <td><?= $atendimento['data_fim'] ?></td>
                        <td><?= $atendimento['atendente'] ?></td>
                        <td><?= $atendimento['programa'] ?></td>
                        <td><?= $atendimento['motivo'] ?></td>
                        <td><?= $atendimento['origem'] ?></td>
                        <td><?= ucfirst($atendimento['status']) ?></td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>

        <!-- Exportação -->
        <a href="exportar_historico.php?<?= http_build_query($_GET) ?>" class="btn btn-success">Exportar para PDF</a>
        <a href="exportar_historico_excel.php?<?= http_build_query($_GET) ?>" class="btn btn-info">Exportar para Excel</a>
        <a href="exportar_historico_word.php?<?= http_build_query($_GET) ?>" class="btn btn-secondary">Exportar para Word</a>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>