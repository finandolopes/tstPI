<?php
session_start();
require 'backend/conexao.php';

$usuarioId = $_SESSION['usuario_id'];

// Buscar permissões do usuário logado
$stmtPermissoes = $conn->prepare("
    SELECT p.nome 
    FROM permissoes p
    JOIN usuario_permissoes up ON p.id = up.permissao_id
    WHERE up.usuario_id = ?
");
$stmtPermissoes->execute([$usuarioId]);
$permissoesUsuario = $stmtPermissoes->fetchAll(PDO::FETCH_COLUMN);

// Itens disponíveis no sidebar
$itensSidebar = [
    'Dashboard' => ['icon' => 'fas fa-home', 'link' => 'dashboard.php'],
    'Novo Atendimento' => ['icon' => 'fas fa-plus-circle', 'link' => 'novo_atendimento.php'],
    'Relatórios' => ['icon' => 'fas fa-chart-bar', 'link' => 'relatorios.php'],
    'Configurações' => ['icon' => 'fas fa-cogs', 'link' => 'configuracoes.php'],
    'Permissões' => ['icon' => 'fas fa-user-lock', 'link' => 'permissoes.php'],
];
?>
<aside class="main-sidebar sidebar-dark-primary elevation-4">
    <a href="#" class="brand-link">
        <img src="../assets/img/CROSS-.png" alt="Logo" class="brand-image img-circle elevation-3">
        <span class="brand-text font-weight-light">SA-CAT</span>
    </a>
    <div class="sidebar">
        <nav class="mt-2">
            <ul class="nav nav-pills nav-sidebar flex-column">
                <?php foreach ($itensSidebar as $nome => $item): ?>
                    <?php if (in_array($nome, $permissoesUsuario)): ?>
                        <li class="nav-item">
                            <a href="<?= $item['link'] ?>" class="nav-link">
                                <i class="nav-icon <?= $item['icon'] ?>"></i>
                                <p><?= $nome ?></p>
                            </a>
                        </li>
                    <?php endif; ?>
                <?php endforeach; ?>
            </ul>
        </nav>
    </div>
</aside>