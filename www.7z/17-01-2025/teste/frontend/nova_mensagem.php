<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

$usuario_id = $_SESSION['usuario_id'];

// Obter lista de usuários
$stmtUsuarios = $conn->query("SELECT id, nome FROM usuarios WHERE id != $usuario_id AND status = 'ativo'");
$usuarios = $stmtUsuarios->fetchAll(PDO::FETCH_ASSOC);

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $destinatario_id = $_POST['destinatario_id'];
    $assunto = $_POST['assunto'];
    $mensagem = $_POST['mensagem'];

    $stmtEnviar = $conn->prepare("INSERT INTO mensagens (remetente_id, destinatario_id, assunto, mensagem, data_envio, lida) VALUES (?, ?, ?, ?, NOW(), 0)");
    $stmtEnviar->execute([$usuario_id, $destinatario_id, $assunto, $mensagem]);

    header('Location: caixa_entrada.php?status=enviado');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Nova Mensagem</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Nova Mensagem</h1>
        <form method="POST">
            <div class="mb-3">
                <label for="destinatario_id" class="form-label">Destinatário</label>
                <select id="destinatario_id" name="destinatario_id" class="form-select" required>
                    <option value="">Selecione o destinatário</option>
                    <?php foreach ($usuarios as $usuario): ?>
                        <option value="<?= $usuario['id'] ?>"><?= $usuario['nome'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="assunto" class="form-label">Assunto</label>
                <input type="text" id="assunto" name="assunto" class="form-control" required>
            </div>
            <div class="mb-3">
                <label for="mensagem" class="form-label">Mensagem</label>
                <textarea id="mensagem" name="mensagem" class="form-control" rows="5" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Enviar</button>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>