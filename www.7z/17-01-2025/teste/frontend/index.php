<?php
session_start();
if (isset($_SESSION['usuario_id'])) {
    header('Location: dashboard.php');
    exit;
}

$erro = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    require 'backend/conexao.php';

    $login = $_POST['login'];
    $senha = $_POST['senha'];

    $stmt = $conn->prepare("
        SELECT id, senha, nome, bloqueado, data_bloqueio 
        FROM usuarios 
        WHERE login = ? AND status = 'ativo'
    ");
    $stmt->execute([$login]);
    $usuario = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($usuario) {
        if ($usuario['bloqueado']) {
            $erro = 'Sua conta está bloqueada. Entre em contato com o administrador.';
        } elseif (password_verify($senha, $usuario['senha'])) {
            $_SESSION['usuario_id'] = $usuario['id'];
            $_SESSION['usuario_nome'] = $usuario['nome'];

            $stmt = $conn->prepare("INSERT INTO login_attempts (usuario_id, ip_address, status) VALUES (?, ?, 'success')");
            $stmt->execute([$usuario['id'], $_SERVER['REMOTE_ADDR']]);

            header('Location: dashboard.php');
            exit;
        } else {
            registrarFalhaLogin($conn, $usuario['id']);
            $erro = 'Login ou senha inválidos.';
        }
    } else {
        registrarFalhaLogin($conn, null);
        $erro = 'Login ou senha inválidos.';
    }
}

function registrarFalhaLogin($conn, $usuarioId) {
    $stmt = $conn->prepare("INSERT INTO login_attempts (usuario_id, ip_address, status) VALUES (?, ?, 'failed')");
    $stmt->execute([$usuarioId, $_SERVER['REMOTE_ADDR']]);

    // Bloqueio após 5 tentativas falhas
    $stmt = $conn->prepare("
        SELECT COUNT(*) as falhas 
        FROM login_attempts 
        WHERE ip_address = ? AND status = 'failed' AND timestamp > NOW() - INTERVAL 15 MINUTE
    ");
    $stmt->execute([$_SERVER['REMOTE_ADDR']]);
    $falhas = $stmt->fetchColumn();

    if ($falhas >= 5 && $usuarioId) {
        $stmt = $conn->prepare("UPDATE usuarios SET bloqueado = 1, data_bloqueio = NOW() WHERE id = ?");
        $stmt->execute([$usuarioId]);
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login - Sistema de Atendimento</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body class="bg-light">
    <div class="container d-flex justify-content-center align-items-center vh-100">
        <div class="card shadow-sm p-4" style="width: 400px;">
            <h3 class="text-center mb-4">Sistema de Atendimento</h3>
            <?php if ($erro): ?>
                <div class="alert alert-danger"><?= $erro ?></div>
            <?php endif; ?>
            <form method="POST">
                <div class="mb-3">
                    <label for="login" class="form-label">Login</label>
                    <input type="text" class="form-control" id="login" name="login" required>
                </div>
                <div class="mb-3">
                    <label for="senha" class="form-label">Senha</label>
                    <input type="password" class="form-control" id="senha" name="senha" required>
                </div>
                <button type="submit" class="btn btn-primary w-100">Entrar</button>
            </form>
        </div>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
