<?php
require 'backend/conexao.php';

$token = $_GET['token'] ?? null;
$novaSenha = $_POST['nova_senha'] ?? null;

if ($token) {
    // Validar token
    $stmt = $conn->prepare("SELECT usuario_id FROM recuperacao_senha WHERE token = ? AND expiracao > NOW()");
    $stmt->execute([$token]);
    $recuperacao = $stmt->fetch(PDO::FETCH_ASSOC);

    if ($recuperacao && $_SERVER['REQUEST_METHOD'] === 'POST') {
        // Atualizar senha
        $novaSenhaHash = password_hash($novaSenha, PASSWORD_DEFAULT);
        $stmtAtualizar = $conn->prepare("UPDATE usuarios SET senha = ? WHERE id = ?");
        $stmtAtualizar->execute([$novaSenhaHash, $recuperacao['usuario_id']]);

        // Excluir token
        $stmtExcluir = $conn->prepare("DELETE FROM recuperacao_senha WHERE token = ?");
        $stmtExcluir->execute([$token]);

        header('Location: index.php?status=senha_redefinida');
        exit;
    } elseif ($_SERVER['REQUEST_METHOD'] === 'POST') {
        $erro = "Token inválido ou expirado.";
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Redefinir Senha</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body class="d-flex justify-content-center align-items-center vh-100">
    <div class="card p-4" style="width: 400px;">
        <h3 class="text-center">Redefinir Senha</h3>
        <?php if (isset($erro)): ?>
            <div class="alert alert-danger"><?= $erro ?></div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label for="nova_senha" class="form-label">Nova Senha</label>
                <input type="password" name="nova_senha" id="nova_senha" class="form-control" required>
            </div>
            <button type="submit" class="btn btn-primary w-100">Salvar Nova Senha</button>
        </form>
    </div>
</body>
</html>