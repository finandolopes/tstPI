<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Obter lista de usuários e permissões disponíveis
$usuarios = $conn->query("SELECT id, nome FROM usuarios")->fetchAll(PDO::FETCH_ASSOC);
$permissoes = $conn->query("SELECT id, recurso FROM permissoes")->fetchAll(PDO::FETCH_ASSOC);

// Verificar se foi submetida uma alteração de permissões
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario_id = $_POST['usuario_id'];
    $permissoes_selecionadas = $_POST['permissoes'] ?? [];

    try {
        // Remover permissões antigas
        $conn->prepare("DELETE FROM usuarios_permissoes WHERE usuario_id = ?")->execute([$usuario_id]);

        // Adicionar novas permissões
        $stmtInsert = $conn->prepare("INSERT INTO usuarios_permissoes (usuario_id, permissao_id) VALUES (?, ?)");
        foreach ($permissoes_selecionadas as $permissao_id) {
            $stmtInsert->execute([$usuario_id, $permissao_id]);
        }
        $mensagemSucesso = "Permissões atualizadas com sucesso!";
    } catch (Exception $e) {
        $mensagemErro = "Erro ao atualizar permissões: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Permissões por Usuário</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
            <li class="nav-item">
                <span class="nav-link">Bem-vindo, <strong><?= htmlspecialchars($_SESSION['usuario_nome']); ?></strong></span>
            </li>
        </ul>
    </nav>

    <!-- Sidebar -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <a href="#" class="brand-link">
            <img src="assets/img/CROSS-.png" alt="Logo" class="brand-image img-circle elevation-3">
            <span class="brand-text font-weight-light">SA-CAT</span>
        </a>
        <div class="sidebar">
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column">
                    <li class="nav-item">
                        <a href="dashboard.php" class="nav-link">
                            <i class="nav-icon fas fa-home"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="permissoes-usuario.php" class="nav-link active">
                            <i class="nav-icon fas fa-user-shield"></i>
                            <p>Permissões</p>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Permissões por Usuário</h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                <?php if (isset($mensagemErro)): ?>
                    <script>
                        Swal.fire('Erro', '<?= $mensagemErro ?>', 'error');
                    </script>
                <?php elseif (isset($mensagemSucesso)): ?>
                    <script>
                        Swal.fire('Sucesso', '<?= $mensagemSucesso ?>', 'success');
                    </script>
                <?php endif; ?>

                <form method="POST">
                    <div class="mb-3">
                        <label for="usuario_id" class="form-label">Usuário</label>
                        <select id="usuario_id" name="usuario_id" class="form-select" required>
                            <option value="">Selecione o usuário</option>
                            <?php foreach ($usuarios as $usuario): ?>
                                <option value="<?= $usuario['id'] ?>"><?= $usuario['nome'] ?></option>
                            <?php endforeach; ?>
                        </select>
                    </div>
                    <div class="mb-3">
                        <label for="permissoes" class="form-label">Permissões Disponíveis</label>
                        <div class="row">
                            <?php foreach ($permissoes as $permissao): ?>
                                <div class="col-md-4">
                                    <div class="form-check">
                                        <input class="form-check-input" type="checkbox" name="permissoes[]" value="<?= $permissao['id'] ?>" id="permissao-<?= $permissao['id'] ?>">
                                        <label class="form-check-label" for="permissao-<?= $permissao['id'] ?>">
                                            <?= $permissao['recurso'] ?>
                                        </label>
                                    </div>
                                </div>
                            <?php endforeach; ?>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary">Salvar Permissões</button>
                </form>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="main-footer text-center">
        <strong>&copy; <?= date('Y') ?> SA-CAT</strong>
    </footer>
</div>
</body>
</html>
