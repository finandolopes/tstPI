<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['perfil'] !== 'administrador') {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Obter perfis e permissões
$perfis = $conn->query("SELECT * FROM perfis")->fetchAll(PDO::FETCH_ASSOC);
$recursos = $conn->query("SELECT * FROM recursos")->fetchAll(PDO::FETCH_ASSOC);

// Atualizar permissões
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $perfil_id = $_POST['perfil'];
    $recursos_selecionados = $_POST['recursos'] ?? [];

    $conn->prepare("DELETE FROM permissoes WHERE perfil_id = ?")->execute([$perfil_id]);

    foreach ($recursos_selecionados as $recurso_id) {
        $stmt = $conn->prepare("INSERT INTO permissoes (perfil_id, recurso_id) VALUES (?, ?)");
        $stmt->execute([$perfil_id, $recurso_id]);
    }

    header("Location: configurar-perfis.php?status=sucesso");
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurar Perfis</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Configurar Perfis</h1>
        <?php if (isset($_GET['status']) && $_GET['status'] === 'sucesso'): ?>
            <div class="alert alert-success">Permissões atualizadas com sucesso!</div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label for="perfil" class="form-label">Selecione o Perfil</label>
                <select id="perfil" name="perfil" class="form-select" required>
                    <?php foreach ($perfis as $perfil): ?>
                        <option value="<?= $perfil['id'] ?>"><?= $perfil['nome'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label class="form-label">Recursos Disponíveis</label>
                <?php foreach ($recursos as $recurso): ?>
                    <div class="form-check">
                        <input class="form-check-input" type="checkbox" name="recursos[]" value="<?= $recurso['id'] ?>" id="recurso-<?= $recurso['id'] ?>">
                        <label class="form-check-label" for="recurso-<?= $recurso['id'] ?>"><?= $recurso['nome'] ?></label>
                    </div>
                <?php endforeach; ?>
            </div>
            <button type="submit" class="btn btn-primary">Salvar Permissões</button>
        </form>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
