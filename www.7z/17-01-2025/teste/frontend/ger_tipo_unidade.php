<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['perfil'] !== 'administrador_sistema') {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Obter lista de tipos de unidades
$stmtTipos = $conn->query("SELECT id, nome, descricao FROM tipos_unidade");
$tiposUnidade = $stmtTipos->fetchAll(PDO::FETCH_ASSOC);

// Lógica de exclusão
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    $stmtDelete = $conn->prepare("DELETE FROM tipos_unidade WHERE id = ?");
    $stmtDelete->execute([$delete_id]);
    header('Location: gerenciar-tipos-unidade.php?status=excluido');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciar Tipos de Unidades</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Gerenciar Tipos de Unidades</h1>
        <?php if (isset($_GET['status']) && $_GET['status'] === 'excluido'): ?>
            <div class="alert alert-success">Tipo de unidade excluído com sucesso!</div>
        <?php endif; ?>
        <table class="table table-bordered">
            <thead>
                <tr>
                    <th>ID</th>
                    <th>Nome</th>
                    <th>Descrição</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($tiposUnidade as $tipo): ?>
                    <tr>
                        <td><?= $tipo['id'] ?></td>
                        <td><?= $tipo['nome'] ?></td>
                        <td><?= $tipo['descricao'] ?></td>
                        <td>
                            <a href="editar-tipo-unidade.php?id=<?= $tipo['id'] ?>" class="btn btn-warning btn-sm">Editar</a>
                            <a href="gerenciar-tipos-unidade.php?delete_id=<?= $tipo['id'] ?>" class="btn btn-danger btn-sm" onclick="return confirm('Tem certeza que deseja excluir este tipo de unidade?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
        <a href="novo-tipo-unidade.php" class="btn btn-primary">+ Novo Tipo de Unidade</a>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>