<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Capturar filtros do formulário
$atendente = $_GET['atendente'] ?? null;
$data_inicio = $_GET['data_inicio'] ?? null;
$data_fim = $_GET['data_fim'] ?? null;

// Consultar dados do relatório
$query = "
    SELECT 
        u.nome AS atendente,
        COUNT(a.id) AS total_atendimentos,
        SUM(CASE WHEN a.status = 'Finalizado' THEN 1 ELSE 0 END) AS finalizados,
        SUM(CASE WHEN a.status = 'Pendente' THEN 1 ELSE 0 END) AS pendentes
    FROM atendimentos a
    JOIN usuarios u ON a.usuario_id = u.id
    WHERE 1=1
";

$params = [];
if ($atendente) {
    $query .= " AND a.usuario_id = ?";
    $params[] = $atendente;
}
if ($data_inicio && $data_fim) {
    $query .= " AND DATE(a.data_inicio) BETWEEN ? AND ?";
    $params[] = $data_inicio;
    $params[] = $data_fim;
}

$query .= " GROUP BY u.id ORDER BY total_atendimentos DESC";
$stmt = $conn->prepare($query);
$stmt->execute($params);

$relatorio = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório de Produtividade</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">
    <!-- Navbar -->
    <?php include 'includes/navbar.php'; ?>
    <!-- Sidebar -->
    <?php include 'includes/sidebar.php'; ?>

    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Relatório de Produtividade por Atendente</h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                <!-- Formulário de Filtros -->
                <form method="GET" class="row mb-4">
                    <div class="col-md-4">
                        <label for="atendente" class="form-label">Atendente</label>
                        <select name="atendente" id="atendente" class="form-select">
                            <option value="">Todos</option>
                            <?php
                            $usuarios = $conn->query("SELECT id, nome FROM usuarios")->fetchAll(PDO::FETCH_ASSOC);
                            foreach ($usuarios as $usuario) {
                                echo "<option value='{$usuario['id']}'" . ($atendente == $usuario['id'] ? ' selected' : '') . ">{$usuario['nome']}</option>";
                            }
                            ?>
                        </select>
                    </div>
                    <div class="col-md-3">
                        <label for="data_inicio" class="form-label">Data Início</label>
                        <input type="date" name="data_inicio" id="data_inicio" class="form-control" value="<?= htmlspecialchars($data_inicio) ?>">
                    </div>
                    <div class="col-md-3">
                        <label for="data_fim" class="form-label">Data Fim</label>
                        <input type="date" name="data_fim" id="data_fim" class="form-control" value="<?= htmlspecialchars($data_fim) ?>">
                    </div>
                    <div class="col-md-2 mt-4">
                        <button type="submit" class="btn btn-primary w-100">Gerar Relatório</button>
                    </div>
                </form>

                <!-- Tabela de Relatório -->
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>Atendente</th>
                            <th>Total de Atendimentos</th>
                            <th>Finalizados</th>
                            <th>Pendentes</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if (!empty($relatorio)): ?>
                            <?php foreach ($relatorio as $item): ?>
                                <tr>
                                    <td><?= htmlspecialchars($item['atendente']) ?></td>
                                    <td><?= htmlspecialchars($item['total_atendimentos']) ?></td>
                                    <td><?= htmlspecialchars($item['finalizados']) ?></td>
                                    <td><?= htmlspecialchars($item['pendentes']) ?></td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="4" class="text-center">Nenhum registro encontrado.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>

                <!-- Botões de Exportação -->
                <div class="mb-3">
                    <a href="exportar_relatorio_produtividade.php?formato=pdf&atendente=<?= $atendente ?>&data_inicio=<?= $data_inicio ?>&data_fim=<?= $data_fim ?>" class="btn btn-danger">Exportar para PDF</a>
                    <a href="exportar_relatorio_produtividade.php?formato=excel&atendente=<?= $atendente ?>&data_inicio=<?= $data_inicio ?>&data_fim=<?= $data_fim ?>" class="btn btn-success">Exportar para Excel</a>
                    <a href="exportar_relatorio_produtividade.php?formato=word&atendente=<?= $atendente ?>&data_inicio=<?= $data_inicio ?>&data_fim=<?= $data_fim ?>" class="btn btn-primary">Exportar para Word</a>
                </div>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <?php include 'includes/footer.php'; ?>
</div>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>