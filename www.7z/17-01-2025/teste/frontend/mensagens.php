<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Lógica para enviar mensagem
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $destinatario_id = $_POST['destinatario_id'];
    $mensagem = $_POST['mensagem'];

    $stmt = $conn->prepare("INSERT INTO mensagens (remetente_id, destinatario_id, mensagem) VALUES (?, ?, ?)");
    $stmt->execute([$_SESSION['usuario_id'], $destinatario_id, $mensagem]);

    header('Location: mensagens.php?status=sucesso');
    exit;
}

// Obter usuários para enviar mensagem
$stmtUsuarios = $conn->query("SELECT id, nome FROM usuarios");
$usuarios = $stmtUsuarios->fetchAll(PDO::FETCH_ASSOC);

// Obter mensagens recebidas
$stmtMensagens = $conn->prepare("
    SELECT m.mensagem, u.nome AS remetente
    FROM mensagens m
    JOIN usuarios u ON m.remetente_id = u.id
    WHERE m.destinatario_id = ?
    ORDER BY m.data_hora DESC
");
$stmtMensagens->execute([$_SESSION['usuario_id']]);
$mensagens = $stmtMensagens->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mensagens Internas</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container my-4">
        <h1>Mensagens Internas</h1>
        <?php if (isset($_GET['status']) && $_GET['status'] === 'sucesso'): ?>
            <div class="alert alert-success">Mensagem enviada com sucesso!</div>
        <?php endif; ?>
        <form method="POST">
            <div class="mb-3">
                <label for="destinatario_id" class="form-label">Destinatário</label>
                <select id="destinatario_id" name="destinatario_id" class="form-select" required>
                    <?php foreach ($usuarios as $usuario): ?>
                        <option value="<?= $usuario['id'] ?>"><?= $usuario['nome'] ?></option>
                    <?php endforeach; ?>
                </select>
            </div>
            <div class="mb-3">
                <label for="mensagem" class="form-label">Mensagem</label>
                <textarea id="mensagem" name="mensagem" class="form-control" rows="3" required></textarea>
            </div>
            <button type="submit" class="btn btn-primary">Enviar</button>
        </form>
        <h2 class="mt-4">Mensagens Recebidas</h2>
        <ul class="list-group">
            <?php foreach ($mensagens as $mensagem): ?>
                <li class="list-group-item">
                    <strong><?= $mensagem['remetente'] ?>:</strong> <?= $mensagem['mensagem'] ?>
                </li>
            <?php endforeach; ?>
        </ul>
    </div>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
</body>
</html>
