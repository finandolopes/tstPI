<?php
session_start();
if (!isset($_SESSION['usuario_id']) || !in_array($_SESSION['perfil'], ['coordenador', 'administrador', 'administrador_sistema'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Filtros de busca
$whereClauses = [];
$params = [];

if (!empty($_GET['nome_paciente'])) {
    $whereClauses[] = "p.nome LIKE ?";
    $params[] = "%" . $_GET['nome_paciente'] . "%";
}
if (!empty($_GET['codigo_paciente'])) {
    $whereClauses[] = "a.codigo_paciente = ?";
    $params[] = $_GET['codigo_paciente'];
}
if (!empty($_GET['data_inicio']) && !empty($_GET['data_fim'])) {
    $whereClauses[] = "DATE(a.data_inicio) BETWEEN ? AND ?";
    $params[] = $_GET['data_inicio'];
    $params[] = $_GET['data_fim'];
}

$where = $whereClauses ? "WHERE " . implode(" AND ", $whereClauses) : "";

// Obter atendimentos
$query = "
    SELECT a.id, a.codigo_paciente, a.data_inicio, a.descricao, u.nome AS atendente, a.status 
    FROM atendimentos a
    JOIN usuarios u ON a.usuario_id = u.id
    $where
    ORDER BY a.data_inicio DESC
    LIMIT 10
";
$stmt = $conn->prepare($query);
$stmt->execute($params);
$atendimentos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lista de Atendimentos</title>
    <link href="favicon.ico" type="image/ico" rel="icon">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
            <li class="nav-item">
                <span class="nav-link">Bem-vindo, <strong>Usuário</strong></span>
            </li>
        </ul>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
                <a class="nav-link" data-bs-toggle="dropdown" href="#">
                    <i class="fas fa-user"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a href="#" class="dropdown-item">Minha Conta</a></li>
                    <li><a href="logout.php" class="dropdown-item">Sair</a></li>
                </ul>
            </li>
        </ul>
    </nav>

    <!-- Sidebar -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <a href="#" class="brand-link">
            <img src="../assets/img/CROSS-.png" alt="Logo" class="brand-image img-circle elevation-3">
            <span class="brand-text font-weight-light">SA-CAT</span>
        </a>
        <div class="sidebar">
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column">
                    <li class="nav-item">
                        <a href="dashboard.html" class="nav-link">
                            <i class="nav-icon fas fa-home"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="novo_atendimento.html" class="nav-link">
                            <i class="nav-icon fas fa-plus-circle"></i>
                            <p>Novo Atendimento</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="lista_atendimentos.php" class="nav-link active">
                            <i class="nav-icon fas fa-list"></i>
                            <p>Lista de Atendimentos</p>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <h3>Lista de Atendimentos</h3>
                <form method="GET" class="mb-4">
                    <div class="row">
                        <div class="col-md-4">
                            <label for="nome_paciente">Nome do Paciente</label>
                            <input type="text" id="nome_paciente" name="nome_paciente" class="form-control" value="<?= htmlspecialchars($_GET['nome_paciente'] ?? '') ?>">
                        </div>
                        <div class="col-md-4">
                            <label for="codigo_paciente">Código do Paciente</label>
                            <input type="text" id="codigo_paciente" name="codigo_paciente" class="form-control" value="<?= htmlspecialchars($_GET['codigo_paciente'] ?? '') ?>">
                        </div>
                        <div class="col-md-4">
                            <label for="data_inicio">Data de Início</label>
                            <input type="date" id="data_inicio" name="data_inicio" class="form-control" value="<?= htmlspecialchars($_GET['data_inicio'] ?? '') ?>">
                        </div>
                        <div class="col-md-4 mt-2">
                            <label for="data_fim">Data de Fim</label>
                            <input type="date" id="data_fim" name="data_fim" class="form-control" value="<?= htmlspecialchars($_GET['data_fim'] ?? '') ?>">
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary mt-3">Filtrar</button>
                </form>
                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Código do Paciente</th>
                            <th>Data de Início</th>
                            <th>Atendente</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($atendimentos as $atendimento): ?>
                            <tr>
                                <td><?= $atendimento['id'] ?></td>
                                <td><?= htmlspecialchars($atendimento['codigo_paciente']) ?></td>
                                <td><?= $atendimento['data_inicio'] ?></td>
                                <td><?= htmlspecialchars($atendimento['atendente']) ?></td>
                                <td><?= ucfirst($atendimento['status']) ?></td>
                                <td>
                                    <button class="btn btn-info btn-sm" data-id="<?= $atendimento['id'] ?>" onclick="visualizarAtendimento(this)">Visualizar</button>
                                    <?php if (in_array($_SESSION['perfil'], ['administrador', 'administrador_sistema'])): ?>
                                        <button class="btn btn-warning btn-sm" data-id="<?= $atendimento['id'] ?>" onclick="editarAtendimento(this)">Editar</button>
                                        <button class="btn btn-danger btn-sm" data-id="<?= $atendimento['id'] ?>" onclick="excluirAtendimento(this)">Excluir</button>
                                    <?php endif; ?>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </section>
    </div>

    <footer class="main-footer text-center">
        <strong>&copy; 2025 Sistema de Atendimento</strong>
    </footer>
</div>

<!-- Modal para Visualizar Atendimento -->
<div class="modal fade" id="visualizarModal" tabindex="-1" aria-labelledby="visualizarModalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="visualizarModalLabel">Visualizar Atendimento</h5>
                <button type="button" class="btn-close" data-bs-dismiss="modal" aria-label="Close"></button>
            </div>
            <div class="modal-body" id="visualizarContent">
                <!-- Conteúdo carregado dinamicamente -->
            </div>
        </div>
    </div>
</div>

<script>
function visualizarAtendimento(button) {
    const atendimentoId = button.getAttribute('data-id');
    $('#visualizarContent').html('Carregando...');
    $('#visualizarModal').modal('show');
    $.get(`visualizar_atendimento.php?id=${atendimentoId}`, function(data) {
        $('#visualizarContent').html(data);
    });
}

function editarAtendimento(button) {
    const atendimentoId = button.getAttribute('data-id');
    window.location.href = `editar_atendimento.php?id=${atendimentoId}`;
}

function excluirAtendimento(button) {
    const atendimentoId = button.getAttribute('data-id');
    Swal.fire({
        title: 'Tem certeza?',
        text: 'Você não poderá reverter esta ação!',
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#d33',
        cancelButtonColor: '#3085d6',
        confirmButtonText: 'Sim, excluir!',
        cancelButtonText: 'Cancelar'
    }).then((result) => {
        if (result.isConfirmed) {
            $.post(`excluir_atendimento.php`, { id: atendimentoId }, function(response) {
                if (response.success) {
                    Swal.fire('Excluído!', 'O atendimento foi excluído com sucesso.', 'success').then(() => {
                        location.reload();
                    });
                } else {
                    Swal.fire('Erro!', response.message, 'error');
                }
            }, 'json');
        }
    });
}
</script>

<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>