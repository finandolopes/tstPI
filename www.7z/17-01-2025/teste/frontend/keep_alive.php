<?php
session_start();
if (isset($_SESSION['usuario_id'])) {
    $_SESSION['last_activity'] = time();
}
?>