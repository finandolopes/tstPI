<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Obter lista de recursos
$mensagemErro = null;
$mensagemSucesso = null;

try {
    $stmtRecursos = $conn->query("SELECT id, nome, tipo, status FROM recursos");
    $recursos = $stmtRecursos->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    $mensagemErro = "Erro ao carregar os recursos: " . $e->getMessage();
}

// Lógica de exclusão de recurso
if (isset($_GET['delete_id'])) {
    $delete_id = $_GET['delete_id'];
    try {
        $stmtDelete = $conn->prepare("DELETE FROM recursos WHERE id = ?");
        $stmtDelete->execute([$delete_id]);
        $mensagemSucesso = "Recurso excluído com sucesso!";
    } catch (Exception $e) {
        $mensagemErro = "Erro ao excluir o recurso: " . $e->getMessage();
    }
}
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciamento de Recursos</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
            <li class="nav-item">
                <span class="nav-link">Bem-vindo, <strong><?= htmlspecialchars($_SESSION['usuario_nome']); ?></strong></span>
            </li>
        </ul>
    </nav>

    <!-- Sidebar -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <a href="#" class="brand-link">
            <img src="assets/img/CROSS-.png" alt="Logo" class="brand-image img-circle elevation-3">
            <span class="brand-text font-weight-light">SA-CAT</span>
        </a>
        <div class="sidebar">
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column">
                    <li class="nav-item">
                        <a href="dashboard.php" class="nav-link">
                            <i class="nav-icon fas fa-home"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="gerenciar-recursos.php" class="nav-link active">
                            <i class="nav-icon fas fa-cogs"></i>
                            <p>Gerenciar Recursos</p>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <div class="content-header">
            <div class="container-fluid">
                <div class="row mb-2">
                    <div class="col-sm-6">
                        <h1 class="m-0">Gerenciamento de Recursos</h1>
                    </div>
                </div>
            </div>
        </div>

        <div class="content">
            <div class="container-fluid">
                <?php if ($mensagemErro): ?>
                    <script>
                        Swal.fire('Erro', '<?= $mensagemErro ?>', 'error');
                    </script>
                <?php elseif ($mensagemSucesso): ?>
                    <script>
                        Swal.fire('Sucesso', '<?= $mensagemSucesso ?>', 'success');
                    </script>
                <?php endif; ?>

                <table class="table table-bordered">
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Tipo</th>
                            <th>Status</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php if ($recursos): ?>
                            <?php foreach ($recursos as $recurso): ?>
                                <tr>
                                    <td><?= $recurso['id'] ?></td>
                                    <td><?= $recurso['nome'] ?></td>
                                    <td><?= ucfirst($recurso['tipo']) ?></td>
                                    <td><?= ucfirst($recurso['status']) ?></td>
                                    <td>
                                        <a href="editar-recurso.php?id=<?= $recurso['id'] ?>" class="btn btn-warning btn-sm">
                                            <i class="fas fa-edit"></i> Editar
                                        </a>
                                        <a href="javascript:void(0);" onclick="confirmExclusao(<?= $recurso['id'] ?>)" class="btn btn-danger btn-sm">
                                            <i class="fas fa-trash"></i> Excluir
                                        </a>
                                    </td>
                                </tr>
                            <?php endforeach; ?>
                        <?php else: ?>
                            <tr>
                                <td colspan="5" class="text-center">Nenhum recurso encontrado.</td>
                            </tr>
                        <?php endif; ?>
                    </tbody>
                </table>
                <a href="novo-recurso.php" class="btn btn-primary">+ Novo Recurso</a>
            </div>
        </div>
    </div>

    <!-- Footer -->
    <footer class="main-footer text-center">
        <strong>&copy; <?= date('Y') ?> SA-CAT</strong>
    </footer>
</div>

<script>
    function confirmExclusao(id) {
        Swal.fire({
            title: 'Tem certeza?',
            text: "Você não poderá reverter esta ação!",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#d33',
            cancelButtonColor: '#3085d6',
            confirmButtonText: 'Sim, excluir!',
            cancelButtonText: 'Cancelar'
        }).then((result) => {
            if (result.isConfirmed) {
                window.location.href = `gerenciar-recursos.php?delete_id=${id}`;
            }
        });
    }
</script>
</body>
</html>
