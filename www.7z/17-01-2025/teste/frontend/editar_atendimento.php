<?php
session_start();
if (!isset($_SESSION['usuario_id']) || !in_array($_SESSION['perfil'], ['coordenador', 'administrador', 'administrador_sistema'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Verificar se o ID foi passado
if (!isset($_GET['id']) || empty($_GET['id'])) {
    header('Location: lista_atendimentos.php');
    exit;
}

$id = $_GET['id'];

// Buscar dados do atendimento
$stmt = $conn->prepare("
    SELECT a.id, a.codigo_paciente, a.data_inicio, a.descricao, a.status, 
           a.unidade_solicitante, a.unidade_executante, 
           o.id AS origem_id, m.id AS motivo_id, r.id AS recurso_id,
           u.nome AS atendente
    FROM atendimentos a
    JOIN usuarios u ON a.usuario_id = u.id
    JOIN origens_atendimento o ON a.origem_id = o.id
    JOIN motivos_atendimento m ON a.motivo_id = m.id
    JOIN recursos r ON a.recurso_id = r.id
    WHERE a.id = ?
");
$stmt->execute([$id]);
$atendimento = $stmt->fetch(PDO::FETCH_ASSOC);

// Redirecionar caso não encontre o atendimento
if (!$atendimento) {
    header('Location: lista_atendimentos.php');
    exit;
}

// Obter listas para dropdowns
$origens = $conn->query("SELECT id, nome FROM origens_atendimento WHERE status = 'ativo'")->fetchAll(PDO::FETCH_ASSOC);
$motivos = $conn->query("SELECT id, nome FROM motivos_atendimento WHERE status = 'ativo'")->fetchAll(PDO::FETCH_ASSOC);
$recursos = $conn->query("SELECT id, nome FROM recursos WHERE status = 'ativo'")->fetchAll(PDO::FETCH_ASSOC);

// Atualizar atendimento
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $codigo_paciente = $_POST['codigo_paciente'];
    $descricao = $_POST['descricao'];
    $status = $_POST['status'];
    $unidade_solicitante = $_POST['unidade_solicitante'];
    $unidade_executante = $_POST['unidade_executante'];
    $origem_id = $_POST['origem'];
    $motivo_id = $_POST['motivo'];
    $recurso_id = $_POST['recurso'];

    $stmtUpdate = $conn->prepare("
        UPDATE atendimentos 
        SET codigo_paciente = ?, descricao = ?, status = ?, 
            unidade_solicitante = ?, unidade_executante = ?, 
            origem_id = ?, motivo_id = ?, recurso_id = ?
        WHERE id = ?
    ");
    $stmtUpdate->execute([
        $codigo_paciente, $descricao, $status, 
        $unidade_solicitante, $unidade_executante, 
        $origem_id, $motivo_id, $recurso_id, $id
    ]);

    header('Location: lista_atendimentos.php?status=atualizado');
    exit;
}
?>
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Editar Atendimento</title>
    <link href="favicon.ico" type="image/ico" rel="icon">
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/css/adminlte.min.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/js/bootstrap.bundle.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
</head>
<body class="hold-transition sidebar-mini layout-fixed">
<div class="wrapper">

    <!-- Navbar -->
    <nav class="main-header navbar navbar-expand navbar-white navbar-light">
        <ul class="navbar-nav">
            <li class="nav-item">
                <a class="nav-link" data-widget="pushmenu" href="#" role="button"><i class="fas fa-bars"></i></a>
            </li>
            <li class="nav-item">
                <span class="nav-link">Bem-vindo, <strong>Usuário</strong></span>
            </li>
        </ul>
        <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown">
                <a class="nav-link" data-bs-toggle="dropdown" href="#">
                    <i class="fas fa-user"></i>
                </a>
                <ul class="dropdown-menu dropdown-menu-end">
                    <li><a href="#" class="dropdown-item">Minha Conta</a></li>
                    <li><a href="logout.php" class="dropdown-item">Sair</a></li>
                </ul>
            </li>
        </ul>
    </nav>

    <!-- Sidebar -->
    <aside class="main-sidebar sidebar-dark-primary elevation-4">
        <a href="#" class="brand-link">
            <img src="../assets/img/CROSS-.png" alt="Logo" class="brand-image img-circle elevation-3">
            <span class="brand-text font-weight-light">SA-CAT</span>
        </a>
        <div class="sidebar">
            <nav class="mt-2">
                <ul class="nav nav-pills nav-sidebar flex-column">
                    <li class="nav-item">
                        <a href="dashboard.html" class="nav-link">
                            <i class="nav-icon fas fa-home"></i>
                            <p>Dashboard</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="novo_atendimento.html" class="nav-link">
                            <i class="nav-icon fas fa-plus-circle"></i>
                            <p>Novo Atendimento</p>
                        </a>
                    </li>
                    <li class="nav-item">
                        <a href="lista_atendimentos.php" class="nav-link">
                            <i class="nav-icon fas fa-list"></i>
                            <p>Lista de Atendimentos</p>
                        </a>
                    </li>
                </ul>
            </nav>
        </div>
    </aside>

    <!-- Content Wrapper -->
    <div class="content-wrapper">
        <section class="content-header">
            <div class="container-fluid">
                <h3>Editar Atendimento</h3>
                <form method="POST">
                    <div class="row">
                        <div class="col-lg-6">
                            <label>Código do Paciente</label>
                            <input type="text" name="codigo_paciente" class="form-control" value="<?= htmlspecialchars($atendimento['codigo_paciente']) ?>" required>
                        </div>
                        <div class="col-lg-6">
                            <label>Status</label>
                            <select name="status" class="form-control" required>
                                <option value="Aberto" <?= $atendimento['status'] === 'Aberto' ? 'selected' : '' ?>>Aberto</option>
                                <option value="Pendente" <?= $atendimento['status'] === 'Pendente' ? 'selected' : '' ?>>Pendente</option>
                                <option value="Fechado" <?= $atendimento['status'] === 'Fechado' ? 'selected' : '' ?>>Fechado</option>
                            </select>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-lg-6">
                            <label>Origem</label>
                            <select name="origem" class="form-control" required>
                                <?php foreach ($origens as $origem): ?>
                                    <option value="<?= $origem['id'] ?>" <?= $origem['id'] == $atendimento['origem_id'] ? 'selected' : '' ?>><?= htmlspecialchars($origem['nome']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-lg-6">
                            <label>Motivo</label>
                            <select name="motivo" class="form-control" required>
                                <?php foreach ($motivos as $motivo): ?>
                                    <option value="<?= $motivo['id'] ?>" <?= $motivo['id'] == $atendimento['motivo_id'] ? 'selected' : '' ?>><?= htmlspecialchars($motivo['nome']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                    </div>
                    <div class="row mt-3">
                        <div class="col-lg-6">
                            <label>Recurso</label>
                            <select name="recurso" class="form-control" required>
                                <?php foreach ($recursos as $recurso): ?>
                                    <option value="<?= $recurso['id'] ?>" <?= $recurso['id'] == $atendimento['recurso_id'] ? 'selected' : '' ?>><?= htmlspecialchars($recurso['nome']) ?></option>
                                <?php endforeach; ?>
                            </select>
                        </div>
                        <div class="col-lg-6">
                            <label>Descrição</label>
                            <textarea name="descricao" class="form-control" rows="3"><?= htmlspecialchars($atendimento['descricao']) ?></textarea>
                        </div>
                    </div>
                    <button type="submit" class="btn btn-primary mt-4">Salvar Alterações</button>
                </form>
            </div>
        </section>
    </div>

    <footer class="main-footer text-center">
        <strong>&copy; 2025 Sistema de Atendimento</strong>
    </footer>
</div>
<script src="https://cdn.jsdelivr.net/npm/admin-lte@3.2/dist/js/adminlte.min.js"></script>
</body>
</html>