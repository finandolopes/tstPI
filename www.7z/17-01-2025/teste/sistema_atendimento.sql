-- Criação do banco de dados
CREATE DATABASE IF NOT EXISTS sistema_atendimento;
USE sistema_atendimento;

-- Tabela de Estados
CREATE TABLE estados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    sigla VARCHAR(2) NOT NULL UNIQUE
    status ENUM('ativo', 'inativo') DEFAULT 'ativo',
);

-- Tabela de Perfis
CREATE TABLE perfis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL UNIQUE
);

-- Inserção dos Perfis
INSERT INTO perfis (id, nome)
VALUES
    (1, 'Administrador Sistema'),
    (2, 'Administrador'),
    (3, 'Coordenador Atendimento'),
    (4, 'Atendente')
    (5, 'Relatorio CAT')

ON DUPLICATE KEY UPDATE nome = VALUES(nome);

-- Tabela de Usuários
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    perfil_id INT NOT NULL,    
    status ENUM('ativo', 'inativo') DEFAULT 'ativo',
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (perfil_id) REFERENCES perfis(id)
);

-- Tabela de Permissões
CREATE TABLE permissoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    descricao TEXT
);

-- Tabela de Recursos
CREATE TABLE recursos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE
    status ENUM('ativo', 'inativo') DEFAULT 'ativo',
);

-- Tabela de Relação Usuário-Grupo
CREATE TABLE usuario_grupo (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    grupo_id INT NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (grupo_id) REFERENCES grupos(id) ON DELETE CASCADE
);

-- Tabela de Relação Grupo-Permissão
CREATE TABLE grupo_permissao (
    id INT AUTO_INCREMENT PRIMARY KEY,
    grupo_id INT NOT NULL,
    permissao_id INT NOT NULL,
    FOREIGN KEY (grupo_id) REFERENCES grupos(id) ON DELETE CASCADE,
    FOREIGN KEY (permissao_id) REFERENCES permissoes(id) ON DELETE CASCADE
);

-- Tabela de Origens de Atendimento
CREATE TABLE origens_atendimento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE
    status ENUM('ativo', 'inativo') DEFAULT 'ativo',
);

-- Tabela de Motivos de Atendimento
CREATE TABLE motivos_atendimento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    descricao TEXT,
    obrigatorio BOOLEAN DEFAULT FALSE,
    status ENUM('ativo', 'inativo') DEFAULT 'ativo',
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

-- Tabela de Atendimentos
CREATE TABLE atendimentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    data_inicio DATETIME DEFAULT CURRENT_TIMESTAMP,
    data_fim DATETIME,
    origem_id INT NOT NULL,
    recurso_id INT NOT NULL,
    motivo_id INT NOT NULL,
    descricao TEXT,
    codigo_paciente VARCHAR(50),
    unidade_solicitante VARCHAR(100),
    unidade_executante VARCHAR(100),
    status ENUM('Aberto', 'Pendente', 'Fechado') NOT NULL DEFAULT 'Aberto',
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    FOREIGN KEY (origem_id) REFERENCES origens_atendimento(id),
    FOREIGN KEY (recurso_id) REFERENCES recursos(id),
    FOREIGN KEY (motivo_id) REFERENCES motivos_atendimento(id)
);

-- Tabela de Municípios
CREATE TABLE municipios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    co_ibge VARCHAR(7) NOT NULL UNIQUE,
    nome VARCHAR(100) NOT NULL,
    no_municipio_cross VARCHAR(100),
    no_regiao_saude VARCHAR(100),
    no_drs VARCHAR(100),
    nu_rras VARCHAR(50),
    no_estado VARCHAR(100),
    cg_lat_municipio DECIMAL(9, 6),
    cg_lon_municipio DECIMAL(9, 6),
    qt_populacao_2018 INT,
    qtd_populacao_2022 INT,
    colegiado_id INT NOT NULL,
    estado_id INT NOT NULL,
    drs_id INT NOT NULL,
    status ENUM('ativo', 'inativo') DEFAULT 'ativo',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (colegiado_id) REFERENCES colegiados(id),
    FOREIGN KEY (estado_id) REFERENCES estados(id),
    FOREIGN KEY (drs_id) REFERENCES drs(id)
);

-- Tabela de Unidades
CREATE TABLE unidades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cnes VARCHAR(15) NOT NULL UNIQUE,
    nome VARCHAR(100) NOT NULL,
    municipio_id INT NOT NULL,
    tipo_unidade_id INT NOT NULL,
    co_ibge VARCHAR(7),
    no_municipio VARCHAR(100),
    no_municipio_cross VARCHAR(100),
    no_regiao_saude VARCHAR(100),
    no_drs VARCHAR(100),
    nu_rras VARCHAR(50),
    no_estado VARCHAR(100),
    cg_lat_municipio DECIMAL(9, 6),
    cg_lon_municipio DECIMAL(9, 6),
    qt_populacao_2018 INT,
    qtd_populacao_2022 INT,
    qtd_populacao_2023 INT,
    qtd_populacao_2024 INT,
    qtd_populacao_2025 INT,
    status ENUM('ativo', 'inativo') DEFAULT 'ativo',
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (municipio_id) REFERENCES municipios(id) ON DELETE CASCADE,
    FOREIGN KEY (tipo_unidade_id) REFERENCES tipos_unidade(id)
);

-- Tabela de Tipos de Unidades
CREATE TABLE tipos_unidade (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    descricao TEXT,
    status ENUM('ativo', 'inativo') DEFAULT 'ativo',
    criado_em DATETIME DEFAULT CURRENT_TIMESTAMP,
    atualizado_em DATETIME DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP
);

CREATE TABLE login_attempts (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NULL,
    ip_address VARCHAR(45) NOT NULL,
    status ENUM('success', 'failed') NOT NULL,
    timestamp DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE
);

ALTER TABLE usuarios ADD COLUMN bloqueado BOOLEAN DEFAULT FALSE;
ALTER TABLE usuarios ADD COLUMN data_bloqueio DATETIME NULL;

CREATE TABLE config_dashboard (
    id INT AUTO_INCREMENT PRIMARY KEY,
    perfil_id INT NOT NULL,
    card_id VARCHAR(50) NOT NULL,
    ativo BOOLEAN DEFAULT TRUE,
    FOREIGN KEY (perfil_id) REFERENCES perfis(id)
);

-- Tabela de Permissões (já existente)
CREATE TABLE IF NOT EXISTS permissoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL UNIQUE,
    descricao TEXT
);

-- Relação entre usuários e permissões
CREATE TABLE IF NOT EXISTS usuario_permissoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    permissao_id INT NOT NULL,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id) ON DELETE CASCADE,
    FOREIGN KEY (permissao_id) REFERENCES permissoes(id) ON DELETE CASCADE
);
-- Inserir o usuário "Fernando Silva" como Administrador Sistema
INSERT INTO usuarios (nome, email, senha, perfil_id, ativo, criado_em)
VALUES
    ('Fernando Silva', 'fernando.silva@cross.org.br', 
     '$2y$10$EGmqpAcxBsRW7J8U/9FDkuZPFPQ2FXmXOb4/eh1ri1xltQFvOc1Ga', 
     1, TRUE, NOW())
ON DUPLICATE KEY UPDATE nome = VALUES(nome), email = VALUES(email);
