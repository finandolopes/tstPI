<?php
header('Content-Type: application/json');

// Simular notificações
$notificacoes = [
    ['id' => 1, 'mensagem' => 'Novo atendimento aberto.', 'data_hora' => date('Y-m-d H:i:s')],
    ['id' => 2, 'mensagem' => 'Atendimento #001 foi finalizado.', 'data_hora' => date('Y-m-d H:i:s')],
];

echo json_encode($notificacoes);
