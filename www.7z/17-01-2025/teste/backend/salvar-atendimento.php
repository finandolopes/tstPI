<?php
require 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $atendente_id = $_POST['atendente_id'];
    $data_inicio = $_POST['inicio'];
    $origem_id = $_POST['origem'];
    $recurso_id = $_POST['recurso'];
    $motivo_id = $_POST['motivo'];
    $codigo_paciente = $_POST['codigo_paciente'];
    $descricao = $_POST['descricao'];
    $unidade_solicitante = $_POST['unidade_solicitante'];
    $unidade_executante = $_POST['unidade_executante'];
    $data_fim = date('Y-m-d H:i:s');

    $stmt = $conn->prepare("INSERT INTO atendimentos 
        (atendente_id, data_inicio, origem_id, recurso_id, motivo_id, codigo_paciente, descricao, unidade_solicitante, unidade_executante, data_fim) 
        VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)");
    $stmt->execute([
        $atendente_id, $data_inicio, $origem_id, $recurso_id, $motivo_id, $codigo_paciente, $descricao, $unidade_solicitante, $unidade_executante, $data_fim
    ]);

    header('Location: ../dashboard.php');
    exit();
}
if ($stmt->execute()) {
    echo "<script>alert('Atendimento salvo com sucesso!'); window.location.href='gerenciamento-atendimentos.html';</script>";
} else {
    echo "<script>alert('Erro ao salvar atendimento!'); window.location.href='novo-atendimento.html';</script>";
}

?>
