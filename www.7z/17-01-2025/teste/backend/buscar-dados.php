<?php
require 'conexao.php';

$origens = $conn->query("SELECT * FROM origens")->fetchAll(PDO::FETCH_ASSOC);
$recursos = $conn->query("SELECT * FROM recursos")->fetchAll(PDO::FETCH_ASSOC);
$motivos = $conn->query("SELECT * FROM motivos_atendimento")->fetchAll(PDO::FETCH_ASSOC);

echo json_encode([
    'origens' => $origens,
    'recursos' => $recursos,
    'motivos' => $motivos
]);
?>
