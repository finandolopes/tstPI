<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

$paciente = $_GET['paciente'] ?? '';
$data_inicio = $_GET['data_inicio'] ?? '';
$data_fim = $_GET['data_fim'] ?? '';
$status = $_GET['status'] ?? '';
$programa = $_GET['programa'] ?? '';
$motivo = $_GET['motivo'] ?? '';

// Construir query com filtros
$whereClauses = [];
$params = [];

if ($paciente) {
    $whereClauses[] = "(a.codigo_paciente = ? OR u.nome LIKE ?)";
    $params[] = $paciente;
    $params[] = "%$paciente%";
}
if ($data_inicio && $data_fim) {
    $whereClauses[] = "DATE(a.data_inicio) BETWEEN ? AND ?";
    $params[] = $data_inicio;
    $params[] = $data_fim;
}
if ($status) {
    $whereClauses[] = "a.status = ?";
    $params[] = $status;
}
if ($programa) {
    $whereClauses[] = "r.nome = ?";
    $params[] = $programa;
}
if ($motivo) {
    $whereClauses[] = "m.nome = ?";
    $params[] = $motivo;
}

$where = $whereClauses ? 'WHERE ' . implode(' AND ', $whereClauses) : '';

$query = "
    SELECT a.id, a.codigo_paciente, a.data_inicio, a.data_fim, a.status, r.nome AS programa, 
           m.nome AS motivo, o.nome AS origem, u.nome AS atendente
    FROM atendimentos a
    JOIN usuarios u ON a.usuario_id = u.id
    JOIN motivos_atendimento m ON a.motivo_id = m.id
    JOIN origens_atendimento o ON a.origem_id = o.id
    JOIN recursos r ON a.recurso_id = r.id
    $where
    ORDER BY a.data_inicio DESC
";
$stmt = $conn->prepare($query);
$stmt->execute($params);
$atendimentos = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>