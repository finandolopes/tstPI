<?php
session_start();
if (!isset($_SESSION['usuario_id']) || $_SESSION['perfil'] !== 'administrador_sistema') {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Obter tipos de atendimento
$stmtTipos = $conn->query("SELECT id, nome FROM motivos_atendimento WHERE status = 'ativo'");
$tiposAtendimento = $stmtTipos->fetchAll(PDO::FETCH_ASSOC);

// Obter workflows
$stmtWorkflows = $conn->query("SELECT id, nome, tipo_atendimento_id FROM workflows");
$workflows = $stmtWorkflows->fetchAll(PDO::FETCH_ASSOC);

// Salvar novo workflow
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $tipoAtendimento = $_POST['tipo_atendimento'];
    $etapas = $_POST['etapas'] ?? [];

    $stmtInsert = $conn->prepare("INSERT INTO workflows (nome, tipo_atendimento_id) VALUES (?, ?)");
    $stmtInsert->execute([$nome, $tipoAtendimento]);
    $workflowId = $conn->lastInsertId();

    $stmtEtapas = $conn->prepare("INSERT INTO workflow_etapas (workflow_id, nome, descricao, ordem) VALUES (?, ?, ?, ?)");
    foreach ($etapas as $ordem => $etapa) {
        $stmtEtapas->execute([$workflowId, $etapa['nome'], $etapa['descricao'], $ordem + 1]);
    }

    header('Location: configuracao_workflows.php?status=sucesso');
    exit;
}
?>