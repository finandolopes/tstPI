<?php
require 'config.php';
require 'registrar-log.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = password_hash($_POST['senha'], PASSWORD_BCRYPT);
    $perfil = $_POST['perfil'];
    $status = $_POST['status'];

    $stmt = $conn->prepare("INSERT INTO usuarios (nome, email, senha, perfil, status) 
                            VALUES (:nome, :email, :senha, :perfil, :status)");
    $stmt->bindParam(':nome', $nome);
    $stmt->bindParam(':email', $email);
    $stmt->bindParam(':senha', $senha);
    $stmt->bindParam(':perfil', $perfil);
    $stmt->bindParam(':status', $status);

    if ($stmt->execute()) {
        registrarLog($conn, $_SESSION['user_id'], "Criou o usuário: $nome ($email)");
        echo "<script>alert('Usuário salvo com sucesso!'); window.location.href='gerenciamento-usuarios.html';</script>";
    } else {
        echo "<script>alert('Erro ao salvar usuário!'); window.location.href='novo-usuario.html';</script>";
    }
}
?>
