<?php
session_start();
require 'backend/conexao.php';

$ip_address = $_SERVER['REMOTE_ADDR'];
$email = $_POST['email'];
$senha = $_POST['senha'];

// Verificar se o usuário está bloqueado
$stmtBloqueado = $conn->prepare("SELECT bloqueado, data_bloqueio FROM usuarios WHERE email = ?");
$stmtBloqueado->execute([$email]);
$usuario = $stmtBloqueado->fetch(PDO::FETCH_ASSOC);

if ($usuario && $usuario['bloqueado']) {
    $tempo_bloqueio = strtotime($usuario['data_bloqueio']);
    $tempo_atual = time();

    if ($tempo_atual - $tempo_bloqueio < 900) { // 15 minutos
        die("Sua conta está temporariamente bloqueada. Tente novamente mais tarde.");
    } else {
        // Desbloquear após 15 minutos
        $stmtDesbloquear = $conn->prepare("UPDATE usuarios SET bloqueado = FALSE, data_bloqueio = NULL WHERE email = ?");
        $stmtDesbloquear->execute([$email]);
    }
}

// Validar login
$stmtLogin = $conn->prepare("SELECT id, senha FROM usuarios WHERE email = ?");
$stmtLogin->execute([$email]);
$user = $stmtLogin->fetch(PDO::FETCH_ASSOC);

if ($user && password_verify($senha, $user['senha'])) {
    // Login bem-sucedido
    $conn->prepare("INSERT INTO login_attempts (usuario_id, ip_address, status) VALUES (?, ?, 'success')")->execute([$user['id'], $ip_address]);
    $_SESSION['usuario_id'] = $user['id'];
    header("Location: dashboard.php");
    exit;
} else {
    // Registrar tentativa de falha
    $conn->prepare("INSERT INTO login_attempts (usuario_id, ip_address, status) VALUES (NULL, ?, 'failed')")->execute([$ip_address]);

    // Verificar tentativas consecutivas
    $stmtFalhas = $conn->prepare("
        SELECT COUNT(*) AS total FROM login_attempts 
        WHERE ip_address = ? AND status = 'failed' AND timestamp > (NOW() - INTERVAL 15 MINUTE)
    ");
    $stmtFalhas->execute([$ip_address]);
    $falhas = $stmtFalhas->fetchColumn();

    if ($falhas >= 5) {
        $conn->prepare("UPDATE usuarios SET bloqueado = TRUE, data_bloqueio = NOW() WHERE email = ?")->execute([$email]);

        // Enviar notificação ao administrador
        mail('admin@example.com', 'Alerta de Segurança', "O IP $ip_address foi bloqueado devido a múltiplas tentativas de login.");
        die("Múltiplas tentativas de login detectadas. Sua conta está temporariamente bloqueada.");
    }

    die("E-mail ou senha incorretos.");
}
?>