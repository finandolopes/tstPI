<?php
// backend/novo_atendimento.php
require_once 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $usuario_id = $_SESSION['user_id']; // Assumindo que o ID do usuário está na sessão
    $origem_id = $_POST['origem'];
    $recurso_id = $_POST['recurso'];
    $motivo_id = $_POST['motivo'];
    $descricao = $_POST['descricao'];
    $codigo_paciente = $_POST['codigo_paciente'];
    $unidade_solicitante = $_POST['unidade_solicitante'];
    $unidade_executante = $_POST['unidade_executante'];

    $query = "INSERT INTO atendimentos 
                (usuario_id, origem_id, recurso_id, motivo_id, descricao, codigo_paciente, unidade_solicitante, unidade_executante, status) 
              VALUES (?, ?, ?, ?, ?, ?, ?, ?, 'Aberto')";

    $stmt = $conn->prepare($query);
    $stmt->bind_param(
        'iiisssss',
        $usuario_id,
        $origem_id,
        $recurso_id,
        $motivo_id,
        $descricao,
        $codigo_paciente,
        $unidade_solicitante,
        $unidade_executante
    );

    if ($stmt->execute()) {
        echo json_encode(['success' => 'Atendimento criado com sucesso!']);
    } else {
        echo json_encode(['error' => 'Erro ao criar o atendimento.']);
    }
}
?>