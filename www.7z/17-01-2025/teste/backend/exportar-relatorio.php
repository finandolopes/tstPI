<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

header('Content-Type: text/csv');
header('Content-Disposition: attachment;filename="relatorio.csv"');

// Obter os dados para exportação
$stmt = $conn->query("SELECT * FROM atendimentos");
$atendimentos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Criar o arquivo CSV
$output = fopen('php://output', 'w');
fputcsv($output, array_keys($atendimentos[0]));

foreach ($atendimentos as $row) {
    fputcsv($output, $row);
}
fclose($output);
exit;
?>
