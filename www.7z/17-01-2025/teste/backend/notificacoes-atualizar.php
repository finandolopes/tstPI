<?php
require 'conexao.php';

$stmt = $conn->query("SELECT * FROM notificacoes WHERE lida = 0 ORDER BY data_hora DESC");
$notificacoes = $stmt->fetchAll(PDO::FETCH_ASSOC);

header('Content-Type: application/json');
echo json_encode($notificacoes);
?>
