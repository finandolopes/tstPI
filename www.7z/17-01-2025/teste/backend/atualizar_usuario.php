<?php
// backend/atualizar_usuario.php
require_once 'conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $user_id = $_SESSION['user_id'];
    $nova_senha = password_hash($_POST['nova_senha'], PASSWORD_DEFAULT);

    $query = "UPDATE usuarios SET senha = ? WHERE id = ?";
    $stmt = $conn->prepare($query);
    $stmt->bind_param('si', $nova_senha, $user_id);

    if ($stmt->execute()) {
        echo json_encode(['success' => 'Senha atualizada com sucesso!']);
    } else {
        echo json_encode(['error' => 'Erro ao atualizar a senha.']);
    }
}
?>