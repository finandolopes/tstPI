<?php
require 'conexao.php';

session_start();
$usuario_id = $_SESSION['usuario_id']; // Certifique-se de configurar o login para definir o ID do usuário na sessão

$stmt = $conn->prepare("SELECT nome, email, login FROM usuarios WHERE id = ?");
$stmt->execute([$usuario_id]);
$usuario = $stmt->fetch(PDO::FETCH_ASSOC);

echo json_encode($usuario);
?>
