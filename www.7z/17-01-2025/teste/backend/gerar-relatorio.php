<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipo_relatorio = $_POST['tipo_relatorio'];
    $data_inicio = $_POST['data_inicio'];
    $data_fim = $_POST['data_fim'];

    header('Content-Type: application/pdf');
    header('Content-Disposition: inline; filename="relatorio.pdf"');

    // Gera conteúdo dinâmico do relatório
    require('fpdf.php');
    $pdf = new FPDF();
    $pdf->AddPage();
    $pdf->SetFont('Arial', 'B', 16);
    $pdf->Cell(0, 10, 'Relatório: ' . ucfirst($tipo_relatorio), 0, 1, 'C');
    $pdf->SetFont('Arial', '', 12);
    $pdf->Ln(10);
    $pdf->Cell(0, 10, 'Período: ' . $data_inicio . ' a ' . $data_fim, 0, 1);

    // Busca dados
    if ($tipo_relatorio === 'produtividade') {
        $stmt = $conn->prepare("SELECT u.nome, COUNT(a.id) AS total 
                                FROM usuarios u 
                                JOIN atendimentos a ON u.id = a.atendente_id 
                                WHERE a.data_inicio BETWEEN :data_inicio AND :data_fim 
                                GROUP BY u.id");
        $stmt->bindParam(':data_inicio', $data_inicio);
        $stmt->bindParam(':data_fim', $data_fim);
    } elseif ($tipo_relatorio === 'producao') {
        $stmt = $conn->prepare("SELECT unidade, COUNT(id) AS total 
                                FROM atendimentos 
                                WHERE data_inicio BETWEEN :data_inicio AND :data_fim 
                                GROUP BY unidade");
        $stmt->bindParam(':data_inicio', $data_inicio);
        $stmt->bindParam(':data_fim', $data_fim);
    } elseif ($tipo_relatorio === 'drs') {
        $stmt = $conn->prepare("SELECT drs, COUNT(id) AS total 
                                FROM atendimentos 
                                WHERE data_inicio BETWEEN :data_inicio AND :data_fim 
                                GROUP BY drs");
        $stmt->bindParam(':data_inicio', $data_inicio);
        $stmt->bindParam(':data_fim', $data_fim);
    }

    $stmt->execute();
    while ($row = $stmt->fetch(PDO::FETCH_ASSOC)) {
        $pdf->Cell(0, 10, $row['nome'] . ': ' . $row['total'], 0, 1);
    }

    $pdf->Output();
}
?>
