<?php
require 'config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $conn->prepare("DELETE FROM atendimentos WHERE id = :id");
    $stmt->bindParam(':id', $id);

    if ($stmt->execute()) {
        echo "<script>alert('Atendimento excluído com sucesso!'); window.location.href='gerenciamento-atendimentos.html';</script>";
    } else {
        echo "<script>alert('Erro ao excluir atendimento!'); window.location.href='gerenciamento-atendimentos.html';</script>";
    }
}
?>
