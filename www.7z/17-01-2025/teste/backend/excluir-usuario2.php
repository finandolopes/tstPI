<?php
require 'config.php';
require 'registrar-log.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $conn->prepare("DELETE FROM usuarios WHERE id = :id");
    $stmt->bindParam(':id', $id);

    if ($stmt->execute()) {
        registrarLog($conn, $_SESSION['user_id'], "Excluiu o usuário com ID: $id");
        echo "<script>alert('Usuário excluído com sucesso!'); window.location.href='gerenciamento-usuarios.html';</script>";
    } else {
        echo "<script>alert('Erro ao excluir usuário!'); window.location.href='gerenciamento-usuarios.html';</script>";
    }
}
?>
