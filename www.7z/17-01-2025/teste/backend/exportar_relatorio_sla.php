<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';
require 'vendor/autoload.php'; // Biblioteca para exportação (MPDF, PhpSpreadsheet)

// Capturar filtros de URL
$programa = $_GET['programa'] ?? null;
$atendente = $_GET['atendente'] ?? null;
$data_inicio = $_GET['data_inicio'] ?? null;
$data_fim = $_GET['data_fim'] ?? null;
$formato = $_GET['formato'] ?? 'pdf'; // PDF por padrão

// Consultar dados
$query = "
    SELECT 
        a.data_inicio,
        a.data_fim,
        u.nome AS atendente,
        TIMESTAMPDIFF(MINUTE, a.data_inicio, a.data_fim) AS tempo_atendimento,
        CASE 
            WHEN TIMESTAMPDIFF(MINUTE, a.data_inicio, a.data_fim) <= 30 THEN 'Cumprido'
            ELSE 'Não Cumprido'
        END AS sla_status
    FROM atendimentos a
    JOIN usuarios u ON a.usuario_id = u.id
    WHERE 1=1
";

$params = [];
if ($programa) {
    $query .= " AND a.programa_id = ?";
    $params[] = $programa;
}
if ($atendente) {
    $query .= " AND a.usuario_id = ?";
    $params[] = $atendente;
}
if ($data_inicio && $data_fim) {
    $query .= " AND DATE(a.data_inicio) BETWEEN ? AND ?";
    $params[] = $data_inicio;
    $params[] = $data_fim;
}

$query .= " ORDER BY a.data_inicio ASC";
$stmt = $conn->prepare($query);
$stmt->execute($params);

$relatorio = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Função de exportação
if ($formato === 'pdf') {
    exportarParaPDF($relatorio);
} elseif ($formato === 'excel') {
    exportarParaExcel($relatorio);
} elseif ($formato === 'word') {
    exportarParaWord($relatorio);
}

function exportarParaPDF($relatorio)
{
    $mpdf = new \Mpdf\Mpdf();

    $html = '
        <h1>Relatório de SLA</h1>
        <table border="1" style="width: 100%; border-collapse: collapse;">
            <thead>
                <tr>
                    <th>Atendente</th>
                    <th>Data Início</th>
                    <th>Data Fim</th>
                    <th>Tempo (Minutos)</th>
                    <th>SLA</th>
                </tr>
            </thead>
            <tbody>
    ';

    foreach ($relatorio as $item) {
        $html .= "
            <tr>
                <td>{$item['atendente']}</td>
                <td>{$item['data_inicio']}</td>
                <td>{$item['data_fim']}</td>
                <td>{$item['tempo_atendimento']}</td>
                <td>{$item['sla_status']}</td>
            </tr>
        ";
    }

    $html .= '</tbody></table>';
    $mpdf->WriteHTML($html);
    $mpdf->Output('relatorio_sla.pdf', 'D');
}

function exportarParaExcel($relatorio)
{
    $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    $sheet->setCellValue('A1', 'Atendente');
    $sheet->setCellValue('B1', 'Data Início');
    $sheet->setCellValue('C1', 'Data Fim');
    $sheet->setCellValue('D1', 'Tempo (Minutos)');
    $sheet->setCellValue('E1', 'SLA');

    $row = 2;
    foreach ($relatorio as $item) {
        $sheet->setCellValue("A{$row}", $item['atendente']);
        $sheet->setCellValue("B{$row}", $item['data_inicio']);
        $sheet->setCellValue("C{$row}", $item['data_fim']);
        $sheet->setCellValue("D{$row}", $item['tempo_atendimento']);
        $sheet->setCellValue("E{$row}", $item['sla_status']);
        $row++;
    }

    $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment; filename="relatorio_sla.xlsx"');
    $writer->save('php://output');
}

function exportarParaWord($relatorio)
{
    $phpWord = new \PhpOffice\PhpWord\PhpWord();
    $section = $phpWord->addSection();

    $section->addText('Relatório de SLA');
    $table = $section->addTable();

    $table->addRow();
    $table->addCell()->addText('Atendente');
    $table->addCell()->addText('Data Início');
    $table->addCell()->addText('Data Fim');
    $table->addCell()->addText('Tempo (Minutos)');
    $table->addCell()->addText('SLA');

    foreach ($relatorio as $item) {
        $table->addRow();
        $table->addCell()->addText($item['atendente']);
        $table->addCell()->addText($item['data_inicio']);
        $table->addCell()->addText($item['data_fim']);
        $table->addCell()->addText($item['tempo_atendimento']);
        $table->addCell()->addText($item['sla_status']);
    }

    $writer = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
    header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    header('Content-Disposition: attachment; filename="relatorio_sla.docx"');
    $writer->save('php://output');
}
?>