<?php
require 'backend/conexao.php';

try {
    // Totais de atendimentos
    $totalAtendimentos = $conn->query("SELECT COUNT(*) AS total FROM atendimentos")->fetch(PDO::FETCH_ASSOC)['total'];
    $atendimentosAbertos = $conn->query("SELECT COUNT(*) AS total FROM atendimentos WHERE status = 'Aberto'")->fetch(PDO::FETCH_ASSOC)['total'];
    $atendimentosFechados = $conn->query("SELECT COUNT(*) AS total FROM atendimentos WHERE status = 'Fechado'")->fetch(PDO::FETCH_ASSOC)['total'];
    $atendimentosPendentes = $conn->query("SELECT COUNT(*) AS total FROM atendimentos WHERE status = 'Pendente'")->fetch(PDO::FETCH_ASSOC)['total'];

    // Últimos 10 atendimentos
    $ultimosAtendimentos = $conn->query("
        SELECT a.id, a.data_inicio, u.nome AS atendente, o.nome AS origem, a.status
        FROM atendimentos a
        JOIN usuarios u ON a.usuario_id = u.id
        JOIN origens_atendimento o ON a.origem_id = o.id
        ORDER BY a.data_inicio DESC
        LIMIT 10
    ")->fetchAll(PDO::FETCH_ASSOC);

    // Top 10 atendentes
    $topAtendentes = $conn->query("
        SELECT u.nome, COUNT(a.id) AS total_atendimentos
        FROM atendimentos a
        JOIN usuarios u ON a.usuario_id = u.id
        GROUP BY u.nome
        ORDER BY total_atendimentos DESC
        LIMIT 10
    ")->fetchAll(PDO::FETCH_ASSOC);

    // Atendimentos por DRS
    $atendimentosPorDRS = $conn->query("
        SELECT d.nome AS drs, COUNT(a.id) AS total_atendimentos
        FROM atendimentos a
        JOIN unidades u ON a.unidade_executante = u.nome
        JOIN drs d ON u.drs_id = d.id
        GROUP BY d.nome
        ORDER BY total_atendimentos DESC
    ")->fetchAll(PDO::FETCH_ASSOC);

    // Atendimentos por Município
    $atendimentosPorMunicipio = $conn->query("
        SELECT m.nome AS municipio, COUNT(a.id) AS total_atendimentos
        FROM atendimentos a
        JOIN unidades u ON a.unidade_executante = u.nome
        JOIN municipios m ON u.municipio_id = m.id
        GROUP BY m.nome
        ORDER BY total_atendimentos DESC
    ")->fetchAll(PDO::FETCH_ASSOC);
} catch (Exception $e) {
    die("Erro ao carregar dados do dashboard: " . $e->getMessage());
}
?>