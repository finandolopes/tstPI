<?php
require 'vendor/autoload.php'; // Para bibliotecas como TCPDF, PHPSpreadsheet e PHPWord

function exportar_logs($logs, $tipo) {
    switch ($tipo) {
        case 'pdf':
            gerar_pdf($logs);
            break;

        case 'excel':
            gerar_excel($logs);
            break;

        case 'word':
            gerar_word($logs);
            break;

        default:
            echo "Formato não suportado.";
            exit;
    }
}

function gerar_pdf($logs) {
    $pdf = new \TCPDF();

    // Configuração inicial do PDF
    $pdf->SetCreator('Sistema de Atendimento');
    $pdf->SetAuthor('Sistema de Atendimento');
    $pdf->SetTitle('Logs do Sistema');
    $pdf->SetHeaderData('', '', 'Logs do Sistema', 'Gerado automaticamente');
    $pdf->setHeaderFont(Array('helvetica', '', 12));
    $pdf->setFooterFont(Array('helvetica', '', 10));
    $pdf->AddPage();

    // Criar tabela
    $html = '<h1>Logs do Sistema</h1><table border="1" cellpadding="4"><thead><tr>
            <th>Data e Hora</th>
            <th>Usuário</th>
            <th>Ação</th>
            <th>Tabela</th>
            <th>Registro ID</th>
            <th>Detalhes</th>
        </tr></thead><tbody>';

    foreach ($logs as $log) {
        $html .= '<tr>
            <td>' . $log['data_hora'] . '</td>
            <td>' . $log['usuario'] . '</td>
            <td>' . ucfirst($log['acao']) . '</td>
            <td>' . $log['tabela'] . '</td>
            <td>' . $log['registro_id'] . '</td>
            <td>' . $log['detalhes'] . '</td>
        </tr>';
    }
    $html .= '</tbody></table>';

    $pdf->writeHTML($html, true, false, true, false, '');
    $pdf->Output('logs.pdf', 'D');
}

function gerar_excel($logs) {
    $spreadsheet = new \PhpOffice\PhpSpreadsheet\Spreadsheet();
    $sheet = $spreadsheet->getActiveSheet();

    // Cabeçalhos
    $sheet->setCellValue('A1', 'Data e Hora')
          ->setCellValue('B1', 'Usuário')
          ->setCellValue('C1', 'Ação')
          ->setCellValue('D1', 'Tabela')
          ->setCellValue('E1', 'Registro ID')
          ->setCellValue('F1', 'Detalhes');

    // Preenchendo dados
    $row = 2;
    foreach ($logs as $log) {
        $sheet->setCellValue("A$row", $log['data_hora'])
              ->setCellValue("B$row", $log['usuario'])
              ->setCellValue("C$row", ucfirst($log['acao']))
              ->setCellValue("D$row", $log['tabela'])
              ->setCellValue("E$row", $log['registro_id'])
              ->setCellValue("F$row", $log['detalhes']);
        $row++;
    }

    // Exportar
    $writer = new \PhpOffice\PhpSpreadsheet\Writer\Xlsx($spreadsheet);
    header('Content-Type: application/vnd.openxmlformats-officedocument.spreadsheetml.sheet');
    header('Content-Disposition: attachment;filename="logs.xlsx"');
    $writer->save('php://output');
}

function gerar_word($logs) {
    $phpWord = new \PhpOffice\PhpWord\PhpWord();
    $section = $phpWord->addSection();

    // Título
    $section->addText('Logs do Sistema', ['bold' => true, 'size' => 16]);

    // Tabela
    $table = $section->addTable();
    $table->addRow();
    $table->addCell(2000)->addText('Data e Hora');
    $table->addCell(2000)->addText('Usuário');
    $table->addCell(2000)->addText('Ação');
    $table->addCell(2000)->addText('Tabela');
    $table->addCell(2000)->addText('Registro ID');
    $table->addCell(3000)->addText('Detalhes');

    foreach ($logs as $log) {
        $table->addRow();
        $table->addCell(2000)->addText($log['data_hora']);
        $table->addCell(2000)->addText($log['usuario']);
        $table->addCell(2000)->addText(ucfirst($log['acao']));
        $table->addCell(2000)->addText($log['tabela']);
        $table->addCell(2000)->addText($log['registro_id']);
        $table->addCell(3000)->addText($log['detalhes']);
    }

    // Exportar
    header('Content-Type: application/vnd.openxmlformats-officedocument.wordprocessingml.document');
    header('Content-Disposition: attachment;filename="logs.docx"');
    $writer = \PhpOffice\PhpWord\IOFactory::createWriter($phpWord, 'Word2007');
    $writer->save('php://output');
}
?>