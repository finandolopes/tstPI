<?php
require 'conexao.php';

$id = $_GET['id'] ?? null;

if (!$id) {
    echo "ID do atendimento não informado.";
    exit;
}

// Buscar detalhes do atendimento
$stmt = $conn->prepare("
    SELECT a.id, u.nome AS atendente, a.data_inicio, a.data_fim, a.status, 
           m.nome AS motivo, o.nome AS origem, a.descricao
    FROM atendimentos a
    JOIN usuarios u ON a.usuario_id = u.id
    JOIN motivos_atendimento m ON a.motivo_id = m.id
    JOIN origens_atendimento o ON a.origem_id = o.id
    WHERE a.id = ?
");
$stmt->execute([$id]);
$atendimento = $stmt->fetch(PDO::FETCH_ASSOC);

if ($atendimento):
?>
    <div class="row">
        <div class="col-md-6"><strong>Atendente:</strong> <?= $atendimento['atendente'] ?></div>
        <div class="col-md-6"><strong>Status:</strong> <?= $atendimento['status'] ?></div>
        <div class="col-md-6"><strong>Data Início:</strong> <?= $atendimento['data_inicio'] ?></div>
        <div class="col-md-6"><strong>Data Fim:</strong> <?= $atendimento['data_fim'] ?? 'Não Finalizado' ?></div>
        <div class="col-md-6"><strong>Motivo:</strong> <?= $atendimento['motivo'] ?></div>
        <div class="col-md-6"><strong>Origem:</strong> <?= $atendimento['origem'] ?></div>
        <div class="col-12"><strong>Descrição:</strong> <?= nl2br($atendimento['descricao']) ?></div>
    </div>
<?php
else:
    echo "Atendimento não encontrado.";
endif;