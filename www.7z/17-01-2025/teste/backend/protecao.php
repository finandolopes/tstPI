<?php
require_once '../includes/token_csrf.php';

// Sanitização global de entradas para evitar XSS
function sanitizarEntrada($data) {
    if (is_array($data)) {
        foreach ($data as $key => $value) {
            $data[$key] = sanitizarEntrada($value);
        }
    } else {
        $data = htmlspecialchars($data, ENT_QUOTES, 'UTF-8');
    }
    return $data;
}

// Sanitizar GET, POST e REQUEST
$_GET = sanitizarEntrada($_GET);
$_POST = sanitizarEntrada($_POST);
$_REQUEST = sanitizarEntrada($_REQUEST);

// Verificar CSRF em requisições POST
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!validarTokenCSRF($_POST['csrf_token'] ?? '')) {
        die('Token CSRF inválido. Recarregue a página e tente novamente.');
    }
}
?>