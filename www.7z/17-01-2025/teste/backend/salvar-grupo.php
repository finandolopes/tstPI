<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $descricao = $_POST['descricao'];

    $stmt = $conn->prepare("INSERT INTO grupos (nome, descricao) VALUES (:nome, :descricao)");
    $stmt->bindParam(':nome', $nome);
    $stmt->bindParam(':descricao', $descricao);

    if ($stmt->execute()) {
        echo "<script>alert('Grupo salvo com sucesso!'); window.location.href='gerenciamento-grupos.html';</script>";
    } else {
        echo "<script>alert('Erro ao salvar grupo!'); window.location.href='novo-grupo.html';</script>";
    }
}
?>
