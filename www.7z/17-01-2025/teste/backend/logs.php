<?php
require 'conexao.php';

function registrar_log($usuario_id, $acao, $detalhes) {
    global $conn;

    $stmt = $conn->prepare("INSERT INTO logs (usuario_id, acao, detalhes) VALUES (?, ?, ?)");
    $stmt->execute([$usuario_id, $acao, $detalhes]);
}
