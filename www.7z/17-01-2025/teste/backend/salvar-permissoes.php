<?php
require 'config.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $tipo = $_POST['usuario_ou_grupo'];
    $selecionado = $_POST['selecionado'];
    $permissoes = $_POST['permissoes_atribuidas'];

    // Tabela de destino
    $tabela = $tipo === 'Usuario' ? 'usuario_permissoes' : 'grupo_permissoes';

    // Remove permissões anteriores
    $stmt = $conn->prepare("DELETE FROM $tabela WHERE id_ref = :id_ref");
    $stmt->bindParam(':id_ref', $selecionado);
    $stmt->execute();

    // Insere novas permissões
    $stmt = $conn->prepare("INSERT INTO $tabela (id_ref, permissao) VALUES (:id_ref, :permissao)");
    foreach ($permissoes as $permissao) {
        $stmt->bindParam(':id_ref', $selecionado);
        $stmt->bindParam(':permissao', $permissao);
        $stmt->execute();
    }

    echo "<script>alert('Permissões salvas com sucesso!'); window.location.href='config-permissoes.html';</script>";
}
?>
