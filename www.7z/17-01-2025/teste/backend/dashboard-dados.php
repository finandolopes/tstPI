<?php
require 'conexao.php';

$response = [
    'totalAtendimentos' => $conn->query("SELECT COUNT(*) AS total FROM atendimentos")->fetch(PDO::FETCH_ASSOC)['total'],
    'atendimentosAbertos' => $conn->query("SELECT COUNT(*) AS total FROM atendimentos WHERE status = 'aberto'")->fetch(PDO::FETCH_ASSOC)['total'],
    'atendimentosFechados' => $conn->query("SELECT COUNT(*) AS total FROM atendimentos WHERE status = 'fechado'")->fetch(PDO::FETCH_ASSOC)['total'],
];

header('Content-Type: application/json');
echo json_encode($response);
