<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: index.php');
    exit;
}

require 'backend/conexao.php';

// Obter atendimentos em andamento
$stmtAtendimentos = $conn->query("
    SELECT a.id, a.data_inicio, u.nome AS atendente, m.nome AS motivo, o.nome AS origem, a.status, a.prioridade
    FROM atendimentos a
    JOIN usuarios u ON a.usuario_id = u.id
    JOIN motivos_atendimento m ON a.motivo_id = m.id
    JOIN origens_atendimento o ON a.origem_id = o.id
    WHERE a.status IN ('Aberto', 'Pendente')
    ORDER BY a.prioridade DESC, a.data_inicio ASC
");
$atendimentos = $stmtAtendimentos->fetchAll(PDO::FETCH_ASSOC);
?>