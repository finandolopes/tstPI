<?php
require 'config.php';

if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $stmt = $conn->prepare("DELETE FROM grupos WHERE id = :id");
    $stmt->bindParam(':id', $id);

    if ($stmt->execute()) {
        echo "<script>alert('Grupo excluído com sucesso!'); window.location.href='gerenciamento-grupos.html';</script>";
    } else {
        echo "<script>alert('Erro ao excluir grupo!'); window.location.href='gerenciamento-grupos.html';</script>";
    }
}
?>
