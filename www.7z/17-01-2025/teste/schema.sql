CREATE DATABASE sistema_atendimento;

USE sistema_atendimento;

-- Tabela de Usuários
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    email VARCHAR(100) UNIQUE NOT NULL,
    senha VARCHAR(255) NOT NULL,
    perfil_id INT NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (perfil_id) REFERENCES perfis(id)
);

-- Tabela de Perfis
CREATE TABLE perfis (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(50) NOT NULL
);

-- Tabela de Permissões
CREATE TABLE permissoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    perfil_id INT NOT NULL,
    recurso_id INT NOT NULL,
    FOREIGN KEY (perfil_id) REFERENCES perfis(id),
    FOREIGN KEY (recurso_id) REFERENCES recursos(id)
);

-- Tabela de Recursos
CREATE TABLE recursos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL
);

-- Tabela de Atendimentos
CREATE TABLE atendimentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    data_inicio DATETIME DEFAULT CURRENT_TIMESTAMP,
    data_fim DATETIME,
    origem_id INT NOT NULL,
    recurso_id INT NOT NULL,
    motivo_id INT NOT NULL,
    descricao TEXT,
    codigo_paciente VARCHAR(50),
    unidade_solicitante VARCHAR(100),
    unidade_executante VARCHAR(100),
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    updated_at DATETIME ON UPDATE CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id),
    FOREIGN KEY (origem_id) REFERENCES origens_atendimento(id),
    FOREIGN KEY (recurso_id) REFERENCES recursos(id),
    FOREIGN KEY (motivo_id) REFERENCES motivos_atendimento(id)
);

-- Tabela de Logs
CREATE TABLE logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    acao VARCHAR(255),
    detalhes TEXT,
    data_hora DATETIME DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Tabela de Unidades
CREATE TABLE unidades (
    id INT AUTO_INCREMENT PRIMARY KEY,
    cnes VARCHAR(20) NOT NULL,
    nome VARCHAR(100) NOT NULL,
    municipio_id INT NOT NULL,
    tipo_unidade VARCHAR(50),
    FOREIGN KEY (municipio_id) REFERENCES municipios(id)
);

-- Tabela de Municípios
CREATE TABLE municipios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    populacao INT,
    colegiado_id INT NOT NULL,
    FOREIGN KEY (colegiado_id) REFERENCES colegiados(id)
);

-- Tabela de Colegiados
CREATE TABLE colegiados (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    drs_id INT NOT NULL,
    FOREIGN KEY (drs_id) REFERENCES drs(id)
);

-- Tabela de DRS (Diretorias Regionais de Saúde)
CREATE TABLE drs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL
);

-- Tabela de Origens de Atendimento
CREATE TABLE origens_atendimento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL
);

-- Tabela de Motivos de Atendimento
CREATE TABLE motivos_atendimento (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(100) NOT NULL,
    obrigatorio BOOLEAN DEFAULT FALSE
);
