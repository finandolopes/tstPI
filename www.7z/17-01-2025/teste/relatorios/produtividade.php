<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}
require_once '../backend/conexao.php';

// Obter dados de produtividade
$stmt = $conn->query("SELECT u.nome AS atendente, COUNT(a.id) AS total_atendimentos 
                      FROM atendimentos a
                      JOIN usuarios u ON a.usuario_id = u.id
                      GROUP BY u.nome
                      ORDER BY total_atendimentos DESC");
$dadosProdutividade = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Preparar dados para Chart.js
$labels = json_encode(array_column($dadosProdutividade, 'atendente'));
$totais = json_encode(array_column($dadosProdutividade, 'total_atendimentos'));
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório de Produtividade - Sistema de Atendimento</title>
    <link rel="stylesheet" href="../assets/css/estilos.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<?php include '../includes/header.php'; ?>
<?php include '../includes/sidebar.php'; ?>
<div class="content">
    <h1>Relatório de Produtividade</h1>
    <canvas id="produtividadeChart" width="400" height="200"></canvas>
</div>

<script>
    const ctx = document.getElementById('produtividadeChart').getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: {
            labels: <?= $labels ?>,
            datasets: [{
                label: 'Total de Atendimentos',
                data: <?= $totais ?>,
                backgroundColor: '#007bff',
                borderColor: '#0056b3',
                borderWidth: 1
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    display: false
                },
                title: {
                    display: true,
                    text: 'Produtividade por Atendente'
                }
            },
            scales: {
                y: {
                    beginAtZero: true
                }
            }
        }
    });
</script>
</body>
</html>