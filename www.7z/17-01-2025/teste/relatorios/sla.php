<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}
require_once '../backend/conexao.php';

// Obter dados para o gráfico
$stmt = $conn->query("SELECT status, COUNT(*) AS total FROM atendimentos GROUP BY status");
$slaData = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Preparar dados para o Chart.js
$statusLabels = json_encode(array_column($slaData, 'status'));
$statusCounts = json_encode(array_column($slaData, 'total'));
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatório de SLA - Sistema de Atendimento</title>
    <link rel="stylesheet" href="../assets/css/estilos.css">
    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
</head>
<body>
<?php include '../includes/header.php'; ?>
<?php include '../includes/sidebar.php'; ?>
<div class="content">
    <h1>Relatório de SLA</h1>
    <canvas id="slaChart" width="400" height="200"></canvas>
</div>

<script>
    const ctx = document.getElementById('slaChart').getContext('2d');
    new Chart(ctx, {
        type: 'pie',
        data: {
            labels: <?= $statusLabels ?>,
            datasets: [{
                data: <?= $statusCounts ?>,
                backgroundColor: ['#28a745', '#ffc107', '#dc3545'],
                hoverOffset: 4
            }]
        },
        options: {
            responsive: true,
            plugins: {
                legend: {
                    position: 'top',
                },
                title: {
                    display: true,
                    text: 'Distribuição de Atendimentos por Status'
                }
            }
        }
    });
</script>
</body>
</html>