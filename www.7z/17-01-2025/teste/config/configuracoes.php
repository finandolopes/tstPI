<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}
require_once '../backend/conexao.php';
require_once '../backend/csrf_token.php';

$csrfToken = gerarToken();
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurações - Sistema de Atendimento</title>
    <link rel="stylesheet" href="../assets/css/estilos.css">
</head>
<body>
<?php include '../includes/header.php'; ?>
<?php include '../includes/sidebar.php'; ?>
<div class="content">
    <h1>Configurações</h1>
    <form action="salvar_configuracoes.php" method="POST">
        <input type="hidden" name="csrf_token" value="<?= $csrfToken ?>">
        <div class="form-group">
            <label for="backup_periodicidade">Periodicidade do Backup:</label>
            <select name="backup_periodicidade" id="backup_periodicidade" class="form-control" required>
                <option value="diário">Diário</option>
                <option value="semanal">Semanal</option>
                <option value="mensal">Mensal</option>
            </select>
        </div>
        <button type="submit" class="btn btn-primary">Salvar Configurações</button>
    </form>
</div>
</body>
</html>