<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}
require_once '../backend/conexao.php';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $host = $_POST['host'];
    $email = $_POST['email'];
    $senha = $_POST['senha'];
    $porta = $_POST['porta'];

    $stmt = $conn->prepare("UPDATE configuracoes_email SET host = ?, email = ?, senha = ?, porta = ?");
    $stmt->execute([$host, $email, $senha, $porta]);
    $msg = "Configurações salvas com sucesso!";
}

// Obter configurações atuais
$config = $conn->query("SELECT * FROM configuracoes_email LIMIT 1")->fetch(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurações de E-mail</title>
</head>
<body>
<?php include '../includes/header.php'; ?>
<?php include '../includes/sidebar.php'; ?>
<div class="content">
    <h1>Configurações de E-mail</h1>
    <?php if (isset($msg)): ?>
        <div class="alert alert-success"><?= htmlspecialchars($msg) ?></div>
    <?php endif; ?>
    <form method="POST">
        <div class="mb-3">
            <label for="host" class="form-label">Servidor SMTP</label>
            <input type="text" name="host" id="host" class="form-control" value="<?= htmlspecialchars($config['host'] ?? '') ?>" required>
        </div>
        <div class="mb-3">
            <label for="email" class="form-label">E-mail</label>
            <input type="email" name="email" id="email" class="form-control" value="<?= htmlspecialchars($config['email'] ?? '') ?>" required>
        </div>
        <div class="mb-3">
            <label for="senha" class="form-label">Senha</label>
            <input type="password" name="senha" id="senha" class="form-control" value="<?= htmlspecialchars($config['senha'] ?? '') ?>" required>
        </div>
        <div class="mb-3">
            <label for="porta" class="form-label">Porta</label>
            <input type="number" name="porta" id="porta" class="form-control" value="<?= htmlspecialchars($config['porta'] ?? '') ?>" required>
        </div>
        <button type="submit" class="btn btn-primary">Salvar</button>
    </form>
</div>
<?php include '../includes/footer.php'; ?>
</body>
</html>