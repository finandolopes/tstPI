document.addEventListener('DOMContentLoaded', () => {
    document.querySelectorAll('.btn-modal').forEach(button => {
        button.addEventListener('click', () => {
            const modalId = button.dataset.target;
            document.getElementById(modalId).classList.add('show');
        });
    });
});