function drawChart(data, elementId) {
    const ctx = document.getElementById(elementId).getContext('2d');
    new Chart(ctx, {
        type: 'bar',
        data: data,
        options: { responsive: true }
    });
}