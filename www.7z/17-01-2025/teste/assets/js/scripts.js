
// Scripts Globais
document.addEventListener('DOMContentLoaded', function () {
    // Exemplo: Ativando tooltip globalmente
    const tooltips = document.querySelectorAll('[data-toggle="tooltip"]');
    tooltips.forEach(tooltip => new bootstrap.Tooltip(tooltip));

    // Suporte ao modo alto contraste
    document.querySelector('#toggle-contrast').addEventListener('click', function () {
        document.body.classList.toggle('high-contrast');
    });
});

// Suporte a atalhos de teclado
document.addEventListener('keydown', function (event) {
    if (event.ctrlKey && event.key === 'f') {
        event.preventDefault();
        window.location.href = '/modules/usability/search.php';
    }
});

// Suporte a SweetAlert2 para alertas customizados
function showAlert(type, message) {
    Swal.fire({
        icon: type,
        title: 'Alerta',
        text: message,
        confirmButtonText: 'Ok'
    });
}
