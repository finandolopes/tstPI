<?php
session_start();

// Função para gerar o token CSRF
definirTokenCSRF();

function definirTokenCSRF() {
    if (!isset($_SESSION['csrf_token'])) {
        $_SESSION['csrf_token'] = bin2hex(random_bytes(32));
    }
}

// Função para verificar o token CSRF
function verificarTokenCSRF($tokenRecebido) {
    return isset($_SESSION['csrf_token']) && hash_equals($_SESSION['csrf_token'], $tokenRecebido);
}

?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Formulário Seguro</title>
    <link rel="stylesheet" href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0-alpha1/dist/css/bootstrap.min.css">
</head>
<body>
    <div class="container mt-5">
        <h1>Formulário com CSRF</h1>
        
        <form method="POST" action="processa_formulario.php">
            <input type="hidden" name="csrf_token" value="<?= $_SESSION['csrf_token'] ?>">
            
            <div class="mb-3">
                <label for="nome" class="form-label">Nome</label>
                <input type="text" class="form-control" id="nome" name="nome" required>
            </div>

            <div class="mb-3">
                <label for="email" class="form-label">E-mail</label>
                <input type="email" class="form-control" id="email" name="email" required>
            </div>

            <button type="submit" class="btn btn-primary">Enviar</button>
        </form>
    </div>
</body>
</html>

<?php
// Arquivo processa_formulario.php
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    if (!verificarTokenCSRF($_POST['csrf_token'])) {
        die('Token CSRF inválido.');
    }

    // Processo seguro do formulário
    $nome = htmlspecialchars($_POST['nome']);
    $email = htmlspecialchars($_POST['email']);

    echo "<h1>Formulário recebido com sucesso!</h1>";
    echo "<p>Nome: $nome</p>";
    echo "<p>E-mail: $email</p>";
}
?>
