<?php
session_start();

// Gera o texto do captcha
if (!isset($_SESSION['captcha'])) {
    $_SESSION['captcha'] = substr(str_shuffle('ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789'), 0, 6);
}

// Configurações do captcha
$largura = 150;
$altura = 50;
$imagem = imagecreate($largura, $altura);

// Cores
$fundo = imagecolorallocate($imagem, 255, 255, 255); // Fundo branco
$cores = [
    imagecolorallocate($imagem, 0, 0, 0),        // Preto
    imagecolorallocate($imagem, 255, 0, 0),      // Vermelho
    imagecolorallocate($imagem, 0, 255, 0),      // Verde
    imagecolorallocate($imagem, 0, 0, 255),      // Azul
    imagecolorallocate($imagem, 255, 165, 0),    // Laranja
    imagecolorallocate($imagem, 128, 0, 128)     // Roxo
];

// Adiciona linhas de interferência
for ($i = 0; $i < 6; $i++) {
    imageline($imagem, rand(0, $largura), rand(0, $altura), rand(0, $largura), rand(0, $altura), $cores[array_rand($cores)]);
}

// Caminho para a fonte
$fonte = __DIR__ . '/../assets/fonts/arial.ttf';
if (!file_exists($fonte)) {
    die("Erro: Arquivo da fonte não encontrado.");
}

// Adiciona o texto do captcha
$angulo = rand(-15, 15);
$x = rand(10, 40);
$y = rand(30, 40);
imagettftext($imagem, 20, $angulo, $x, $y, $cores[array_rand($cores)], $fonte, $_SESSION['captcha']);

// Cabeçalho da imagem
header("Content-Type: image/png");
imagepng($imagem);
imagedestroy($imagem);
?>