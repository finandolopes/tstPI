<?php
header('Content-Type: application/json');

// Simulação de notificações; substitua com lógica do banco de dados
$notificacoes = [
    ['id' => 1, 'mensagem' => 'Novo atendimento criado!', 'data_hora' => date('Y-m-d H:i:s')],
    ['id' => 2, 'mensagem' => 'Atendimento #12 foi finalizado.', 'data_hora' => date('Y-m-d H:i:s')],
];

echo json_encode($notificacoes);
