<?php
require '../backend/conexao.php';

// Obter perfis e permissões
$perfis = $conn->query("SELECT * FROM perfis")->fetchAll(PDO::FETCH_ASSOC);
$recursos = $conn->query("SELECT * FROM recursos")->fetchAll(PDO::FETCH_ASSOC);

// Atualizar permissões
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $perfil_id = $_POST['perfil'];
    $recursos_selecionados = $_POST['recursos'] ?? [];

    $conn->prepare("DELETE FROM permissoes WHERE perfil_id = ?")->execute([$perfil_id]);

    foreach ($recursos_selecionados as $recurso_id) {
        $stmt = $conn->prepare("INSERT INTO permissoes (perfil_id, recurso_id) VALUES (?, ?)");
        $stmt->execute([$perfil_id, $recurso_id]);
    }

    echo json_encode(['status' => 'sucesso']);
    exit;
}

// Resposta JSON com perfis e recursos
echo json_encode([
    'perfis' => $perfis,
    'recursos' => $recursos,
]);
