<?php
require '../vendor/autoload.php';
require '../backend/conexao.php';

use Mpdf\Mpdf;

// Consulta para obter dados do relatório
$stmt = $conn->query("
    SELECT a.id, a.data_inicio, a.data_fim, a.status, u.nome AS atendente, o.descricao AS origem
    FROM atendimentos a
    JOIN usuarios u ON a.atendente_id = u.id
    JOIN origens o ON a.origem_id = o.id
    ORDER BY a.data_inicio DESC
");
$atendimentos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Gerar HTML para o PDF
$html = '<h1>Relatório de Atendimentos</h1>';
$html .= '<table border="1" style="width:100%; border-collapse:collapse;">
    <thead>
        <tr>
            <th>ID</th>
            <th>Data Início</th>
            <th>Data Fim</th>
            <th>Atendente</th>
            <th>Origem</th>
            <th>Status</th>
        </tr>
    </thead>
    <tbody>';

foreach ($atendimentos as $atendimento) {
    $html .= '<tr>
        <td>' . $atendimento['id'] . '</td>
        <td>' . $atendimento['data_inicio'] . '</td>
        <td>' . ($atendimento['data_fim'] ?? 'N/A') . '</td>
        <td>' . $atendimento['atendente'] . '</td>
        <td>' . $atendimento['origem'] . '</td>
        <td>' . ucfirst($atendimento['status']) . '</td>
    </tr>';
}

$html .= '</tbody></table>';

// Geração do PDF
try {
    $mpdf = new Mpdf();
    $mpdf->WriteHTML($html);
    $mpdf->Output('Relatorio_Atendimentos.pdf', 'D');
} catch (\Mpdf\MpdfException $e) {
    echo $e->getMessage();
}
