<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}
require_once '../backend/conexao.php';

// Filtro de logs
$filtroUsuario = isset($_GET['usuario_id']) ? (int)$_GET['usuario_id'] : null;
$filtroAcao = isset($_GET['acao']) ? trim($_GET['acao']) : null;

$sql = "SELECT la.*, u.nome AS usuario 
        FROM logs_auditoria la
        JOIN usuarios u ON la.usuario_id = u.id";
$params = [];

if ($filtroUsuario) {
    $sql .= " WHERE la.usuario_id = ?";
    $params[] = $filtroUsuario;
}
if ($filtroAcao) {
    $sql .= $filtroUsuario ? " AND la.acao LIKE ?" : " WHERE la.acao LIKE ?";
    $params[] = "%$filtroAcao%";
}
$sql .= " ORDER BY la.data DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Obter lista de usuários para o filtro
$usuarios = $conn->query("SELECT id, nome FROM usuarios")->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Logs de Ações - Sistema de Atendimento</title>
    <link rel="stylesheet" href="../assets/css/estilos.css">
</head>
<body>
<?php include '../includes/header.php'; ?>
<?php include '../includes/sidebar.php'; ?>
<div class="content">
    <h1>Logs de Ações</h1>
    <form method="GET" class="form-inline mb-3">
        <div class="form-group">
            <label for="usuario_id">Usuário:</label>
            <select name="usuario_id" id="usuario_id" class="form-control mx-2">
                <option value="">Todos</option>
                <?php foreach ($usuarios as $usuario): ?>
                    <option value="<?= $usuario['id'] ?>" <?= $usuario['id'] == $filtroUsuario ? 'selected' : '' ?>>
                        <?= htmlspecialchars($usuario['nome']) ?>
                    </option>
                <?php endforeach; ?>
            </select>
        </div>
        <div class="form-group mx-2">
            <label for="acao">Ação:</label>
            <input type="text" name="acao" id="acao" value="<?= htmlspecialchars($filtroAcao) ?>" class="form-control">
        </div>
        <button type="submit" class="btn btn-primary">Filtrar</button>
    </form>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>ID</th>
            <th>Usuário</th>
            <th>Ação</th>
            <th>Descrição</th>
            <th>Data</th>
        </tr>
        </thead>
        <tbody>
        <?php if (empty($logs)): ?>
            <tr>
                <td colspan="5" class="text-center">Nenhum log encontrado.</td>
            </tr>
        <?php else: ?>
            <?php foreach ($logs as $log): ?>
                <tr>
                    <td><?= $log['id'] ?></td>
                    <td><?= htmlspecialchars($log['usuario']) ?></td>
                    <td><?= htmlspecialchars($log['acao']) ?></td>
                    <td><?= htmlspecialchars($log['descricao']) ?></td>
                    <td><?= $log['data'] ?></td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>