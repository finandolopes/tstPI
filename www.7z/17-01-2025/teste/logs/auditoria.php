<?php
session_start();
if (!isset($_SESSION['usuario_id'])) {
    header('Location: ../login.php');
    exit;
}
require_once '../backend/conexao.php';

// Filtrar auditorias por data
$filtroDataInicio = isset($_GET['data_inicio']) ? $_GET['data_inicio'] : null;
$filtroDataFim = isset($_GET['data_fim']) ? $_GET['data_fim'] : null;

$sql = "SELECT la.*, u.nome AS usuario 
        FROM logs_auditoria la
        JOIN usuarios u ON la.usuario_id = u.id";
$params = [];

if ($filtroDataInicio || $filtroDataFim) {
    $sql .= " WHERE";
    if ($filtroDataInicio) {
        $sql .= " la.data >= ?";
        $params[] = $filtroDataInicio;
    }
    if ($filtroDataFim) {
        $sql .= $filtroDataInicio ? " AND" : "";
        $sql .= " la.data <= ?";
        $params[] = $filtroDataFim;
    }
}
$sql .= " ORDER BY la.data DESC";

$stmt = $conn->prepare($sql);
$stmt->execute($params);
$auditorias = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>
<!DOCTYPE html>
<html lang="pt-br">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Auditoria - Sistema de Atendimento</title>
    <link rel="stylesheet" href="../assets/css/estilos.css">
</head>
<body>
<?php include '../includes/header.php'; ?>
<?php include '../includes/sidebar.php'; ?>
<div class="content">
    <h1>Auditoria</h1>
    <form method="GET" class="form-inline mb-3">
        <div class="form-group">
            <label for="data_inicio">Data de Início:</label>
            <input type="date" name="data_inicio" id="data_inicio" value="<?= htmlspecialchars($filtroDataInicio) ?>" class="form-control mx-2">
        </div>
        <div class="form-group">
            <label for="data_fim">Data de Fim:</label>
            <input type="date" name="data_fim" id="data_fim" value="<?= htmlspecialchars($filtroDataFim) ?>" class="form-control mx-2">
        </div>
        <button type="submit" class="btn btn-primary">Filtrar</button>
    </form>
    <table class="table table-bordered">
        <thead>
        <tr>
            <th>ID</th>
            <th>Usuário</th>
            <th>Ação</th>
            <th>Descrição</th>
            <th>Data</th>
        </tr>
        </thead>
        <tbody>
        <?php if (empty($auditorias)): ?>
            <tr>
                <td colspan="5" class="text-center">Nenhuma auditoria encontrada.</td>
            </tr>
        <?php else: ?>
            <?php foreach ($auditorias as $auditoria): ?>
                <tr>
                    <td><?= $auditoria['id'] ?></td>
                    <td><?= htmlspecialchars($auditoria['usuario']) ?></td>
                    <td><?= htmlspecialchars($auditoria['acao']) ?></td>
                    <td><?= htmlspecialchars($auditoria['descricao']) ?></td>
                    <td><?= $auditoria['data'] ?></td>
                </tr>
            <?php endforeach; ?>
        <?php endif; ?>
        </tbody>
    </table>
</div>
</body>
</html>