<?php
/*
Plugin Name: One Click Accessibility
Plugin URI: https://wpaccessibility.io/?utm_source=wp-plugins&utm_campaign=plugin-uri&utm_medium=wp-dash
Description: The One Click Accessibility toolbar is the fastest plugin to help you make your WordPress website more accessible.
Author: One Click Accessibility
Author URI: https://wpaccessibility.io/?utm_source=wp-plugins&utm_campaign=author-uri&utm_medium=wp-dash
Version: 2.1.0
Text Domain: pojo-accessibility
Domain Path: /languages/
*/
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

define( 'POJO_A11Y__FILE__', __FILE__ );
define( 'POJO_A11Y_BASE', plugin_basename( POJO_A11Y__FILE__ ) );
define( 'POJO_A11Y_URL', plugins_url( '/', POJO_A11Y__FILE__ ) );
define( 'POJO_A11Y_ASSETS_PATH', plugin_dir_path( POJO_A11Y__FILE__ ) . 'assets/' );
define( 'POJO_A11Y_ASSETS_URL', POJO_A11Y_URL . 'assets/' );
define( 'POJO_A11Y_CUSTOMIZER_OPTIONS', 'pojo_a11y_customizer_options' );

final class Pojo_Accessibility {

	/**
	 * @var Pojo_Accessibility The one true Pojo_Accessibility
	 * @since 1.0.0
	 */
	public static $instance = null;

	/**
	 * @var Pojo_A11y_Frontend
	 */
	public $frontend;

	/**
	 * @var Pojo_A11y_Customizer
	 */
	public $customizer;

	/**
	 * @var Pojo_A11y_Settings
	 */
	public $settings;

	/**
	 * @var Pojo_A11y_Admin_UI
	 */
	public $admin_ui;

	public function load_textdomain() {
		load_plugin_textdomain( 'pojo-accessibility' );
	}

	/**
	 * Throw error on object clone
	 *
	 * The whole idea of the singleton design pattern is that there is a single
	 * object therefore, we don't want the object to be cloned.
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function __clone() {
		// Cloning instances of the class is forbidden
		_doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?', 'pojo-accessibility' ), '1.0.0' );
	}

	/**
	 * Disable unserializing of the class
	 *
	 * @since 1.0.0
	 * @return void
	 */
	public function __wakeup() {
		// Unserializing instances of the class is forbidden
		_doing_it_wrong( __FUNCTION__, __( 'Cheatin&#8217; huh?', 'pojo-accessibility' ), '1.0.0' );
	}

	/**
	 * @return Pojo_Accessibility
	 */
	public static function instance() {
		if ( is_null( self::$instance ) ) {
			self::$instance = new self();
		}
		return self::$instance;
	}

	public function bootstrap() {
		require( 'includes/pojo-a11y-frontend.php' );
		require( 'includes/pojo-a11y-customizer.php' );
		require( 'includes/pojo-a11y-settings.php' );
		require( 'includes/pojo-a11y-admin-ui.php' );

		$this->frontend   = new Pojo_A11y_Frontend();
		$this->customizer = new Pojo_A11y_Customizer();
		$this->settings = new Pojo_A11y_Settings();
		$this->admin_ui = new Pojo_A11y_Admin_UI();
	}

	public function backwards_compatibility() {
		if ( false === get_option( POJO_A11Y_CUSTOMIZER_OPTIONS, false ) ) {
			$customizer_fields = $this->customizer->get_customizer_fields();
			$options = array();
			$mods = get_theme_mods();
			foreach ( $customizer_fields as $field ) {
				if ( isset( $mods[ $field['id'] ] ) ) {
					$options[ $field['id'] ] = $mods[ $field['id'] ];
				} else {
					$options[ $field['id'] ] = $field['std'];
				}
			}
			update_option( POJO_A11Y_CUSTOMIZER_OPTIONS, $options );
		}
	}

	public function add_elementor_support() {
		require( 'includes/pojo-a11y-elementor.php' );

		new Pojo_A11y_Elementor();
	}

	private function __construct() {
		add_action( 'init', array( &$this, 'bootstrap' ) );
		add_action( 'admin_init', array( &$this, 'backwards_compatibility' ) );
		add_action( 'plugins_loaded', array( &$this, 'load_textdomain' ) );

		add_action( 'elementor/init', array( $this, 'add_elementor_support' ) );
	}

}

Pojo_Accessibility::instance();

<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Pojo_A11y_Admin_UI {

	const SETTINGS_SLUG = 'toplevel_page_accessibility-settings';
	const TOOLBAR_SLUG = 'accessibility_page_accessibility-toolbar';

	private function _is_elementor_installed() {
		$file_path = 'elementor/elementor.php';
		$installed_plugins = get_plugins();
		return isset( $installed_plugins[ $file_path ] );
	}

	public function ajax_a11y_install_elementor_set_admin_notice_viewed() {
		update_user_meta( get_current_user_id(), '_a11y_elementor_install_notice', 'true' );
	}

	public function admin_notices() {
		if ( ! current_user_can( 'install_plugins' ) || $this->_is_elementor_installed() ) {
			return;
		}

		if ( 'true' === get_user_meta( get_current_user_id(), '_a11y_elementor_install_notice', true ) ) {
			return;
		}

		if ( ! in_array( get_current_screen()->id, array( self::SETTINGS_SLUG, self::TOOLBAR_SLUG, 'dashboard', 'plugins', 'plugins-network' ) ) ) {
			return;
		}
		add_action( 'admin_footer', array( &$this, 'print_js' ) );
		$install_url = self_admin_url( 'plugin-install.php?tab=search&s=elementor' );
		?>
		<style>
			.notice.a11y-notice {
				border-left-color: #92003B !important;
				padding: 20px;
			}
			.rtl .notice.a11y-notice {
				border-right-color: #92003B !important;
			}
			.notice.a11y-notice .a11y-notice-inner {
				display: table;
				width: 100%;
			}
			.notice.a11y-notice .a11y-notice-inner .a11y-notice-icon,
			.notice.a11y-notice .a11y-notice-inner .a11y-notice-content,
			.notice.a11y-notice .a11y-notice-inner .a11y-install-now {
				display: table-cell;
				vertical-align: middle;
			}
			.notice.a11y-notice .a11y-notice-icon {
				color: #92003B;
				font-size: 50px;
				width: 50px;
				height: 50px;
			}
			.notice.a11y-notice .a11y-notice-content {
				padding: 0 20px;
			}
			.notice.a11y-notice p {
				padding: 0;
				margin: 0;
			}
			.notice.a11y-notice h3 {
				margin: 0 0 5px;
			}
			.notice.a11y-notice .a11y-install-now {
				text-align: center;
			}
			.notice.a11y-notice .a11y-install-now .a11y-install-button {
				background-color: #92003B;
				color: #fff;
				border-color: #92003B;
				box-shadow: 0 1px 0 #92003B;
				padding: 5px 30px;
				height: auto;
				line-height: 20px;
				text-transform: capitalize;
			}
			.notice.a11y-notice .a11y-install-now .a11y-install-button i {
				padding-right: 5px;
			}
			.rtl .notice.a11y-notice .a11y-install-now .a11y-install-button i {
				padding-right: 0;
				padding-left: 5px;
			}
			.notice.a11y-notice .a11y-install-now .a11y-install-button:hover {
				background-color: #92003B;
			}
			.notice.a11y-notice .a11y-install-now .a11y-install-button:active {
				box-shadow: inset 0 1px 0 #92003B;
				transform: translateY(1px);
			}
			@media (max-width: 767px) {
				.notice.a11y-notice {
					padding: 10px;
				}
				.notice.a11y-notice .a11y-notice-inner {
					display: block;
				}
				.notice.a11y-notice .a11y-notice-inner .a11y-notice-content {
					display: block;
					padding: 0;
				}
				.notice.a11y-notice .a11y-notice-inner .a11y-notice-icon,
				.notice.a11y-notice .a11y-notice-inner .a11y-install-now {
					display: none;
				}
			}
		</style>
		<div class="notice updated is-dismissible a11y-notice a11y-install-elementor">
			<div class="a11y-notice-inner">
				<div class="a11y-notice-icon">
					<svg width="50" height="50" viewBox="0 0 28 28" fill="none" xmlns="http://www.w3.org/2000/svg">
						<path d="M14.0035 3.98515e-07C8.34084 -0.00134594 3.23499 3.40874 1.06704 8.64C-1.10092 13.8713 0.0960255 19.8934 4.09968 23.898C8.10333 27.9026 14.1252 29.1009 19.3569 26.9342C24.5887 24.7675 28 19.6625 28 13.9998C28 6.26922 21.7341 0.00183839 14.0035 3.98515e-07Z" fill="#92003B"/>
						<rect x="8.1687" y="8.16504" width="2.3333" height="11.6665" fill="white"/>
						<rect x="12.8352" y="17.498" width="6.9999" height="2.3333" fill="white"/>
						<rect x="12.8352" y="12.8315" width="6.9999" height="2.3333" fill="white"/>
						<rect x="12.8352" y="8.16504" width="6.9999" height="2.3333" fill="white"/>
					</svg>
				</div>

				<div class="a11y-notice-content">
					<h3><?php esc_html_e( 'Do You Like One Click Accessibility? You\'ll Love Elementor!', 'pojo-accessibility' ); ?></h3>
					<p><?php esc_html_e( 'Create high-end, pixel perfect websites at record speeds. Any theme, any page, any design. The most advanced frontend drag & drop page builder.', 'pojo-accessibility' ); ?>
						<a href="https://elementor.com/?utm_source=accessibility&utm_medium=wp-dash&utm_campaign=notice" target="_blank"><?php esc_html_e( 'Learn more about Elementor', 'pojo-accessibility' ); ?></a>.</p>
				</div>

				<div class="a11y-install-now">
					<a class="button a11y-install-button" href="<?php echo $install_url; ?>"><i class="dashicons dashicons-download"></i><?php esc_html_e( 'Install Now For Free!', 'pojo-accessibility' ); ?></a>
				</div>
			</div>
		</div>
		<?php
	}

	public function print_js() {
		?>
		<script>jQuery( function( $ ) {
				$( 'div.notice.a11y-install-elementor' ).on( 'click', 'button.notice-dismiss', function( event ) {
					event.preventDefault();
					$.post( ajaxurl, {
						action: 'a11y_install_elementor_set_admin_notice_viewed'
					} );
				} );
			} );</script>
		<?php
	}

	public function admin_footer_text( $footer_text ) {
		$current_screen = get_current_screen();
		if ( in_array( $current_screen->id, array( self::SETTINGS_SLUG, self::TOOLBAR_SLUG ) ) ) {
			$footer_text = sprintf(
				/* translators: 1: One Click Accessibility, 2: Link to plugin review */
				__( 'Enjoyed %1$s? Please leave us a %2$s rating. We really appreciate your support!', 'pojo-accessibility' ),
				'<strong>' . __( 'One Click Accessibility', 'pojo-accessibility' ) . '</strong>',
				'<a href="https://wordpress.org/support/plugin/pojo-accessibility/reviews/?filter=5#new-post" target="_blank">&#9733;&#9733;&#9733;&#9733;&#9733;</a>'
			);
		}

		return $footer_text;
	}

	public function __construct() {
		add_action( 'admin_notices', array( &$this, 'admin_notices' ) );
		add_action( 'wp_ajax_a11y_install_elementor_set_admin_notice_viewed', array( &$this, 'ajax_a11y_install_elementor_set_admin_notice_viewed' ) );
		add_filter( 'admin_footer_text', [ $this, 'admin_footer_text' ] );
	}
}
<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Pojo_A11y_Customizer {

	private $css_rules = array();
	private $css_code = '';

	public function get_customizer_fields() {
		$fields = array();

		$fields[] = array(
			'id' => 'a11y_toolbar_icon',
			'title' => __( 'Toolbar Icon', 'pojo-accessibility' ),
			'type' => 'select',
			'choices' => array(
				'one-click' => __( 'One Click', 'pojo-accessibility' ),
				'wheelchair' => __( 'Wheelchair', 'pojo-accessibility' ),
				'accessibility' => __( 'Accessibility', 'pojo-accessibility' ),
			),
			'std' => 'one-click',
			'description' => __( 'Set Toolbar Icon', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'a11y_toolbar_position',
			'title' => __( 'Toolbar Position', 'pojo-accessibility' ),
			'type' => 'select',
			'choices' => array(
				'left' => __( 'Left', 'pojo-accessibility' ),
				'right' => __( 'Right', 'pojo-accessibility' ),
			),
			'std' => is_rtl() ? 'right' : 'left',
			'description' => __( 'Set Toolbar Position', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'a11y_toolbar_distance_top',
			'title' => __( 'Offset from Top (Desktop)', 'pojo-accessibility' ),
			'type' => 'text',
			'std' => '100px',
			'description' => __( 'Set Toolbar top offset (Desktop)', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'a11y_toolbar_distance_top_mobile',
			'title' => __( 'Offset from Top (Mobile)', 'pojo-accessibility' ),
			'type' => 'text',
			'std' => '50px',
			'description' => __( 'Set Toolbar top offset (Mobile)', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'a11y_bg_toolbar',
			'title' => __( 'Toolbar Background', 'pojo-accessibility' ),
			'type' => 'color',
			'std' => '#ffffff',
			'selector' => '#pojo-a11y-toolbar .pojo-a11y-toolbar-overlay',
			'change_type' => 'bg_color',
			'description' => __( 'Set Toolbar background color', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'a11y_color_toolbar',
			'title' => __( 'Toolbar Color', 'pojo-accessibility' ),
			'type' => 'color',
			'std' => '#333333',
			'selector' => '#pojo-a11y-toolbar .pojo-a11y-toolbar-overlay ul.pojo-a11y-toolbar-items li.pojo-a11y-toolbar-item a, #pojo-a11y-toolbar .pojo-a11y-toolbar-overlay p.pojo-a11y-toolbar-title',
			'change_type' => 'color',
			'description' => __( 'Set Toolbar text color', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'a11y_toggle_button_bg_color',
			'title' => __( 'Toggle Button Background', 'pojo-accessibility' ),
			'type' => 'color',
			'std' => '#4054b2',
			'description' => __( 'Set Toolbar toggle button background color', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'a11y_toggle_button_color',
			'title' => __( 'Toggle Button Color', 'pojo-accessibility' ),
			'type' => 'color',
			'std' => '#ffffff',
			'selector' => '#pojo-a11y-toolbar .pojo-a11y-toolbar-toggle a',
			'change_type' => 'color',
			'description' => __( 'Set Toolbar toggle button icon color', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'a11y_bg_active',
			'title' => __( 'Active Background', 'pojo-accessibility' ),
			'type' => 'color',
			'std' => '#4054b2',
			'selector' => '#pojo-a11y-toolbar .pojo-a11y-toolbar-overlay ul.pojo-a11y-toolbar-items li.pojo-a11y-toolbar-item a.active',
			'change_type' => 'bg_color',
			'description' => __( 'Set Toolbar active background color', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'a11y_color_active',
			'title' => __( 'Active Color', 'pojo-accessibility' ),
			'type' => 'color',
			'std' => '#ffffff',
			'selector' => '#pojo-a11y-toolbar .pojo-a11y-toolbar-overlay ul.pojo-a11y-toolbar-items li.pojo-a11y-toolbar-item a.active',
			'change_type' => 'color',
			'description' => __( 'Set Toolbar active text color', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'a11y_focus_outline_style',
			'title' => __( 'Focus Outline Style', 'pojo-accessibility' ),
			'type' => 'select',
			'choices' => array(
				'solid' => __( 'Solid', 'pojo-accessibility' ),
				'dotted' => __( 'Dotted', 'pojo-accessibility' ),
				'dashed' => __( 'Dashed', 'pojo-accessibility' ),
				'double' => __( 'Double', 'pojo-accessibility' ),
				'groove' => __( 'Groove', 'pojo-accessibility' ),
				'ridge' => __( 'Ridge', 'pojo-accessibility' ),
				'outset' => __( 'Outset', 'pojo-accessibility' ),
				'initial' => __( 'Initial', 'pojo-accessibility' ),
			),
			'std' => 'solid',
			'description' => __( 'Set Focus outline style', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'a11y_focus_outline_width',
			'title' => __( 'Focus Outline Width', 'pojo-accessibility' ),
			'type' => 'select',
			'choices' => array(
				'1px' => '1px',
				'2px' => '2px',
				'3px' => '3px',
				'4px' => '4px',
				'5px' => '5px',
				'6px' => '6px',
				'7px' => '7px',
				'8px' => '8px',
				'9px' => '9px',
				'10px' => '10px',
			),
			'std' => '1px',
			'description' => __( 'Set Focus outline width', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'a11y_focus_outline_color',
			'title' => __( 'Focus Outline Color', 'pojo-accessibility' ),
			'type' => 'color',
			'std' => '#FF0000',
			'description' => __( 'Set Focus outline color', 'pojo-accessibility' ),
		);

		return $fields;
	}

	public function customize_a11y( $wp_customize ) {
		$fields = $this->get_customizer_fields();

		$section_description = '<p>' . __( 'Use the control below to customize the appearance and layout of the Accessibility Toolbar', 'pojo-accessibility' ) . '</p><p>' .
			sprintf( __( 'Additional Toolbar settings can be configured at the %s page.', 'pojo-accessibility' ),
				'<a href="' . admin_url( 'admin.php?page=accessibility-toolbar' ) . '" target="blank">' . __( 'Accessibility Toolbar', 'pojo-accessibility' ) . '</a>'
			) . '</p>';

		$wp_customize->add_section( 'accessibility', array(
			'title' => __( 'Accessibility', 'pojo-accessibility' ),
			'priority'   => 30,
			'description' => $section_description,
		) );

		foreach ( $fields as $field ) {
			$customizer_id = POJO_A11Y_CUSTOMIZER_OPTIONS . '[' . $field['id'] . ']';
			$wp_customize->add_setting( $customizer_id, array(
				'default' => $field['std'] ? $field['std'] : null,
				'type' => 'option',
			) );
			switch ( $field['type'] ) {
				case 'color':
					$wp_customize->add_control( new WP_Customize_Color_Control( $wp_customize, $field['id'], array(
						'label'    => $field['title'],
						'section'  => 'accessibility',
						'settings' => $customizer_id,
						'description' => isset( $field['description'] ) ? $field['description'] : null,
					) ) );
					break;
				case 'select':
				case 'text':
					$wp_customize->add_control( $field['id'], array(
						'label'    => $field['title'],
						'section'  => 'accessibility',
						'settings' => $customizer_id,
						'type'     => $field['type'],
						'choices'  => isset( $field['choices'] ) ? $field['choices'] : null,
						'description' => isset( $field['description'] ) ? $field['description'] : null,
					) );
					break;
			}
		}
	}

	public function get_custom_css_code() {
		$options = $this->get_customizer_options();
		$bg_color = $options['a11y_toggle_button_bg_color']; // get_theme_mod( 'a11y_toggle_button_bg_color', '#4054b2' );
		if ( ! empty( $bg_color ) ) {
			$this->add_css_rule( '#pojo-a11y-toolbar .pojo-a11y-toolbar-toggle a', 'background-color', $bg_color );
			$this->add_css_rule( '#pojo-a11y-toolbar .pojo-a11y-toolbar-overlay, #pojo-a11y-toolbar .pojo-a11y-toolbar-overlay ul.pojo-a11y-toolbar-items.pojo-a11y-links', 'border-color', $bg_color );
		}

		$outline_style = $options['a11y_focus_outline_style']; //get_theme_mod( 'a11y_focus_outline_style', 'solid' );
		if ( ! empty( $outline_style ) ) {
			$this->add_css_rule( 'body.pojo-a11y-focusable a:focus', 'outline-style', $outline_style . ' !important' );
		}

		$outline_width = $options['a11y_focus_outline_width']; // get_theme_mod( 'a11y_focus_outline_width', '1px' );
		if ( ! empty( $outline_width ) ) {
			$this->add_css_rule( 'body.pojo-a11y-focusable a:focus', 'outline-width', $outline_width . ' !important' );
		}

		$outline_color = $options['a11y_focus_outline_color']; //get_theme_mod( 'a11y_focus_outline_color', '#FF0000' );
		if ( ! empty( $outline_color ) ) {
			$this->add_css_rule( 'body.pojo-a11y-focusable a:focus', 'outline-color', $outline_color . ' !important' );
		}

		$distance_top = $options['a11y_toolbar_distance_top']; //get_theme_mod( 'a11y_toolbar_distance_top', '100px' );
		if ( ! empty( $distance_top ) ) {
			$this->add_css_rule( '#pojo-a11y-toolbar', 'top', $distance_top . ' !important' );
		}

		$distance_top_mobile = $options['a11y_toolbar_distance_top_mobile']; // get_theme_mod( 'a11y_toolbar_distance_top_mobile', '50px' );
		if ( ! empty( $distance_top_mobile ) ) {
			$this->add_css_code( "@media (max-width: 767px) { #pojo-a11y-toolbar { top: {$distance_top_mobile} !important; } }" );
		}

		$fields = $this->get_customizer_fields();
		foreach ( $fields as $field ) {
			if ( empty( $field['selector'] ) || empty( $field['change_type'] ) ) {
				continue;
			}

			$option = $options[ $field['id'] ];

			if ( 'color' === $field['change_type'] ) {
				$this->add_css_rule( $field['selector'], 'color', $option );
			} elseif ( 'bg_color' === $field['change_type'] ) {
				$this->add_css_rule( $field['selector'], 'background-color', $option );
			}
		}
	}

	private function get_customizer_options() {
		static $options = false;
		if ( false === $options ) {
			$options = get_option( POJO_A11Y_CUSTOMIZER_OPTIONS );
		}
		return $options;
	}

	private function add_css_rule( $selector, $rule, $value ) {
		if ( ! isset( $this->css_rules[ $selector ] ) ) {
			$this->css_rules[ $selector ] = array();
		}
		$this->css_rules[ $selector ][] = $rule . ': ' . $value . ';';
	}

	private function add_css_code( $code ) {
		$this->css_code .= "\n" . $code;
	}

	public function print_css_code() {
		$this->get_custom_css_code();
		$css = '';
		foreach ( $this->css_rules as $selector => $css_rules ) {
			$css .= "\n" . $selector . '{ ' . implode( "\t", $css_rules ) . '}';
		}
		echo '<style type="text/css">' . $css . $this->css_code . '</style>';
	}

	public function __construct() {
		add_filter( 'customize_register', array( &$this, 'customize_a11y' ), 610 );
		add_filter( 'wp_head', array( &$this, 'print_css_code' ) );
	}
}
<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

final class Pojo_A11y_Elementor {

	public function is_toolbar_active( $is_active ) {
		if ( \Elementor\Plugin::$instance->preview->is_preview_mode() ) {
			$is_active = false;
		}

		return $is_active;
	}

	public function __construct() {
		add_filter( 'pojo_a11y_frontend_is_toolbar_active', [ $this, 'is_toolbar_active' ] );
	}
}
<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

final class Pojo_A11y_Frontend {

	public $svg_icons = null;

	public function is_toolbar_active() {
		$is_active = 'disable' !== get_option( 'pojo_a11y_toolbar' );

		$is_active = apply_filters( 'pojo_a11y_frontend_is_toolbar_active', $is_active );

		return $is_active;
	}

	public function is_toolbar_button_active( $button_type ) {
		return 'disable' !== get_option( "pojo_a11y_toolbar_button_{$button_type}" );
	}

	public function get_toolbar_button_title( $button_type ) {
		$title = Pojo_Accessibility::$instance->settings->get_default_title_text( "pojo_a11y_toolbar_button_{$button_type}_title" );
		return '<span class="pojo-a11y-toolbar-icon">' . $this->get_toolbar_svg( $button_type, $title ) . '</span><span class="pojo-a11y-toolbar-text">' . $title . '</span>';
	}

	public function enqueue_scripts() {
		wp_register_script(
			'pojo-a11y',
			POJO_A11Y_ASSETS_URL . 'js/app.min.js',
			array(
				'jquery',
			),
			'1.0.0',
			true
		);

		wp_register_style(
			'pojo-a11y',
			POJO_A11Y_ASSETS_URL . 'css/style.min.css',
			array(),
			'1.0.0'
		);

		wp_enqueue_script( 'pojo-a11y' );
		wp_enqueue_style( 'pojo-a11y' );

		wp_localize_script(
			'pojo-a11y',
			'PojoA11yOptions',
			array(
				'focusable' => ( 'enable' === get_option( 'pojo_a11y_focusable' ) ),
				'remove_link_target' => ( 'enable' === get_option( 'pojo_a11y_remove_link_target' ) ),
				'add_role_links' => ( 'enable' === get_option( 'pojo_a11y_add_role_links' ) ),
				'enable_save' => ( 'enable' === get_option( 'pojo_a11y_save' ) ),
				'save_expiration' => get_option( 'pojo_a11y_save_expiration' ),
			)
		);
	}

	public function print_skip_to_content_link() {
		$skip_to_content_link = get_option( 'pojo_a11y_skip_to_content_link' );
		if ( 'disable' === $skip_to_content_link ) {
			return;
		}

		$element_id = get_option( 'pojo_a11y_skip_to_content_link_element_id', 'content' );

		?>
		<a id="pojo-a11y-skip-content" class="pojo-skip-link pojo-skip-content" tabindex="1" accesskey="s" href="#<?php echo esc_html( $element_id ); ?>"><?php esc_html_e( 'Skip to content', 'pojo-accessibility' ); ?></a>
		<?php
	}

	public function print_toolbar() {
		if ( ! $this->is_toolbar_active() ) {
			return;
		}

		$customizer_options = get_option( POJO_A11Y_CUSTOMIZER_OPTIONS );

		$toolbar_position = $customizer_options['a11y_toolbar_position'];
		if ( empty( $toolbar_position ) || ! in_array( $toolbar_position, array( 'right', 'left' ) ) ) {
			$toolbar_position = 'left';
		}

		$toolbar_title = Pojo_Accessibility::$instance->settings->get_default_title_text( 'pojo_a11y_toolbar_title' );
		$toolbar_visibility = get_option( 'pojo_a11y_toolbar' );

		$wrapper_classes = array(
			'pojo-a11y-toolbar-' . $toolbar_position,
		);

		if ( 'enable' !== $toolbar_visibility ) {
			$wrapper_classes[] = 'pojo-a11y-' . $toolbar_visibility;
		}

		$sitemap_link = get_option( 'pojo_a11y_toolbar_button_sitemap_link' );
		$help_link = get_option( 'pojo_a11y_toolbar_button_help_link' );
		$feedback_link = get_option( 'pojo_a11y_toolbar_button_feedback_link' );

		$has_custom_links = ( ! empty( $sitemap_link ) || ! empty( $help_link ) || ! empty( $feedback_link ) );

		$icon = isset( $customizer_options['a11y_toolbar_icon'] ) ? $customizer_options['a11y_toolbar_icon'] : 'one-click';

		?>
		<nav id="pojo-a11y-toolbar" class="<?php echo esc_attr( implode( ' ', $wrapper_classes ) ); ?>" role="navigation">
			<div class="pojo-a11y-toolbar-toggle">
				<a class="pojo-a11y-toolbar-link pojo-a11y-toolbar-toggle-link" href="javascript:void(0);" title="<?php echo esc_attr( $toolbar_title ); ?>" role="button">
					<span class="pojo-sr-only sr-only"><?php esc_html_e( 'Open toolbar', 'pojo-accessibility' ); ?></span>
					<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100" fill="currentColor" width="1em">
						<title><?php echo esc_html( $toolbar_title ); ?></title>
						<?php echo $this->get_svg_icon( $icon ); ?>
					</svg>
				</a>
			</div>
			<div class="pojo-a11y-toolbar-overlay">
				<div class="pojo-a11y-toolbar-inner">
					<p class="pojo-a11y-toolbar-title"><?php echo $toolbar_title; ?></p>
					
					<ul class="pojo-a11y-toolbar-items pojo-a11y-tools">
						<?php do_action( 'pojo_a11y_toolbar_before_buttons' ); ?>
						<?php if ( $this->is_toolbar_button_active( 'resize_font' ) ) : ?>
							<li class="pojo-a11y-toolbar-item">
								<a href="#" class="pojo-a11y-toolbar-link pojo-a11y-btn-resize-font pojo-a11y-btn-resize-plus" data-action="resize-plus" data-action-group="resize" tabindex="-1" role="button">
									<?php echo $this->get_toolbar_button_title( 'resize_font_add' ); ?>
								</a>
							</li>
							
							<li class="pojo-a11y-toolbar-item">
								<a href="#" class="pojo-a11y-toolbar-link pojo-a11y-btn-resize-font pojo-a11y-btn-resize-minus" data-action="resize-minus" data-action-group="resize" tabindex="-1" role="button">
									<?php echo $this->get_toolbar_button_title( 'resize_font_less' ); ?>
								</a>
							</li>
						<?php endif; ?>

						<?php if ( $this->is_toolbar_button_active( 'grayscale' ) ) : ?>
							<li class="pojo-a11y-toolbar-item">
								<a href="#" class="pojo-a11y-toolbar-link pojo-a11y-btn-background-group pojo-a11y-btn-grayscale" data-action="grayscale" data-action-group="schema" tabindex="-1" role="button">
									<?php echo $this->get_toolbar_button_title( 'grayscale' ); ?>
								</a>
							</li>
						<?php endif; ?>

						<?php if ( $this->is_toolbar_button_active( 'high_contrast' ) ) : ?>
							<li class="pojo-a11y-toolbar-item">
								<a href="#" class="pojo-a11y-toolbar-link pojo-a11y-btn-background-group pojo-a11y-btn-high-contrast" data-action="high-contrast" data-action-group="schema" tabindex="-1" role="button">
									<?php echo $this->get_toolbar_button_title( 'high_contrast' ); ?>
								</a>
							</li>
						<?php endif; ?>

						<?php if ( $this->is_toolbar_button_active( 'negative_contrast' ) ) : ?>
							<li class="pojo-a11y-toolbar-item">
								<a href="#" class="pojo-a11y-toolbar-link pojo-a11y-btn-background-group pojo-a11y-btn-negative-contrast" data-action="negative-contrast" data-action-group="schema" tabindex="-1" role="button">

									<?php echo $this->get_toolbar_button_title( 'negative_contrast' ); ?>
								</a>
							</li>
						<?php endif; ?>

						<?php if ( $this->is_toolbar_button_active( 'light_bg' ) ) : ?>
							<li class="pojo-a11y-toolbar-item">
								<a href="#" class="pojo-a11y-toolbar-link pojo-a11y-btn-background-group pojo-a11y-btn-light-background" data-action="light-background" data-action-group="schema" tabindex="-1" role="button">
									<?php echo $this->get_toolbar_button_title( 'light_bg' ); ?>
								</a>
							</li>
						<?php endif; ?>

						<?php if ( $this->is_toolbar_button_active( 'links_underline' ) ) : ?>
							<li class="pojo-a11y-toolbar-item">
								<a href="#" class="pojo-a11y-toolbar-link pojo-a11y-btn-links-underline" data-action="links-underline" data-action-group="toggle" tabindex="-1" role="button">
									<?php echo $this->get_toolbar_button_title( 'links_underline' ); ?>
								</a>
							</li>
						<?php endif; ?>

						<?php if ( $this->is_toolbar_button_active( 'readable_font' ) ) : ?>
							<li class="pojo-a11y-toolbar-item">
								<a href="#" class="pojo-a11y-toolbar-link pojo-a11y-btn-readable-font" data-action="readable-font" data-action-group="toggle" tabindex="-1" role="button">
									<?php echo $this->get_toolbar_button_title( 'readable_font' ); ?>
								</a>
							</li>
						<?php endif; ?>
						<?php do_action( 'pojo_a11y_toolbar_after_buttons' ); ?>
						<li class="pojo-a11y-toolbar-item">
							<a href="#" class="pojo-a11y-toolbar-link pojo-a11y-btn-reset" data-action="reset" tabindex="-1" role="button">
								<span class="pojo-a11y-toolbar-icon"><?php echo $this->get_toolbar_svg( 'reset', esc_html__( 'Reset', 'pojo-accessibility' ) ); ?></span>
								<span class="pojo-a11y-toolbar-text"><?php esc_html_e( 'Reset', 'pojo-accessibility' ); ?></span>
							</a>
						</li>
					</ul>
					<?php if ( $has_custom_links ) : ?>
					<ul class="pojo-a11y-toolbar-items pojo-a11y-links">
						<?php if ( ! empty( $sitemap_link ) ) : ?>
						<li class="pojo-a11y-toolbar-item">
							<a href="<?php echo esc_attr( $sitemap_link ); ?>" class="pojo-a11y-toolbar-link pojo-a11y-link-sitemap" tabindex="-1" role="button">
								<?php echo $this->get_toolbar_button_title( 'sitemap' ); ?>
							</a>
						</li>
						<?php endif; ?>
						<?php if ( ! empty( $help_link ) ) : ?>
						<li class="pojo-a11y-toolbar-item">
							<a href="<?php echo esc_attr( $help_link ); ?>" class="pojo-a11y-toolbar-link pojo-a11y-link-help" tabindex="-1" role="button">
								<?php echo $this->get_toolbar_button_title( 'help' ); ?>
							</a>
						</li>
						<?php endif; ?>
						<?php if ( ! empty( $feedback_link ) ) : ?>
						<li class="pojo-a11y-toolbar-item">
							<a href="<?php echo esc_attr( $feedback_link ); ?>" class="pojo-a11y-toolbar-link pojo-a11y-link-feedback" tabindex="-1" role="button">
								<?php echo $this->get_toolbar_button_title( 'feedback' ); ?>
							</a>
						</li>
						<?php endif; ?>
					</ul>
					<?php endif; ?>
				</div>
			</div>
		</nav>
		<?php
	}

	private function get_toolbar_svg( $icon, $icon_title = '' ) {
		$icons = array(
			'resize_font_add'   => '<path fill="currentColor" d="M256 200v16c0 4.25-3.75 8-8 8h-56v56c0 4.25-3.75 8-8 8h-16c-4.25 0-8-3.75-8-8v-56h-56c-4.25 0-8-3.75-8-8v-16c0-4.25 3.75-8 8-8h56v-56c0-4.25 3.75-8 8-8h16c4.25 0 8 3.75 8 8v56h56c4.25 0 8 3.75 8 8zM288 208c0-61.75-50.25-112-112-112s-112 50.25-112 112 50.25 112 112 112 112-50.25 112-112zM416 416c0 17.75-14.25 32-32 32-8.5 0-16.75-3.5-22.5-9.5l-85.75-85.5c-29.25 20.25-64.25 31-99.75 31-97.25 0-176-78.75-176-176s78.75-176 176-176 176 78.75 176 176c0 35.5-10.75 70.5-31 99.75l85.75 85.75c5.75 5.75 9.25 14 9.25 22.5z"></path>',
			'resize_font_less'  => '<path fill="currentColor" d="M256 200v16c0 4.25-3.75 8-8 8h-144c-4.25 0-8-3.75-8-8v-16c0-4.25 3.75-8 8-8h144c4.25 0 8 3.75 8 8zM288 208c0-61.75-50.25-112-112-112s-112 50.25-112 112 50.25 112 112 112 112-50.25 112-112zM416 416c0 17.75-14.25 32-32 32-8.5 0-16.75-3.5-22.5-9.5l-85.75-85.5c-29.25 20.25-64.25 31-99.75 31-97.25 0-176-78.75-176-176s78.75-176 176-176 176 78.75 176 176c0 35.5-10.75 70.5-31 99.75l85.75 85.75c5.75 5.75 9.25 14 9.25 22.5z"></path>',
			'grayscale'         => '<path fill="currentColor" d="M15.75 384h-15.75v-352h15.75v352zM31.5 383.75h-8v-351.75h8v351.75zM55 383.75h-7.75v-351.75h7.75v351.75zM94.25 383.75h-7.75v-351.75h7.75v351.75zM133.5 383.75h-15.5v-351.75h15.5v351.75zM165 383.75h-7.75v-351.75h7.75v351.75zM180.75 383.75h-7.75v-351.75h7.75v351.75zM196.5 383.75h-7.75v-351.75h7.75v351.75zM235.75 383.75h-15.75v-351.75h15.75v351.75zM275 383.75h-15.75v-351.75h15.75v351.75zM306.5 383.75h-15.75v-351.75h15.75v351.75zM338 383.75h-15.75v-351.75h15.75v351.75zM361.5 383.75h-15.75v-351.75h15.75v351.75zM408.75 383.75h-23.5v-351.75h23.5v351.75zM424.5 383.75h-8v-351.75h8v351.75zM448 384h-15.75v-352h15.75v352z"></path>',
			'high_contrast'     => '<path fill="currentColor" d="M192 360v-272c-75 0-136 61-136 136s61 136 136 136zM384 224c0 106-86 192-192 192s-192-86-192-192 86-192 192-192 192 86 192 192z"></path>',
			'negative_contrast' => '<path fill="currentColor" d="M416 240c-23.75-36.75-56.25-68.25-95.25-88.25 10 17 15.25 36.5 15.25 56.25 0 61.75-50.25 112-112 112s-112-50.25-112-112c0-19.75 5.25-39.25 15.25-56.25-39 20-71.5 51.5-95.25 88.25 42.75 66 111.75 112 192 112s149.25-46 192-112zM236 144c0-6.5-5.5-12-12-12-41.75 0-76 34.25-76 76 0 6.5 5.5 12 12 12s12-5.5 12-12c0-28.5 23.5-52 52-52 6.5 0 12-5.5 12-12zM448 240c0 6.25-2 12-5 17.25-46 75.75-130.25 126.75-219 126.75s-173-51.25-219-126.75c-3-5.25-5-11-5-17.25s2-12 5-17.25c46-75.5 130.25-126.75 219-126.75s173 51.25 219 126.75c3 5.25 5 11 5 17.25z"></path>',
			'light_bg' => '<path fill="currentColor" d="M184 144c0 4.25-3.75 8-8 8s-8-3.75-8-8c0-17.25-26.75-24-40-24-4.25 0-8-3.75-8-8s3.75-8 8-8c23.25 0 56 12.25 56 40zM224 144c0-50-50.75-80-96-80s-96 30-96 80c0 16 6.5 32.75 17 45 4.75 5.5 10.25 10.75 15.25 16.5 17.75 21.25 32.75 46.25 35.25 74.5h57c2.5-28.25 17.5-53.25 35.25-74.5 5-5.75 10.5-11 15.25-16.5 10.5-12.25 17-29 17-45zM256 144c0 25.75-8.5 48-25.75 67s-40 45.75-42 72.5c7.25 4.25 11.75 12.25 11.75 20.5 0 6-2.25 11.75-6.25 16 4 4.25 6.25 10 6.25 16 0 8.25-4.25 15.75-11.25 20.25 2 3.5 3.25 7.75 3.25 11.75 0 16.25-12.75 24-27.25 24-6.5 14.5-21 24-36.75 24s-30.25-9.5-36.75-24c-14.5 0-27.25-7.75-27.25-24 0-4 1.25-8.25 3.25-11.75-7-4.5-11.25-12-11.25-20.25 0-6 2.25-11.75 6.25-16-4-4.25-6.25-10-6.25-16 0-8.25 4.5-16.25 11.75-20.5-2-26.75-24.75-53.5-42-72.5s-25.75-41.25-25.75-67c0-68 64.75-112 128-112s128 44 128 112z"></path>',
			'links_underline' => '<path fill="currentColor" d="M364 304c0-6.5-2.5-12.5-7-17l-52-52c-4.5-4.5-10.75-7-17-7-7.25 0-13 2.75-18 8 8.25 8.25 18 15.25 18 28 0 13.25-10.75 24-24 24-12.75 0-19.75-9.75-28-18-5.25 5-8.25 10.75-8.25 18.25 0 6.25 2.5 12.5 7 17l51.5 51.75c4.5 4.5 10.75 6.75 17 6.75s12.5-2.25 17-6.5l36.75-36.5c4.5-4.5 7-10.5 7-16.75zM188.25 127.75c0-6.25-2.5-12.5-7-17l-51.5-51.75c-4.5-4.5-10.75-7-17-7s-12.5 2.5-17 6.75l-36.75 36.5c-4.5 4.5-7 10.5-7 16.75 0 6.5 2.5 12.5 7 17l52 52c4.5 4.5 10.75 6.75 17 6.75 7.25 0 13-2.5 18-7.75-8.25-8.25-18-15.25-18-28 0-13.25 10.75-24 24-24 12.75 0 19.75 9.75 28 18 5.25-5 8.25-10.75 8.25-18.25zM412 304c0 19-7.75 37.5-21.25 50.75l-36.75 36.5c-13.5 13.5-31.75 20.75-50.75 20.75-19.25 0-37.5-7.5-51-21.25l-51.5-51.75c-13.5-13.5-20.75-31.75-20.75-50.75 0-19.75 8-38.5 22-52.25l-22-22c-13.75 14-32.25 22-52 22-19 0-37.5-7.5-51-21l-52-52c-13.75-13.75-21-31.75-21-51 0-19 7.75-37.5 21.25-50.75l36.75-36.5c13.5-13.5 31.75-20.75 50.75-20.75 19.25 0 37.5 7.5 51 21.25l51.5 51.75c13.5 13.5 20.75 31.75 20.75 50.75 0 19.75-8 38.5-22 52.25l22 22c13.75-14 32.25-22 52-22 19 0 37.5 7.5 51 21l52 52c13.75 13.75 21 31.75 21 51z"></path>',
			'readable_font' => '<path fill="currentColor" d="M181.25 139.75l-42.5 112.5c24.75 0.25 49.5 1 74.25 1 4.75 0 9.5-0.25 14.25-0.5-13-38-28.25-76.75-46-113zM0 416l0.5-19.75c23.5-7.25 49-2.25 59.5-29.25l59.25-154 70-181h32c1 1.75 2 3.5 2.75 5.25l51.25 120c18.75 44.25 36 89 55 133 11.25 26 20 52.75 32.5 78.25 1.75 4 5.25 11.5 8.75 14.25 8.25 6.5 31.25 8 43 12.5 0.75 4.75 1.5 9.5 1.5 14.25 0 2.25-0.25 4.25-0.25 6.5-31.75 0-63.5-4-95.25-4-32.75 0-65.5 2.75-98.25 3.75 0-6.5 0.25-13 1-19.5l32.75-7c6.75-1.5 20-3.25 20-12.5 0-9-32.25-83.25-36.25-93.5l-112.5-0.5c-6.5 14.5-31.75 80-31.75 89.5 0 19.25 36.75 20 51 22 0.25 4.75 0.25 9.5 0.25 14.5 0 2.25-0.25 4.5-0.5 6.75-29 0-58.25-5-87.25-5-3.5 0-8.5 1.5-12 2-15.75 2.75-31.25 3.5-47 3.5z"></path>',
			'reset' => '<path fill="currentColor" d="M384 224c0 105.75-86.25 192-192 192-57.25 0-111.25-25.25-147.75-69.25-2.5-3.25-2.25-8 0.5-10.75l34.25-34.5c1.75-1.5 4-2.25 6.25-2.25 2.25 0.25 4.5 1.25 5.75 3 24.5 31.75 61.25 49.75 101 49.75 70.5 0 128-57.5 128-128s-57.5-128-128-128c-32.75 0-63.75 12.5-87 34.25l34.25 34.5c4.75 4.5 6 11.5 3.5 17.25-2.5 6-8.25 10-14.75 10h-112c-8.75 0-16-7.25-16-16v-112c0-6.5 4-12.25 10-14.75 5.75-2.5 12.75-1.25 17.25 3.5l32.5 32.25c35.25-33.25 83-53 132.25-53 105.75 0 192 86.25 192 192z"></path>',
			'sitemap' => '<path fill="currentColor" d="M448 312v80c0 13.25-10.75 24-24 24h-80c-13.25 0-24-10.75-24-24v-80c0-13.25 10.75-24 24-24h24v-48h-128v48h24c13.25 0 24 10.75 24 24v80c0 13.25-10.75 24-24 24h-80c-13.25 0-24-10.75-24-24v-80c0-13.25 10.75-24 24-24h24v-48h-128v48h24c13.25 0 24 10.75 24 24v80c0 13.25-10.75 24-24 24h-80c-13.25 0-24-10.75-24-24v-80c0-13.25 10.75-24 24-24h24v-48c0-17.5 14.5-32 32-32h128v-48h-24c-13.25 0-24-10.75-24-24v-80c0-13.25 10.75-24 24-24h80c13.25 0 24 10.75 24 24v80c0 13.25-10.75 24-24 24h-24v48h128c17.5 0 32 14.5 32 32v48h24c13.25 0 24 10.75 24 24z"></path>',
			'help' => '<path fill="currentColor" d="M224 344v-48c0-4.5-3.5-8-8-8h-48c-4.5 0-8 3.5-8 8v48c0 4.5 3.5 8 8 8h48c4.5 0 8-3.5 8-8zM288 176c0-45.75-48-80-91-80-40.75 0-71.25 17.5-92.75 53.25-2.25 3.5-1.25 8 2 10.5l33 25c1.25 1 3 1.5 4.75 1.5 2.25 0 4.75-1 6.25-3 11.75-15 16.75-19.5 21.5-23 4.25-3 12.5-6 21.5-6 16 0 30.75 10.25 30.75 21.25 0 13-6.75 19.5-22 26.5-17.75 8-42 28.75-42 53v9c0 4.5 3.5 8 8 8h48c4.5 0 8-3.5 8-8v0c0-5.75 7.25-18 19-24.75 19-10.75 45-25.25 45-63.25zM384 224c0 106-86 192-192 192s-192-86-192-192 86-192 192-192 192 86 192 192z"></path>',
			'feedback' => '<path fill="currentColor" d="M448 224c0 88.5-100.25 160-224 160-12.25 0-24.5-0.75-36.25-2-32.75 29-71.75 49.5-115 60.5-9 2.5-18.75 4.25-28.5 5.5-5.5 0.5-10.75-3.5-12-9.5v-0.25c-1.25-6.25 3-10 6.75-14.5 15.75-17.75 33.75-32.75 45.5-74.5-51.5-29.25-84.5-74.5-84.5-125.25 0-88.25 100.25-160 224-160s224 71.5 224 160z"></path>',
		);

		if ( isset( $icons[ $icon ] ) ) {
			$icon_title_html = '';
			if ( ! empty( $icon_title ) ) {
				$icon_title_html = '<title>' . esc_html( $icon_title ) . '</title>';
			}

			return sprintf( '<svg version="1.1" xmlns="http://www.w3.org/2000/svg" width="1em" viewBox="0 0 448 448">%s%s</svg>', $icon_title_html, $icons[ $icon ] );
		}

		return '';
	}

	private function get_svg_icon( $icon ) {
		if ( null === $this->svg_icons ) {
			$this->svg_icons = array(
				'wheelchair' => '<g><path d="M60.4,78.9c-2.2,4.1-5.3,7.4-9.2,9.8c-4,2.4-8.3,3.6-13,3.6c-6.9,0-12.8-2.4-17.7-7.3c-4.9-4.9-7.3-10.8-7.3-17.7c0-5,1.4-9.5,4.1-13.7c2.7-4.2,6.4-7.2,10.9-9.2l-0.9-7.3c-6.3,2.3-11.4,6.2-15.3,11.8C7.9,54.4,6,60.6,6,67.3c0,5.8,1.4,11.2,4.3,16.1s6.8,8.8,11.7,11.7c4.9,2.9,10.3,4.3,16.1,4.3c7,0,13.3-2.1,18.9-6.2c5.7-4.1,9.6-9.5,11.7-16.2l-5.7-11.4C63.5,70.4,62.5,74.8,60.4,78.9z"/><path d="M93.8,71.3l-11.1,5.5L70,51.4c-0.6-1.3-1.7-2-3.2-2H41.3l-0.9-7.2h22.7v-7.2H39.6L37.5,19c2.5,0.3,4.8-0.5,6.7-2.3c1.9-1.8,2.9-4,2.9-6.6c0-2.5-0.9-4.6-2.6-6.3c-1.8-1.8-3.9-2.6-6.3-2.6c-2,0-3.8,0.6-5.4,1.8c-1.6,1.2-2.7,2.7-3.2,4.6c-0.3,1-0.4,1.8-0.3,2.3l5.4,43.5c0.1,0.9,0.5,1.6,1.2,2.3c0.7,0.6,1.5,0.9,2.4,0.9h26.4l13.4,26.7c0.6,1.3,1.7,2,3.2,2c0.6,0,1.1-0.1,1.6-0.4L97,77.7L93.8,71.3z"/></g>',
				'one-click' => '<path d="M50 .8c5.7 0 10.4 4.7 10.4 10.4S55.7 21.6 50 21.6s-10.4-4.7-10.4-10.4S44.3.8 50 .8zM92.2 32l-21.9 2.3c-2.6.3-4.6 2.5-4.6 5.2V94c0 2.9-2.3 5.2-5.2 5.2H60c-2.7 0-4.9-2.1-5.2-4.7l-2.2-24.7c-.1-1.5-1.4-2.5-2.8-2.4-1.3.1-2.2 1.1-2.4 2.4l-2.2 24.7c-.2 2.7-2.5 4.7-5.2 4.7h-.5c-2.9 0-5.2-2.3-5.2-5.2V39.4c0-2.7-2-4.9-4.6-5.2L7.8 32c-2.6-.3-4.6-2.5-4.6-5.2v-.5c0-2.6 2.1-4.7 4.7-4.7h.5c19.3 1.8 33.2 2.8 41.7 2.8s22.4-.9 41.7-2.8c2.6-.2 4.9 1.6 5.2 4.3v1c-.1 2.6-2.1 4.8-4.8 5.1z"/>',
				'accessibility' => '<path d="M50 8.1c23.2 0 41.9 18.8 41.9 41.9 0 23.2-18.8 41.9-41.9 41.9C26.8 91.9 8.1 73.2 8.1 50S26.8 8.1 50 8.1M50 0C22.4 0 0 22.4 0 50s22.4 50 50 50 50-22.4 50-50S77.6 0 50 0zm0 11.3c-21.4 0-38.7 17.3-38.7 38.7S28.6 88.7 50 88.7 88.7 71.4 88.7 50 71.4 11.3 50 11.3zm0 8.9c4 0 7.3 3.2 7.3 7.3S54 34.7 50 34.7s-7.3-3.2-7.3-7.3 3.3-7.2 7.3-7.2zm23.7 19.7c-5.8 1.4-11.2 2.6-16.6 3.2.2 20.4 2.5 24.8 5 31.4.7 1.9-.2 4-2.1 4.7-1.9.7-4-.2-4.7-2.1-1.8-4.5-3.4-8.2-4.5-15.8h-2c-1 7.6-2.7 11.3-4.5 15.8-.7 1.9-2.8 2.8-4.7 2.1-1.9-.7-2.8-2.8-2.1-4.7 2.6-6.6 4.9-11 5-31.4-5.4-.6-10.8-1.8-16.6-3.2-1.7-.4-2.8-2.1-2.4-3.9.4-1.7 2.1-2.8 3.9-2.4 19.5 4.6 25.1 4.6 44.5 0 1.7-.4 3.5.7 3.9 2.4.7 1.8-.3 3.5-2.1 3.9z"/>',
			);
		}

		if ( isset( $this->svg_icons[ $icon ] ) ) {
			return $this->svg_icons[ $icon ];
		}

		return $this->svg_icons['accessibility'];
	}

	public function __construct() {
		add_action( 'wp_enqueue_scripts', array( &$this, 'enqueue_scripts' ) );

		add_action( 'wp_footer', array( &$this, 'print_skip_to_content_link' ), 20 );
		add_action( 'wp_footer', array( &$this, 'print_toolbar' ), 30 );
	}

}
<?php
if ( ! defined( 'ABSPATH' ) ) exit; // Exit if accessed directly

class Pojo_A11y_Settings {

	public $menu_slug = null;

	const PAGE_ID = 'pojo-a11y';
	const SETTINGS_PAGE = 'toplevel_page_accessibility-settings';
	const TOOLBAR_PAGE = 'accessibility_page_accessibility-toolbar';
	const FIELD_TEXT     = 'text';
	const FIELD_SELECT   = 'select';
	const FIELD_CHECKBOX_LIST = 'checkbox_list';

	protected $_fields = array();

	protected $_sections = array();
	protected $_defaults = array();
	protected $_pages    = array();


	/**
	 * Setup Toolbar fields
	 *
	 * @param array $sections
	 *
	 * @return array
	 */
	public function section_a11y_toolbar( $sections = array() ) {
		$fields = array();

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar',
			'title' => __( 'Display Toolbar', 'pojo-accessibility' ),
			'type' => self::FIELD_SELECT,
			'options' => array(
				'enable' => __( 'Show on all devices', 'pojo-accessibility' ),
				'visible-desktop' => __( 'Visible Desktop', 'pojo-accessibility' ),
				'visible-tablet' => __( 'Visible Tablet', 'pojo-accessibility' ),
				'visible-phone' => __( 'Visible Phone', 'pojo-accessibility' ),
				'hidden-desktop' => __( 'Hidden Desktop', 'pojo-accessibility' ),
				'hidden-tablet' => __( 'Hidden Tablet', 'pojo-accessibility' ),
				'hidden-phone' => __( 'Hidden Phone', 'pojo-accessibility' ),
				'disable' => __( 'Disable', 'pojo-accessibility' ),
			),
			'std' => 'enable',
		);

		$toolbar_options_classes = 'pojo-a11y-toolbar-button';

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar_title',
			'title' => __( 'Title', 'pojo-accessibility' ),
			'type' => self::FIELD_TEXT,
			'desc' => __( 'Title top of the toolbar (recommended).', 'pojo-accessibility' ),
			'class' => $toolbar_options_classes,
			'std' => __( 'Accessibility Tools', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar_button_resize_font',
			'title' => __( 'Resize Font', 'pojo-accessibility' ),
			'type' => self::FIELD_SELECT,
			'class' => $toolbar_options_classes,
			'options' => array(
				'enable' => __( 'Enable', 'pojo-accessibility' ),
				'disable' => __( 'Disable', 'pojo-accessibility' ),
			),
			'std' => 'enable',
		);

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar_button_resize_font_add_title',
			'title' => __( 'Increase Text', 'pojo-accessibility' ),
			'type' => self::FIELD_TEXT,
			'class' => $toolbar_options_classes . ' pojo-settings-child-row no-border',
			'std' => __( 'Increase Text', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar_button_resize_font_less_title',
			'title' => __( 'Decrease Text', 'pojo-accessibility' ),
			'type' => self::FIELD_TEXT,
			'class' => $toolbar_options_classes . ' pojo-settings-child-row',
			'std' => __( 'Decrease Text', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar_button_grayscale',
			'title' => __( 'Grayscale', 'pojo-accessibility' ),
			'type' => self::FIELD_SELECT,
			'class' => $toolbar_options_classes,
			'options' => array(
				'enable' => __( 'Enable', 'pojo-accessibility' ),
				'disable' => __( 'Disable', 'pojo-accessibility' ),
			),
			'std' => 'enable',
		);

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar_button_grayscale_title',
			'title' => __( 'Grayscale Title', 'pojo-accessibility' ),
			'type' => self::FIELD_TEXT,
			'class' => $toolbar_options_classes . ' pojo-settings-child-row',
			'std' => __( 'Grayscale', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar_button_high_contrast',
			'title' => __( 'High Contrast', 'pojo-accessibility' ),
			'type' => self::FIELD_SELECT,
			'class' => $toolbar_options_classes,
			'options' => array(
				'enable' => __( 'Enable', 'pojo-accessibility' ),
				'disable' => __( 'Disable', 'pojo-accessibility' ),
			),
			'std' => 'enable',
		);

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar_button_high_contrast_title',
			'title' => __( 'High Contrast Title', 'pojo-accessibility' ),
			'type' => self::FIELD_TEXT,
			'class' => $toolbar_options_classes . ' pojo-settings-child-row',
			'std' => __( 'High Contrast', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar_button_negative_contrast',
			'title' => __( 'Negative Contrast', 'pojo-accessibility' ),
			'type' => self::FIELD_SELECT,
			'class' => $toolbar_options_classes,
			'options' => array(
				'enable' => __( 'Enable', 'pojo-accessibility' ),
				'disable' => __( 'Disable', 'pojo-accessibility' ),
			),
			'std' => 'enable',
		);

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar_button_negative_contrast_title',
			'title' => __( 'Negative Contrast Title', 'pojo-accessibility' ),
			'type' => self::FIELD_TEXT,
			'class' => $toolbar_options_classes . ' pojo-settings-child-row',
			'std' => __( 'Negative Contrast', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar_button_light_bg',
			'title' => __( 'Light Background', 'pojo-accessibility' ),
			'type' => self::FIELD_SELECT,
			'class' => $toolbar_options_classes,
			'options' => array(
				'enable' => __( 'Enable', 'pojo-accessibility' ),
				'disable' => __( 'Disable', 'pojo-accessibility' ),
			),
			'std' => 'enable',
		);

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar_button_light_bg_title',
			'title' => __( 'Light Background Title', 'pojo-accessibility' ),
			'type' => self::FIELD_TEXT,
			'class' => $toolbar_options_classes . ' pojo-settings-child-row',
			'std' => __( 'Light Background', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar_button_links_underline',
			'title' => __( 'Links Underline', 'pojo-accessibility' ),
			'type' => self::FIELD_SELECT,
			'class' => $toolbar_options_classes,
			'options' => array(
				'enable' => __( 'Enable', 'pojo-accessibility' ),
				'disable' => __( 'Disable', 'pojo-accessibility' ),
			),
			'std' => 'enable',
		);

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar_button_links_underline_title',
			'title' => __( 'Links Underline Title', 'pojo-accessibility' ),
			'type' => self::FIELD_TEXT,
			'class' => $toolbar_options_classes . ' pojo-settings-child-row',
			'std' => __( 'Links Underline', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar_button_readable_font',
			'title' => __( 'Readable Font', 'pojo-accessibility' ),
			'type' => self::FIELD_SELECT,
			'class' => $toolbar_options_classes,
			'options' => array(
				'enable' => __( 'Enable', 'pojo-accessibility' ),
				'disable' => __( 'Disable', 'pojo-accessibility' ),
			),
			'std' => 'enable',
		);

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar_button_readable_font_title',
			'title' => __( 'Readable Font Title', 'pojo-accessibility' ),
			'type' => self::FIELD_TEXT,
			'class' => $toolbar_options_classes . ' pojo-settings-child-row',
			'std' => __( 'Readable Font', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar_button_sitemap_title',
			'title' => __( 'Sitemap Title', 'pojo-accessibility' ),
			'type' => self::FIELD_TEXT,
			'class' => $toolbar_options_classes,
			'std' => __( 'Sitemap', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar_button_sitemap_link',
			'title' => __( 'Sitemap Link', 'pojo-accessibility' ),
			'type' => self::FIELD_TEXT,
			'placeholder' => 'http://your-domain.com/sitemap',
			'desc' => __( 'Link for sitemap page in your website. Leave blank to disable.', 'pojo-accessibility' ),
			'class' => $toolbar_options_classes . ' pojo-settings-child-row',
			'std' => '',
		);

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar_button_help_title',
			'title' => __( 'Help Title', 'pojo-accessibility' ),
			'type' => self::FIELD_TEXT,
			'class' => $toolbar_options_classes,
			'std' => __( 'Help', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar_button_help_link',
			'title' => __( 'Help Link', 'pojo-accessibility' ),
			'type' => self::FIELD_TEXT,
			'placeholder' => 'http://your-domain.com/help',
			'desc' => __( 'Link for help page in your website. Leave blank to disable.', 'pojo-accessibility' ),
			'class' => $toolbar_options_classes . ' pojo-settings-child-row',
			'std' => '',
		);

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar_button_feedback_title',
			'title' => __( 'Feedback Title', 'pojo-accessibility' ),
			'type' => self::FIELD_TEXT,
			'class' => $toolbar_options_classes,
			'std' => __( 'Feedback', 'pojo-accessibility' ),
		);

		$fields[] = array(
			'id' => 'pojo_a11y_toolbar_button_feedback_link',
			'title' => __( 'Feedback Link', 'pojo-accessibility' ),
			'type' => self::FIELD_TEXT,
			'placeholder' => 'http://your-domain.com/feedback',
			'desc' => __( 'Link for feedback page in your website. Leave blank to disable.', 'pojo-accessibility' ),
			'class' => $toolbar_options_classes . ' pojo-settings-child-row',
			'std' => '',
		);

		$sections[] = array(
			'id' => 'section-a11y-toolbar',
			'page' => self::TOOLBAR_PAGE,
			'title' => __( 'Toolbar Settings', 'pojo-accessibility' ),
			'intro' => '',
			'fields' => $fields,
		);

		$sections[] = array(
			'id' => 'section-a11y-styles',
			'page' => self::TOOLBAR_PAGE,
			'title' => __( 'Style Settings', 'pojo-accessibility' ),
			'intro' => sprintf( __( 'For style settings of accessibility tools go to > Customize > <a href="%s">Accessibility</a>.', 'pojo-accessibility' ), $this->get_admin_url( 'customizer' ) ),
			'fields' => array(),
		);

		return $sections;
	}

	public function section_a11y_settings( $sections ) {
		$fields = array();

		$fields[] = array(
			'id' => 'pojo_a11y_focusable',
			'title' => __( 'Add Outline Focus', 'pojo-accessibility' ),
			'type' => self::FIELD_SELECT,
			'desc' => __( 'Add outline to elements on keyboard focus.', 'pojo-accessibility' ),
			'options' => array(
				'enable' => __( 'Enable', 'pojo-accessibility' ),
				'disable' => __( 'Disable', 'pojo-accessibility' ),
			),
			'std' => 'disable',
		);

		$fields[] = array(
			'id' => 'pojo_a11y_skip_to_content_link',
			'title' => __( 'Skip to Content link', 'pojo-accessibility' ),
			'type' => self::FIELD_SELECT,
			'desc' => __( 'Add skip to content link when using keyboard.', 'pojo-accessibility' ),
			'options' => array(
				'enable' => __( 'Enable', 'pojo-accessibility' ),
				'disable' => __( 'Disable', 'pojo-accessibility' ),
			),
			'std' => 'enable',
		);

		$fields[] = array(
			'id' => 'pojo_a11y_skip_to_content_link_element_id',
			'title' => __( 'Skip to Content Element ID', 'pojo-accessibility' ),
			'placeholder' => 'content',
			'type' => self::FIELD_TEXT,
			'std' => 'content',
		);

		$fields[] = array(
			'id' => 'pojo_a11y_remove_link_target',
			'title' => __( 'Remove target attribute from links', 'pojo-accessibility' ),
			'type' => self::FIELD_SELECT,
			'desc' => __( 'This option will reset all your target links to open in the same window or tab.', 'pojo-accessibility' ),
			'options' => array(
				'enable' => __( 'Enable', 'pojo-accessibility' ),
				'disable' => __( 'Disable', 'pojo-accessibility' ),
			),
			'std' => 'disable',
		);

		$fields[] = array(
			'id' => 'pojo_a11y_add_role_links',
			'title' => __( 'Add landmark roles to all links', 'pojo-accessibility' ),
			'type' => self::FIELD_SELECT,
			'desc' => __( 'This option will add <code>role="link"</code> to all links on the page.', 'pojo-accessibility' ),
            'options' => array(
				'enable' => __( 'Enable', 'pojo-accessibility' ),
				'disable' => __( 'Disable', 'pojo-accessibility' ),
			),
			'std' => 'enable',
		);

		$fields[] = array(
			'id' => 'pojo_a11y_save',
			'title' => __( 'Sitewide Accessibility', 'pojo-accessibility' ),
			'desc' => __( 'Consistent accessibility throughout your site visit. Site remembers you and stays accessible.', 'pojo-accessibility' ),
			'type' => self::FIELD_SELECT,
			'options' => array(
				'enable' => __( 'Enable', 'pojo-accessibility' ),
				'disable' => __( 'Disable', 'pojo-accessibility' ),
			),
			'std' => 'enable',
		);

		$fields[] = array(
			'id' => 'pojo_a11y_save_expiration',
			'title' => __( 'Remember user for', 'pojo-accessibility' ),
			'type' => self::FIELD_SELECT,
			'desc' => __( 'Define how long your toolbar settings will be remembered', 'pojo-accessibility' ),
			'options' => array(
				'1' => __( '1 Hour', 'pojo-accessibility' ),
				'6' => __( '6 Hours', 'pojo-accessibility' ),
				'12' => __( '12 Hours', 'pojo-accessibility' ),
				'24' => __( '1 Day', 'pojo-accessibility' ),
				'48' => __( '2 Days', 'pojo-accessibility' ),
				'72' => __( '3 Days', 'pojo-accessibility' ),
				'168' => __( '1 Week', 'pojo-accessibility' ),
				'720' => __( '1 Month', 'pojo-accessibility' ),
			),
			'std' => '12',
		);

		$sections[] = array(
			'id' => 'section-a11y-settings',
			'page' => self::SETTINGS_PAGE,
			'title' => __( 'General Settings', 'pojo-accessibility' ),
			'intro' => '',
			'fields' => $fields,
		);

		return $sections;
	}

	public function print_js() {
		// TODO: Maybe need to move to other file
		?>
		<script>
			jQuery( document ).ready( function( $ ) {
				var $a11yToolbarOption = $( 'table.form-table #pojo_a11y_toolbar' ),
					$a11yToolbarButtons = $( 'tr.pojo-a11y-toolbar-button' );
				
				$a11yToolbarOption.on( 'change', function() {
					if ( 'disable' !== $( this ).val() ) {
						$a11yToolbarButtons.fadeIn( 'fast' );
					} else {
						$a11yToolbarButtons.hide();
					}
				} );
				$a11yToolbarOption.trigger( 'change' );
			} );
		</script>
		<?php
	}

	public function get_settings_sections() {
		$sections  = array();
		$sections = $this->section_a11y_toolbar( $sections );
		$sections = $this->section_a11y_settings( $sections );
		$this->_sections = $sections;
		return $this->_sections;
	}

	public function add_settings_section( $args = array() ) {
		$args = wp_parse_args( $args, array(
			'id' => '',
			'title' => '',
		) );

		foreach ( $this->_sections as $section ) {
			if ( $args['id'] !== $section['id'] ) {
				continue;
			}
			if ( empty( $section['intro'] ) ) {
				return;
			}
			printf( '<p>%s</p>', $section['intro'] );
			break;
		}
	}

	public function add_settings_field( $args = array() ) {
		if ( empty( $args ) ) {
			return;
		}

		$args = wp_parse_args( $args, array(
			'id' => '',
			'std' => '',
			'type' => self::FIELD_TEXT,
		) );

		if ( empty( $args['id'] ) || empty( $args['type'] ) ) {
			return;
		}

		$field_callback = 'render_' . $args['type'] . '_field';
		if ( method_exists( $this, $field_callback ) ) {
			call_user_func( array( $this, $field_callback ), $args );
		}
	}

	public function render_select_field( $field ) {
		$options = array();
		foreach ( $field['options'] as $option_key => $option_value ) {
			$options[] = sprintf(
				'<option value="%1$s"%2$s>%3$s</option>',
				esc_attr( $option_key ),
				selected( get_option( $field['id'], $field['std'] ), $option_key, false ),
				$option_value
			);
		}
		?>
        <select id="<?php echo $field['id']; ?>" name="<?php echo $field['id']; ?>">
			<?php echo implode( '', $options ); ?>
        </select>
		<?php if ( ! empty( $field['sub_desc'] ) ) echo $field['sub_desc']; ?>
		<?php if ( ! empty( $field['desc'] ) ) : ?>
            <p class="description"><?php echo $field['desc']; ?></p>
		<?php endif; ?>
		<?php
	}

	public function render_text_field( $field ) {
		if ( empty( $field['classes'] ) )
			$field['classes'] = array( 'regular-text' );
		?>
        <input type="text" class="<?php echo implode( ' ', $field['classes'] ); ?>" id="<?php echo $field['id']; ?>" name="<?php echo $field['id']; ?>" value="<?php echo esc_attr( get_option( $field['id'], $field['std'] ) ); ?>"<?php echo ! empty( $field['placeholder'] ) ? ' placeholder="' . $field['placeholder'] . '"' : ''; ?> />
		<?php if ( ! empty( $field['sub_desc'] ) ) echo $field['sub_desc']; ?>
		<?php if ( ! empty( $field['desc'] ) ) : ?>
            <p class="description"><?php echo $field['desc']; ?></p>
		<?php endif; ?>
		<?php
	}

	public function admin_init() {
		foreach ( $this->get_settings_sections() as $section_key => $section ) {
			add_settings_section(
				$section['id'],
				$section['title'],
				array( &$this, 'add_settings_section' ),
				$section['page']
			);

			if ( empty( $section['fields'] ) ) {
				continue;
			}

			foreach ( $section['fields'] as $field ) {
				add_settings_field(
					$field['id'],
					$field['title'],
					array( &$this, 'add_settings_field' ),
					$section['page'],
					$section['id'],
					$field
				);

				$sanitize_callback = array( $this, 'field_html' );
				if ( ! empty( $field['type'] ) && self::FIELD_CHECKBOX_LIST === $field['type'] ) {
					$sanitize_callback = array( $this, 'field_checkbox_list' );
				}
				if ( ! empty( $field['sanitize_callback'] ) ) {
					$sanitize_callback = $field['sanitize_callback'];
				}

				register_setting( $section['page'], $field['id'], $sanitize_callback );
			}
		}
	}

	public static function field_html( $input ) {
		return stripslashes( wp_filter_post_kses( addslashes( $input ) ) );
	}

	public static function field_checkbox_list( $input ) {
		if ( empty( $input ) ) {
			$input = array();
		}

		return $input;
	}

	public function display_settings_page() {
		$screen = get_current_screen();
		$screen_id = $screen->id;
		if ( false !== strpos( $screen_id, 'toolbar' ) ) {
			$screen_id = self::TOOLBAR_PAGE;
		}
		?>
		<div class="wrap">
			<h2><?php echo $this->_page_title; ?></h2>
			<?php settings_errors( $screen_id ); ?>
			<form method="post" action="options.php">
				<?php
				settings_fields( $screen_id );
				do_settings_sections( $screen_id );

				submit_button();
				?>
			</form>

		</div><!-- /.wrap -->
		<?php
	}

	public function admin_menu() {
		$this->menu_slug = add_menu_page(
			__( 'Accessibility', 'pojo-accessibility' ),
			__( 'Accessibility', 'pojo-accessibility' ),
			'manage_options',
			'accessibility-settings',
			array( &$this, 'display_settings_page' ),
			'dashicons-universal-access-alt'
		);
		add_submenu_page(
			'accessibility-settings',
			__( 'Accessibility Settings', 'pojo-accessibility' ),
			__( 'Settings', 'pojo-accessibility' ),
			'manage_options',
			'accessibility-settings',
			array( &$this, 'display_settings_page' )
		);
		add_submenu_page(
			'accessibility-settings',
			__( 'Accessibility Toolbar', 'pojo-accessibility' ),
			__( 'Toolbar', 'pojo-accessibility' ),
			'manage_options',
			'accessibility-toolbar',
			array( &$this, 'display_settings_page' )
		);
		add_submenu_page(
			'accessibility-settings',
			__( 'Customize', 'pojo-accessibility' ),
			__( 'Customize', 'pojo-accessibility' ),
			'manage_options',
			'/customize.php?autofocus[section]=accessibility'
		);
	}

	public function plugin_action_links( $links, $plugin_file ) {
		if ( POJO_A11Y_BASE === $plugin_file ) {
			$settings = '<a href="' . $this->get_admin_url( 'general' ) . '" aria-label="' . esc_attr__( 'Set Accessibility settings', 'pojo-accessibility' ) . '">' . __( 'Settings', 'pojo-accessibility' ) . '</a>';
			$toolbar = '<a href="' . $this->get_admin_url( 'toolbar' ) . '" aria-label="' . esc_attr__( 'Set Accessibility Toolbar Settings', 'pojo-accessibility' ) . '">' . __( 'Toolbar', 'pojo-accessibility' ) . '</a>';
			$customizer = '<a href="' . $this->get_admin_url( 'customizer' ) . '" aria-label="' . esc_attr__( 'Customize Toolbar', 'pojo-accessibility' ) . '" target="_blank">' . __( 'Customize', 'pojo-accessibility' ) . '</a>';
			array_unshift( $links, $customizer );
			array_unshift( $links, $toolbar );
			array_unshift( $links, $settings );
		}
		return $links;
	}

	private function get_admin_url( $type ) {
		switch ( $type ) {
			case 'customizer':
				return admin_url( 'customize.php?autofocus[section]=accessibility' );
				break;
			case 'general':
				return admin_url( 'admin.php?page=accessibility-settings' );
				break;
			case 'toolbar':
				return admin_url( 'admin.php?page=accessibility-toolbar' );
				break;
		}
	}

	private function get_default_values() {
		if ( empty( $this->_defaults ) ) {
			if ( empty( $this->_sections ) ) {
				$this->get_settings_sections();
			}
			$defaults = array();
			foreach ( $this->_sections as $section ) {
				foreach ( $section['fields'] as $field ) {
					$defaults[ $field['id'] ] = isset( $field['std'] ) ? $field['std'] : '';
				}
			}
			$this->_defaults = $defaults;
		}
	}

	public function get_default_title_text( $option ) {
		$this->get_default_values();
		$default = isset( $this->_defaults[ $option ] ) ? $this->_defaults[ $option ] : '';

		return get_option( $option, $default );
	}

	public function __construct() {
		$this->_page_title = __( 'One Click Accessibility', 'pojo-accessibility' );
		$this->_page_menu_title = __( 'One Click Accessibility', 'pojo-accessibility' );
		$this->_menu_parent = 'themes.php';

		add_action( 'admin_menu', array( &$this, 'admin_menu' ), 20 );
		add_action( 'admin_init', array( &$this, 'admin_init' ), 20 );
		add_action( 'admin_footer', array( &$this, 'print_js' ) );
		add_filter( 'plugin_action_links_' . POJO_A11Y_BASE, [ $this, 'plugin_action_links' ], 10, 2 );
	}
}