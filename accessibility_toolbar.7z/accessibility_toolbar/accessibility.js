
document.addEventListener('DOMContentLoaded', function () {
    // Mapeamento das teclas de atalho
    const shortcutKeys = {
        '1': 'btn-high-contrast',
        '2': 'btn-dark-mode',
        '3': 'btn-marker',
        '4': 'btn-line-guide',
        '5': 'btn-increase-font',
        '6': 'btn-decrease-font',
        '7': 'btn-reset',
        '8': 'btn-vlibras'
    };

    // Funções de acessibilidade
    document.getElementById('btn-high-contrast').addEventListener('click', function () {
        document.body.classList.toggle('high-contrast');
    });

    document.getElementById('btn-dark-mode').addEventListener('click', function () {
        document.body.classList.toggle('dark-mode');
    });

    document.getElementById('btn-increase-font').addEventListener('click', function () {
        adjustFontSize(1);
    });

    document.getElementById('btn-decrease-font').addEventListener('click', function () {
        adjustFontSize(-1);
    });

    document.getElementById('btn-gray-scale').addEventListener('click', function () {
        document.body.classList.toggle('grayscale');
    });

    document.getElementById('btn-negative-contrast').addEventListener('click', function () {
        document.body.classList.toggle('negative-contrast');
    });

    document.getElementById('btn-underlined-links').addEventListener('click', function () {
        toggleLinkUnderline();
    });

    document.getElementById('btn-readable-font').addEventListener('click', function () {
        document.body.classList.toggle('readable-font');
    });

    document.getElementById('btn-reset').addEventListener('click', function () {
        document.body.classList.remove('high-contrast', 'dark-mode', 'grayscale', 'negative-contrast', 'readable-font');
        resetFontSize();
        removeLinkUnderline();
    });

    function adjustFontSize(step) {
        const elements = document.querySelectorAll('body, body *:not(script):not(style)');
        elements.forEach(function (el) {
            const currentSize = window.getComputedStyle(el).getPropertyValue('font-size');
            const newSize = parseFloat(currentSize) + step;
            el.style.fontSize = newSize + 'px';
        });
    }

    function resetFontSize() {
        const elements = document.querySelectorAll('body, body *:not(script):not(style)');
        elements.forEach(function (el) {
            el.style.fontSize = '';
        });
    }

    function toggleLinkUnderline() {
        const links = document.querySelectorAll('a');
        links.forEach(link => {
            link.style.textDecoration = link.style.textDecoration === 'underline' ? 'none' : 'underline';
        });
    }

    function removeLinkUnderline() {
        const links = document.querySelectorAll('a');
        links.forEach(link => {
            link.style.textDecoration = 'none';
        });
    }
});
