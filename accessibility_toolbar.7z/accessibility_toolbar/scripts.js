
let fontSize = 16;
let isHighContrast = false;

function toggleToolbar() {
    const toolbar = document.getElementById('accessibility-toolbar');
    toolbar.classList.toggle('accessibility-toolbar-closed');
}

function adjustFontSize(change) {
    fontSize += change;
    if (fontSize < 12) fontSize = 12; // Limite mínimo
    document.body.style.fontSize = fontSize + 'px';
}

function toggleHighContrast() {
    isHighContrast = !isHighContrast;
    document.body.classList.toggle('high-contrast');
}

function resetAccessibility() {
    document.body.style.fontSize = '16px';
    if (isHighContrast) {
        toggleHighContrast();
    }
}
