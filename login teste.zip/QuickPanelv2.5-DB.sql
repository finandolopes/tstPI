-- phpMyAdmin SQL Dump
-- version 4.9.7
-- https://www.phpmyadmin.net/
--
-- Host: localhost:3306
-- Generation Time: Feb 11, 2023 at 12:30 PM
-- Server version: 10.3.37-MariaDB-log-cll-lve
-- PHP Version: 7.4.33

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET AUTOCOMMIT = 0;
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `ownshnnr_vv2`
--

-- --------------------------------------------------------

--
-- Table structure for table `admins`
--

CREATE TABLE `admins` (
  `admin_id` int(11) NOT NULL,
  `username` varchar(225) DEFAULT NULL,
  `password` text NOT NULL,
  `register_date` datetime NOT NULL,
  `login_date` datetime DEFAULT NULL,
  `login_ip` varchar(225) DEFAULT NULL,
  `client_type` enum('1','2') NOT NULL DEFAULT '2' COMMENT '2 -> ON, 1 -> OFF',
  `access` enum('{"admin_access":"1","users":"1","orders":"1","subscriptions":"1","dripfeed":"1","services":"1","payments":"1","tickets":"1","reports":"1","general_settings":"1","pages":"1","payments_settings":"1","bank_accounts":"1","payments_bonus":"1","alert_settings":"1","providers":"1","themes":"1","child-panels":"1","language":"1","meta":"1","twice":"1","proxy":"1","kuponlar":"1","admins":"1"}') DEFAULT '{"admin_access":"1","users":"1","orders":"1","subscriptions":"1","dripfeed":"1","services":"1","payments":"1","tickets":"1","reports":"1","general_settings":"1","pages":"1","payments_settings":"1","bank_accounts":"1","payments_bonus":"1","alert_settings":"1","providers":"1","themes":"1","child-panels":"1","language":"1","meta":"1","twice":"1","proxy":"1","kuponlar":"1","admins":"1"}',
  `currency` int(11) NOT NULL,
  `admin_type` varchar(225) NOT NULL,
  `users` text NOT NULL,
  `services` text NOT NULL,
  `orders` text NOT NULL,
  `payments` text NOT NULL,
  `tickets` text NOT NULL,
  `logs_report` text NOT NULL,
  `additional` text NOT NULL,
  `appearance` text NOT NULL,
  `settings` text NOT NULL,
  `broadcast` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `admins`
--

INSERT INTO `admins` (`admin_id`, `username`, `password`, `register_date`, `login_date`, `login_ip`, `client_type`, `access`, `currency`, `admin_type`, `users`, `services`, `orders`, `payments`, `tickets`, `logs_report`, `additional`, `appearance`, `settings`, `broadcast`) VALUES
(1, 'admin', '12345678', '2022-11-27 13:17:21', '2023-02-11 22:48:47', '166.196.47.255', '2', '{\"admin_access\":\"1\",\"users\":\"1\",\"orders\":\"1\",\"subscriptions\":\"1\",\"dripfeed\":\"1\",\"services\":\"1\",\"payments\":\"1\",\"tickets\":\"1\",\"reports\":\"1\",\"general_settings\":\"1\",\"pages\":\"1\",\"payments_settings\":\"1\",\"bank_accounts\":\"1\",\"payments_bonus\":\"1\",\"alert_settings\":\"1\",\"providers\":\"1\",\"themes\":\"1\",\"child-panels\":\"1\",\"language\":\"1\",\"meta\":\"1\",\"twice\":\"1\",\"proxy\":\"1\",\"kuponlar\":\"1\",\"admins\":\"1\"}', 1, 'osp', '1', '1', '1', '1', '1', '1', '1', '1', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `article`
--

CREATE TABLE `article` (
  `id` int(11) NOT NULL,
  `title` varchar(128) NOT NULL,
  `content` text NOT NULL,
  `published_at` datetime DEFAULT NULL,
  `image_file` varchar(200) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `bank_accounts`
--

CREATE TABLE `bank_accounts` (
  `id` int(11) NOT NULL,
  `bank_name` varchar(225) NOT NULL,
  `bank_sube` varchar(225) NOT NULL,
  `bank_hesap` varchar(225) NOT NULL,
  `bank_iban` text NOT NULL,
  `bank_alici` varchar(225) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `blogs`
--

CREATE TABLE `blogs` (
  `id` int(11) NOT NULL,
  `title` varchar(128) NOT NULL,
  `content` text NOT NULL,
  `published_at` datetime NOT NULL,
  `image_file` varchar(200) DEFAULT NULL,
  `status` enum('1','2') NOT NULL DEFAULT '1',
  `blog_get` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `updated_at` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `categories`
--

CREATE TABLE `categories` (
  `category_id` int(11) NOT NULL,
  `category_name` text NOT NULL,
  `category_line` double NOT NULL,
  `category_type` enum('1','2') CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '2',
  `category_secret` enum('1','2') NOT NULL DEFAULT '2',
  `category_icon` text NOT NULL,
  `is_refill` enum('1','2') CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `categories`
--

INSERT INTO `categories` (`category_id`, `category_name`, `category_line`, `category_type`, `category_secret`, `category_icon`, `is_refill`) VALUES
(1, '🎉 Instagram Real Likes ', 1, '2', '2', '', ''),
(2, 'Instagram Mix Followers', 2, '2', '2', '', '');

-- --------------------------------------------------------

--
-- Table structure for table `childpanels`
--

CREATE TABLE `childpanels` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `domain` varchar(191) NOT NULL,
  `currency` varchar(191) NOT NULL,
  `child_username` varchar(191) NOT NULL,
  `child_password` varchar(191) NOT NULL,
  `charge` double NOT NULL,
  `status` enum('Pending','Active','Frozen','Suspended') NOT NULL DEFAULT 'Pending',
  `renewal_date` date NOT NULL,
  `date_created` datetime NOT NULL,
  `dreampanel_id` int(11) NOT NULL,
  `keyc` varchar(225) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

-- --------------------------------------------------------

--
-- Table structure for table `clients`
--

CREATE TABLE `clients` (
  `client_id` int(11) NOT NULL,
  `name` varchar(225) DEFAULT NULL,
  `email` varchar(225) NOT NULL,
  `username` varchar(225) DEFAULT NULL,
  `admin_type` enum('1','2') NOT NULL DEFAULT '2',
  `password` text NOT NULL,
  `telephone` varchar(225) DEFAULT NULL,
  `balance` decimal(21,4) NOT NULL,
  `balance_type` enum('1','2') NOT NULL DEFAULT '2',
  `debit_limit` double DEFAULT NULL,
  `spent` decimal(21,4) NOT NULL,
  `register_date` datetime NOT NULL,
  `login_date` datetime DEFAULT NULL,
  `login_ip` varchar(225) DEFAULT NULL,
  `apikey` text NOT NULL,
  `tel_type` enum('1','2') NOT NULL DEFAULT '1' COMMENT '2 -> ON, 1 -> OFF',
  `email_type` enum('1','2') NOT NULL DEFAULT '1' COMMENT '2 -> ON, 1 -> OFF',
  `client_type` enum('1','2') NOT NULL DEFAULT '2' COMMENT '2 -> ON, 1 -> OFF',
  `access` text DEFAULT NULL,
  `lang` varchar(255) NOT NULL DEFAULT 'tr',
  `timezone` double NOT NULL DEFAULT 0,
  `currency_type` enum('INR','USD') NOT NULL DEFAULT 'USD',
  `ref_code` text NOT NULL,
  `ref_by` text DEFAULT NULL,
  `change_email` enum('1','2') NOT NULL DEFAULT '2',
  `resend_max` int(11) NOT NULL,
  `currency` varchar(225) NOT NULL DEFAULT '1',
  `passwordreset_token` varchar(225) NOT NULL,
  `verified` enum('Yes','No') NOT NULL DEFAULT 'No',
  `coustm_rate` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `clients_category`
--

CREATE TABLE `clients_category` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `category_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `clients_price`
--

CREATE TABLE `clients_price` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `service_price` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `clients_service`
--

CREATE TABLE `clients_service` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `client_report`
--

CREATE TABLE `client_report` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `action` text NOT NULL,
  `report_ip` varchar(225) NOT NULL,
  `report_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `crons`
--

CREATE TABLE `crons` (
  `cron_id` int(11) NOT NULL,
  `cron_name` varchar(50) NOT NULL,
  `cron_operation` varchar(200) NOT NULL,
  `cron_updefault` int(11) NOT NULL DEFAULT 1,
  `cron_endup` int(11) NOT NULL,
  `cron_date_update` timestamp NOT NULL DEFAULT current_timestamp(),
  `cron_status` int(1) NOT NULL DEFAULT 0
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `crons`
--

INSERT INTO `crons` (`cron_id`, `cron_name`, `cron_operation`, `cron_updefault`, `cron_endup`, `cron_date_update`, `cron_status`) VALUES
(1, 'osp.php', '', 1, 0, '2022-08-15 18:39:06', 1);

-- --------------------------------------------------------

--
-- Table structure for table `currency`
--

CREATE TABLE `currency` (
  `id` int(11) NOT NULL,
  `symbol` text DEFAULT NULL,
  `value` double DEFAULT NULL,
  `name` varchar(225) NOT NULL,
  `status` enum('1','2') NOT NULL DEFAULT '1',
  `default` enum('2','1') NOT NULL DEFAULT '2',
  `nouse` enum('1','2') NOT NULL DEFAULT '2'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `currency`
--

INSERT INTO `currency` (`id`, `symbol`, `value`, `name`, `status`, `default`, `nouse`) VALUES
(1, '$', 1, 'USD', '1', '1', '1'),
(3, '₹', 82.73, 'INR', '1', '2', '2');

-- --------------------------------------------------------

--
-- Table structure for table `earn`
--

CREATE TABLE `earn` (
  `earn_id` int(255) NOT NULL,
  `client_id` int(255) NOT NULL,
  `link` text NOT NULL,
  `earn_note` text NOT NULL,
  `status` enum('Pending','Under Review','Funds Granted','Rejected','Not Eligible') NOT NULL DEFAULT 'Pending'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `files`
--

CREATE TABLE `files` (
  `id` int(11) NOT NULL,
  `link` text DEFAULT NULL,
  `date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `files`
--

INSERT INTO `files` (`id`, `link`, `date`) VALUES
(4, 'https://quickpanelv2.ownsmmpanel.in/img/files/800da2c0c51c6f64339721abecbdf95a.png', '2023-02-11 22:41:48');

-- --------------------------------------------------------

--
-- Table structure for table `General_options`
--

CREATE TABLE `General_options` (
  `id` int(11) NOT NULL,
  `coupon_status` enum('1','2') NOT NULL DEFAULT '1',
  `updates_show` enum('1','2') NOT NULL DEFAULT '1',
  `panel_status` enum('Pending','Active','Frozen','Suspended') NOT NULL,
  `panel_orders` int(11) NOT NULL,
  `panel_thismonthorders` int(11) NOT NULL,
  `massorder` enum('1','2') NOT NULL DEFAULT '2',
  `balance_format` enum('0.0','0.00','0.000','0.0000') NOT NULL DEFAULT '0.0',
  `currency_format` enum('0','2','3','4') NOT NULL DEFAULT '3',
  `ticket_system` enum('1','2') NOT NULL DEFAULT '1'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_unicode_ci;

--
-- Dumping data for table `General_options`
--

INSERT INTO `General_options` (`id`, `coupon_status`, `updates_show`, `panel_status`, `panel_orders`, `panel_thismonthorders`, `massorder`, `balance_format`, `currency_format`, `ticket_system`) VALUES
(1, '', '2', 'Active', 1000, 1000, '', '0.0000', '3', '2');

-- --------------------------------------------------------

--
-- Table structure for table `integrations`
--

CREATE TABLE `integrations` (
  `id` int(11) NOT NULL,
  `name` varchar(225) NOT NULL,
  `description` varchar(225) NOT NULL,
  `icon_url` varchar(225) NOT NULL,
  `code` text NOT NULL,
  `visibility` int(11) NOT NULL,
  `status` int(11) NOT NULL DEFAULT 1
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `integrations`
--

INSERT INTO `integrations` (`id`, `name`, `description`, `icon_url`, `code`, `visibility`, `status`) VALUES
(1, 'Beamer', 'Announce updates and get feedback with in-app notification center, widgets and changelog', '/img/integrations/Beamer.svg', '', 1, 2),
(2, 'Getsitecontrol', 'It helps you prevent website visitors from leaving your website without taking any action.', '/img/integrations/Getsitecontrol.svg', '', 1, 1),
(3, 'Google Analytics', 'Statistics and basic analytical tools for search engine optimization (SEO) and marketing purposes', '/img/integrations/Google%20Analytics.svg', '', 1, 1),
(4, 'Google Tag manager', 'Manage all your website tags without editing the code using simple tag management solutions', '/img/integrations/Google%20Tag%20manager.svg', '', 1, 1),
(5, 'JivoChat', 'All-in-one business messenger to talk to customers: live chat, phone, email and social', '/img/integrations/JivoChat.svg', '', 1, 1),
(6, 'Onesignal', 'Leader in customer engagement, empowers mobile push, web push, email, in-app messages', '/img/integrations/Onesignal.svg', '', 1, 1),
(7, 'Push alert', 'Increase reach, revenue, retarget users with Push Notifications on desktop and mobile', '/img/integrations/Push%20alert.svg', '', 1, 1),
(8, 'Smartsupp', 'Live chat, email inbox and Facebook Messenger in one customer messaging platform', '/img/integrations/Smartsupp.svg', '', 1, 1),
(9, 'Tawk.to', 'Track and chat with visitors on your website, mobile app or a free customizable page', '/img/integrations/Tawk.to.svg', '', 1, 1),
(10, 'Tidio', 'Communicator for businesses that keep live chat, chatbots, Messenger and email in one place', '/img/integrations/Tidio.svg', '', 1, 1),
(11, 'Zendesk Chat', 'Helps respond quickly to customer questions, reduce wait times and increase sales', '/img/integrations/Zendesk%20Chat.svg', '', 1, 1),
(12, 'Getbutton.io', 'Chat with website visitors through popular messaging apps. Whatsapp, messenger etc. contact button.', '/img/integrations/Getbutton.svg', '', 1, 1),
(13, 'Google reCAPTCHA v2', 'It uses an advanced risk analysis engine and adaptive challenges to prevent malware from engaging in abusive activities on your website.', '/img/integrations/reCAPTCHA.svg', '', 1, 1);

-- --------------------------------------------------------

--
-- Table structure for table `kuponlar`
--

CREATE TABLE `kuponlar` (
  `id` int(11) NOT NULL,
  `kuponadi` varchar(255) NOT NULL,
  `adet` int(11) NOT NULL,
  `tutar` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `kupon_kullananlar`
--

CREATE TABLE `kupon_kullananlar` (
  `id` int(11) NOT NULL,
  `uye_id` int(11) NOT NULL,
  `kuponadi` varchar(255) NOT NULL,
  `tutar` double NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=latin1 COLLATE=latin1_swedish_ci;

-- --------------------------------------------------------

--
-- Table structure for table `languages`
--

CREATE TABLE `languages` (
  `id` int(11) NOT NULL,
  `language_name` varchar(225) NOT NULL,
  `language_code` varchar(225) NOT NULL,
  `language_type` enum('2','1') NOT NULL DEFAULT '2',
  `default_language` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `languages`
--

INSERT INTO `languages` (`id`, `language_name`, `language_code`, `language_type`, `default_language`) VALUES
(2, 'English', 'en', '2', '1');

-- --------------------------------------------------------

--
-- Table structure for table `Mailforms`
--

CREATE TABLE `Mailforms` (
  `id` int(11) NOT NULL,
  `subject` varchar(225) NOT NULL,
  `message` varchar(225) NOT NULL,
  `status` enum('1','2') NOT NULL DEFAULT '1',
  `header` varchar(225) NOT NULL,
  `footer` varchar(225) NOT NULL,
  `type` enum('Admins','Users') NOT NULL DEFAULT 'Users'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `menus`
--

CREATE TABLE `menus` (
  `id` int(11) NOT NULL,
  `name` text NOT NULL,
  `menu_line` double NOT NULL,
  `type` enum('1','2') CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '2',
  `slug` varchar(225) NOT NULL DEFAULT '2',
  `icon` varchar(225) DEFAULT NULL,
  `menu_status` enum('1','2') CHARACTER SET utf8 COLLATE utf8_general_ci NOT NULL DEFAULT '1',
  `visible` enum('Internal','External') NOT NULL DEFAULT 'Internal',
  `active` varchar(225) NOT NULL,
  `tiptext` varchar(225) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_bin;

--
-- Dumping data for table `menus`
--

INSERT INTO `menus` (`id`, `name`, `menu_line`, `type`, `slug`, `icon`, `menu_status`, `visible`, `active`, `tiptext`) VALUES
(1, 'New Order', 1, '2', '/', 'fas fa-cart-arrow-down', '1', 'Internal', 'neworder', ''),
(48, 'Services', 1, '2', '/services', 'fas fa-clipboard-list', '1', 'External', 'servicea', ''),
(3, 'Orders ', 4, '2', '/orders', 'fas fa-server', '1', 'Internal', 'orders', ''),
(4, 'Refill', 5, '2', '/refill', 'fas fa-recycle', '1', 'Internal', 'refill', 'Shown only if user have at least one refill task'),
(5, 'Login', 4, '2', '/', 'fas fa-address-card', '1', 'External', 'login', ''),
(6, 'Services', 2, '2', '/services', 'fas fa-cogs', '1', 'Internal', 'services', ''),
(7, 'Add Funds', 3, '2', '/addfunds', 'fas fa-credit-card', '1', 'Internal', 'addfunds', ''),
(8, 'Api', 10, '2', '/api', 'fas fa-code', '1', 'Internal', 'api', ''),
(9, 'Tickets ', 9, '2', '/tickets', 'fas fa-headset', '1', 'Internal', 'tickets', ''),
(10, 'Child Panels', 7, '2', '/child-panels', 'fas fa-child', '1', 'Internal', 'child-panels', 'Shown only if child panels selling enabled'),
(11, 'Refer & Earn', 6, '2', '/refer', 'fas fa-bezier-curve', '1', 'Internal', 'refer', 'Shown only if affiliate system enabled for use'),
(13, 'Terms', 11, '2', '/terms', 'fas fa-exclamation-triangle', '1', 'Internal', 'terms', ''),
(14, 'Signup ', 5, '2', '/signup', 'fas fa-arrow-right', '1', 'External', 'signup', 'Shown only if Signup system enabled for use'),
(15, 'Api', 3, '2', '/api', 'fas fa-code', '1', 'External', 'api', ''),
(17, 'Updates', 8, '2', '/updates', 'fas fa-bell', '1', 'Internal', '', 'Shown only if Updates System enabled'),
(18, 'Terms', 2, '2', '/terms', 'fas fa-exclamation-triangle', '1', 'External', 'terms', '');

-- --------------------------------------------------------

--
-- Table structure for table `news`
--

CREATE TABLE `news` (
  `id` int(11) NOT NULL,
  `news_icon` varchar(225) NOT NULL,
  `news_title` varchar(225) NOT NULL,
  `news_content` varchar(225) NOT NULL,
  `news_date` datetime NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `news`
--

INSERT INTO `news` (`id`, `news_icon`, `news_title`, `news_content`, `news_date`) VALUES
(1, 'youtube', 'WebTechz', 'SUBSCRIBE [ WebTechz ] For SMM Panel Website Videos.', '2023-02-11 22:56:05');

-- --------------------------------------------------------

--
-- Table structure for table `notifications_popup`
--

CREATE TABLE `notifications_popup` (
  `id` int(11) NOT NULL,
  `title` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `action_link` text NOT NULL,
  `isAllPage` enum('0','1') NOT NULL DEFAULT '0',
  `isAllUser` enum('1','0') NOT NULL DEFAULT '0',
  `expiry_date` date NOT NULL,
  `status` enum('1','2','0') NOT NULL DEFAULT '1',
  `allPages` varchar(225) NOT NULL,
  `description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `image_file` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci DEFAULT NULL,
  `action_text` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `notifications_popup`
--

INSERT INTO `notifications_popup` (`id`, `title`, `action_link`, `isAllPage`, `isAllUser`, `expiry_date`, `status`, `allPages`, `description`, `image_file`, `action_text`) VALUES
(1, 'QuickPanel V2.5', 'https://ownsmmpanel.in', '1', '0', '2023-03-31', '1', 'null', '<p>QuickPanel V2.5 SMM Panel Script.</p><p>Start Your Own SMM Panel Website With This OSM! SMM Panel Script With New&nbsp;Advanced Features.</p><p><br></p><p>Get Your Full Ready To Use SMM Panel Website With OwnSMMPanel.in</p>', NULL, 'GET DEMO');

-- --------------------------------------------------------

--
-- Table structure for table `orders`
--

CREATE TABLE `orders` (
  `order_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `api_orderid` int(11) NOT NULL DEFAULT 0,
  `order_error` text NOT NULL,
  `order_detail` text DEFAULT NULL,
  `order_api` int(11) NOT NULL DEFAULT 0,
  `api_serviceid` int(11) NOT NULL DEFAULT 0,
  `api_charge` double NOT NULL DEFAULT 0,
  `api_currencycharge` double DEFAULT 1,
  `order_profit` double NOT NULL,
  `order_quantity` double NOT NULL,
  `order_extras` text NOT NULL,
  `order_charge` double NOT NULL,
  `dripfeed` enum('1','2','3') DEFAULT '1' COMMENT '2 -> ON, 1 -> OFF',
  `dripfeed_id` double NOT NULL DEFAULT 0,
  `subscriptions_id` double NOT NULL DEFAULT 0,
  `subscriptions_type` enum('1','2') NOT NULL DEFAULT '1' COMMENT '2 -> ON, 1 -> OFF',
  `dripfeed_totalcharges` double DEFAULT NULL,
  `dripfeed_runs` double DEFAULT NULL,
  `dripfeed_delivery` double NOT NULL DEFAULT 0,
  `dripfeed_interval` double DEFAULT NULL,
  `dripfeed_totalquantity` double DEFAULT NULL,
  `dripfeed_status` enum('active','completed','canceled') NOT NULL DEFAULT 'active',
  `order_url` text NOT NULL,
  `order_start` double NOT NULL DEFAULT 0,
  `order_finish` double NOT NULL DEFAULT 0,
  `order_remains` double NOT NULL DEFAULT 0,
  `order_create` datetime NOT NULL,
  `order_status` enum('pending','inprogress','completed','partial','processing','psw','canceled') NOT NULL DEFAULT 'pending',
  `subscriptions_status` enum('active','paused','completed','canceled','expired','limit') NOT NULL DEFAULT 'active',
  `subscriptions_username` text DEFAULT NULL,
  `subscriptions_posts` double DEFAULT NULL,
  `subscriptions_delivery` double NOT NULL DEFAULT 0,
  `subscriptions_delay` double DEFAULT NULL,
  `subscriptions_min` double DEFAULT NULL,
  `subscriptions_max` double DEFAULT NULL,
  `subscriptions_expiry` date DEFAULT NULL,
  `last_check` datetime NOT NULL,
  `order_where` enum('site','api') NOT NULL DEFAULT 'site',
  `refill_status` enum('Pending','Refilling','Completed','Rejected','Error') NOT NULL DEFAULT 'Pending',
  `is_refill` enum('1','2') NOT NULL DEFAULT '1',
  `refill` varchar(225) NOT NULL DEFAULT '1',
  `cancelbutton` enum('1','2') NOT NULL DEFAULT '1' COMMENT '1 -> ON, 2 -> OFF',
  `show_refill` enum('true','false') NOT NULL DEFAULT 'true',
  `api_refillid` double NOT NULL DEFAULT 0,
  `avg_done` enum('0','1') NOT NULL DEFAULT '1',
  `order_increase` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ROW_FORMAT=FIXED;

-- --------------------------------------------------------

--
-- Table structure for table `pages`
--

CREATE TABLE `pages` (
  `page_id` int(11) NOT NULL,
  `page_name` varchar(225) NOT NULL,
  `page_get` varchar(225) NOT NULL,
  `page_content` text NOT NULL,
  `page_status` enum('1','2') NOT NULL DEFAULT '1',
  `active` enum('1','2') NOT NULL DEFAULT '1',
  `seo_title` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `seo_keywords` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `seo_description` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `last_modified` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `pages`
--

INSERT INTO `pages` (`page_id`, `page_name`, `page_get`, `page_content`, `page_status`, `active`, `seo_title`, `seo_keywords`, `seo_description`, `last_modified`) VALUES
(2, 'Add funds', 'addfunds', '', '1', '1', 'ADD Funds', 'SMM Panel', 'SMM Panel', '2022-12-11 11:11:43'),
(3, 'Affiliates', 'refer', '', '1', '1', 'Affiliates', 'SMM Panel', 'SMM Panel', '2022-12-11 04:10:38'),
(4, 'Api', 'api', '', '1', '1', 'API Docs', 'SMM Panel', 'SMM Panel', '2022-11-30 06:43:54'),
(5, 'Blog', 'blog', '\r\n', '1', '1', 'Blog', 'SMM Panel', 'SMM Panel', '2022-12-16 03:36:41'),
(6, 'Login', 'auth', '<h1>Buy Cheap Social Media followers, likes, Views, Share instantly.<br></h1>              <span><i class=\"fas fa-chevron-right\"></i> Fully Automated Instant trusted Panel.</span><br>                     <span><i class=\"fas fa-chevron-right\"></i> Orders are completed fully automatically and quickly.</span>             <br>        <span><i class=\"fas fa-chevron-right\"></i> We provide instant support for your questions and problems 24 hours a day, 7 days a week.</span>        <br>        <span><i class=\"fas fa-chevron-right\"></i> SMM Panel meaning is Cheapest SMM and SEO Services Reseller Panel Script or website, where People Buy-Sell Social Media Marketing Service Such as Facebook Fans, Twitter devotees, Instagram Followers, YouTube watch time Views, Website Traffic, tiktok likes, and more significant associations.</span>           ', '1', '1', 'SMM Panel', 'SMM Panel', 'SMM Panel', '2023-02-07 09:21:49'),
(7, 'Child Panels', 'child-panels', '', '1', '1', 'Child Panels', 'SMM Panel', 'SMM Panel', '2022-11-30 06:46:27'),
(8, 'Mass Order', 'massorder', '', '1', '1', 'Mass Orders', 'SMM Panel', 'SMM Panel', '2022-11-30 06:48:35'),
(9, 'New Order', 'neworder', '\r\n', '1', '1', 'New Order', 'SMM Panel', 'SMM Panel', '2022-12-16 04:51:16'),
(10, 'Orders', 'orders', '', '1', '1', 'Order Logs', 'SMM Panel', 'SMM Panel', '2022-11-30 06:50:13'),
(11, 'Refill', 'refill', '', '1', '1', 'Refill Logs', 'SMM Panel', 'SMM Panel', '2022-11-30 06:50:36'),
(12, 'Services', 'services', '', '2', '1', 'Services', 'SMM Panel', 'SMM Panel', '2023-02-08 10:27:36'),
(13, 'Sign Up', 'signup', '', '1', '1', 'Signup', 'SMM Panel', 'SMM Panel', '2023-02-07 10:22:46'),
(14, 'Terms', 'terms', '<p style=\"margin-bottom: 1rem; color: rgb(70, 78, 119); font-family: Poppins, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif; font-size: 16px;\">The use of services provided by YourDomain (<span style=\"font-weight: bolder;\"> Your Domain </span>) Established the agreement to these terms. By registering or using our services you agree that you have read and fully understood the following terms of Service and SocialKart will not be help liable for loss in any way for users who have not read the below terms of service.</p><p><span style=\"font-weight: bolder; color: rgb(70, 78, 119); font-family: Poppins, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif; font-size: 16px;\">Delivery Policy</span><span style=\"color: rgb(70, 78, 119); font-family: Poppins, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif; font-size: 16px;\"></span></p><p style=\"margin-bottom: 1rem; color: rgb(70, 78, 119); font-family: Poppins, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif; font-size: 16px;\">● By placing an order with <span style=\"font-weight: bolder;\">YourDomain</span>, you automatically accept all the below-listed term of services whether you read them or not.</p><p style=\"margin-bottom: 1rem; color: rgb(70, 78, 119); font-family: Poppins, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif; font-size: 16px;\">● We reserve the right to change these terms of service without notice. You are expected to read all terms of service before placing every order to ensure you are up to date with any changes or any future changes.</p><p style=\"margin-bottom: 1rem; color: rgb(70, 78, 119); font-family: Poppins, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif; font-size: 16px;\">● You will only use the <span style=\"font-weight: 700;\">YourDomain </span>website in a manner which follows all agreements made with <span style=\"font-weight: bolder;\">Soundcloud/Vine/Pinterest/Youtube/other social media site</span> on their individual Terms of Service page.</p><p style=\"margin-bottom: 1rem; color: rgb(70, 78, 119); font-family: Poppins, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif; font-size: 16px;\">● <span style=\"font-weight: 700;\">YourDomain </span>rates are subject to change at any time without notice. The terms stay in effect in the case of rate changes.</p><p style=\"margin-bottom: 1rem; color: rgb(70, 78, 119); font-family: Poppins, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif; font-size: 16px;\">● <span style=\"font-weight: 700;\">YourDomain </span>( YourDomain ) does not guarantee a delivery time for any services as its depend on the services order quantity. We offer our best estimation for when the order will be delivered. This is only an estimation and <span style=\"font-weight: 700;\">YourDomain </span>will not refund orders that are processing if you feel they are taking too long.</p><p style=\"margin-bottom: 1rem; color: rgb(70, 78, 119); font-family: Poppins, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif; font-size: 16px;\">● <span style=\"font-weight: 700;\">YourDomain </span>tries hard to deliver exactly what is expected of us by our resellers. In this case, we reserve the right to change a service type if we deem it necessary to complete an order.</p><p style=\"margin-bottom: 1rem; color: rgb(70, 78, 119); font-family: Poppins, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif; font-size: 16px;\">● <span style=\"font-weight: 700;\">YourDomain </span>Always provide the amount mentioned in Service Descriptions , But Remember , If Incase there is Any Update in Any Social Media Platforms then the Drop Ratios of NON DROP or any Guarantee can be Changed , And YourDomain cant be Responsible for this.</p><p><span style=\"font-weight: bolder; color: rgb(70, 78, 119); font-family: Poppins, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif; font-size: 16px;\">Disclaimer:</span><span style=\"color: rgb(70, 78, 119); font-family: Poppins, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif; font-size: 16px;\"></span></p><p style=\"margin-bottom: 1rem; color: rgb(70, 78, 119); font-family: Poppins, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif; font-size: 16px;\"><span style=\"font-weight: 700;\">YourDomain </span>will not be responsible for any damages you or your business may suffer.</p><p><span style=\"font-weight: bolder; color: rgb(70, 78, 119); font-family: Poppins, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif; font-size: 16px;\">Liabilities:</span><span style=\"color: rgb(70, 78, 119); font-family: Poppins, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif; font-size: 16px;\"></span></p><p style=\"margin-bottom: 1rem; color: rgb(70, 78, 119); font-family: Poppins, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif; font-size: 16px;\"><span style=\"font-weight: 700;\">YourDomain </span>is in no way liable for any account suspension or picture deletion done by Instagram or Twitter or Facebook or YouTube or Other Social Media.</p><p><br style=\"color: rgb(70, 78, 119); font-family: Poppins, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif; font-size: 16px;\"></p><h2 class=\"mb-5\" style=\"margin-top: 0px; line-height: 1.2; font-size: 2rem; color: rgb(70, 78, 119); font-family: Poppins, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif; margin-bottom: 3rem !important;\">Privacy Policy</h2><p style=\"margin-bottom: 1rem; color: rgb(70, 78, 119); font-family: Poppins, -apple-system, BlinkMacSystemFont, \"Segoe UI\", Roboto, Oxygen, Ubuntu, Cantarell, \"Open Sans\", \"Helvetica Neue\", sans-serif; font-size: 16px;\">● This policy covers how we use your personal information. We take your privacy seriously and will take all measures to protect your personal information. Any personal information received will only be used to fill your order. We will not sell or redistribute your personal information to anyone. All personal information is encrypted and saved in secure servers.</p>', '1', '1', 'Terms', 'SMM Panel', 'SMM Panel', '2023-01-27 02:13:29'),
(784, 'About Us', 'about-us', '\r\n', '1', '1', 'About Us', 'SMM Panel', 'SMM Panel', '2022-12-11 10:47:15');

-- --------------------------------------------------------

--
-- Table structure for table `payments`
--

CREATE TABLE `payments` (
  `payment_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `client_balance` decimal(15,2) NOT NULL DEFAULT 0.00,
  `payment_amount` decimal(15,4) NOT NULL,
  `payment_privatecode` double DEFAULT NULL,
  `payment_method` int(11) NOT NULL,
  `payment_status` enum('1','2','3') NOT NULL DEFAULT '1',
  `payment_delivery` enum('1','2') NOT NULL DEFAULT '1',
  `payment_note` varchar(255) NOT NULL DEFAULT 'No',
  `payment_mode` enum('Manuel','Otomatik','Auto') NOT NULL DEFAULT 'Otomatik',
  `payment_create_date` datetime NOT NULL,
  `payment_update_date` datetime NOT NULL,
  `payment_ip` varchar(225) NOT NULL,
  `payment_extra` text NOT NULL,
  `payment_bank` int(11) NOT NULL,
  `t_id` varchar(255) DEFAULT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payments_bonus`
--

CREATE TABLE `payments_bonus` (
  `bonus_id` int(11) NOT NULL,
  `bonus_method` int(11) NOT NULL,
  `bonus_from` double NOT NULL,
  `bonus_amount` double NOT NULL,
  `bonus_type` enum('1','2') NOT NULL DEFAULT '2'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `payment_methods`
--

CREATE TABLE `payment_methods` (
  `id` int(11) NOT NULL,
  `method_name` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `method_get` varchar(225) NOT NULL,
  `method_min` double NOT NULL,
  `method_max` double NOT NULL,
  `method_type` enum('1','2') NOT NULL DEFAULT '2' COMMENT '2 -> ON, 1 -> OFF	',
  `method_extras` text NOT NULL,
  `method_line` double NOT NULL,
  `nouse` enum('1','2') NOT NULL DEFAULT '2',
  `content` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `payment_methods`
--

INSERT INTO `payment_methods` (`id`, `method_name`, `method_get`, `method_min`, `method_max`, `method_type`, `method_extras`, `method_line`, `nouse`, `content`) VALUES
(1, 'Paypal', 'paypal', 10, 100, '2', '{\"method_type\":\"2\",\"name\":\"International Payments [\\ud835\\udc0f\\ud835\\udc1a\\ud835\\udc32\\ud835\\udc0f\\ud835\\udc1a\\ud835\\udc25] [\\ud835\\udc14\\ud835\\udc12\\ud835\\udc03]\",\"min\":\"10\",\"max\":\"100\",\"client_id\":\"\",\"client_secret\":\"\",\"fee\":\"10\"}', 7, '2', 'hello'),
(2, 'Stripe', 'stripe', 1, 100, '2', '{\"method_type\":\"1\",\"name\":\"Credit card\",\"min\":\"1\",\"max\":\"100\",\"stripe_publishable_key\":\"\",\"stripe_secret_key\":\"\",\"stripe_webhooks_secret\":\"\",\"fee\":\"10\",\"currency\":\"USD\"}', 10, '2', ''),
(3, 'Shopier', 'shopier', 5, 0, '2', '{\"method_type\":\"1\",\"name\":\"Kredi \\/ Banka Kart\\u0131 ile \\u00d6de\",\"min\":\"5\",\"max\":\"0\",\"apiKey\":\"\",\"apiSecret\":\"\",\"website_index\":\"1\",\"processing_fee\":\"1\",\"fee\":\"10\",\"currency\":\"USD\"}', 16, '2', ''),
(5, 'Paywant', 'paywant', 1, 0, '2', '{\"method_type\":\"1\",\"name\":\"Paywant\",\"min\":\"1\",\"max\":\"0\",\"apiKey\":\"\",\"apiSecret\":\"\",\"fee\":\"0\",\"currency\":\"USD\",\"commissionType\":\"2\",\"payment_type\":[\"1\",\"2\",\"3\"]}', 17, '2', ''),
(7, 'PayTR', 'paytr', 1, 0, '2', '{\"method_type\":\"1\",\"name\":\"Paytr\",\"min\":\"1\",\"max\":\"0\",\"merchant_id\":\"\",\"merchant_key\":\"\",\"merchant_salt\":\"\",\"fee\":\"0\",\"currency\":\"USD\"}', 19, '2', ''),
(8, 'Coinpayments', 'coinpayments', 10, 0, '2', '{\"method_type\":\"1\",\"name\":\"CoinPayments ( Cryptocurrency )\",\"min\":\"10\",\"max\":\"0\",\"coinpayments_public_key\":\"\",\"coinpayments_private_key\":\"\",\"coinpayments_currency\":\"BTC\",\"merchant_id\":\"\",\"ipn_secret\":\"\",\"fee\":\"0\",\"currency\":\"USD\"}', 8, '2', ''),
(9, '2checkout', '2checkout', 1, 0, '2', '{\"method_type\":\"1\",\"name\":\"2checkout\",\"min\":\"1\",\"max\":\"0\",\"seller_id\":\"\",\"private_key\":\"\",\"fee\":\"1\",\"currency\":\"USD\"}', 12, '2', ''),
(10, 'Payoneer', 'payoneer', 0, 0, '2', '{\"method_type\":\"1\",\"name\":\"Payoneer\",\"email\":\"\"}', 11, '2', ''),
(11, 'Mollie', 'mollie', 1, 0, '2', '{\"method_type\":\"1\",\"name\":\"Mollie\",\"min\":\"1\",\"max\":\"0\",\"live_api_key\":\"\",\"fee\":\"0\",\"currency\":\"USD\"}', 20, '2', ''),
(12, 'PayTM', 'paytm', 10, 100000, '2', '{\"method_type\":\"2\",\"name\":\"PayTM ( INR )( UPI \\/ NET BANKING \\/ DEBIT \\/ CREDIT CARD)\",\"min\":\"10\",\"max\":\"100000\",\"merchant_key\":\"\",\"merchant_mid\":\"\",\"merchant_website\":\"DEFAULT\",\"fee\":\"0\",\"currency\":\"\"}', 2, '2', ''),
(13, 'Instamojo', 'instamojo', 0, 0, '2', '{\"method_type\":\"1\",\"name\":\"Instamojo\",\"min\":\"0\",\"max\":\"0\",\"api_key\":\"\",\"live_auth_token_key\":\"\",\"fee\":\"0\",\"currency\":\"INR\"}', 18, '2', ''),
(14, 'Paytm Business', 'paytmqr', 0.1, 0, '2', '{\"method_type\":\"2\",\"name\":\"PayTM QR\",\"min\":\"0.10\",\"max\":\"0\",\"merchant_key\":\"\\/img\\/files\\/800da2c0c51c6f64339721abecbdf95a.png\",\"merchant_mid\":\"\",\"merchant_website\":\"DEFAULT\",\"fee\":\"0\"}', 3, '2', ''),
(15, 'Razorpay', 'razorpay', 1, 0, '2', '{\"method_type\":\"1\",\"name\":\"Razorpay\",\"min\":\"1\",\"max\":\"0\",\"api_key\":\"0\",\"api_secret_key\":\"0\",\"fee\":\"0\",\"currency\":\"INR\"}', 9, '2', ''),
(16, 'Iyzico', 'iyzico', 1, 0, '2', '{\"method_type\":\"1\",\"name\":\"Iyzico\",\"min\":\"1\",\"max\":\"0\",\"api_key\":\"0\",\"api_secret_key\":\"0\",\"fee\":\"0\",\"currency\":\"USD\"}', 21, '2', ''),
(17, 'Authorize.net', 'authorize-net', 1, 0, '2', '{\"method_type\":\"1\",\"name\":\"Authorize.net\",\"min\":\"1\",\"max\":\"0\",\"api_login_id\":\"0\",\"secret_transaction_key\":\"0\",\"fee\":\"0\",\"currency\":\"USD\"}', 22, '2', ''),
(20, 'Ravepay', 'ravepay', 1, 10, '2', '{\"method_type\":\"2\",\"name\":\"Ravepay\",\"min\":\"1\",\"max\":\"10\",\"public_api_key\":\"0\",\"secret_api_key\":\"0\",\"fee\":\"0\",\"currency\":\"USD\"}', 23, '2', ''),
(21, 'Pagseguro', 'pagseguro', 1, 0, '2', '{\"method_type\":\"1\",\"name\":\"Pagseguro\",\"min\":\"1\",\"max\":\"0\",\"email_id\":\"0\",\"live_production_token\":\"0\",\"fee\":\"0\",\"currency\":\"USD\"}', 24, '2', ''),
(22, 'Cashmaal', 'Cashmaal', 10, 0, '2', '{\"method_type\":\"2\",\"name\":\"JAZZCASH\\/EASYPAISA [\\ud835\\udc02\\ud835\\udc1a\\ud835\\udc2c\\ud835\\udc21\\ud835\\udc0c\\ud835\\udc1a\\ud835\\udc25\\ud835\\udc25] [\\ud835\\udc14\\ud835\\udc12\\ud835\\udc03]\",\"min\":\"10\",\"max\":\"0\",\"web_id\":\"\",\"fee\":\"0\",\"currency\":\"USD\"}', 5, '2', ''),
(25, 'Refer & earn', 'refer', 0, 0, '1', '{\"method_type\":\"2\",\"name\":\"Do Not Use\",\"min\":\"1\",\"max\":\"10000\",\"merchant_key\":\"P#n%aKfB3&DRAMqH\",\"merchant_mid\":\"DBWvgX98800736620578\",\"merchant_website\":\"DEFAULT\",\"fee\":\"0\",\"currency\":\"\"}', 25, '1', ''),
(26, 'payumoney', 'payumoney', 0.1, 0, '2', '{\"method_type\":\"2\",\"name\":\"UPI PHONEPE \\/ PAYTM - GPAY [\\ud835\\udc0f\\ud835\\udc00\\ud835\\udc18\\ud835\\udc14\\ud835\\udc0c\\ud835\\udc0e\\ud835\\udc0d\\ud835\\udc04\\ud835\\udc18] [\\ud835\\udc08\\ud835\\udc0d\\ud835\\udc11]\",\"min\":\"0.10\",\"max\":\"0\",\"merchant_key\":\"\",\"salt_key\":\"\",\"fee\":\"2\",\"currency\":\"USD\"}', 1, '2', ''),
(30, 'Freebalance', 'Freebalance', 1, 0, '1', '{\"method_type\":\"1\",\"name\":\"Freebalance\",\"min\":\"1\",\"max\":\"0\",\"merchant_id\":\"\",\"merchant_key\":\"\",\"merchant_salt\":\"\",\"fee\":\"0\"}', 30, '1', ''),
(31, 'Perfect Money', 'perfectmoney', 0.1, 10000, '2', '{\"method_type\":\"2\",\"name\":\"2% Extra Bonus [\\ud835\\udc0f\\ud835\\udc1e\\ud835\\udc2b\\ud835\\udc1f\\ud835\\udc1e\\ud835\\udc1c\\ud835\\udc2d\\ud835\\udc0c\\ud835\\udc28\\ud835\\udc27\\ud835\\udc32] [\\ud835\\udc14\\ud835\\udc12\\ud835\\udc03]\",\"min\":\"0.10\",\"max\":\"10000\",\"passphrase\":\"\",\"usd\":\"\",\"merchant_website\":\"OwnSMMPanel.in\",\"fee\":\"0\"}', 4, '2', ''),
(32, 'Coinbase', 'Coinbase', 1, 0, '2', '{\"method_type\":\"2\",\"name\":\"Cryptocurrency  [\\ud835\\udc02\\ud835\\udc28\\ud835\\udc22\\ud835\\udc27\\ud835\\udc1b\\ud835\\udc1a\\ud835\\udc2c\\ud835\\udc1e] [\\ud835\\udc01\\ud835\\udc13\\ud835\\udc02] \",\"min\":\"1\",\"max\":\"0\",\"api_key\":\"\",\"webhook_api\":\"\",\"fee\":\"3\"}', 6, '2', ''),
(33, 'Webmoney', 'Webmoney', 1, 1, '2', '{\"method_type\":\"2\",\"name\":\"Webmoney\",\"min\":\"1\",\"max\":\"1\",\"wmid\":\"\",\"purse\":\"\",\"fee\":\"0\"}', 25, '2', ''),
(34, 'UnitPay', 'UnityPay', 1, 0, '2', '{\"method_type\":\"1\",\"name\":\"UnitPay\",\"min\":\"1\",\"max\":\"0\",\"secret_key\":\"\",\"reg_email\":\"\",\"fee\":\"0\"}', 26, '2', ''),
(35, 'Payeer', 'payeer', 10, 0, '2', '{\"method_type\":\"2\",\"name\":\"Payeer\",\"min\":\"1\",\"max\":\"100000\",\"account\":\"P1059667343\",\"client_secret\":\"tQCaSXyX94pRgpOt\",\"user_id\":\"1654044737\",\"user_pass\":\"tQCaSXyX94pRgpOt\",\"m_shop\":\"1652134607\"}', 13, '2', ''),
(37, 'opay', 'opay', 1, 1000, '2', '{\"method_type\":\"1\",\"is_demo\":\"0\",\"name\":\"opay - Visa - Mastercard - Mobile Wallets\",\"min\":\"1\",\"max\":\"1000\",\"merchant_id\":\"\",\"secret_key\":\"\",\"public_key\":\"\",\"dollar_rate\":\"18.5\"}', 15, '2', ''),
(38, 'Custom', 'custom', 0, 0, '2', '{\"method_type\":\"1\",\"name\":\"Manul\",\"content\":\"\"}', 27, '2', ''),
(987, 'Gbprimepay', 'gbprimepay', 10, 10000, '2', '{\"method_type\":\"1\",\"name\":\"Gbprimepay\",\"min\":\"10\",\"max\":\"10000\",\"token\":\"\"}', 14, '2', '');

-- --------------------------------------------------------

--
-- Table structure for table `referral`
--

CREATE TABLE `referral` (
  `referral_id` int(11) NOT NULL,
  `referral_client_id` int(11) NOT NULL,
  `referral_clicks` double NOT NULL DEFAULT 0,
  `referral_sign_up` double NOT NULL DEFAULT 0,
  `referral_totalFunds_byReffered` double NOT NULL DEFAULT 0,
  `referral_earned_commision` double DEFAULT 0,
  `referral_requested_commision` varchar(225) DEFAULT '0',
  `referral_total_commision` double DEFAULT 0,
  `referral_status` enum('1','2') NOT NULL DEFAULT '1',
  `referral_code` text NOT NULL,
  `referral_rejected_commision` double NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `referral_payouts`
--

CREATE TABLE `referral_payouts` (
  `r_p_id` int(11) NOT NULL,
  `r_p_code` text NOT NULL,
  `r_p_status` enum('1','2','3','4','0') NOT NULL DEFAULT '0',
  `r_p_amount_requested` double NOT NULL,
  `r_p_requested_at` datetime NOT NULL,
  `r_p_updated_at` datetime NOT NULL,
  `client_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `refill_status`
--

CREATE TABLE `refill_status` (
  `id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `order_id` int(11) NOT NULL,
  `refill_apiid` int(11) DEFAULT NULL,
  `order_url` text NOT NULL,
  `creation_date` datetime DEFAULT NULL,
  `ending_date` date DEFAULT NULL,
  `service_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `refill_status` enum('Pending','Refilling','Completed','Rejected','Error') DEFAULT 'Pending',
  `order_apiid` int(11) DEFAULT 0,
  `refill_response` text DEFAULT NULL,
  `refill_where` enum('site','api') DEFAULT 'site'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `serviceapi_alert`
--

CREATE TABLE `serviceapi_alert` (
  `id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `serviceapi_alert` text NOT NULL,
  `servicealert_extra` text NOT NULL,
  `servicealert_date` datetime NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `services`
--

CREATE TABLE `services` (
  `service_id` int(11) NOT NULL,
  `service_api` int(11) NOT NULL DEFAULT 0,
  `api_service` int(11) NOT NULL DEFAULT 0,
  `api_servicetype` enum('1','2') NOT NULL DEFAULT '2',
  `api_detail` text NOT NULL,
  `category_id` int(11) NOT NULL,
  `service_line` double NOT NULL,
  `service_type` enum('1','2') NOT NULL DEFAULT '2',
  `service_package` enum('1','2','3','4','5','6','7','8','9','10','11','12','13','14','15','16','17') NOT NULL,
  `service_name` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `service_description` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL,
  `service_price` varchar(225) NOT NULL,
  `service_min` double NOT NULL,
  `service_max` double NOT NULL,
  `service_dripfeed` enum('1','2') NOT NULL DEFAULT '1',
  `service_autotime` double NOT NULL DEFAULT 0,
  `service_autopost` double NOT NULL DEFAULT 0,
  `service_speed` enum('1','2','3','4') NOT NULL,
  `want_username` enum('1','2') NOT NULL DEFAULT '1',
  `service_secret` enum('1','2') NOT NULL DEFAULT '2',
  `price_type` enum('normal','percent','amount') NOT NULL DEFAULT 'normal',
  `price_cal` text DEFAULT NULL,
  `instagram_second` enum('1','2') NOT NULL DEFAULT '2',
  `start_count` enum('none','instagram_follower','instagram_photo','') NOT NULL,
  `instagram_private` enum('1','2') NOT NULL,
  `name_lang` varchar(225) DEFAULT 'en',
  `description_lang` text DEFAULT NULL,
  `time_lang` varchar(225) NOT NULL DEFAULT 'Not enough data',
  `time` varchar(225) NOT NULL DEFAULT 'Not enough data',
  `cancelbutton` enum('1','2') NOT NULL DEFAULT '2' COMMENT '1 -> ON, 2 -> OFF',
  `show_refill` enum('true','false') NOT NULL DEFAULT 'false',
  `service_profit` varchar(225) NOT NULL,
  `refill_days` varchar(225) NOT NULL DEFAULT '30',
  `refill_hours` varchar(225) NOT NULL DEFAULT '24',
  `avg_days` int(11) NOT NULL,
  `avg_hours` int(11) NOT NULL,
  `avg_minutes` int(11) NOT NULL,
  `avg_many` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `services`
--

INSERT INTO `services` (`service_id`, `service_api`, `api_service`, `api_servicetype`, `api_detail`, `category_id`, `service_line`, `service_type`, `service_package`, `service_name`, `service_description`, `service_price`, `service_min`, `service_max`, `service_dripfeed`, `service_autotime`, `service_autopost`, `service_speed`, `want_username`, `service_secret`, `price_type`, `price_cal`, `instagram_second`, `start_count`, `instagram_private`, `name_lang`, `description_lang`, `time_lang`, `time`, `cancelbutton`, `show_refill`, `service_profit`, `refill_days`, `refill_hours`, `avg_days`, `avg_hours`, `avg_minutes`, `avg_many`) VALUES
(1, 1, 825, '2', '{\"min\":\"20\",\"max\":\"100000\",\"rate\":\"0.1650\",\"refill\":false,\"currency\":\"USD\"}', 1, 1, '2', '1', 'Instagram Likes - [ Max - 45k ] [ Real Likes ] [ SLOW ] INSTANT-5MINS', 'Link - Post Link\r\n\r\nStart - INSTANT\r\nSpeed - 10K-20K PER HOUR\r\nQuality - REAL ', '0.182', 20, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Likes - [ Max - 45k ] [ Real Likes ] [ SLOW ] INSTANT-5MINS\"}', '{\"en\":\"Link - Post Link\\r\\n\\r\\nStart - INSTANT\\r\\nSpeed - 10K-20K PER HOUR\\r\\nQuality - REAL \"}', 'Not enough data', 'Not enough data', '2', 'false', '10', '30', '24', 0, 0, 0, 0),
(2, 1, 824, '2', '{\"min\":\"10\",\"max\":\"50000\",\"rate\":\"0.2530\",\"refill\":false,\"currency\":\"USD\"}', 1, 1, '2', '1', 'Instagram Likes [ Max - 50k ] [ REAL - Indian/Turkish ] INSTANT-15MINS', 'Link - Post Link\r\n\r\nStart - INSTANT\r\nSpeed - 10K-20K PER HOUR\r\nQuality - REAL - Indian/Turkish', '0.278', 10, 50000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Likes [ Max - 50k ] [ REAL - Indian\\/Turkish ] INSTANT-15MINS\"}', '{\"en\":\"Link - Post Link\\r\\n\\r\\nStart - INSTANT\\r\\nSpeed - 10K-20K PER HOUR\\r\\nQuality - REAL - Indian\\/Turkish\"}', 'Not enough data', 'Not enough data', '2', 'false', '10', '30', '24', 0, 0, 0, 0),
(3, 1, 823, '2', '{\"min\":\"20\",\"max\":\"49000\",\"rate\":\"0.2420\",\"refill\":false,\"currency\":\"USD\"}', 1, 1, '2', '1', 'Instagram Likes - [ Max - 49k ] [ Real Likes, Reliable ] [ FASTEST ] INSTANT', 'INSTANT START\r\nSUPER FAST\r\nREAL LIKES\r\nPost must have less then 7k likes, If more then 7k likes, Order will be auto cancel!', '0.266', 20, 49000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Likes - [ Max - 49k ] [ Real Likes, Reliable ] [ FASTEST ] INSTANT\"}', '{\"en\":\"INSTANT START\\r\\nSUPER FAST\\r\\nREAL LIKES\\r\\nPost must have less then 7k likes, If more then 7k likes, Order will be auto cancel!\"}', 'Not enough data', 'Not enough data', '2', 'false', '10', '30', '24', 0, 0, 0, 0),
(4, 1, 822, '2', '{\"min\":\"10\",\"max\":\"30000\",\"rate\":\"0.2640\",\"refill\":false,\"currency\":\"USD\"}', 1, 1, '2', '1', 'Instagram Likes [ Max - 25k ] [ REAL, Good Users ] INSTANT-15MINS', 'Reliable, Good account names!\r\nNatural Increase\r\n\r\nStart : 0-15mins\r\nQuality : 70% Real Likes, 30% BOT\r\nSample- https://prnt.sc/zuPw4YPI9ND6\r\nRefill : NO', '0.290', 10, 30000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Likes [ Max - 25k ] [ REAL, Good Users ] INSTANT-15MINS\"}', '{\"en\":\"Reliable, Good account names!\\r\\nNatural Increase\\r\\n\\r\\nStart : 0-15mins\\r\\nQuality : 70% Real Likes, 30% BOT\\r\\nSample- https:\\/\\/prnt.sc\\/zuPw4YPI9ND6\\r\\nRefill : NO\"}', 'Not enough data', 'Not enough data', '2', 'false', '10', '30', '24', 0, 0, 0, 0),
(5, 1, 821, '2', '{\"min\":\"20\",\"max\":\"20000\",\"rate\":\"0.2090\",\"refill\":false,\"currency\":\"USD\"}', 1, 1, '2', '1', 'Instagram Likes - [ Max - 20k ] [ REAL LIKES - SUPERFAST ] INSTANT', 'Link - Post Link\r\n\r\nStart - INSTANT START\r\nSpeed - 1K-2K PER HOUR\r\nQuality - 100% REAL ACCOUNTS\r\n\r\n\r\nSUPER-FAST\r\nALWAYS INSTANT!', '0.230', 20, 20000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Likes - [ Max - 20k ] [ REAL LIKES - SUPERFAST ] INSTANT\"}', '{\"en\":\"Link - Post Link\\r\\n\\r\\nStart - INSTANT START\\r\\nSpeed - 1K-2K PER HOUR\\r\\nQuality - 100% REAL ACCOUNTS\\r\\n\\r\\n\\r\\nSUPER-FAST\\r\\nALWAYS INSTANT!\"}', 'Not enough data', 'Not enough data', '2', 'false', '10', '30', '24', 0, 0, 0, 0),
(6, 1, 826, '2', '{\"min\":\"20\",\"max\":\"60000\",\"rate\":\"0.2970\",\"refill\":false,\"currency\":\"USD\"}', 1, 1, '2', '1', 'Instagram Likes - [ Max - 60k ] [ Real, Natural Increase ] INSTANT', 'Link - Post Link\r\n\r\nStart - INSTANT\r\nSpeed - 10K-20K PER HOUR\r\nQuality - REAL', '0.327', 20, 60000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Likes - [ Max - 60k ] [ Real, Natural Increase ] INSTANT\"}', '{\"en\":\"Link - Post Link\\r\\n\\r\\nStart - INSTANT\\r\\nSpeed - 10K-20K PER HOUR\\r\\nQuality - REAL\"}', 'Not enough data', 'Not enough data', '2', 'false', '10', '30', '24', 0, 0, 0, 0),
(7, 1, 820, '2', '{\"min\":\"20\",\"max\":\"10000\",\"rate\":\"0.2750\",\"refill\":false,\"currency\":\"USD\"}', 1, 1, '2', '1', 'Instagram Likes - [ Max - 10k ] [ 80-90% REAL ] [ Fastest ] INSTANT', 'Link - Post Link\r\n\r\nStart - Instant\r\nSpeed - 50K / day\r\nQuality - 80-90% REAL', '0.303', 20, 10000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Likes - [ Max - 10k ] [ 80-90% REAL ] [ Fastest ] INSTANT\"}', '{\"en\":\"Link - Post Link\\r\\n\\r\\nStart - Instant\\r\\nSpeed - 50K \\/ day\\r\\nQuality - 80-90% REAL\"}', 'Not enough data', 'Not enough data', '2', 'false', '10', '30', '24', 0, 0, 0, 0),
(8, 1, 819, '2', '{\"min\":\"100\",\"max\":\"50000\",\"rate\":\"0.35\",\"refill\":false,\"currency\":\"USD\"}', 1, 1, '2', '1', 'Instagram Likes - [ Max - 50k ] [ SUPERFAST ] SUPER INSTANT', 'Link - Post Link\r\n\r\nStart - SUPER INSTANT\r\nSpeed - 10K-20K PER HOUR\r\nQuality - MOSTLY REAL ACC!\r\n\r\n', '0.385', 100, 50000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Likes - [ Max - 50k ] [ SUPERFAST ] SUPER INSTANT\"}', '{\"en\":\"Link - Post Link\\r\\n\\r\\nStart - SUPER INSTANT\\r\\nSpeed - 10K-20K PER HOUR\\r\\nQuality - MOSTLY REAL ACC!\\r\\n\\r\\n\"}', 'Not enough data', 'Not enough data', '2', 'false', '10', '30', '24', 0, 0, 0, 0),
(9, 1, 10, '2', '{\"min\":\"10\",\"max\":\"500000\",\"rate\":\"0.2772\",\"refill\":true,\"currency\":\"USD\"}', 2, 1, '2', '1', 'Instagram Instant  Followers [ 5K-10K / day ] [ R 30 / Day ]', 'Link - Instagram Profile URL / Username \r\n\r\nStart - Instant \r\nSpeed - 10K-30K / day \r\nQuality - Indian Mix \r\nDrop - 10-30% \r\nRefill - 30 days [ With Button ] \r\n\r\n\r\nNote - \r\nInstant Start Natural Speed.\r\nRefill button working for 30 days.\r\nManual Cancel Support Available.\r\n\r\n\r\n\r\n', '0.305', 10, 500000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Instant  Followers [ 5K-10K \\/ day ] [ R 30 \\/ Day ]\"}', '{\"en\":\"Link - Instagram Profile URL \\/ Username \\r\\n\\r\\nStart - Instant \\r\\nSpeed - 10K-30K \\/ day \\r\\nQuality - Indian Mix \\r\\nDrop - 10-30% \\r\\nRefill - 30 days [ With Button ] \\r\\n\\r\\n\\r\\nNote - \\r\\nInstant Start Natural Speed.\\r\\nRefill button working for 30 days.\\r\\nManual Cancel Support Available.\\r\\n\\r\\n\\r\\n\\r\\n\"}', 'Not enough data', 'Not enough data', '2', 'true', '10', '30', '24', 0, 0, 0, 0),
(10, 1, 9, '2', '{\"min\":\"100\",\"max\":\"150000\",\"rate\":\"0.2217\",\"refill\":true,\"currency\":\"USD\"}', 2, 1, '2', '1', 'Instagram Mix Quality Followers [ 5K-10K / day ] [ R 30 / Day ]', 'Link - Instagram Profile URL \r\n\r\nStart - 0-15 min \r\nSpeed - 25K-50K / day \r\nQuality - High Quality Majority Story and Private Accounts \r\nRefill - 30 days \r\nDrop - 0-10%\r\n \r\nNote - \r\nSpeed Up Not Available in this server since already mentioned Natural Speed.\r\nCancel Button And Refill Button Active \r\nNo need to press refill button since its auto refill.\r\nEvery 24 hrs followers are refilled automatically.', '0.244', 100, 150000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Mix Quality Followers [ 5K-10K \\/ day ] [ R 30 \\/ Day ]\"}', '{\"en\":\"Link - Instagram Profile URL \\r\\n\\r\\nStart - 0-15 min \\r\\nSpeed - 25K-50K \\/ day \\r\\nQuality - High Quality Majority Story and Private Accounts \\r\\nRefill - 30 days \\r\\nDrop - 0-10%\\r\\n \\r\\nNote - \\r\\nSpeed Up Not Available in this server since already mentioned Natural Speed.\\r\\nCancel Button And Refill Button Active \\r\\nNo need to press refill button since its auto refill.\\r\\nEvery 24 hrs followers are refilled automatically.\"}', 'Not enough data', 'Not enough data', '2', 'true', '10', '30', '24', 0, 0, 0, 0),
(11, 1, 8, '2', '{\"min\":\"50\",\"max\":\"100000\",\"rate\":\"0.2286\",\"refill\":true,\"currency\":\"USD\"}', 2, 1, '2', '1', 'Instagram HQ Followers [ 5K-10K / day ] [ R 30 / Day ]', 'Link - Instagram Profile URL / Username\r\n\r\nStart - 0-1 hrs \r\nSpeed - 5K-10K /day \r\nDrop - 10-20% [ Can be more in future ] \r\nRefill - 30 days refill \r\nQuality - Indian Mix + Bots \r\n\r\n\r\nNote - \r\nSometimes have Start Delays.\r\nDrops are Very Less Currently but can be more in future.\r\nCancel Button Active.', '0.251', 50, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram HQ Followers [ 5K-10K \\/ day ] [ R 30 \\/ Day ]\"}', '{\"en\":\"Link - Instagram Profile URL \\/ Username\\r\\n\\r\\nStart - 0-1 hrs \\r\\nSpeed - 5K-10K \\/day \\r\\nDrop - 10-20% [ Can be more in future ] \\r\\nRefill - 30 days refill \\r\\nQuality - Indian Mix + Bots \\r\\n\\r\\n\\r\\nNote - \\r\\nSometimes have Start Delays.\\r\\nDrops are Very Less Currently but can be more in future.\\r\\nCancel Button Active.\"}', 'Not enough data', 'Not enough data', '2', 'true', '10', '30', '24', 0, 0, 0, 0),
(12, 1, 6, '2', '{\"min\":\"10\",\"max\":\"50000\",\"rate\":\"0.1642\",\"refill\":true,\"currency\":\"USD\"}', 2, 1, '2', '1', 'Instagram Followers Fast [ R 15 / Day ]', 'Link - Instagram Profile URL / Username \r\n\r\nStart - Instant \r\nSpeed - 50K+ / day \r\nQuality - Bots\r\nDrop - 50-90% \r\nRefill - 15 Days Button\r\n\r\nNote - \r\n• High Drop Low Quality.\r\n• Refill Available for 15 days.\r\n• Cancel Button Enabled .', '0.181', 10, 50000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Followers Fast [ R 15 \\/ Day ]\"}', '{\"en\":\"Link - Instagram Profile URL \\/ Username \\r\\n\\r\\nStart - Instant \\r\\nSpeed - 50K+ \\/ day \\r\\nQuality - Bots\\r\\nDrop - 50-90% \\r\\nRefill - 15 Days Button\\r\\n\\r\\nNote - \\r\\n\\u2022 High Drop Low Quality.\\r\\n\\u2022 Refill Available for 15 days.\\r\\n\\u2022 Cancel Button Enabled .\"}', 'Not enough data', 'Not enough data', '2', 'true', '10', '30', '24', 0, 0, 0, 0),
(13, 1, 7, '2', '{\"min\":\"100\",\"max\":\"10000\",\"rate\":\"0.2252\",\"refill\":true,\"currency\":\"USD\"}', 2, 1, '2', '1', 'Instagram Mix Followers - Instant  [ 10-20K /day ] [ R 30 / Day ]', 'Link - Instagram Profile URL / Username\r\n\r\nStart - Instant \r\nSpeed - 10K-30K /day\r\nDrop - 10-30 % \r\nRefill - 30 days refill button \r\nQuality -  Mix \r\n\r\nNote - \r\n• Recovery of followers for 30 days.\r\n• Has Drops but all drops are covered by Refill.\r\n', '0.248', 100, 10000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Mix Followers - Instant  [ 10-20K \\/day ] [ R 30 \\/ Day ]\"}', '{\"en\":\"Link - Instagram Profile URL \\/ Username\\r\\n\\r\\nStart - Instant \\r\\nSpeed - 10K-30K \\/day\\r\\nDrop - 10-30 % \\r\\nRefill - 30 days refill button \\r\\nQuality -  Mix \\r\\n\\r\\nNote - \\r\\n\\u2022 Recovery of followers for 30 days.\\r\\n\\u2022 Has Drops but all drops are covered by Refill.\\r\\n\"}', 'Not enough data', 'Not enough data', '2', 'true', '10', '30', '24', 0, 0, 0, 0),
(14, 1, 13, '2', '{\"min\":\"50\",\"max\":\"50000000\",\"rate\":\"0.4155\",\"refill\":true,\"currency\":\"USD\"}', 2, 1, '2', '1', 'Instagram HQ Followers [ 𝟗𝟗 𝐝𝐚𝐲𝐬 𝐀𝐮𝐭𝐨 𝐑𝐞𝐟𝐢𝐥𝐥 ♻ ] [ 10K / day ] ', 'Link - Instagram Profile URL\r\n\r\nStart - Instant [ Never Delay ] \r\nSpeed - 10K-50K / day\r\nQuality - Old Accounts with posts\r\nDrop - Non Drop [ Stable ]\r\nRefill  - 99 days auto refill  \r\n\r\n\r\nNote -\r\nLong Term Service.\r\nCancel Button Enabled.\r\nHigh Quality Accounts with profiles and posts.\r\n99 days auto refill to avoid drops.', '0.457', 50, 50000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram HQ Followers [ \\ud835\\udfd7\\ud835\\udfd7 \\ud835\\udc1d\\ud835\\udc1a\\ud835\\udc32\\ud835\\udc2c \\ud835\\udc00\\ud835\\udc2e\\ud835\\udc2d\\ud835\\udc28 \\ud835\\udc11\\ud835\\udc1e\\ud835\\udc1f\\ud835\\udc22\\ud835\\udc25\\ud835\\udc', '{\"en\":\"Link - Instagram Profile URL\\r\\n\\r\\nStart - Instant [ Never Delay ] \\r\\nSpeed - 10K-50K \\/ day\\r\\nQuality - Old Accounts with posts\\r\\nDrop - Non Drop [ Stable ]\\r\\nRefill  - 99 days auto refill  \\r\\n\\r\\n\\r\\nNote -\\r\\nLong Term Service.\\r\\nCancel Button Enabled.\\r\\nHigh Quality Accounts with profiles and posts.\\r\\n99 days auto refill to avoid drops.\"}', 'Not enough data', 'Not enough data', '2', 'true', '10', '30', '24', 0, 0, 0, 0),
(15, 1, 12, '2', '{\"min\":\"100\",\"max\":\"5000000\",\"rate\":\"0.4850\",\"refill\":true,\"currency\":\"USD\"}', 2, 1, '2', '1', 'Instagram Instant Followers [ 𝟑𝟔𝟓 𝐝𝐚𝐲𝐬 𝐀𝐮𝐭𝐨 𝐑𝐞𝐟𝐢𝐥𝐥 ♻  ] [ 15K  / day ] ', 'Link - Instagram Profile URL \r\n\r\nStart - Instant \r\nSpeed - 25K-50K / day \r\nQuality - HQ  \r\nDrop - Never Drop \r\nRefill - Auto Refill 365 days + Button Active \r\n\r\n\r\nNote - \r\nSuperfast Speed \r\nHigh Quality Accounts ( Worldwide )\r\n365 days auto refill to avoid drops no need to press refill button or drop ticket.\r\nOld Reliable Server.\r\n\r\n', '0.534', 100, 5000000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Instant Followers [ \\ud835\\udfd1\\ud835\\udfd4\\ud835\\udfd3 \\ud835\\udc1d\\ud835\\udc1a\\ud835\\udc32\\ud835\\udc2c \\ud835\\udc00\\ud835\\udc2e\\ud835\\udc2d\\ud835\\udc28 \\ud835\\udc11\\ud835\\udc1e\\ud835\\udc1f\\ud835\\udc22\\ud83', '{\"en\":\"Link - Instagram Profile URL \\r\\n\\r\\nStart - Instant \\r\\nSpeed - 25K-50K \\/ day \\r\\nQuality - HQ  \\r\\nDrop - Never Drop \\r\\nRefill - Auto Refill 365 days + Button Active \\r\\n\\r\\n\\r\\nNote - \\r\\nSuperfast Speed \\r\\nHigh Quality Accounts ( Worldwide )\\r\\n365 days auto refill to avoid drops no need to press refill button or drop ticket.\\r\\nOld Reliable Server.\\r\\n\\r\\n\"}', 'Not enough data', 'Not enough data', '2', 'true', '10', '30', '24', 0, 0, 0, 0),
(16, 1, 14, '2', '{\"min\":\"100\",\"max\":\"100000\",\"rate\":\"0.4503\",\"refill\":true,\"currency\":\"USD\"}', 2, 1, '2', '1', 'Instagram HQ Followers [  𝟗𝟗 𝐝𝐚𝐲𝐬 𝐀𝐮𝐭𝐨 𝐑𝐞𝐟𝐢𝐥𝐥 ♻ ] [ 5-6K / day ]', 'Link - Instagram Profile URL \r\n\r\nStart - Instant \r\nSpeed - 20K / day \r\nDrop - Non Drop ( 0-5% )\r\nRefill - 99 days auto refill \r\nQuality - HQ Accounts ( Indian Mix Mostly with posts )\r\n\r\n\r\nNote - \r\nFast Speed Reliable Server.\r\nHigh Quality Accounts  ( Indian Mix ).\r\n99 days auto refill to avoid drops no need to press refill button or drop ticket.\r\nFast Server ( Indian Mix Old Accounts ).\r\n\r\n       ', '0.495', 100, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram HQ Followers [  \\ud835\\udfd7\\ud835\\udfd7 \\ud835\\udc1d\\ud835\\udc1a\\ud835\\udc32\\ud835\\udc2c \\ud835\\udc00\\ud835\\udc2e\\ud835\\udc2d\\ud835\\udc28 \\ud835\\udc11\\ud835\\udc1e\\ud835\\udc1f\\ud835\\udc22\\ud835\\udc25\\ud835\\ud', '{\"en\":\"Link - Instagram Profile URL \\r\\n\\r\\nStart - Instant \\r\\nSpeed - 20K \\/ day \\r\\nDrop - Non Drop ( 0-5% )\\r\\nRefill - 99 days auto refill \\r\\nQuality - HQ Accounts ( Indian Mix Mostly with posts )\\r\\n\\r\\n\\r\\nNote - \\r\\nFast Speed Reliable Server.\\r\\nHigh Quality Accounts  ( Indian Mix ).\\r\\n99 days auto refill to avoid drops no need to press refill button or drop ticket.\\r\\nFast Server ( Indian Mix Old Accounts ).\\r\\n\\r\\n       \"}', 'Not enough data', 'Not enough data', '2', 'true', '10', '30', '24', 0, 0, 0, 0),
(17, 1, 15, '2', '{\"min\":\"250\",\"max\":\"100000\",\"rate\":\"0.3464\",\"refill\":true,\"currency\":\"USD\"}', 2, 1, '2', '1', 'Instagram Mix Followers [ 𝟑𝟔𝟓 𝐝𝐚𝐲𝐬 𝐀𝐮𝐭𝐨 𝐑𝐞𝐟𝐢𝐥𝐥 ♻ ] [ 10K-20K / Day ]  ', 'Link - Instagram Profile URL \r\n\r\nStart - Instant \r\nSpeed - 30K-50K / day \r\nDrop - Less Drop ( 0-10% )\r\nRefill - 365 days auto refill \r\nQuality - Mix Accounts ( Indian Mix  ) \r\n\r\n\r\nNote - \r\nFast Speed Reliable Server.\r\nMix  Quality Accounts  ( Indian Mix ).\r\n365 days auto refill to avoid drops no need to press refill button or drop ticket.\r\nCancel Button Enabled if u are not satisfied with speed.\r\n\r\n\r\n       ', '0.381', 250, 100000, '1', 0, 0, '1', '1', '2', 'normal', NULL, '2', 'none', '1', '{\"en\":\"Instagram Mix Followers [ \\ud835\\udfd1\\ud835\\udfd4\\ud835\\udfd3 \\ud835\\udc1d\\ud835\\udc1a\\ud835\\udc32\\ud835\\udc2c \\ud835\\udc00\\ud835\\udc2e\\ud835\\udc2d\\ud835\\udc28 \\ud835\\udc11\\ud835\\udc1e\\ud835\\udc1f\\ud835\\udc22\\ud835\\ud', '{\"en\":\"Link - Instagram Profile URL \\r\\n\\r\\nStart - Instant \\r\\nSpeed - 30K-50K \\/ day \\r\\nDrop - Less Drop ( 0-10% )\\r\\nRefill - 365 days auto refill \\r\\nQuality - Mix Accounts ( Indian Mix  ) \\r\\n\\r\\n\\r\\nNote - \\r\\nFast Speed Reliable Server.\\r\\nMix  Quality Accounts  ( Indian Mix ).\\r\\n365 days auto refill to avoid drops no need to press refill button or drop ticket.\\r\\nCancel Button Enabled if u are not satisfied with speed.\\r\\n\\r\\n\\r\\n       \"}', 'Not enough data', 'Not enough data', '2', 'true', '10', '30', '24', 0, 0, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `service_api`
--

CREATE TABLE `service_api` (
  `id` int(11) NOT NULL,
  `api_name` varchar(225) NOT NULL,
  `api_url` text NOT NULL,
  `api_key` varchar(225) NOT NULL,
  `api_type` int(11) NOT NULL,
  `api_limit` double NOT NULL DEFAULT 0,
  `currency` enum('INR','USD') DEFAULT NULL,
  `api_alert` enum('1','2') NOT NULL DEFAULT '2' COMMENT '2 -> Gönder, 1 -> Gönderildi',
  `status` enum('1','2') NOT NULL DEFAULT '2'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `service_api`
--

INSERT INTO `service_api` (`id`, `api_name`, `api_url`, `api_key`, `api_type`, `api_limit`, `currency`, `api_alert`, `status`) VALUES
(1, 'socialkart.in', 'https://socialkart.in/api/v2', '5a5bf923864a72912be11532b27ce4d875103e99', 1, 0, 'USD', '1', '1');

-- --------------------------------------------------------

--
-- Table structure for table `settings`
--

CREATE TABLE `settings` (
  `id` int(11) NOT NULL,
  `site_seo` text NOT NULL,
  `site_title` text DEFAULT NULL,
  `site_description` text DEFAULT NULL,
  `site_keywords` text DEFAULT NULL,
  `site_logo` text DEFAULT NULL,
  `site_name` text DEFAULT NULL,
  `site_currency` varchar(2555) NOT NULL DEFAULT 'try',
  `favicon` text DEFAULT NULL,
  `site_language` varchar(225) NOT NULL DEFAULT 'tr',
  `site_theme` text NOT NULL,
  `site_theme_alt` text DEFAULT NULL,
  `recaptcha` enum('1','2') NOT NULL DEFAULT '1',
  `recaptcha_key` text DEFAULT NULL,
  `recaptcha_secret` text DEFAULT NULL,
  `custom_header` text DEFAULT NULL,
  `custom_footer` text DEFAULT NULL,
  `ticket_system` enum('1','2') NOT NULL DEFAULT '2',
  `register_page` enum('1','2') NOT NULL DEFAULT '2',
  `service_speed` enum('1','2') NOT NULL,
  `service_list` enum('1','2') NOT NULL,
  `dolar_charge` double NOT NULL,
  `euro_charge` double NOT NULL,
  `smtp_user` text NOT NULL,
  `smtp_pass` text NOT NULL,
  `smtp_server` text NOT NULL,
  `smtp_port` varchar(225) NOT NULL,
  `smtp_protocol` enum('0','ssl','tls') NOT NULL,
  `alert_type` enum('1','2','3') NOT NULL,
  `alert_apimail` enum('1','2') NOT NULL,
  `alert_newmanuelservice` enum('1','2') NOT NULL,
  `alert_newticket` enum('1','2') NOT NULL,
  `alert_apibalance` enum('1','2') NOT NULL,
  `alert_serviceapialert` enum('1','2') NOT NULL,
  `sms_provider` varchar(225) NOT NULL,
  `sms_title` varchar(225) NOT NULL,
  `sms_user` varchar(225) NOT NULL,
  `sms_pass` varchar(225) NOT NULL,
  `sms_validate` enum('0','1') NOT NULL DEFAULT '0' COMMENT '1 -> OK, 0 -> NO',
  `admin_mail` varchar(225) NOT NULL,
  `admin_telephone` varchar(225) NOT NULL,
  `resetpass_page` enum('1','2') NOT NULL,
  `resetpass_sms` enum('1','2') NOT NULL,
  `resetpass_email` enum('1','2') NOT NULL,
  `site_maintenance` enum('1','2') NOT NULL DEFAULT '2',
  `servis_siralama` varchar(255) NOT NULL,
  `bronz_statu` int(11) NOT NULL,
  `silver_statu` int(11) NOT NULL,
  `gold_statu` int(11) NOT NULL,
  `bayi_statu` int(11) NOT NULL,
  `ns1` varchar(191) DEFAULT NULL,
  `ns2` varchar(191) DEFAULT NULL,
  `childpanel_price` double DEFAULT NULL,
  `snow_effect` enum('1','2') NOT NULL DEFAULT '2',
  `snow_colour` text NOT NULL,
  `promotion` enum('1','2') DEFAULT '2',
  `referral_commision` double NOT NULL,
  `referral_payout` double NOT NULL,
  `referral_status` enum('1','2') NOT NULL DEFAULT '1',
  `childpanel_selling` enum('1','2') NOT NULL DEFAULT '1',
  `tickets_per_user` double NOT NULL DEFAULT 5,
  `name_fileds` enum('1','2') NOT NULL DEFAULT '1' COMMENT '1 -> ON, 2 -> NO',
  `skype_feilds` enum('1','2') NOT NULL DEFAULT '1' COMMENT '1 -> ON, 2 -> NO',
  `csymbol` text NOT NULL,
  `inr_symbol` text NOT NULL,
  `inr_value` double NOT NULL DEFAULT 0,
  `usd_symbol` text NOT NULL,
  `inr_convert` double NOT NULL DEFAULT 0,
  `otp_login` enum('1','2','0') NOT NULL DEFAULT '0',
  `auto_deactivate_payment` enum('1','2') NOT NULL DEFAULT '1',
  `service_avg_time` enum('1','0') NOT NULL DEFAULT '0',
  `alert_orderfail` enum('1','2') NOT NULL DEFAULT '2',
  `alert_welcomemail` enum('1','2') NOT NULL DEFAULT '2',
  `freebalance` enum('1','2') NOT NULL DEFAULT '1',
  `freeamount` double DEFAULT 0,
  `alert_newmessage` enum('1','2') NOT NULL DEFAULT '1',
  `email_confirmation` enum('1','2') NOT NULL DEFAULT '2',
  `osp_license` text NOT NULL,
  `licence_id` text NOT NULL,
  `osp_orders` text DEFAULT NULL,
  `resend_max` int(11) NOT NULL,
  `whatsappbutton` text NOT NULL,
  `whatsappnumber` text NOT NULL,
  `whatsappcolour` text NOT NULL,
  `theme_bg_img` text NOT NULL,
  `whatsappposition` text NOT NULL,
  `telegrambutton` text NOT NULL,
  `telegramusername` text NOT NULL,
  `telegramposition` text NOT NULL,
  `panel_status` text NOT NULL,
  `fake_order_min` int(11) NOT NULL,
  `fake_order_max` int(11) NOT NULL,
  `fake_order_after` int(11) NOT NULL,
  `fake_order` int(11) NOT NULL,
  `fake_order_fix` int(11) NOT NULL,
  `fake_ticket_min` int(11) NOT NULL,
  `fake_ticket_max` int(11) NOT NULL,
  `fake_ticket_after` int(11) NOT NULL,
  `fake_ticket` int(11) NOT NULL,
  `fake_ticket_fix` int(11) NOT NULL,
  `panel_order` int(11) NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `settings`
--

INSERT INTO `settings` (`id`, `site_seo`, `site_title`, `site_description`, `site_keywords`, `site_logo`, `site_name`, `site_currency`, `favicon`, `site_language`, `site_theme`, `site_theme_alt`, `recaptcha`, `recaptcha_key`, `recaptcha_secret`, `custom_header`, `custom_footer`, `ticket_system`, `register_page`, `service_speed`, `service_list`, `dolar_charge`, `euro_charge`, `smtp_user`, `smtp_pass`, `smtp_server`, `smtp_port`, `smtp_protocol`, `alert_type`, `alert_apimail`, `alert_newmanuelservice`, `alert_newticket`, `alert_apibalance`, `alert_serviceapialert`, `sms_provider`, `sms_title`, `sms_user`, `sms_pass`, `sms_validate`, `admin_mail`, `admin_telephone`, `resetpass_page`, `resetpass_sms`, `resetpass_email`, `site_maintenance`, `servis_siralama`, `bronz_statu`, `silver_statu`, `gold_statu`, `bayi_statu`, `ns1`, `ns2`, `childpanel_price`, `snow_effect`, `snow_colour`, `promotion`, `referral_commision`, `referral_payout`, `referral_status`, `childpanel_selling`, `tickets_per_user`, `name_fileds`, `skype_feilds`, `csymbol`, `inr_symbol`, `inr_value`, `usd_symbol`, `inr_convert`, `otp_login`, `auto_deactivate_payment`, `service_avg_time`, `alert_orderfail`, `alert_welcomemail`, `freebalance`, `freeamount`, `alert_newmessage`, `email_confirmation`, `osp_license`, `licence_id`, `osp_orders`, `resend_max`, `whatsappbutton`, `whatsappnumber`, `whatsappcolour`, `theme_bg_img`, `whatsappposition`, `telegrambutton`, `telegramusername`, `telegramposition`, `panel_status`, `fake_order_min`, `fake_order_max`, `fake_order_after`, `fake_order`, `fake_order_fix`, `fake_ticket_min`, `fake_ticket_max`, `fake_ticket_after`, `fake_ticket`, `fake_ticket_fix`, `panel_order`) VALUES
(1, 'QuickPanel V2', 'QuickPanel V2', 'QuickPanel V2', 'QuickPanel V2', 'public/images/019d385eb67632a7e958e23f24bd07d7.png', 'QuickPanel v2.5', 'USD', 'public/images/09d66f6e5482d9b0ba91815c350fd9af3770819b.png', 'en', 'Simplify', 'v6', '1', '', '', '', '', '1', '2', '1', '2', 82.72, 0, '', '121345', '', '465', 'ssl', '2', '1', '1', '1', '1', '1', 'bizimsms', '', '', '', '1', '', '918355965199', '2', '1', '2', '2', 'asc', 5, 20, 60, 150, 'ns1.ownwebhost.in', 'ns2.ownwebhost.in', 10, '', '', '1', 10, 1, '2', '2', 9999999999, '2', '2', '$', '₹', 82.73, '$', 0.012, '0', '1', '1', '1', '1', '1', 0, '1', '2', '', '₹', '99999999', 6, '1', '', '', '', 'right', '0', '', 'left', '2', 0, 0, 3, 1000, 0, 0, 0, 3, 5, 0, 0);

-- --------------------------------------------------------

--
-- Table structure for table `sync_logs`
--

CREATE TABLE `sync_logs` (
  `id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `action` varchar(225) NOT NULL,
  `date` datetime NOT NULL,
  `description` varchar(225) NOT NULL,
  `api_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `themes`
--

CREATE TABLE `themes` (
  `id` int(11) NOT NULL,
  `theme_name` text NOT NULL,
  `theme_dirname` text NOT NULL,
  `theme_extras` text NOT NULL,
  `last_modified` datetime NOT NULL,
  `osp_img` text NOT NULL,
  `newpage` text NOT NULL
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `themes`
--

INSERT INTO `themes` (`id`, `theme_name`, `theme_dirname`, `theme_extras`, `last_modified`, `osp_img`, `newpage`) VALUES
(1, 'QuickPanel', 'Simplify', '', '2022-08-16 12:41:25', '1/', '{% include \'header.twig\' %} <div class=\"wrapper-content\">     <div class=\"wrapper-content__header\">           </div>     <div class=\"wrapper-content__body\">       <!-- Main variables *content* -->       <div id=\"block_93\">     <div class=\"new_order-block \">         <div class=\"bg\"></div>         <div class=\"divider-top\"></div>         <div class=\"divider-bottom\"></div>         <div class=\"container\">             <div class=\"row new-order-form\">                 <div class=\"col-lg-8\">                    <div class=\"component_form_group component_card component_radio_button\">                       <div class=\"card \">     <div class=\"col-md-12\">         {{ contentText }}       </div>     </div>   </div>  </div>  </div> </div> </div> </div>   </div> </div>  {% include \'footer.twig\' %}'),
(2, 'PerfectPanel', 'Simplify1', '', '2022-08-16 12:42:25', '', '{% include \'header.twig\' %} <div class=\"wrapper-content\">     <div class=\"wrapper-content__header\">           </div>     <div class=\"wrapper-content__body\">       <!-- Main variables *content* -->       <div id=\"block_93\">     <div class=\"new_order-block \">         <div class=\"bg\"></div>         <div class=\"divider-top\"></div>         <div class=\"divider-bottom\"></div>         <div class=\"container\">             <div class=\"row new-order-form\">                 <div class=\"col-lg-8\">                    <div class=\"component_form_group component_card component_radio_button\">                       <div class=\"card \">     <div class=\"col-md-12\">         {{ contentText }}       </div>     </div>   </div>  </div>  </div> </div> </div> </div>   </div> </div>  {% include \'footer.twig\' %}');

-- --------------------------------------------------------

--
-- Table structure for table `tickets`
--

CREATE TABLE `tickets` (
  `ticket_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `subject` varchar(225) NOT NULL,
  `time` datetime NOT NULL,
  `lastupdate_time` datetime NOT NULL,
  `client_new` enum('1','2') NOT NULL DEFAULT '2',
  `status` enum('pending','answered','closed') NOT NULL DEFAULT 'pending',
  `support_new` enum('1','2') NOT NULL DEFAULT '1',
  `canmessage` enum('1','2') NOT NULL DEFAULT '2'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_reply`
--

CREATE TABLE `ticket_reply` (
  `id` int(11) NOT NULL,
  `ticket_id` int(11) NOT NULL,
  `client_id` int(11) NOT NULL,
  `time` datetime NOT NULL,
  `support` enum('1','2') NOT NULL DEFAULT '1',
  `message` text CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `readed` enum('1','2') NOT NULL DEFAULT '1'
) ENGINE=MyISAM DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `ticket_subjects`
--

CREATE TABLE `ticket_subjects` (
  `subject_id` int(11) NOT NULL,
  `subject` varchar(225) NOT NULL,
  `content` text DEFAULT NULL,
  `auto_reply` enum('0','1') NOT NULL DEFAULT '0'
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci ROW_FORMAT=COMPACT;

--
-- Dumping data for table `ticket_subjects`
--

INSERT INTO `ticket_subjects` (`subject_id`, `subject`, `content`, `auto_reply`) VALUES
(1, 'Orders', '', '0'),
(2, 'Payments', '\r\n', '0'),
(3, 'API And Services', '', '0'),
(4, 'Others', 'Hi..', '1');

-- --------------------------------------------------------

--
-- Table structure for table `units_per_page`
--

CREATE TABLE `units_per_page` (
  `id` int(11) NOT NULL,
  `unit` int(11) NOT NULL,
  `page` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Dumping data for table `units_per_page`
--

INSERT INTO `units_per_page` (`id`, `unit`, `page`) VALUES
(1, 50, 'clients'),
(2, 500, 'orders'),
(3, 100, 'payments'),
(4, 50, 'refill');

-- --------------------------------------------------------

--
-- Table structure for table `updates`
--

CREATE TABLE `updates` (
  `u_id` int(11) NOT NULL,
  `service_id` int(11) NOT NULL,
  `action` varchar(225) NOT NULL,
  `date` datetime NOT NULL,
  `description` varchar(225) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8 COLLATE=utf8_general_ci;

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admins`
--
ALTER TABLE `admins`
  ADD PRIMARY KEY (`admin_id`);

--
-- Indexes for table `article`
--
ALTER TABLE `article`
  ADD PRIMARY KEY (`id`),
  ADD KEY `title` (`title`);

--
-- Indexes for table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `blogs`
--
ALTER TABLE `blogs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `categories`
--
ALTER TABLE `categories`
  ADD PRIMARY KEY (`category_id`);

--
-- Indexes for table `childpanels`
--
ALTER TABLE `childpanels`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients`
--
ALTER TABLE `clients`
  ADD PRIMARY KEY (`client_id`);

--
-- Indexes for table `clients_category`
--
ALTER TABLE `clients_category`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients_price`
--
ALTER TABLE `clients_price`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `clients_service`
--
ALTER TABLE `clients_service`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `client_report`
--
ALTER TABLE `client_report`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `crons`
--
ALTER TABLE `crons`
  ADD PRIMARY KEY (`cron_id`);

--
-- Indexes for table `currency`
--
ALTER TABLE `currency`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `earn`
--
ALTER TABLE `earn`
  ADD PRIMARY KEY (`earn_id`);

--
-- Indexes for table `files`
--
ALTER TABLE `files`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `General_options`
--
ALTER TABLE `General_options`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `integrations`
--
ALTER TABLE `integrations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kuponlar`
--
ALTER TABLE `kuponlar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `kupon_kullananlar`
--
ALTER TABLE `kupon_kullananlar`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `languages`
--
ALTER TABLE `languages`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `Mailforms`
--
ALTER TABLE `Mailforms`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `menus`
--
ALTER TABLE `menus`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `news`
--
ALTER TABLE `news`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `notifications_popup`
--
ALTER TABLE `notifications_popup`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `orders`
--
ALTER TABLE `orders`
  ADD PRIMARY KEY (`order_id`) USING BTREE;

--
-- Indexes for table `pages`
--
ALTER TABLE `pages`
  ADD PRIMARY KEY (`page_id`);

--
-- Indexes for table `payments`
--
ALTER TABLE `payments`
  ADD PRIMARY KEY (`payment_id`);

--
-- Indexes for table `payments_bonus`
--
ALTER TABLE `payments_bonus`
  ADD PRIMARY KEY (`bonus_id`);

--
-- Indexes for table `payment_methods`
--
ALTER TABLE `payment_methods`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `referral`
--
ALTER TABLE `referral`
  ADD PRIMARY KEY (`referral_id`);

--
-- Indexes for table `referral_payouts`
--
ALTER TABLE `referral_payouts`
  ADD PRIMARY KEY (`r_p_id`);

--
-- Indexes for table `refill_status`
--
ALTER TABLE `refill_status`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `serviceapi_alert`
--
ALTER TABLE `serviceapi_alert`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `services`
--
ALTER TABLE `services`
  ADD PRIMARY KEY (`service_id`);

--
-- Indexes for table `service_api`
--
ALTER TABLE `service_api`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `settings`
--
ALTER TABLE `settings`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `sync_logs`
--
ALTER TABLE `sync_logs`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `themes`
--
ALTER TABLE `themes`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `tickets`
--
ALTER TABLE `tickets`
  ADD PRIMARY KEY (`ticket_id`);

--
-- Indexes for table `ticket_reply`
--
ALTER TABLE `ticket_reply`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ticket_subjects`
--
ALTER TABLE `ticket_subjects`
  ADD PRIMARY KEY (`subject_id`);

--
-- Indexes for table `units_per_page`
--
ALTER TABLE `units_per_page`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `updates`
--
ALTER TABLE `updates`
  ADD PRIMARY KEY (`u_id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admins`
--
ALTER TABLE `admins`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=116;

--
-- AUTO_INCREMENT for table `article`
--
ALTER TABLE `article`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `bank_accounts`
--
ALTER TABLE `bank_accounts`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `blogs`
--
ALTER TABLE `blogs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `categories`
--
ALTER TABLE `categories`
  MODIFY `category_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `childpanels`
--
ALTER TABLE `childpanels`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clients`
--
ALTER TABLE `clients`
  MODIFY `client_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `clients_category`
--
ALTER TABLE `clients_category`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clients_price`
--
ALTER TABLE `clients_price`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `clients_service`
--
ALTER TABLE `clients_service`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `client_report`
--
ALTER TABLE `client_report`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `crons`
--
ALTER TABLE `crons`
  MODIFY `cron_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `currency`
--
ALTER TABLE `currency`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;

--
-- AUTO_INCREMENT for table `earn`
--
ALTER TABLE `earn`
  MODIFY `earn_id` int(255) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `files`
--
ALTER TABLE `files`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `General_options`
--
ALTER TABLE `General_options`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `integrations`
--
ALTER TABLE `integrations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=14;

--
-- AUTO_INCREMENT for table `kuponlar`
--
ALTER TABLE `kuponlar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `kupon_kullananlar`
--
ALTER TABLE `kupon_kullananlar`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `languages`
--
ALTER TABLE `languages`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `Mailforms`
--
ALTER TABLE `Mailforms`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `menus`
--
ALTER TABLE `menus`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=49;

--
-- AUTO_INCREMENT for table `news`
--
ALTER TABLE `news`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `notifications_popup`
--
ALTER TABLE `notifications_popup`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `orders`
--
ALTER TABLE `orders`
  MODIFY `order_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `pages`
--
ALTER TABLE `pages`
  MODIFY `page_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=788;

--
-- AUTO_INCREMENT for table `payments`
--
ALTER TABLE `payments`
  MODIFY `payment_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `payments_bonus`
--
ALTER TABLE `payments_bonus`
  MODIFY `bonus_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT for table `payment_methods`
--
ALTER TABLE `payment_methods`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=988;

--
-- AUTO_INCREMENT for table `referral`
--
ALTER TABLE `referral`
  MODIFY `referral_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `referral_payouts`
--
ALTER TABLE `referral_payouts`
  MODIFY `r_p_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `refill_status`
--
ALTER TABLE `refill_status`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `serviceapi_alert`
--
ALTER TABLE `serviceapi_alert`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=1902;

--
-- AUTO_INCREMENT for table `services`
--
ALTER TABLE `services`
  MODIFY `service_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;

--
-- AUTO_INCREMENT for table `service_api`
--
ALTER TABLE `service_api`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `settings`
--
ALTER TABLE `settings`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `sync_logs`
--
ALTER TABLE `sync_logs`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `themes`
--
ALTER TABLE `themes`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2147483648;

--
-- AUTO_INCREMENT for table `tickets`
--
ALTER TABLE `tickets`
  MODIFY `ticket_id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ticket_reply`
--
ALTER TABLE `ticket_reply`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `ticket_subjects`
--
ALTER TABLE `ticket_subjects`
  MODIFY `subject_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `units_per_page`
--
ALTER TABLE `units_per_page`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `updates`
--
ALTER TABLE `updates`
  MODIFY `u_id` int(11) NOT NULL AUTO_INCREMENT;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
