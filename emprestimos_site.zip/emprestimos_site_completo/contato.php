<?php
session_start();
require_once 'config/conexao.php';

// Mensagem de feedback
$mensagem = "";

// Verifica se o formulário foi enviado
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = trim($_POST['nome']);
    $email = trim($_POST['email']);
    $telefone = trim($_POST['telefone']);
    $mensagem_contato = trim($_POST['mensagem']);

    if (!empty($nome) && !empty($email) && !empty($telefone) && !empty($mensagem_contato)) {
        try {
            $stmt = $conn->prepare("INSERT INTO contatos (nome, email, telefone, mensagem, data) VALUES (?, ?, ?, ?, NOW())");
            $stmt->execute([$nome, $email, $telefone, $mensagem_contato]);

            $mensagem = "Mensagem enviada com sucesso! Retornaremos em breve.";
        } catch (PDOException $e) {
            $mensagem = "Erro ao enviar mensagem: " . $e->getMessage();
        }
    } else {
        $mensagem = "Por favor, preencha todos os campos.";
    }
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Contato</title>
    <link rel="stylesheet" href="assets/css/style.css">
</head>
<body>
    <header>
        <h1>Fale Conosco</h1>
        <nav>
            <ul>
                <li><a href="index.php">Início</a></li>
                <li><a href="simulador.php">Simulador</a></li>
                <li><a href="depoimentos.php">Depoimentos</a></li>
                <li><a href="contato.php">Contato</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section id="contato">
            <h2>Entre em contato</h2>

            <?php if ($mensagem): ?>
                <p class="mensagem"><?= htmlspecialchars($mensagem) ?></p>
            <?php endif; ?>

            <form action="contato.php" method="POST">
                <label for="nome">Nome:</label>
                <input type="text" name="nome" id="nome" required>

                <label for="email">E-mail:</label>
                <input type="email" name="email" id="email" required>

                <label for="telefone">Telefone:</label>
                <input type="text" name="telefone" id="telefone" required>

                <label for="mensagem">Mensagem:</label>
                <textarea name="mensagem" id="mensagem" required></textarea>

                <button type="submit">Enviar</button>
            </form>
        </section>
    </main>

    <footer>
        <p>&copy; 2025 Empréstimos Consignados</p>
    </footer>
</body>
</html>