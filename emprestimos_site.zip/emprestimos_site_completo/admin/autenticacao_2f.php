<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $codigo = $_POST['codigo'];
    
    // Verifique o código (normalmente gerado via e-mail ou aplicativo de autenticação)
    if ($codigo === $_SESSION['codigo_2f']) {
        // Autenticação bem-sucedida, redireciona para o painel
        header("Location: index.php");
        exit;
    } else {
        echo "Código inválido.";
    }
}
?>

<form method="POST">
    <label for="codigo">Código de Autenticação:</label>
    <input type="text" name="codigo" required>
    <button type="submit">Verificar Código</button>
</form>