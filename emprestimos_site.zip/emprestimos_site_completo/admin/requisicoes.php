<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

require_once '../config/conexao.php';

// Filtro de pesquisa
$search = isset($_GET['search']) ? trim($_GET['search']) : '';
$status_filter = isset($_GET['status']) ? $_GET['status'] : '';

// Construção da query de pesquisa
$query = "SELECT * FROM solicitacoes WHERE nome LIKE ? AND status LIKE ?";
$stmt = $conn->prepare($query);
$stmt->execute(['%' . $search . '%', '%' . $status_filter . '%']);
$solicitacoes = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Alterar status da solicitação
if (isset($_POST['update_status'])) {
    $id = $_POST['id'];
    $status = $_POST['status'];
    $stmt = $conn->prepare("UPDATE solicitacoes SET status = ? WHERE id = ?");
    $stmt->execute([$status, $id]);

    header("Location: requisicoes.php");
    exit();
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Requisições de Crédito</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <header>
        <h1>Requisições de Análise de Crédito</h1>
        <nav>
            <ul>
                <li><a href="index.php">Início</a></li>
                <li><a href="solicitacoes.php">Solicitações</a></li>
                <li><a href="depoimentos.php">Depoimentos</a></li>
                <li><a href="mensagens.php">Mensagens</a></li>
                <li><a href="banners.php">Banners</a></li>
                <li><a href="logout.php">Sair</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section>
            <h2>Filtrar Requisições</h2>
            <form action="requisicoes.php" method="GET">
                <input type="text" name="search" placeholder="Pesquisar por nome..." value="<?= htmlspecialchars($search) ?>">
                <select name="status">
                    <option value="">--Selecione o Status--</option>
                    <option value="Pendente" <?= ($status_filter == 'Pendente') ? 'selected' : '' ?>>Pendente</option>
                    <option value="Aprovado" <?= ($status_filter == 'Aprovado') ? 'selected' : '' ?>>Aprovado</option>
                    <option value="Rejeitado" <?= ($status_filter == 'Rejeitado') ? 'selected' : '' ?>>Rejeitado</option>
                </select>
                <button type="submit">Filtrar</button>
            </form>

            <h2>Últimas Requisições de Crédito</h2>

            <?php if ($solicitacoes): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>Valor Solicitado</th>
                            <th>Status</th>
                            <th>Data da Solicitação</th>
                            <th>Ações</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($solicitacoes as $solicitacao): ?>
                            <tr>
                                <td><?= htmlspecialchars($solicitacao['nome']) ?></td>
                                <td>R$ <?= number_format($solicitacao['valor'], 2, ',', '.') ?></td>
                                <td><?= htmlspecialchars($solicitacao['status']) ?></td>
                                <td><?= date('d/m/Y H:i:s', strtotime($solicitacao['data_solicitacao'])) ?></td>
                                <td>
                                    <form action="requisicoes.php" method="POST">
                                        <input type="hidden" name="id" value="<?= $solicitacao['id'] ?>">
                                        <select name="status">
                                            <option value="Pendente" <?= ($solicitacao['status'] == 'Pendente') ? 'selected' : '' ?>>Pendente</option>
                                            <option value="Aprovado" <?= ($solicitacao['status'] == 'Aprovado') ? 'selected' : '' ?>>Aprovado</option>
                                            <option value="Rejeitado" <?= ($solicitacao['status'] == 'Rejeitado') ? 'selected' : '' ?>>Rejeitado</option>
                                        </select>
                                        <button type="submit" name="update_status">Alterar Status</button>
                                    </form>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>Não há requisições para exibir.</p>
            <?php endif; ?>
        </section>
    </main>
</body>
</html>