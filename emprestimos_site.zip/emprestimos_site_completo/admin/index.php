<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

require_once '../config/conexao.php';

// Contagem de registros para o painel
$solicitacoes = $conn->query("SELECT COUNT(*) FROM solicitacoes")->fetchColumn();
$depoimentos_pendentes = $conn->query("SELECT COUNT(*) FROM depoimentos WHERE status = 'Pendente'")->fetchColumn();
$mensagens = $conn->query("SELECT COUNT(*) FROM contatos")->fetchColumn();
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Painel Administrativo</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <header>
        <h1>Painel Administrativo</h1>
        <nav>
            <ul>
                <li><a href="solicitacoes.php">Solicitações (<?= $solicitacoes ?>)</a></li>
                <li><a href="depoimentos.php">Depoimentos Pendentes (<?= $depoimentos_pendentes ?>)</a></li>
                <li><a href="mensagens.php">Mensagens (<?= $mensagens ?>)</a></li>
                <li><a href="banners.php">Gerenciar Banners</a></li>
                <li><a href="logout.php">Sair</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section>
            <h2>Bem-vindo ao Painel</h2>
            <p>Gerencie as solicitações, depoimentos e mensagens dos clientes.</p>
        </section>
    </main>
</body>
</html>
