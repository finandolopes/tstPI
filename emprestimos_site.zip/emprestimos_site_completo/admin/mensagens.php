<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

require_once '../config/conexao.php';

// Verifica se há algum filtro de pesquisa
$search = isset($_GET['search']) ? trim($_GET['search']) : '';

// Consulta de mensagens recebidas
$query = "SELECT * FROM contatos WHERE nome LIKE ?";
$stmt = $conn->prepare($query);
$stmt->execute(['%' . $search . '%']);
$mensagens = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Mensagens</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <header>
        <h1>Gestão de Mensagens de Contato</h1>
        <nav>
            <ul>
                <li><a href="index.php">Início</a></li>
                <li><a href="solicitacoes.php">Solicitações</a></li>
                <li><a href="depoimentos.php">Depoimentos</a></li>
                <li><a href="mensagens.php">Mensagens</a></li>
                <li><a href="banners.php">Banners</a></li>
                <li><a href="logout.php">Sair</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section>
            <h2>Filtrar Mensagens</h2>
            <form action="mensagens.php" method="GET">
                <input type="text" name="search" placeholder="Pesquisar por nome..." value="<?= htmlspecialchars($search) ?>">
                <button type="submit">Filtrar</button>
            </form>

            <h2>Mensagens Recebidas</h2>

            <?php if ($mensagens): ?>
                <table>
                    <thead>
                        <tr>
                            <th>Nome</th>
                            <th>E-mail</th>
                            <th>Telefone</th>
                            <th>Data</th>
                            <th>Ação</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($mensagens as $mensagem): ?>
                            <tr>
                                <td><?= htmlspecialchars($mensagem['nome']) ?></td>
                                <td><?= htmlspecialchars($mensagem['email']) ?></td>
                                <td><?= htmlspecialchars($mensagem['telefone']) ?></td>
                                <td><?= date('d/m/Y', strtotime($mensagem['data'])) ?></td>
                                <td>
                                    <a href="ver_mensagem.php?id=<?= $mensagem['id'] ?>">Ver Mensagem</a>
                                </td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php else: ?>
                <p>Não há mensagens recebidas.</p>
            <?php endif; ?>
        </section>
    </main>
</body>
</html>