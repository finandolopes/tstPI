<?php
require_once 'config/conexao.php';

if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $nome = $_POST['nome'];
    $mensagem = $_POST['mensagem'];

    $stmt = $conn->prepare("INSERT INTO depoimentos (nome, mensagem, aprovado) VALUES (?, ?, 0)");
    $stmt->execute([$nome, $mensagem]);

    echo "Seu depoimento foi enviado para análise.";
}
?>