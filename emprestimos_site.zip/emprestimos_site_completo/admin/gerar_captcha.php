<?php
session_start();

// Configurações da imagem
header('Content-type: image/png');
$imagem = imagecreatetruecolor(120, 50);
$cor_fundo = imagecolorallocate($imagem, 255, 255, 255);  // Cor de fundo branca
$cor_texto = imagecolorallocate($imagem, 0, 0, 0);  // Cor do texto preta

imagefill($imagem, 0, 0, $cor_fundo);

// Adiciona o texto do CAPTCHA na imagem
$captcha = $_SESSION['captcha'];
imagestring($imagem, 5, 20, 15, $captcha, $cor_texto);

// Exibe a imagem
imagepng($imagem);
imagedestroy($imagem);