<?php
require_once '../config/conexao.php';

// Verifica se o usuário tem permissão de administrador
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Buscar todos os depoimentos aguardando moderação
$query_depoimentos = "SELECT * FROM depoimentos WHERE status = 'pendente'";
$depoimentos = $conn->query($query_depoimentos)->fetchAll(PDO::FETCH_ASSOC);

// Aprovar ou Rejeitar depoimento
if (isset($_GET['aprovar'])) {
    $id = $_GET['aprovar'];
    $update_query = "UPDATE depoimentos SET status = 'aprovado' WHERE id = :id";
    $stmt = $conn->prepare($update_query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    header('Location: depoimentos.php');
}

if (isset($_GET['rejeitar'])) {
    $id = $_GET['rejeitar'];
    $update_query = "UPDATE depoimentos SET status = 'rejeitado' WHERE id = :id";
    $stmt = $conn->prepare($update_query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    header('Location: depoimentos.php');
}

// Excluir depoimento
if (isset($_GET['excluir'])) {
    $id = $_GET['excluir'];
    $delete_query = "DELETE FROM depoimentos WHERE id = :id";
    $stmt = $conn->prepare($delete_query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    header('Location: depoimentos.php');
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de Depoimentos</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header>
        <div class="logo">
            <h1>Painel Administrativo</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Dashboard</a></li>
                <li><a href="depoimentos.php">Depoimentos</a></li>
                <li><a href="contato.php">Mensagens</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="analise_credito.php">Análise de Crédito</a></li>
                <li><a href="usuarios.php">Usuários</a></li>
                <li><a href="relatorios.php">Relatórios</a></li>
                <li><a href="slideshow.php">Slides</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Gestão de Depoimentos</h2>

        <!-- Listagem de depoimentos aguardando moderação -->
        <h3>Depoimentos Pendentes</h3>
        <table>
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>Depoimento</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($depoimentos as $depoimento) : ?>
                <tr>
                    <td><?= $depoimento['nome']; ?></td>
                    <td><?= $depoimento['depoimento']; ?></td>
                    <td>
                        <a href="depoimentos.php?aprovar=<?= $depoimento['id']; ?>">Aprovar</a> | 
                        <a href="depoimentos.php?rejeitar=<?= $depoimento['id']; ?>">Rejeitar</a> | 
                        <a href="depoimentos.php?excluir=<?= $depoimento['id']; ?>">Excluir</a>
                    </td>
                </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </main>
</body>
</html>