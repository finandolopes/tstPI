<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

require_once '../config/conexao.php';

// Atualizar status da requisição
if (isset($_POST['update_status'])) {
    $id = $_POST['id'];
    $status = $_POST['status'];
    $stmt = $conn->prepare("UPDATE requisicoes SET status = ? WHERE id = ?");
    $stmt->execute([$status, $id]);

    header("Location: requisicoes.php");
    exit();
}

// Buscar todas as requisições
$query = "SELECT * FROM requisicoes";
$requisicoes = $conn->query($query)->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Requisições de Análise de Crédito</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <header>
        <h1>Requisições de Análise de Crédito</h1>
        <nav>
            <ul>
                <li><a href="index.php">Início</a></li>
                <li><a href="solicitacoes.php">Solicitações</a></li>
                <li><a href="depoimentos.php">Depoimentos</a></li>
                <li><a href="banners.php">Banners</a></li>
                <li><a href="estatisticas.php">Estatísticas</a></li>
                <li><a href="logout.php">Sair</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section>
            <h2>Requisições Pendentes</h2>
            <table>
                <thead>
                    <tr>
                        <th>Nome do Cliente</th>
                        <th>Valor do Empréstimo</th>
                        <th>Status</th>
                        <th>Data da Requisição</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($requisicoes as $requisicao): ?>
                        <tr>
                            <td><?= htmlspecialchars($requisicao['nome_cliente']) ?></td>
                            <td><?= htmlspecialchars($requisicao['valor']) ?></td>
                            <td>
                                <form action="requisicoes.php" method="POST">
                                    <input type="hidden" name="id" value="<?= $requisicao['id'] ?>">
                                    <select name="status">
                                        <option value="Pendente" <?= $requisicao['status'] == 'Pendente' ? 'selected' : '' ?>>Pendente</option>
                                        <option value="Aprovada" <?= $requisicao['status'] == 'Aprovada' ? 'selected' : '' ?>>Aprovada</option>
                                        <option value="Rejeitada" <?= $requisicao['status'] == 'Rejeitada' ? 'selected' : '' ?>>Rejeitada</option>
                                    </select>
                                    <button type="submit" name="update_status">Atualizar</button>
                                </form>
                            </td>
                            <td><?= date('d/m/Y', strtotime($requisicao['data_requisicao'])) ?></td>
                            <td><a href="detalhes_requisicao.php?id=<?= $requisicao['id'] ?>">Ver Detalhes</a></td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    </main>
</body>
</html>