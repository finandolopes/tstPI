<?php
require_once '../config/conexao.php';
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

if (isset($_GET['aprovar'])) {
    $id = $_GET['aprovar'];
    $conn->query("UPDATE depoimentos SET aprovado = 1 WHERE id = $id");
}

$depoimentos = $conn->query("SELECT * FROM depoimentos WHERE aprovado = 0")->fetchAll();
?>

<h2>🔍 Moderação de Depoimentos</h2>
<ul>
    <?php foreach ($depoimentos as $depoimento): ?>
        <li>
            <strong><?php echo $depoimento['nome']; ?></strong>: <?php echo $depoimento['mensagem']; ?>
            <a href="?aprovar=<?php echo $depoimento['id']; ?>">✔ Aprovar</a>
        </li>
    <?php endforeach; ?>
</ul>