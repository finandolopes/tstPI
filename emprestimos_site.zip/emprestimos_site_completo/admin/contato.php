<?php
require_once '../config/conexao.php';

// Verifica se o usuário tem permissão de administrador
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Buscar mensagens de contato
$query_mensagens = "SELECT * FROM mensagens ORDER BY data_envio DESC";
$mensagens = $conn->query($query_mensagens)->fetchAll(PDO::FETCH_ASSOC);

// Marcar mensagem como lida
if (isset($_GET['ler'])) {
    $id = $_GET['ler'];
    $update_query = "UPDATE mensagens SET status = 'Lida' WHERE id = :id";
    $stmt = $conn->prepare($update_query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    header('Location: contato.php');
}

// Responder mensagem
if (isset($_POST['responder'])) {
    $id = $_POST['id'];
    $resposta = $_POST['resposta'];
    $update_query = "UPDATE mensagens SET resposta = :resposta, status = 'Respondida' WHERE id = :id";
    $stmt = $conn->prepare($update_query);
    $stmt->bindParam(':resposta', $resposta);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    header('Location: contato.php');
}

// Excluir mensagem
if (isset($_GET['excluir'])) {
    $id = $_GET['excluir'];
    $delete_query = "DELETE FROM mensagens WHERE id = :id";
    $stmt = $conn->prepare($delete_query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    header('Location: contato.php');
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Mensagens de Contato</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header>
        <div class="logo">
            <h1>Painel Administrativo</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Dashboard</a></li>
                <li><a href="depoimentos.php">Depoimentos</a></li>
                <li><a href="contato.php">Mensagens</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="analise_credito.php">Análise de Crédito</a></li>
                <li><a href="usuarios.php">Usuários</a></li>
                <li><a href="relatorios.php">Relatórios</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Mensagens Enviadas</h2>
        <table>
            <thead>
                <tr>
                    <th>Nome</th>
                    <th>E-mail</th>
                    <th>Assunto</th>
                    <th>Status</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($mensagens as $mensagem): ?>
                    <tr>
                        <td><?= htmlspecialchars($mensagem['nome']) ?></td>
                        <td><?= htmlspecialchars($mensagem['email']) ?></td>
                        <td><?= htmlspecialchars($mensagem['assunto']) ?></td>
                        <td><?= htmlspecialchars($mensagem['status']) ?></td>
                        <td>
                            <?php if ($mensagem['status'] === 'Não Lida'): ?>
                                <a href="?ler=<?= $mensagem['id'] ?>">Marcar como Lida</a>
                            <?php elseif ($mensagem['status'] === 'Lida' && !$mensagem['resposta']): ?>
                                <form action="contato.php" method="POST">
                                    <textarea name="resposta" required placeholder="Escreva sua resposta"></textarea>
                                    <input type="hidden" name="id" value="<?= $mensagem['id'] ?>">
                                    <button type="submit" name="responder">Responder</button>
                                </form>
                            <?php endif; ?>
                            <a href="?excluir=<?= $mensagem['id'] ?>">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </main>
</body>
</html>