<?php
require_once '../config/conexao.php';

// Verifica se o usuário tem permissão de administrador
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Buscar estatísticas gerais
$query_acessos = "SELECT COUNT(*) AS total_acessos FROM acessos";
$query_clientes = "SELECT COUNT(*) AS total_clientes FROM usuarios";
$query_solicitacoes = "SELECT COUNT(*) AS total_solicitacoes FROM analises_credito";

// Executar as consultas
$acessos = $conn->query($query_acessos)->fetch(PDO::FETCH_ASSOC);
$clientes = $conn->query($query_clientes)->fetch(PDO::FETCH_ASSOC);
$solicitacoes = $conn->query($query_solicitacoes)->fetch(PDO::FETCH_ASSOC);

// Buscar relatórios detalhados (exemplo: solicitações por período)
$query_detalhes = "SELECT * FROM analises_credito WHERE data_solicitacao BETWEEN :data_inicio AND :data_fim";
if (isset($_POST['gerar_relatorio'])) {
    $data_inicio = $_POST['data_inicio'];
    $data_fim = $_POST['data_fim'];
    $stmt = $conn->prepare($query_detalhes);
    $stmt->bindParam(':data_inicio', $data_inicio);
    $stmt->bindParam(':data_fim', $data_fim);
    $stmt->execute();
    $detalhes = $stmt->fetchAll(PDO::FETCH_ASSOC);
} else {
    $detalhes = [];
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Relatórios</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header>
        <div class="logo">
            <h1>Painel Administrativo</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Dashboard</a></li>
                <li><a href="depoimentos.php">Depoimentos</a></li>
                <li><a href="contato.php">Mensagens</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="analise_credito.php">Análise de Crédito</a></li>
                <li><a href="usuarios.php">Usuários</a></li>
                <li><a href="relatorios.php">Relatórios</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Relatórios de Atividades</h2>
        <section class="relatorios-gerais">
            <h3>Estatísticas Gerais</h3>
            <ul>
                <li>Total de Acessos: <?php echo $acessos['total_acessos']; ?></li>
                <li>Total de Clientes: <?php echo $clientes['total_clientes']; ?></li>
                <li>Total de Solicitações de Crédito: <?php echo $solicitacoes['total_solicitacoes']; ?></li>
            </ul>
        </section>

        <section class="relatorios-detalhados">
            <h3>Relatório Detalhado</h3>
            <form action="relatorios.php" method="POST">
                <label for="data_inicio">Data Início:</label>
                <input type="date" name="data_inicio" id="data_inicio" required>

                <label for="data_fim">Data Fim:</label>
                <input type="date" name="data_fim" id="data_fim" required>

                <button type="submit" name="gerar_relatorio">Gerar Relatório</button>
            </form>

            <?php if (!empty($detalhes)): ?>
                <h4>Solicitações entre <?php echo $data_inicio; ?> e <?php echo $data_fim; ?>:</h4>
                <table>
                    <thead>
                        <tr>
                            <th>ID</th>
                            <th>Nome</th>
                            <th>Status</th>
                            <th>Data Solicitação</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php foreach ($detalhes as $solicitacao): ?>
                            <tr>
                                <td><?php echo $solicitacao['id']; ?></td>
                                <td><?php echo $solicitacao['nome_cliente']; ?></td>
                                <td><?php echo $solicitacao['status']; ?></td>
                                <td><?php echo $solicitacao['data_solicitacao']; ?></td>
                            </tr>
                        <?php endforeach; ?>
                    </tbody>
                </table>
            <?php endif; ?>
        </section>
    </main>
</body>
</html>