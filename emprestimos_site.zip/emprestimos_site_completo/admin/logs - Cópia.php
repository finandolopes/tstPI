<?php
require_once '../config/conexao.php';
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Listando logs
$stmt = $conn->prepare("SELECT * FROM logs ORDER BY data DESC");
$stmt->execute();
$logs = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Logs de Atividades</h2>

<table>
    <thead>
        <tr>
            <th>Usuário</th>
            <th>Ação</th>
            <th>Data</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($logs as $log): ?>
        <tr>
            <td><?php echo $log['usuario']; ?></td>
            <td><?php echo $log['acao']; ?></td>
            <td><?php echo $log['data']; ?></td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>