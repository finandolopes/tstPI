<?php
// Inicia a sessão e verifica se o usuário é admin
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

require_once '../config/conexao.php';

// Criar usuário
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $senha = password_hash($_POST['senha'], PASSWORD_DEFAULT); // Hash da senha

    $stmt = $conn->prepare("INSERT INTO usuarios (nome, email, senha, status) VALUES (?, ?, ?, ?)");
    $stmt->execute([$nome, $email, $senha, 'ativo']);
    header('Location: usuarios.php');
}

// Listar usuários
$stmt = $conn->query("SELECT * FROM usuarios");
$usuarios = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<?php include 'includes/header.php'; ?>
<?php include 'includes/sidebar.php'; ?>

<main>
    <h2>Gerenciamento de Usuários</h2>
    <form action="usuarios.php" method="POST">
        <input type="text" name="nome" placeholder="Nome" required>
        <input type="email" name="email" placeholder="E-mail" required>
        <input type="password" name="senha" placeholder="Senha" required>
        <button type="submit">Criar Usuário</button>
    </form>

    <h3>Usuários Cadastrados</h3>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Nome</th>
                <th>E-mail</th>
                <th>Status</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($usuarios as $usuario): ?>
                <tr>
                    <td><?php echo $usuario['id']; ?></td>
                    <td><?php echo $usuario['nome']; ?></td>
                    <td><?php echo $usuario['email']; ?></td>
                    <td><?php echo $usuario['status']; ?></td>
                    <td>
                        <a href="usuarios.php?bloquear=<?php echo $usuario['id']; ?>">Bloquear</a>
                        <a href="usuarios.php?desbloquear=<?php echo $usuario['id']; ?>">Desbloquear</a>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</main>

<?php
// Bloquear usuário
if (isset($_GET['bloquear'])) {
    $id_usuario = $_GET['bloquear'];
    $stmt = $conn->prepare("UPDATE usuarios SET status = 'bloqueado' WHERE id = ?");
    $stmt->execute([$id_usuario]);
    header('Location: usuarios.php');
}

// Desbloquear usuário
if (isset($_GET['desbloquear'])) {
    $id_usuario = $_GET['desbloquear'];
    $stmt = $conn->prepare("UPDATE usuarios SET status = 'ativo' WHERE id = ?");
    $stmt->execute([$id_usuario]);
    header('Location: usuarios.php');
}
?>

<?php include 'includes/footer.php'; ?>