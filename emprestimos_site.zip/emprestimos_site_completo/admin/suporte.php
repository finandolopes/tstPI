<?php
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

require_once '../config/conexao.php';

// Criar novo ticket
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $assunto = $_POST['assunto'];
    $descricao = $_POST['descricao'];
    $status = 'aberto';
    $id_usuario = $_SESSION['user_id'];

    $stmt = $conn->prepare("INSERT INTO tickets (assunto, descricao, status, id_usuario) VALUES (?, ?, ?, ?)");
    $stmt->execute([$assunto, $descricao, $status, $id_usuario]);
    header('Location: suporte.php');
}

// Listar tickets
$stmt = $conn->query("SELECT * FROM tickets WHERE status = 'aberto'");
$tickets = $stmt->fetchAll(PDO::FETCH_ASSOC);
?>

<?php include 'includes/header.php'; ?>
<?php include 'includes/sidebar.php'; ?>

<main>
    <h2>Suporte ao Cliente</h2>
    <h3>Criar Novo Ticket</h3>
    <form action="suporte.php" method="POST">
        <input type="text" name="assunto" placeholder="Assunto" required>
        <textarea name="descricao" placeholder="Descrição" required></textarea>
        <button type="submit">Criar Ticket</button>
    </form>

    <h3>Tickets Abertos</h3>
    <table>
        <thead>
            <tr>
                <th>ID</th>
                <th>Assunto</th>
                <th>Descrição</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($tickets as $ticket): ?>
                <tr>
                    <td><?php echo $ticket['id']; ?></td>
                    <td><?php echo $ticket['assunto']; ?></td>
                    <td><?php echo $ticket['descricao']; ?></td>
                    <td><?php echo $ticket['status']; ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</main>

<?php include 'includes/footer.php'; ?>