<?php
require_once '../config/conexao.php';

// Verifica se o usuário tem permissão de administrador
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Função para salvar as configurações gerais (ex.: taxa de juros)
if (isset($_POST['salvar_configuracao'])) {
    $taxa_juros = $_POST['taxa_juros'];
    $prazo_maximo = $_POST['prazo_maximo'];
    
    // Atualizar as configurações no banco de dados
    $update_query = "UPDATE configuracoes SET taxa_juros = :taxa_juros, prazo_maximo = :prazo_maximo WHERE id = 1";
    $stmt = $conn->prepare($update_query);
    $stmt->bindParam(':taxa_juros', $taxa_juros);
    $stmt->bindParam(':prazo_maximo', $prazo_maximo);
    $stmt->execute();
    header('Location: configuracoes.php');
}

// Gerenciar Slides
if (isset($_POST['add_slide'])) {
    // Lógica para adicionar novo slide (com upload de imagem)
    $slide_image = $_FILES['slide_image']['name'];
    $target = "../assets/slides/" . basename($slide_image);
    move_uploaded_file($_FILES['slide_image']['tmp_name'], $target);
    
    // Salvar o slide na tabela
    $insert_slide = "INSERT INTO slides (imagem) VALUES (:imagem)";
    $stmt = $conn->prepare($insert_slide);
    $stmt->bindParam(':imagem', $slide_image);
    $stmt->execute();
    header('Location: configuracoes.php');
}

?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Configurações do Site</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header>
        <div class="logo">
            <h1>Painel Administrativo</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Dashboard</a></li>
                <li><a href="depoimentos.php">Depoimentos</a></li>
                <li><a href="contato.php">Mensagens</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="analise_credito.php">Análise de Crédito</a></li>
                <li><a href="usuarios.php">Usuários</a></li>
                <li><a href="relatorios.php">Relatórios</a></li>
                <li><a href="configuracoes.php">Configurações</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Configurações Gerais</h2>

        <section class="configuracoes-gerais">
            <h3>Configurações de Taxa de Juros e Prazo Máximo</h3>
            <form method="POST" action="configuracoes.php">
                <label for="taxa_juros">Taxa de Juros (%):</label>
                <input type="text" id="taxa_juros" name="taxa_juros" value="5.5" required>
                
                <label for="prazo_maximo">Prazo Máximo (meses):</label>
                <input type="text" id="prazo_maximo" name="prazo_maximo" value="72" required>

                <button type="submit" name="salvar_configuracao">Salvar Configurações</button>
            </form>
        </section>

        <section class="gerenciar-slides">
            <h3>Gerenciar Slides</h3>
            <form method="POST" action="configuracoes.php" enctype="multipart/form-data">
                <label for="slide_image">Escolher Imagem para o Slide:</label>
                <input type="file" id="slide_image" name="slide_image" required>

                <button type="submit" name="add_slide">Adicionar Slide</button>
            </form>
        </section>

        <section class="lista-slides">
            <h3>Slides Atuais</h3>
            <ul>
                <?php
                $query_slides = "SELECT * FROM slides";
                $slides = $conn->query($query_slides)->fetchAll(PDO::FETCH_ASSOC);

                foreach ($slides as $slide) {
                    echo "<li><img src='../assets/slides/{$slide['imagem']}' alt='Slide'></li>";
                }
                ?>
            </ul>
        </section>
    </main>
</body>
</html>