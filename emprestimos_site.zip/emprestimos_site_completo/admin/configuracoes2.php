<?php
require_once '../config/conexao.php';
session_start();

if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

if (isset($_POST['salvar'])) {
    $taxa = $_POST['taxa'];
    $stmt = $conn->prepare("UPDATE configuracoes SET taxa_juros = ?");
    $stmt->execute([$taxa]);
}

$config = $conn->query("SELECT taxa_juros FROM configuracoes")->fetch(PDO::FETCH_ASSOC);

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<main>
    <h2>Configurações de Taxas</h2>
    <form method="POST">
        <label>Taxa de Juros (%):</label>
        <input type="number" name="taxa" value="<?php echo $config['taxa_juros']; ?>" required>
        <button type="submit" name="salvar">Salvar</button>
    </form>
</main>