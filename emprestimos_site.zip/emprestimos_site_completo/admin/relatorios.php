<?php
session_start();
require_once '../config/conexao.php';

// Verifica se o usuário é admin
if ($_SESSION['user_tipo'] !== 'admin') {
    header("Location: index.php");
    exit;
}

// Relatório de Empréstimos
$stmt = $conn->query("SELECT COUNT(*) AS total_emprestimos, SUM(valor) AS total_solicitado FROM emprestimos WHERE status = 'aprovado'");
$relatorio_emprestimos = $stmt->fetch(PDO::FETCH_ASSOC);

?>

<h2>Relatórios Avançados</h2>
<h3>Empréstimos Aprovados</h3>
<p>Total de Empréstimos: <?php echo $relatorio_emprestimos['total_emprestimos']; ?></p>
<p>Total Solicitado: R$ <?php echo number_format($relatorio_emprestimos['total_solicitado'], 2, ',', '.'); ?></p>