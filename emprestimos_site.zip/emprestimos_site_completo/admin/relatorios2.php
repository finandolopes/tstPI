<?php
require_once '../config/conexao.php';
session_start();

// Verificar se o usuário tem permissão
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Consultas para os relatórios
$acessos = $conn->query("SELECT * FROM estatisticas ORDER BY data DESC")->fetchAll(PDO::FETCH_ASSOC);
$clientes = $conn->query("SELECT * FROM usuarios ORDER BY data_cadastro DESC")->fetchAll(PDO::FETCH_ASSOC);

include 'includes/header.php';
include 'includes/sidebar.php';
?>

<main>
    <h2>Relatórios Avançados</h2>

    <h3>Últimos Acessos</h3>
    <table>
        <thead>
            <tr>
                <th>Data</th>
                <th>IP</th>
                <th>Página Visitada</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($acessos as $acesso): ?>
                <tr>
                    <td><?php echo htmlspecialchars($acesso['data']); ?></td>
                    <td><?php echo htmlspecialchars($acesso['ip']); ?></td>
                    <td><?php echo htmlspecialchars($acesso['pagina']); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <h3>Últimos Clientes</h3>
    <table>
        <thead>
            <tr>
                <th>Nome</th>
                <th>Email</th>
                <th>Data de Cadastro</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($clientes as $cliente): ?>
                <tr>
                    <td><?php echo htmlspecialchars($cliente['nome']); ?></td>
                    <td><?php echo htmlspecialchars($cliente['email']); ?></td>
                    <td><?php echo htmlspecialchars($cliente['data_cadastro']); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</main>

<?php include 'includes/footer.php'; ?>