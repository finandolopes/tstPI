<?php
require_once '../config/conexao.php'; // Conexão com o banco
session_start();

// Verificar se o usuário está autenticado
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Função para adicionar um novo slide
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'add') {
    if (isset($_FILES['slide']) && $_FILES['slide']['error'] == 0) {
        $arquivo = $_FILES['slide'];
        $nome_arquivo = uniqid() . '-' . $arquivo['name'];
        $diretorio_destino = '../uploads/slides/' . $nome_arquivo;

        // Mover o arquivo para o diretório de uploads
        if (move_uploaded_file($arquivo['tmp_name'], $diretorio_destino)) {
            // Inserir o caminho do slide no banco de dados
            $stmt = $conn->prepare("INSERT INTO slides (imagem) VALUES (?)");
            $stmt->execute([$diretorio_destino]);
            echo "<p>Slide adicionado com sucesso!</p>";
        } else {
            echo "<p>Erro ao carregar o slide!</p>";
        }
    }
}

// Função para excluir um slide
if ($_SERVER['REQUEST_METHOD'] == 'POST' && isset($_POST['action']) && $_POST['action'] == 'delete') {
    $id = $_POST['id'];
    
    // Buscar o caminho da imagem antes de deletá-la
    $stmt = $conn->prepare("SELECT imagem FROM slides WHERE id = ?");
    $stmt->execute([$id]);
    $slide = $stmt->fetch(PDO::FETCH_ASSOC);
    
    if ($slide) {
        // Deletar o arquivo de imagem
        unlink($slide['imagem']);
        
        // Excluir o slide do banco de dados
        $stmt = $conn->prepare("DELETE FROM slides WHERE id = ?");
        $stmt->execute([$id]);
        echo "<p>Slide excluído com sucesso!</p>";
    }
}

// Buscar todos os slides do banco de dados
$slides = $conn->query("SELECT * FROM slides ORDER BY id DESC")->fetchAll(PDO::FETCH_ASSOC);

// Incluir cabeçalho e barra lateral
include 'includes/header.php';
include 'includes/sidebar.php';
?>

<main>
    <h2>Gestão de Slides</h2>

    <!-- Formulário para adicionar um novo slide -->
    <form action="slides.php" method="POST" enctype="multipart/form-data">
        <label for="slide">Escolha o arquivo de slide</label>
        <input type="file" name="slide" required>
        <input type="hidden" name="action" value="add">
        <button type="submit">Adicionar Slide</button>
    </form>

    <h3>Lista de Slides</h3>
    <table>
        <thead>
            <tr>
                <th>Imagem</th>
                <th>Ações</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($slides as $slide): ?>
                <tr>
                    <td><img src="<?php echo htmlspecialchars($slide['imagem']); ?>" alt="Slide" width="200"></td>
                    <td>
                        <form action="slides.php" method="POST" style="display:inline;">
                            <input type="hidden" name="id" value="<?php echo $slide['id']; ?>">
                            <input type="hidden" name="action" value="delete">
                            <button type="submit" onclick="return confirm('Tem certeza que deseja excluir este slide?')">Excluir</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</main>

<?php include 'includes/footer.php'; ?>