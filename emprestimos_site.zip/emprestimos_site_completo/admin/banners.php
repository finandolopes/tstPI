<?php
session_start();
if (!isset($_SESSION['admin'])) {
    header("Location: login.php");
    exit();
}

require_once '../config/conexao.php';

// Adicionar novo banner
if (isset($_POST['add_banner'])) {
    $titulo = $_POST['titulo'];
    $descricao = $_POST['descricao'];
    $status = $_POST['status'];

    // Upload da imagem do banner
    if (isset($_FILES['imagem']) && $_FILES['imagem']['error'] == 0) {
        $image_name = uniqid() . "-" . $_FILES['imagem']['name'];
        move_uploaded_file($_FILES['imagem']['tmp_name'], "../uploads/banners/$image_name");
    } else {
        $image_name = ''; // Caso não haja imagem
    }

    $stmt = $conn->prepare("INSERT INTO banners (titulo, descricao, imagem, status) VALUES (?, ?, ?, ?)");
    $stmt->execute([$titulo, $descricao, $image_name, $status]);

    header("Location: banners.php");
    exit();
}

// Excluir banner
if (isset($_GET['delete'])) {
    $id = $_GET['delete'];
    // Excluir imagem do servidor
    $stmt = $conn->prepare("SELECT imagem FROM banners WHERE id = ?");
    $stmt->execute([$id]);
    $banner = $stmt->fetch(PDO::FETCH_ASSOC);
    if ($banner['imagem']) {
        unlink("../uploads/banners/" . $banner['imagem']);
    }

    // Excluir banner do banco de dados
    $stmt = $conn->prepare("DELETE FROM banners WHERE id = ?");
    $stmt->execute([$id]);

    header("Location: banners.php");
    exit();
}

// Atualizar status do banner
if (isset($_POST['update_status'])) {
    $id = $_POST['id'];
    $status = $_POST['status'];
    $stmt = $conn->prepare("UPDATE banners SET status = ? WHERE id = ?");
    $stmt->execute([$status, $id]);

    header("Location: banners.php");
    exit();
}

// Buscar banners
$query = "SELECT * FROM banners";
$banners = $conn->query($query)->fetchAll(PDO::FETCH_ASSOC);
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gerenciamento de Banners</title>
    <link rel="stylesheet" href="../assets/css/admin.css">
</head>
<body>
    <header>
        <h1>Gerenciamento de Banners</h1>
        <nav>
            <ul>
                <li><a href="index.php">Início</a></li>
                <li><a href="solicitacoes.php">Solicitações</a></li>
                <li><a href="requisicoes.php">Requisições</a></li>
                <li><a href="depoimentos.php">Depoimentos</a></li>
                <li><a href="estatisticas.php">Estatísticas</a></li>
                <li><a href="logout.php">Sair</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <section>
            <h2>Cadastrar Novo Banner</h2>
            <form action="banners.php" method="POST" enctype="multipart/form-data">
                <input type="text" name="titulo" placeholder="Título do Banner" required>
                <textarea name="descricao" placeholder="Descrição do Banner" required></textarea>
                <input type="file" name="imagem" required>
                <select name="status">
                    <option value="Ativo">Ativo</option>
                    <option value="Inativo">Inativo</option>
                </select>
                <button type="submit" name="add_banner">Adicionar Banner</button>
            </form>
        </section>

        <section>
            <h2>Lista de Banners</h2>
            <table>
                <thead>
                    <tr>
                        <th>Título</th>
                        <th>Imagem</th>
                        <th>Status</th>
                        <th>Ações</th>
                    </tr>
                </thead>
                <tbody>
                    <?php foreach ($banners as $banner): ?>
                        <tr>
                            <td><?= htmlspecialchars($banner['titulo']) ?></td>
                            <td><img src="../uploads/banners/<?= htmlspecialchars($banner['imagem']) ?>" alt="Banner" width="100"></td>
                            <td><?= htmlspecialchars($banner['status']) ?></td>
                            <td>
                                <form action="banners.php" method="POST">
                                    <input type="hidden" name="id" value="<?= $banner['id'] ?>">
                                    <select name="status" onchange="this.form.submit()">
                                        <option value="Ativo" <?= $banner['status'] == 'Ativo' ? 'selected' : '' ?>>Ativo</option>
                                        <option value="Inativo" <?= $banner['status'] == 'Inativo' ? 'selected' : '' ?>>Inativo</option>
                                    </select>
                                    <button type="submit" name="update_status">Atualizar Status</button>
                                </form>
                                <a href="banners.php?delete=<?= $banner['id'] ?>" onclick="return confirm('Tem certeza que deseja excluir este banner?')">Excluir</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                </tbody>
            </table>
        </section>
    </main>
</body>
</html>