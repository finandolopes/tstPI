<?php
require_once '../config/conexao.php';
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Listando depoimentos
$stmt = $conn->prepare("SELECT * FROM depoimentos");
$stmt->execute();
$depoimentos = $stmt->fetchAll(PDO::FETCH_ASSOC);

// Aprovar ou rejeitar depoimento
if (isset($_GET['acao']) && isset($_GET['id'])) {
    $acao = $_GET['acao'];
    $id = $_GET['id'];
    $status = ($acao == 'aprovar') ? 'Aprovado' : 'Rejeitado';
    
    $stmt = $conn->prepare("UPDATE depoimentos SET status = :status WHERE id = :id");
    $stmt->bindParam(':status', $status);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    
    header("Location: depoimentos.php");
}
?>

<h2>Moderação de Depoimentos</h2>

<table>
    <thead>
        <tr>
            <th>Nome</th>
            <th>Mensagem</th>
            <th>Status</th>
            <th>Ações</th>
        </tr>
    </thead>
    <tbody>
        <?php foreach ($depoimentos as $depoimento): ?>
        <tr>
            <td><?php echo $depoimento['nome']; ?></td>
            <td><?php echo $depoimento['mensagem']; ?></td>
            <td><?php echo $depoimento['status']; ?></td>
            <td>
                <?php if ($depoimento['status'] == 'Pendente'): ?>
                    <a href="?acao=aprovar&id=<?php echo $depoimento['id']; ?>">Aprovar</a> | 
                    <a href="?acao=rejeitar&id=<?php echo $depoimento['id']; ?>">Rejeitar</a>
                <?php else: ?>
                    -
                <?php endif; ?>
            </td>
        </tr>
        <?php endforeach; ?>
    </tbody>
</table>