<?php
require_once '../config/conexao.php';

// Verifica se o usuário tem permissão de administrador
session_start();
if ($_SESSION['role'] !== 'admin') {
    header("Location: login.php");
    exit;
}

// Buscar todas as perguntas e respostas cadastradas
$query_faq = "SELECT * FROM faq";
$faq_items = $conn->query($query_faq)->fetchAll(PDO::FETCH_ASSOC);

// Adicionar nova pergunta
if (isset($_POST['add_faq'])) {
    $pergunta = $_POST['pergunta'];
    $resposta = $_POST['resposta'];
    
    $insert_query = "INSERT INTO faq (pergunta, resposta) VALUES (:pergunta, :resposta)";
    $stmt = $conn->prepare($insert_query);
    $stmt->bindParam(':pergunta', $pergunta);
    $stmt->bindParam(':resposta', $resposta);
    $stmt->execute();
    
    header('Location: faq.php');
}

// Excluir pergunta
if (isset($_GET['excluir'])) {
    $id = $_GET['excluir'];
    $delete_query = "DELETE FROM faq WHERE id = :id";
    $stmt = $conn->prepare($delete_query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    header('Location: faq.php');
}

// Editar pergunta
if (isset($_GET['editar'])) {
    $id = $_GET['editar'];
    $faq_query = "SELECT * FROM faq WHERE id = :id";
    $stmt = $conn->prepare($faq_query);
    $stmt->bindParam(':id', $id);
    $stmt->execute();
    $faq_item = $stmt->fetch(PDO::FETCH_ASSOC);
}
?>

<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Gestão de FAQ</title>
    <link rel="stylesheet" href="../assets/css/style.css">
</head>
<body>
    <header>
        <div class="logo">
            <h1>Painel Administrativo</h1>
        </div>
        <nav>
            <ul>
                <li><a href="index.php">Dashboard</a></li>
                <li><a href="depoimentos.php">Depoimentos</a></li>
                <li><a href="contato.php">Mensagens</a></li>
                <li><a href="faq.php">FAQ</a></li>
                <li><a href="analise_credito.php">Análise de Crédito</a></li>
                <li><a href="usuarios.php">Usuários</a></li>
                <li><a href="relatorios.php">Relatórios</a></li>
            </ul>
        </nav>
    </header>

    <main>
        <h2>Gestão de FAQ</h2>

        <!-- Formulário de Adicionar/Editar FAQ -->
        <form action="faq.php" method="POST">
            <label for="pergunta">Pergunta:</label>
            <input type="text" name="pergunta" id="pergunta" required value="<?php echo isset($faq_item) ? $faq_item['pergunta'] : ''; ?>" />
            <br>
            <label for="resposta">Resposta:</label>
            <textarea name="resposta" id="resposta" required><?php echo isset($faq_item) ? $faq_item['resposta'] : ''; ?></textarea>
            <br>
            <button type="submit" name="add_faq">Salvar</button>
        </form>

        <h3>Perguntas Frequentes</h3>
        <table>
            <thead>
                <tr>
                    <th>Pergunta</th>
                    <th>Resposta</th>
                    <th>Ações</th>
                </tr>
            </thead>
            <tbody>
                <?php foreach ($faq_items as $item): ?>
                    <tr>
                        <td><?php echo $item['pergunta']; ?></td>
                        <td><?php echo $item['resposta']; ?></td>
                        <td>
                            <a href="faq.php?editar=<?php echo $item['id']; ?>">Editar</a> | 
                            <a href="faq.php?excluir=<?php echo $item['id']; ?>" onclick="return confirm('Tem certeza que deseja excluir?')">Excluir</a>
                        </td>
                    </tr>
                <?php endforeach; ?>
            </tbody>
        </table>
    </main>

</body>
</html>