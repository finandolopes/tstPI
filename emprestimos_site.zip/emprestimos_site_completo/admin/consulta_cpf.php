<?php
function validarCPF($cpf) {
    $cpf = preg_replace('/[^0-9]/', '', $cpf);
    if (strlen($cpf) !== 11) {
        return false;
    }
    
    // Algoritmo de validação do CPF
    for ($t = 9; $t < 11; $t++) {
        for ($d = 0, $c = 0; $c < $t; $c++) {
            $d += $cpf[$c] * (($t + 1) - $c);
        }
        $d = ((10 * $d) % 11) % 10;
        if ($cpf[$c] != $d) {
            return false;
        }
    }
    return true;
}

$cpf = $_GET['cpf'] ?? '';
if ($cpf && validarCPF($cpf)) {
    echo json_encode(["status" => "válido", "mensagem" => "CPF ativo na Receita Federal."]);
} else {
    echo json_encode(["status" => "inválido", "mensagem" => "CPF inválido ou inativo."]);
}
?>