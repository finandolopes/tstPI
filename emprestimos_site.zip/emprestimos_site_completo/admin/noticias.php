// Arquivo: /admin/noticias.php

<?php
    include 'includes/header.php'; 
    include 'includes/sidebar.php';
    
    $noticias = $conn->query("SELECT * FROM noticias ORDER BY data DESC")->fetchAll(PDO::FETCH_ASSOC);
?>

<h2>Notícias e Atualizações</h2>
<ul>
    <?php foreach ($noticias as $noticia): ?>
        <li>
            <h3><?php echo $noticia['titulo']; ?></h3>
            <p><?php echo substr($noticia['conteudo'], 0, 100); ?>...</p>
            <a href="noticia.php?id=<?php echo $noticia['id']; ?>">Leia mais</a>
        </li>
    <?php endforeach; ?>
</ul>