<?php
require_once 'config/conexao.php';
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $email = $_POST['email'];
    
    // Verifica se o e-mail existe
    $stmt = $conn->prepare("SELECT * FROM usuarios WHERE email = :email");
    $stmt->bindParam(':email', $email);
    $stmt->execute();
    
    if ($stmt->rowCount() > 0) {
        $usuario = $stmt->fetch(PDO::FETCH_ASSOC);
        // Envia o e-mail com o link para redefinir a senha
        $token = bin2hex(random_bytes(50));  // Gerando um token único
        $expiracao = date("Y-m-d H:i:s", strtotime("+1 hour"));
        
        // Armazena o token na tabela de recuperação
        $stmt = $conn->prepare("INSERT INTO recuperacao_senha (usuario_id, token, expiracao) VALUES (:usuario_id, :token, :expiracao)");
        $stmt->bindParam(':usuario_id', $usuario['id']);
        $stmt->bindParam(':token', $token);
        $stmt->bindParam(':expiracao', $expiracao);
        $stmt->execute();
        
        // Envia o e-mail
        $link = "http://seusite.com/redefinir_senha.php?token=$token";
        $mensagem = "Clique no link abaixo para redefinir sua senha: $link";
        mail($email, "Redefinir Senha", $mensagem);
        
        echo "Um e-mail foi enviado com as instruções para redefinir sua senha.";
    } else {
        echo "E-mail não encontrado.";
    }
}
?>

<form method="POST">
    <label for="email">Digite seu e-mail:</label>
    <input type="email" name="email" id="email" required>
    <button type="submit">Recuperar Senha</button>
</form>