<?php
// Simulação de parcelamento
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    $valor = $_POST['valor'];
    $parcelas = $_POST['parcelas'];
    $taxa_juros = 0.05; // 5% ao mês

    $prestacao = ($valor * $taxa_juros) / (1 - pow(1 + $taxa_juros, -$parcelas));
    $total = $prestacao * $parcelas;
}
?>

<form method="POST" action="simulacao.php">
    <label for="valor">Valor do Empréstimo:</label>
    <input type="number" name="valor" required>
    
    <label for="parcelas">Número de Parcelas:</label>
    <input type="number" name="parcelas" required>
    
    <button type="submit">Simular</button>
</form>

<?php if (isset($total)): ?>
    <h3>Simulação de Empréstimo</h3>
    <p>Valor Total a Pagar: R$ <?php echo number_format($total, 2, ',', '.'); ?></p>
    <p>Valor da Parcela: R$ <?php echo number_format($prestacao, 2, ',', '.'); ?></p>
<?php endif; ?>