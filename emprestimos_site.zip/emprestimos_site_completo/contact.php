<?php
if ($_SERVER['REQUEST_METHOD'] == 'POST') {
    // Conectar ao banco de dados
    require_once 'config/conexao.php';

    // Captura os dados do formulário
    $nome = $_POST['nome'];
    $email = $_POST['email'];
    $assunto = $_POST['assunto'];
    $mensagem = $_POST['mensagem'];

    // Inserir os dados na tabela de contatos
    $stmt = $conn->prepare("INSERT INTO contato (nome, email, assunto, mensagem) VALUES (?, ?, ?, ?)");
    $stmt->execute([$nome, $email, $assunto, $mensagem]);

    // Exibir mensagem de sucesso
    echo "<p>Mensagem enviada com sucesso! Em breve entraremos em contato.</p>";
}
?>

<form action="contact.php" method="POST">
    <label for="nome">Nome</label>
    <input type="text" id="nome" name="nome" required>

    <label for="email">Email</label>
    <input type="email" id="email" name="email" required>

    <label for="assunto">Assunto</label>
    <input type="text" id="assunto" name="assunto" required>

    <label for="mensagem">Mensagem</label>
    <textarea id="mensagem" name="mensagem" rows="5" required></textarea>

    <button type="submit">Enviar</button>
</form>