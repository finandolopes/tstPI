function initMap() {
    // Coordenadas da empresa CONFINTER
    var localizacao = { lat: -23.528829, lng: -46.345672 };

    // Criar o mapa dentro do elemento <div id="map">
    var map = new google.maps.Map(document.getElementById("map"), {
        zoom: 16, // Ajuste do zoom para uma boa visualização
        center: localizacao,
    });

    // Adiciona um marcador no mapa
    var marcador = new google.maps.Marker({
        position: localizacao,
        map: map,
        title: "CONFINTER - Rua Maria La Regina, 302 - Poá/SP",
    });

    // Botão para abrir rotas no Google Maps
    document.getElementById("rota").addEventListener("click", function () {
        window.open(`https://www.google.com/maps/dir/?api=1&destination=${localizacao.lat},${localizacao.lng}`, "_blank");
    });
}