CREATE DATABASE emprestimos;
USE emprestimos;

-- Tabela de usuários (Controle de usuários, autenticação, permissões)
CREATE TABLE usuarios (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL UNIQUE,
    senha VARCHAR(255) NOT NULL,
    tipo ENUM('admin', 'usuario') NOT NULL DEFAULT 'usuario',
    status ENUM('ativo', 'bloqueado') NOT NULL DEFAULT 'ativo', -- Novo campo de status
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de empréstimos
CREATE TABLE emprestimos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    parcelas INT NOT NULL,
    juros DECIMAL(5,2) DEFAULT 0, -- Adicionando cálculo de juros
    status ENUM('pendente', 'aprovado', 'recusado') DEFAULT 'pendente',
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Tabela de depoimentos (Moderação de depoimentos)
CREATE TABLE depoimentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    mensagem TEXT NOT NULL,
    aprovado BOOLEAN DEFAULT FALSE,  -- Controle de moderação
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Tabela de banners (Slides)
CREATE TABLE banners (
    id INT AUTO_INCREMENT PRIMARY KEY,
    imagem VARCHAR(255) NOT NULL,
    ativo BOOLEAN DEFAULT TRUE,  -- Controle de visibilidade
    criado_em TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de slides (Gestão de slides)
CREATE TABLE slides (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(255) NOT NULL,
    descricao TEXT,
    imagem VARCHAR(255) NOT NULL,
    status ENUM('Ativo', 'Inativo') DEFAULT 'Ativo',  -- Controle de status de exibição
    data TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de solicitações de crédito (Análise de crédito)
CREATE TABLE solicitacoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    valor DECIMAL(10,2) NOT NULL,
    status ENUM('Pendente', 'Aprovado', 'Rejeitado') DEFAULT 'Pendente',
    data_solicitacao TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de contatos (Formulário de contato)
CREATE TABLE contatos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome VARCHAR(255) NOT NULL,
    email VARCHAR(255) NOT NULL,
    telefone VARCHAR(15) NOT NULL,
    mensagem TEXT NOT NULL,
    data TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de acessos (Monitoramento de acessos ao site)
CREATE TABLE acessos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    ip VARCHAR(255) NOT NULL,
    data_acesso TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de logs (Auditoria e ações de sistema)
CREATE TABLE logs (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL, -- Referência ao usuário que fez a ação
    acao VARCHAR(255) NOT NULL,  -- Descrição da ação realizada
    data TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Tabela de FAQ (Perguntas frequentes)
CREATE TABLE faq (
    id INT AUTO_INCREMENT PRIMARY KEY,
    pergunta VARCHAR(255) NOT NULL,
    resposta TEXT NOT NULL
);

-- Tabela de notícias (Notícias e atualizações)
CREATE TABLE noticias (
    id INT AUTO_INCREMENT PRIMARY KEY,
    titulo VARCHAR(255) NOT NULL,
    conteudo TEXT NOT NULL,
    data DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de agendamentos (Agendamentos de clientes)
CREATE TABLE agendamentos (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome_cliente VARCHAR(100),
    telefone VARCHAR(20),
    data_agendamento DATETIME,
    status ENUM('pendente', 'realizado') DEFAULT 'pendente'
);

-- Tabela de backups (Backup automático dos dados do sistema)
CREATE TABLE backups (
    id INT AUTO_INCREMENT PRIMARY KEY,
    nome_arquivo VARCHAR(255) NOT NULL,
    data_backup TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Tabela de notificações (Notificações e alertas para o sistema)
CREATE TABLE notificacoes (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,  -- Relacionado ao usuário
    mensagem TEXT NOT NULL,
    lido BOOLEAN DEFAULT FALSE,  -- Indica se a notificação foi lida
    data TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);

-- Tabela de autenticação em 2 fatores
CREATE TABLE autenticacao_2f (
    id INT AUTO_INCREMENT PRIMARY KEY,
    usuario_id INT NOT NULL,
    codigo_2f VARCHAR(6) NOT NULL,
    data_envio TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    validado BOOLEAN DEFAULT FALSE,
    FOREIGN KEY (usuario_id) REFERENCES usuarios(id)
);