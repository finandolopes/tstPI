
(function() {
    function createAccessibilityMenu() {
        const button = document.createElement('button');
        button.innerHTML = '<i class="fas fa-universal-access fa-2x"></i>';
        button.className = 'accessibility-toggle btn btn-primary';
        button.setAttribute('aria-label', 'Menu de Acessibilidade');
        button.title = 'Menu de Acessibilidade';
        document.body.appendChild(button);

        const menu = document.createElement('div');
        menu.className = 'accessibility-menu hidden';
        menu.id = 'accessibilityMenu';
        menu.innerHTML = `
            <div class="card bg-dark text-light p-3">
                <div class="button-container row">
                    <button class="btn btn-outline-light m-2 col" onclick="toggleHighContrast()"><i class="fas fa-adjust"></i> Alto Contraste</button>
                    <button class="btn btn-outline-light m-2 col" onclick="toggleDarkMode()"><i class="fas fa-moon"></i> Modo Escuro</button>
                    <button class="btn btn-outline-light m-2 col" onclick="increaseFont()"><i class="fas fa-search-plus"></i> Aumentar Fonte</button>
                    <button class="btn btn-outline-light m-2 col" onclick="decreaseFont()"><i class="fas fa-search-minus"></i> Diminuir Fonte</button>
                     <button class="btn btn-outline-light m-2 col" onclick="toggleColorBlindMode()"><i class="fas fa-palette"></i> Daltonismo</button>
                    <button class="btn btn-outline-light m-2 col" onclick="toggleSaturation()"><i class="fas fa-tint"></i> Saturação</button>
                    <button class="btn btn-outline-light m-2 col" onclick="toggleTextSpacing()"><i class="fas fa-arrows-alt-v"></i> Espaçamento de Texto</button>
                    <button class="btn btn-outline-light m-2 col" onclick="toggleReadingMode()"><i class="fas fa-book"></i> Modo de Leitura</button>
                    <button class="btn btn-outline-light m-2 col" onclick="toggleReadingMask()"><i class="fas fa-mask"></i> Máscara de Leitura</button>
                    <button class="btn btn-outline-light m-2 col" onclick="toggleTextToSpeech()"><i class="fas fa-volume-up"></i> Leitura de Textos</button>
                    <button class="btn btn-outline-light m-2 col" onclick="resetSettings()"><i class="fas fa-undo"></i> Resetar</button>
<button class="btn btn-outline-light m-2 col" onclick="showHelp()"><i class="fas fa-question-circle"></i> Ajuda</button>
                </div>
            </div>
        `;
        document.body.appendChild(menu);

        button.onclick = () => {
            menu.classList.toggle('hidden');
            if (!menu.classList.contains('hidden')) {
                Swal.fire({ icon: 'success', title: 'Menu Ativo', text: 'Menu de acessibilidade ativado.', timer: 1500, showConfirmButton: false });
            } else {
                Swal.fire({ icon: 'info', title: 'Menu Inativo', text: 'Menu de acessibilidade desativado.', timer: 1500, showConfirmButton: false });
            }
        };
    }
// Daltonismo
    let daltonismIndex = 0;
    window.toggleColorBlindMode = function() {
        const modes = ['protanopia', 'deuteranopia', 'tritanopia'];
        document.body.classList.remove(...modes);
        daltonismIndex = (daltonismIndex + 1) % modes.length;
        document.body.classList.add(modes[daltonismIndex]);
        Swal.fire('Daltonismo', `Modo ${modes[daltonismIndex]} ativado.`, 'info');
    }

    // Leitura de Textos
    let speechRate = 1;
    window.toggleTextToSpeech = function() {
        const rates = [1, 1.5, 0.75];
        const labels = ['Normal', 'Rápido', 'Lento'];
        speechRate = (speechRate + 1) % rates.length;
        const speech = new SpeechSynthesisUtterance(document.body.innerText);
        speech.rate = rates[speechRate];
        window.speechSynthesis.speak(speech);
        Swal.fire('Leitura de Textos', `Velocidade de leitura: ${labels[speechRate]}`, 'info');
    }

    // Saturação
    let saturationLevel = 0;
    window.toggleSaturation = function() {
        const levels = ['saturate(1)', 'saturate(0.5)', 'saturate(2)'];
        saturationLevel = (saturationLevel + 1) % levels.length;
        document.body.style.filter = levels[saturationLevel];
        Swal.fire('Saturação', `Nível de saturação: ${saturationLevel + 1}`, 'info');
    }

    // Espaçamento de Texto
    let spacingEnabled = false;
    window.toggleTextSpacing = function() {
        document.body.style.lineHeight = spacingEnabled ? 'normal' : '2';
        spacingEnabled = !spacingEnabled;
        Swal.fire('Espaçamento de Texto', spacingEnabled ? 'Espaçamento aumentado.' : 'Espaçamento normal.', 'info');
    }

    // Modo de Leitura
    window.toggleReadingMode = function() {
        document.querySelectorAll('img').forEach(img => img.style.display = 'none');
        document.body.style.backgroundColor = 'white';
        document.body.style.color = 'black';
        Swal.fire('Modo de Leitura', 'Imagens removidas. Apenas texto exibido.', 'info');
    }

    // Máscara de Leitura
    let maskSize = 0;
    window.toggleReadingMask = function() {
        const sizes = ['small', 'medium', 'large'];
        maskSize = (maskSize + 1) % sizes.length;
        document.body.classList.toggle(sizes[maskSize]);
        Swal.fire('Máscara de Leitura', `Tamanho da máscara: ${sizes[maskSize]}`, 'info');
    }

    window.toggleHighContrast = function() {
        document.body.classList.toggle('high-contrast');
        Swal.fire('Alto Contraste', 'Modo de alto contraste ativado/desativado.', 'info');
    }

    window.toggleDarkMode = function() {
        document.body.classList.toggle('dark-mode');
        Swal.fire('Modo Escuro', 'Modo escuro ativado/desativado.', 'info');
    }

    window.increaseFont = function() {
        document.querySelectorAll('*').forEach(function(el) {
            let currentSize = window.getComputedStyle(el).fontSize;
            let newSize = (parseFloat(currentSize) * 1.1) + 'px';
            el.style.fontSize = newSize;
        });
        Swal.fire('Fonte Aumentada', 'O tamanho da fonte foi aumentado.', 'info');
    }

    window.decreaseFont = function() {
        document.querySelectorAll('*').forEach(function(el) {
            let currentSize = window.getComputedStyle(el).fontSize;
            let newSize = (parseFloat(currentSize) * 0.9) + 'px';
            el.style.fontSize = newSize;
        });
        Swal.fire('Fonte Diminuída', 'O tamanho da fonte foi diminuído.', 'info');
    }

    window.resetSettings = function() {
        document.body.classList.remove('high-contrast', 'dark-mode');
        document.body.style.fontSize = '';
        Swal.fire('Resetar', 'Configurações de acessibilidade resetadas.', 'info');
    }

    window.toggleColorBlindMode = function() {
        Swal.fire('Daltonismo', 'Modo de daltonismo ativado/desativado.', 'info');
    }

    window.toggleTextToSpeech = function() {
        document.body.addEventListener('click', function(event) {
            let text = event.target.innerText || event.target.alt || '';
            if (text) {
                let speech = new SpeechSynthesisUtterance(text);
                window.speechSynthesis.speak(speech);
            }
        });
    }

    window.showHelp = function() {
        Swal.fire({
            title: 'Ajuda',
            html: `
                <p><strong>Alto Contraste (Alt+1):</strong> Ativa/desativa o modo de alto contraste.</p>
                <p><strong>Modo Escuro (Alt+2):</strong> Ativa/desativa o modo escuro.</p>
                <p><strong>Aumentar Fonte (Alt+3):</strong> Aumenta o tamanho da fonte.</p>
                <p><strong>Diminuir Fonte (Alt+4):</strong> Diminui o tamanho da fonte.</p>
                <p><strong>Resetar (Alt+5):</strong> Reseta as configurações de acessibilidade.</p>
                <p><strong>Daltonismo (Alt+R):</strong> Ativa/desativa o modo de daltonismo.</p>
                <p><strong>Leitura de Textos (Alt+T):</strong> Ativa/desativa a leitura de textos.</p>
            `,
            icon: 'info'
        });
    }

    document.addEventListener('keydown', function(event) {
        if (event.altKey) {
            switch (event.key) {
                case '1':
                    toggleHighContrast();
                    break;
                case '2':
                    toggleDarkMode();
                    break;
                case '3':
                    increaseFont();
                    break;
                case '4':
                    decreaseFont();
                    break;
                case '5':
                    resetSettings();
                    break;
                case 'r':
                    toggleColorBlindMode();
                    break;
                case 't':
                    toggleTextToSpeech();
                    break;
            }
        }
    });

    const style = document.createElement('style');
    style.innerHTML = `
        .accessibility-toggle {
            background-color: #007bff;
            border: none;
            color: white;
            padding: 10px;
            cursor: pointer;
            position: fixed;
            top: 50%;
            right: 0;
            transform: translateY(-50%);
            border-radius: 5px 0 0 5px;
            z-index: 1001;
        }
       .accessibility-menu {
            position: fixed;
            top: 50%;
            right: 0;
            transform: translateY(-50%);
            background-color: #333;
            color: white;
            padding: 10px;
            border-radius: 5px 0 0 5px;
            z-index: 1000;
        }
        .hidden {
            display: none;
        }
        .btn-outline-light:hover {
            background-color: #555;
        }
    `;
    document.head.appendChild(style);

    document.addEventListener('DOMContentLoaded', createAccessibilityMenu);
})();
